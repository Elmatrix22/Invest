import { 
  Signal, 
  Users, 
  Newspaper, 
  BookOpen, 
  User,
  Brain,
  TrendingUp,
  MessageSquare,
  BarChart3,
  GraduationCap,
  Crown,
  Zap,
  Globe,
  Award
} from 'lucide-react';

export interface ServiceTab {
  value: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  status?: 'free' | 'top' | 'live' | 'weekly' | 'locked';
  requiresAuth?: boolean;
  badge?: string;
}

export const createServiceTabsConfig = (t: any, marketData: any, user: any): ServiceTab[] => [
  {
    value: 'signals',
    title: t.navSignals || 'AI Signals',
    description: t.liveSignalsSubtitle || 'Real-time • AI Powered',
    icon: <Brain />,
    status: 'live',
    badge: `${marketData?.prices ? Object.keys(marketData.prices).length : 247}+ Live`
  },
  {
    value: 'community',
    title: t.navCommunity || 'Business Learning',
    description: t.communityTitle || 'Investment Community',
    icon: <GraduationCap />,
    status: 'top',
    badge: '125k+ Members'
  },
  {
    value: 'news',
    title: t.navNews || 'Market News',
    description: t.newsTitle || 'Latest Market News',
    icon: <Newspaper />,
    status: 'live',
    badge: 'Breaking News'
  },
  {
    value: 'blog',
    title: t.navBlog || 'Education',
    description: t.blogTitle || 'Trading Education',
    icon: <BookOpen />,
    status: 'weekly',
    badge: 'Updated Weekly'
  },
  {
    value: 'profile',
    title: t.navProfile || 'Profile',
    description: user ? 'Premium Member' : 'Join Free',
    icon: user ? <Crown /> : <User />,
    status: user ? 'free' : 'locked',
    requiresAuth: !user,
    badge: user ? 'Premium' : 'Login Required'
  }
];

export const renderServiceTab = (tab: ServiceTab, activeTab: string, marketData: any) => {
  const isActive = activeTab === tab.value;
  
  return (
    <div className="service-tab-card">
      {/* Status Badge */}
      <div className={`service-tab-status status-${tab.status}`}>
        {tab.badge}
      </div>

      {/* Icon */}
      <div className="service-tab-icon-wrapper">
        <div className="service-tab-icon">
          {tab.icon}
        </div>
      </div>

      {/* Content */}
      <div className="service-tab-info">
        <div className="service-tab-title">
          {tab.title}
        </div>
        <div className="service-tab-description">
          {tab.description}
        </div>
      </div>
    </div>
  );
};