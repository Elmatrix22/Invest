-- Automated SEO Backend Schema for Invest-Free.com
-- This schema supports automated content generation, link building, social media, and SEO optimization

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_cron";

-- 1. CONTENT MANAGEMENT SYSTEM
CREATE TABLE blog_posts (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  slug VARCHAR(255) UNIQUE NOT NULL,
  content TEXT NOT NULL,
  excerpt TEXT,
  featured_image_url TEXT,
  meta_title VARCHAR(60),
  meta_description VARCHAR(160),
  keywords TEXT[], -- Array of target keywords
  category VARCHAR(100),
  tags TEXT[],
  author_id UUID REFERENCES auth.users(id),
  status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'scheduled', 'published', 'archived')),
  scheduled_publish_at TIMESTAMPTZ,
  published_at TIMESTAMPTZ,
  view_count INTEGER DEFAULT 0,
  like_count INTEGER DEFAULT 0,
  share_count INTEGER DEFAULT 0,
  seo_score INTEGER DEFAULT 0,
  reading_time_minutes INTEGER,
  language VARCHAR(5) DEFAULT 'en',
  ai_generated BOOLEAN DEFAULT false,
  content_source VARCHAR(50), -- 'ai', 'manual', 'scrape', 'guest'
  target_keywords JSONB, -- Detailed keyword targeting data
  backlink_count INTEGER DEFAULT 0,
  internal_link_count INTEGER DEFAULT 0,
  external_link_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. SEO KEYWORD MANAGEMENT
CREATE TABLE seo_keywords (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  keyword VARCHAR(255) NOT NULL,
  search_volume INTEGER,
  difficulty_score INTEGER CHECK (difficulty_score BETWEEN 0 AND 100),
  cpc DECIMAL(10,2),
  competition VARCHAR(20) CHECK (competition IN ('low', 'medium', 'high')),
  current_ranking INTEGER,
  target_ranking INTEGER DEFAULT 1,
  trend VARCHAR(20) CHECK (trend IN ('up', 'down', 'stable')),
  category VARCHAR(100),
  priority INTEGER DEFAULT 5 CHECK (priority BETWEEN 1 AND 10),
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'paused', 'achieved')),
  related_keywords TEXT[],
  content_gaps TEXT[],
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. AUTOMATED CONTENT GENERATION
CREATE TABLE content_templates (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(100),
  template_type VARCHAR(50) CHECK (template_type IN ('blog_post', 'social_post', 'email', 'guest_post')),
  content_structure JSONB, -- Template structure with placeholders
  target_keywords TEXT[],
  min_word_count INTEGER DEFAULT 500,
  max_word_count INTEGER DEFAULT 2000,
  tone VARCHAR(50) DEFAULT 'professional',
  target_audience VARCHAR(100),
  call_to_action TEXT,
  seo_requirements JSONB,
  is_active BOOLEAN DEFAULT true,
  usage_count INTEGER DEFAULT 0,
  success_rate DECIMAL(5,2) DEFAULT 0.0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. LINK BUILDING MANAGEMENT
CREATE TABLE link_building_targets (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  domain VARCHAR(255) NOT NULL,
  domain_authority INTEGER CHECK (domain_authority BETWEEN 0 AND 100),
  spam_score INTEGER CHECK (spam_score BETWEEN 0 AND 100),
  contact_email VARCHAR(255),
  contact_name VARCHAR(255),
  niche VARCHAR(100),
  link_type VARCHAR(50) CHECK (link_type IN ('guest_post', 'resource_page', 'broken_link', 'mention', 'directory')),
  outreach_status VARCHAR(50) DEFAULT 'pending' CHECK (outreach_status IN ('pending', 'contacted', 'responded', 'negotiating', 'accepted', 'rejected', 'published')),
  pitch_template_id UUID REFERENCES content_templates(id),
  estimated_cost DECIMAL(10,2),
  priority INTEGER DEFAULT 5 CHECK (priority BETWEEN 1 AND 10),
  last_contact_date TIMESTAMPTZ,
  follow_up_date TIMESTAMPTZ,
  notes TEXT,
  success_rate DECIMAL(5,2) DEFAULT 0.0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. LINK BUILDING CAMPAIGNS
CREATE TABLE link_building_campaigns (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  target_id UUID REFERENCES link_building_targets(id),
  blog_post_id UUID REFERENCES blog_posts(id),
  campaign_type VARCHAR(50),
  subject_line VARCHAR(255),
  email_content TEXT,
  sent_at TIMESTAMPTZ,
  opened_at TIMESTAMPTZ,
  replied_at TIMESTAMPTZ,
  link_acquired_at TIMESTAMPTZ,
  link_url TEXT,
  anchor_text VARCHAR(255),
  link_status VARCHAR(20) CHECK (link_status IN ('pending', 'live', 'removed', 'nofollow')),
  follow_up_count INTEGER DEFAULT 0,
  cost DECIMAL(10,2),
  roi_score DECIMAL(5,2),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. SOCIAL MEDIA AUTOMATION
CREATE TABLE social_media_accounts (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  platform VARCHAR(50) NOT NULL CHECK (platform IN ('twitter', 'linkedin', 'facebook', 'instagram', 'tiktok', 'youtube')),
  account_handle VARCHAR(255),
  account_id VARCHAR(255),
  access_token TEXT,
  refresh_token TEXT,
  token_expires_at TIMESTAMPTZ,
  followers_count INTEGER DEFAULT 0,
  following_count INTEGER DEFAULT 0,
  posts_count INTEGER DEFAULT 0,
  engagement_rate DECIMAL(5,2) DEFAULT 0.0,
  is_active BOOLEAN DEFAULT true,
  auto_post BOOLEAN DEFAULT true,
  posting_schedule JSONB, -- Schedule configuration
  hashtag_strategy JSONB,
  content_preferences JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. SOCIAL MEDIA CONTENT QUEUE
CREATE TABLE social_media_posts (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  account_id UUID REFERENCES social_media_accounts(id),
  blog_post_id UUID REFERENCES blog_posts(id) NULL,
  platform VARCHAR(50) NOT NULL,
  content_type VARCHAR(50) CHECK (content_type IN ('text', 'image', 'video', 'carousel', 'story')),
  content TEXT NOT NULL,
  media_urls TEXT[],
  hashtags TEXT[],
  mentions TEXT[],
  scheduled_for TIMESTAMPTZ,
  posted_at TIMESTAMPTZ,
  platform_post_id VARCHAR(255),
  status VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('draft', 'scheduled', 'posted', 'failed', 'deleted')),
  likes_count INTEGER DEFAULT 0,
  shares_count INTEGER DEFAULT 0,
  comments_count INTEGER DEFAULT 0,
  clicks_count INTEGER DEFAULT 0,
  impressions_count INTEGER DEFAULT 0,
  engagement_rate DECIMAL(5,2) DEFAULT 0.0,
  ai_generated BOOLEAN DEFAULT false,
  performance_score INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. USER GENERATED CONTENT
CREATE TABLE user_reviews (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  title VARCHAR(255),
  content TEXT,
  category VARCHAR(100),
  is_featured BOOLEAN DEFAULT false,
  is_approved BOOLEAN DEFAULT false,
  moderation_notes TEXT,
  helpful_votes INTEGER DEFAULT 0,
  not_helpful_votes INTEGER DEFAULT 0,
  platform_source VARCHAR(50), -- 'website', 'google', 'trustpilot', 'facebook'
  external_url TEXT,
  sentiment_score DECIMAL(3,2), -- -1 to 1
  keywords_mentioned TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. COMMUNITY ENGAGEMENT
CREATE TABLE community_posts (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  title VARCHAR(255),
  content TEXT,
  category VARCHAR(100),
  tags TEXT[],
  upvotes INTEGER DEFAULT 0,
  downvotes INTEGER DEFAULT 0,
  comments_count INTEGER DEFAULT 0,
  views_count INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT false,
  seo_value_score INTEGER DEFAULT 0,
  keywords_density JSONB,
  internal_links_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. SEO MONITORING & ANALYTICS
CREATE TABLE seo_rankings (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  keyword VARCHAR(255) NOT NULL,
  url TEXT NOT NULL,
  search_engine VARCHAR(20) DEFAULT 'google',
  position INTEGER,
  previous_position INTEGER,
  change_value INTEGER,
  search_volume INTEGER,
  traffic_estimate INTEGER,
  click_through_rate DECIMAL(5,2),
  country VARCHAR(5) DEFAULT 'US',
  device VARCHAR(20) DEFAULT 'desktop' CHECK (device IN ('desktop', 'mobile', 'tablet')),
  recorded_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. COMPETITOR ANALYSIS
CREATE TABLE competitor_analysis (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  competitor_domain VARCHAR(255) NOT NULL,
  keyword VARCHAR(255) NOT NULL,
  position INTEGER,
  estimated_traffic INTEGER,
  content_length INTEGER,
  backlinks_count INTEGER,
  domain_authority INTEGER,
  page_authority INTEGER,
  content_quality_score INTEGER,
  loading_speed_score INTEGER,
  mobile_friendly BOOLEAN,
  https_enabled BOOLEAN,
  structured_data_score INTEGER,
  social_signals_count INTEGER,
  content_gaps TEXT[],
  opportunities TEXT[],
  threats TEXT[],
  analyzed_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. AUTOMATION TASKS & JOBS
CREATE TABLE automation_jobs (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  job_type VARCHAR(100) NOT NULL,
  job_name VARCHAR(255),
  schedule_cron VARCHAR(100),
  parameters JSONB,
  last_run_at TIMESTAMPTZ,
  next_run_at TIMESTAMPTZ,
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'paused', 'failed', 'completed')),
  success_count INTEGER DEFAULT 0,
  failure_count INTEGER DEFAULT 0,
  last_error TEXT,
  execution_time_seconds INTEGER,
  priority INTEGER DEFAULT 5,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. AI CONTENT GENERATION LOG
CREATE TABLE ai_content_log (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  content_type VARCHAR(50),
  prompt_used TEXT,
  ai_model VARCHAR(100),
  input_tokens INTEGER,
  output_tokens INTEGER,
  cost DECIMAL(10,4),
  quality_score INTEGER CHECK (quality_score BETWEEN 1 AND 10),
  content_id UUID, -- Reference to generated content
  generation_time_seconds DECIMAL(5,2),
  success BOOLEAN DEFAULT true,
  error_message TEXT,
  keywords_targeted TEXT[],
  readability_score INTEGER,
  uniqueness_percentage DECIMAL(5,2),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. PERFORMANCE METRICS
CREATE TABLE seo_performance_metrics (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  metric_date DATE NOT NULL,
  organic_traffic INTEGER DEFAULT 0,
  keyword_rankings_improved INTEGER DEFAULT 0,
  keyword_rankings_declined INTEGER DEFAULT 0,
  backlinks_acquired INTEGER DEFAULT 0,
  backlinks_lost INTEGER DEFAULT 0,
  content_pieces_published INTEGER DEFAULT 0,
  social_media_engagement INTEGER DEFAULT 0,
  conversion_rate DECIMAL(5,2) DEFAULT 0.0,
  bounce_rate DECIMAL(5,2) DEFAULT 0.0,
  avg_session_duration INTEGER DEFAULT 0,
  domain_authority INTEGER DEFAULT 0,
  page_authority_avg INTEGER DEFAULT 0,
  core_web_vitals_score INTEGER DEFAULT 0,
  mobile_usability_score INTEGER DEFAULT 0,
  technical_seo_score INTEGER DEFAULT 0,
  roi DECIMAL(10,2) DEFAULT 0.0
);

-- INDEXES for performance
CREATE INDEX idx_blog_posts_status ON blog_posts(status);
CREATE INDEX idx_blog_posts_published_at ON blog_posts(published_at);
CREATE INDEX idx_blog_posts_keywords ON blog_posts USING gin(keywords);
CREATE INDEX idx_seo_keywords_ranking ON seo_keywords(current_ranking);
CREATE INDEX idx_seo_rankings_keyword ON seo_rankings(keyword);
CREATE INDEX idx_seo_rankings_recorded_at ON seo_rankings(recorded_at);
CREATE INDEX idx_social_media_posts_scheduled ON social_media_posts(scheduled_for);
CREATE INDEX idx_automation_jobs_next_run ON automation_jobs(next_run_at);

-- TRIGGERS for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_blog_posts_updated_at BEFORE UPDATE ON blog_posts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- RLS (Row Level Security) Policies
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE seo_keywords ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_posts ENABLE ROW LEVEL SECURITY;

-- Basic RLS policies (can be customized based on requirements)
CREATE POLICY "Public blog posts are viewable by everyone" ON blog_posts FOR SELECT USING (status = 'published');
CREATE POLICY "Users can view their own reviews" ON user_reviews FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage their own community posts" ON community_posts FOR ALL USING (auth.uid() = user_id);

-- Grant permissions
GRANT USAGE ON SCHEMA public TO authenticated, anon;
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;