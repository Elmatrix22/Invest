import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  Trophy, 
  Medal, 
  Target, 
  Users, 
  Clock, 
  TrendingUp,
  Gift,
  Crown,
  Star,
  Zap,
  DollarSign,
  Calendar,
  ExternalLink
} from 'lucide-react';

interface Competition {
  id: string;
  title: string;
  description: string;
  type: 'weekly' | 'monthly' | 'daily' | 'special';
  status: 'active' | 'upcoming' | 'ended';
  startDate: string;
  endDate: string;
  participants: number;
  maxParticipants?: number;
  prizePool: number;
  prizes: { position: string; reward: string; value: number }[];
  rules: string[];
  category: 'signals' | 'portfolio' | 'prediction' | 'referral';
}

interface Participant {
  rank: number;
  username: string;
  avatar: string;
  score: number;
  profit: number;
  accuracy: number;
  trades: number;
  isCurrentUser?: boolean;
}

interface TradingCompetitionsProps {
  translations: any;
  binanceReferralUrl: string;
}

export function TradingCompetitions({ translations, binanceReferralUrl }: TradingCompetitionsProps) {
  const [activeCompetitions, setActiveCompetitions] = useState<Competition[]>([
    {
      id: '1',
      title: 'Weekly Signal Master',
      description: 'Compete for the highest signal accuracy this week',
      type: 'weekly',
      status: 'active',
      startDate: '2025-01-13T00:00:00Z',
      endDate: '2025-01-20T00:00:00Z',
      participants: 1247,
      maxParticipants: 2000,
      prizePool: 5000,
      prizes: [
        { position: '1st', reward: 'Cash Prize', value: 2500 },
        { position: '2nd', reward: 'Trading Bonus', value: 1500 },
        { position: '3rd', reward: 'VIP Access', value: 1000 }
      ],
      rules: [
        'Must share at least 5 signals during the week',
        'Signals must have clear entry/exit points',
        'Accuracy calculated based on community feedback',
        'No manipulation or fake signals allowed'
      ],
      category: 'signals'
    },
    {
      id: '2',
      title: 'Million Dollar Portfolio Challenge',
      description: 'Start with $100k virtual money, see who can grow it the most',
      type: 'monthly',
      status: 'active',
      startDate: '2025-01-01T00:00:00Z',
      endDate: '2025-01-31T23:59:59Z',
      participants: 3456,
      prizePool: 10000,
      prizes: [
        { position: '1st', reward: 'Cash + Binance VIP', value: 5000 },
        { position: '2nd', reward: 'Trading Fund', value: 3000 },
        { position: '3rd', reward: 'Premium Tools', value: 2000 }
      ],
      rules: [
        'Start with $100,000 virtual portfolio',
        'Trade any crypto, forex, or binary options',
        'Must use Binance for at least 50% of trades',
        'Real-time tracking with verified results'
      ],
      category: 'portfolio'
    },
    {
      id: '3',
      title: 'Daily Prediction Arena',
      description: 'Predict BTC price movement for the next 24 hours',
      type: 'daily',
      status: 'active',
      startDate: '2025-01-15T00:00:00Z',
      endDate: '2025-01-16T00:00:00Z',
      participants: 892,
      prizePool: 1000,
      prizes: [
        { position: '1st', reward: 'Daily Winner', value: 500 },
        { position: '2nd-5th', reward: 'Bonus Credits', value: 100 },
        { position: '6th-20th', reward: 'VIP Features', value: 25 }
      ],
      rules: [
        'Predict BTC price direction and percentage',
        'Closest prediction wins',
        'One prediction per user per day',
        'Results verified against Binance prices'
      ],
      category: 'prediction'
    }
  ]);

  const [leaderboard, setLeaderboard] = useState<Participant[]>([
    { rank: 1, username: 'CryptoKing2025', avatar: 'CK', score: 2547, profit: 147.2, accuracy: 94, trades: 23, isCurrentUser: false },
    { rank: 2, username: 'SignalMaster', avatar: 'SM', score: 2341, profit: 132.8, accuracy: 87, trades: 31, isCurrentUser: false },
    { rank: 3, username: 'ProfitHunter', avatar: 'PH', score: 2198, profit: 119.5, accuracy: 91, trades: 19, isCurrentUser: false },
    { rank: 4, username: 'YouTrader', avatar: 'YT', score: 1876, profit: 98.3, accuracy: 78, trades: 17, isCurrentUser: true },
    { rank: 5, username: 'BullRunner', avatar: 'BR', score: 1654, profit: 87.1, accuracy: 83, trades: 28, isCurrentUser: false }
  ]);

  const [selectedCompetition, setSelectedCompetition] = useState(activeCompetitions[0]);
  const [timeRemaining, setTimeRemaining] = useState('');

  useEffect(() => {
    const updateTimeRemaining = () => {
      const now = new Date();
      const endDate = new Date(selectedCompetition.endDate);
      const diff = endDate.getTime() - now.getTime();
      
      if (diff <= 0) {
        setTimeRemaining('Competition Ended');
        return;
      }
      
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      
      setTimeRemaining(`${days}d ${hours}h ${minutes}m`);
    };

    updateTimeRemaining();
    const interval = setInterval(updateTimeRemaining, 60000);
    
    return () => clearInterval(interval);
  }, [selectedCompetition]);

  const handleJoinCompetition = (competitionId: string) => {
    // Simulate joining competition
    setActiveCompetitions(prev => prev.map(comp => 
      comp.id === competitionId 
        ? { ...comp, participants: comp.participants + 1 }
        : comp
    ));
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-old-money-sage text-old-money-cream';
      case 'upcoming': return 'bg-old-money-gold text-old-money-navy';
      case 'ended': return 'bg-old-money-warm-gray text-old-money-cream';
      default: return 'bg-old-money-navy text-old-money-cream';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'signals': return <Target className="w-4 h-4" />;
      case 'portfolio': return <TrendingUp className="w-4 h-4" />;
      case 'prediction': return <Zap className="w-4 h-4" />;
      case 'referral': return <Users className="w-4 h-4" />;
      default: return <Trophy className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-old-money-navy flex items-center gap-2">
            <Trophy className="w-6 h-6 text-old-money-gold" />
            Trading Competitions
          </h2>
          <p className="text-old-money-warm-gray">
            Compete with traders worldwide and win real prizes. Test your skills and climb the leaderboards!
          </p>
        </div>
        <Button
          onClick={handleBinanceClick}
          className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy font-medium"
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          Trade on Binance
        </Button>
      </div>

      {/* Competition Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-navy">3</div>
            <div className="text-sm text-old-money-warm-gray">Active Competitions</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-sage">5,595</div>
            <div className="text-sm text-old-money-warm-gray">Total Participants</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-gold">$16,000</div>
            <div className="text-sm text-old-money-warm-gray">Prize Pool</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-burgundy">4th</div>
            <div className="text-sm text-old-money-warm-gray">Your Best Rank</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-md bg-old-money-cream-dark border border-old-money-beige">
          <TabsTrigger value="active" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Active
          </TabsTrigger>
          <TabsTrigger value="leaderboard" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Leaderboard
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-6">
          {/* Featured Competition */}
          <Card className="border-old-money-gold bg-gradient-to-r from-old-money-gold/10 to-old-money-gold-light/10">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-old-money-gold rounded-full flex items-center justify-center">
                    <Crown className="w-6 h-6 text-old-money-navy" />
                  </div>
                  <div>
                    <CardTitle className="text-old-money-navy">{selectedCompetition.title}</CardTitle>
                    <p className="text-old-money-warm-gray text-sm">{selectedCompetition.description}</p>
                  </div>
                </div>
                <Badge className={getStatusColor(selectedCompetition.status)}>
                  {selectedCompetition.status.toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center gap-2 text-sm text-old-money-warm-gray mb-1">
                      <Clock className="w-4 h-4" />
                      Time Remaining
                    </div>
                    <div className="font-bold text-old-money-navy">{timeRemaining}</div>
                  </div>
                  
                  <div>
                    <div className="flex items-center gap-2 text-sm text-old-money-warm-gray mb-1">
                      <Users className="w-4 h-4" />
                      Participants
                    </div>
                    <div className="font-bold text-old-money-navy">
                      {selectedCompetition.participants.toLocaleString()}
                      {selectedCompetition.maxParticipants && (
                        <span className="text-old-money-warm-gray"> / {selectedCompetition.maxParticipants.toLocaleString()}</span>
                      )}
                    </div>
                    {selectedCompetition.maxParticipants && (
                      <Progress 
                        value={(selectedCompetition.participants / selectedCompetition.maxParticipants) * 100} 
                        className="h-2 mt-1" 
                      />
                    )}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-sm text-old-money-warm-gray mb-2">
                    <Trophy className="w-4 h-4" />
                    Prize Pool: ${selectedCompetition.prizePool.toLocaleString()}
                  </div>
                  <div className="space-y-2">
                    {selectedCompetition.prizes.map((prize, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-white/50 rounded">
                        <div className="flex items-center gap-2">
                          {index === 0 && <Crown className="w-4 h-4 text-old-money-gold" />}
                          {index === 1 && <Medal className="w-4 h-4 text-old-money-warm-gray" />}
                          {index === 2 && <Medal className="w-4 h-4 text-old-money-burgundy" />}
                          <span className="text-sm font-medium text-old-money-navy">{prize.position}</span>
                        </div>
                        <div className="text-sm text-old-money-warm-gray">
                          ${prize.value.toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <Button
                    onClick={() => handleJoinCompetition(selectedCompetition.id)}
                    className="w-full bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy font-bold"
                  >
                    <Trophy className="w-4 h-4 mr-2" />
                    Join Competition
                  </Button>
                  
                  <div className="text-xs text-old-money-warm-gray">
                    <strong>Rules:</strong>
                    <ul className="mt-1 space-y-1">
                      {selectedCompetition.rules.slice(0, 2).map((rule, index) => (
                        <li key={index}>• {rule}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Other Active Competitions */}
          <div className="grid md:grid-cols-2 gap-6">
            {activeCompetitions.slice(1).map((competition) => (
              <Card key={competition.id} className="border-old-money-beige hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedCompetition(competition)}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getCategoryIcon(competition.category)}
                      <CardTitle className="text-lg text-old-money-navy">{competition.title}</CardTitle>
                    </div>
                    <Badge className={getStatusColor(competition.status)} variant="outline">
                      {competition.type}
                    </Badge>
                  </div>
                  <p className="text-old-money-warm-gray text-sm">{competition.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-sm text-old-money-warm-gray">Prize Pool</div>
                      <div className="font-bold text-old-money-gold">${competition.prizePool.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-sm text-old-money-warm-gray">Participants</div>
                      <div className="font-bold text-old-money-navy">{competition.participants.toLocaleString()}</div>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full mt-4 bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleJoinCompetition(competition.id);
                    }}
                  >
                    Join Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="leaderboard" className="space-y-6">
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <Medal className="w-5 h-5 text-old-money-gold" />
                Current Leaderboard - {selectedCompetition.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboard.map((participant) => (
                  <div 
                    key={participant.rank} 
                    className={`flex items-center justify-between p-4 rounded-lg border ${
                      participant.isCurrentUser 
                        ? 'bg-old-money-sage/10 border-old-money-sage' 
                        : 'bg-old-money-cream-dark border-old-money-beige'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        participant.rank === 1 ? 'bg-old-money-gold text-old-money-navy' :
                        participant.rank === 2 ? 'bg-old-money-warm-gray text-old-money-cream' :
                        participant.rank === 3 ? 'bg-old-money-burgundy text-old-money-cream' :
                        'bg-old-money-navy text-old-money-cream'
                      }`}>
                        {participant.rank}
                      </div>
                      
                      <Avatar className="w-10 h-10">
                        <AvatarFallback className="bg-old-money-sage-light text-old-money-navy">
                          {participant.avatar}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div>
                        <div className="font-medium text-old-money-navy flex items-center gap-2">
                          {participant.username}
                          {participant.isCurrentUser && <Badge className="bg-old-money-sage text-old-money-cream text-xs">You</Badge>}
                        </div>
                        <div className="text-sm text-old-money-warm-gray">
                          {participant.trades} trades • {participant.accuracy}% accuracy
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-bold text-old-money-navy">{participant.score.toLocaleString()} pts</div>
                      <div className="text-sm text-old-money-sage">+{participant.profit}%</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 bg-old-money-gold/10 rounded-lg border border-old-money-gold/30">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-old-money-navy">Want to climb higher?</h4>
                    <p className="text-sm text-old-money-warm-gray">
                      Start trading on Binance to boost your competition score
                    </p>
                  </div>
                  <Button
                    onClick={handleBinanceClick}
                    className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Trade Now
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="text-old-money-navy">Your Competition History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: 'December Trading Challenge', rank: 4, participants: 2341, prize: '$250', date: 'Dec 2024' },
                  { name: 'Black Friday Signals', rank: 7, participants: 1876, prize: '$100', date: 'Nov 2024' },
                  { name: 'Crypto Prediction Master', rank: 12, participants: 3456, prize: 'VIP Access', date: 'Nov 2024' }
                ].map((competition, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-old-money-cream-dark rounded-lg border border-old-money-beige">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        competition.rank <= 3 ? 'bg-old-money-gold text-old-money-navy' : 'bg-old-money-navy text-old-money-cream'
                      }`}>
                        {competition.rank}
                      </div>
                      <div>
                        <div className="font-medium text-old-money-navy">{competition.name}</div>
                        <div className="text-sm text-old-money-warm-gray">
                          {competition.participants.toLocaleString()} participants • {competition.date}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-old-money-sage">{competition.prize}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}