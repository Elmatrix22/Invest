import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Users, 
  TrendingUp, 
  Signal, 
  ExternalLink,
  Zap,
  Shield,
  Trophy,
  MessageCircle,
  Gift,
  Brain,
  Lock,
  Unlock,
  DollarSign,
  Euro,
  PoundSterling,
  Activity,
  Target,
  Sparkles,
  BarChart3,
  Globe,
  Star
} from 'lucide-react';

interface HeroBannerProps {
  user: any;
  translations: any;
  onShowAuthModal: () => void;
  onSetActiveTab: (tab: string) => void;
  onBinanceReferral: () => void;
}

export function HeroBanner({ 
  user, 
  translations: t, 
  onShowAuthModal, 
  onSetActiveTab, 
  onBinanceReferral 
}: HeroBannerProps) {
  return (
    <>
      {/* Main Hero Banner - Enhanced with better colors */}
      <div className="relative bg-gradient-to-br from-deep-navy via-deep-ocean to-deep-navy py-24 overflow-hidden">
        {/* Enhanced Background Patterns */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(78,205,196,0.15),transparent_60%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(139,92,246,0.15),transparent_60%)]"></div>
        <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_30%,rgba(78,205,196,0.05)_50%,transparent_70%)]"></div>
        
        <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            
            {/* Main Heading */}
            <div className="mb-10">
              <div className="inline-flex items-center gap-3 bg-soft-teal/20 border border-soft-teal/30 rounded-full px-6 py-3 mb-8 backdrop-blur-sm">
                <Sparkles className="w-5 h-5 text-soft-teal animate-pulse" />
                <span className="text-pearl-white font-semibold">Free AI Trading Platform</span>
                <Badge className="bg-soft-teal text-deep-navy text-xs font-bold">NEW</Badge>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-pearl-white mb-8 leading-tight">
                Get FREE AI Trading Signals for{' '}
                <span className="bg-gradient-to-r from-soft-teal via-soft-teal-light to-subtle-lavender bg-clip-text text-transparent">
                  Everything
                </span>
              </h1>
              
              <p className="text-xl sm:text-2xl text-pearl-white/90 mb-6 max-w-4xl mx-auto leading-relaxed">
                🎯 <span className="font-bold text-soft-teal">Crypto • Forex • Stocks • Commodities • Indices</span>
              </p>
              
              <p className="text-lg text-pearl-white/80 max-w-3xl mx-auto mb-10">
                AI-powered signals with <span className="font-bold text-soft-mint">84% accuracy</span>. 
                Daily updates. Beginner to Professional levels.
                <span className="block mt-3 font-semibold text-soft-teal text-xl">
                  🔐 Registration Required for Full Access
                </span>
              </p>
            </div>
            
            {/* Asset Class Icons - Enhanced with vibrant colors */}
            <div className="mb-16">
              <div className="grid grid-cols-5 gap-8 max-w-3xl mx-auto">
                <div className="flex flex-col items-center group cursor-pointer">
                  <div className="w-20 h-20 bg-gradient-to-br from-soft-teal to-soft-teal-dark rounded-3xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110 group-hover:shadow-glow-dark border-2 border-soft-teal/30 group-hover:border-soft-teal">
                    <DollarSign className="w-10 h-10 text-pearl-white" />
                  </div>
                  <span className="text-sm font-semibold text-pearl-white">Crypto</span>
                </div>
                
                <div className="flex flex-col items-center group cursor-pointer">
                  <div className="w-20 h-20 bg-gradient-to-br from-subtle-lavender to-subtle-lavender-light rounded-3xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110 group-hover:shadow-glow-dark border-2 border-subtle-lavender/30 group-hover:border-subtle-lavender">
                    <Euro className="w-10 h-10 text-pearl-white" />
                  </div>
                  <span className="text-sm font-semibold text-pearl-white">Forex</span>
                </div>
                
                <div className="flex flex-col items-center group cursor-pointer">
                  <div className="w-20 h-20 bg-gradient-to-br from-soft-mint to-soft-mint-light rounded-3xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110 group-hover:shadow-glow-dark border-2 border-soft-mint/30 group-hover:border-soft-mint">
                    <TrendingUp className="w-10 h-10 text-pearl-white" />
                  </div>
                  <span className="text-sm font-semibold text-pearl-white">Stocks</span>
                </div>
                
                <div className="flex flex-col items-center group cursor-pointer">
                  <div className="w-20 h-20 bg-gradient-to-br from-warning-amber to-warning-amber/80 rounded-3xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110 group-hover:shadow-glow-dark border-2 border-warning-amber/30 group-hover:border-warning-amber">
                    <Target className="w-10 h-10 text-pearl-white" />
                  </div>
                  <span className="text-sm font-semibold text-pearl-white">Commodities</span>
                </div>
                
                <div className="flex flex-col items-center group cursor-pointer">
                  <div className="w-20 h-20 bg-gradient-to-br from-deep-ocean-light to-deep-ocean rounded-3xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110 group-hover:shadow-glow-dark border-2 border-deep-ocean-light/50 group-hover:border-soft-teal">
                    <Activity className="w-10 h-10 text-soft-teal" />
                  </div>
                  <span className="text-sm font-semibold text-pearl-white">Indices</span>
                </div>
              </div>
            </div>

            {/* Call to Action Buttons - Enhanced */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16">
              {!user ? (
                <>
                  <Button
                    onClick={onShowAuthModal}
                    size="lg"
                    className="bg-gradient-to-r from-soft-teal to-soft-teal-light hover:from-soft-teal-light hover:to-soft-teal text-deep-navy font-bold text-lg px-10 py-5 shadow-glow-dark hover:shadow-deep transition-all duration-300 transform hover:scale-105"
                  >
                    <Unlock className="w-6 h-6 mr-3" />
                    Get Free Access Now
                  </Button>
                  <Button
                    onClick={() => onSetActiveTab('signals')}
                    variant="outline"
                    size="lg"
                    className="text-lg px-10 py-5 border-2 border-pearl-white/80 text-pearl-white hover:bg-pearl-white hover:text-deep-navy transition-all duration-300 backdrop-blur-sm bg-pearl-white/10"
                  >
                    <Signal className="w-6 h-6 mr-3" />
                    View Live Signals
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    onClick={() => onSetActiveTab('signals')}
                    size="lg"
                    className="bg-gradient-to-r from-soft-teal to-soft-teal-light hover:from-soft-teal-light hover:to-soft-teal text-deep-navy font-bold text-lg px-10 py-5 shadow-glow-dark hover:shadow-deep transition-all duration-300 transform hover:scale-105"
                  >
                    <Signal className="w-6 h-6 mr-3" />
                    View Your Signals
                  </Button>
                  <Button
                    onClick={() => onSetActiveTab('community')}
                    variant="outline"
                    size="lg"
                    className="text-lg px-10 py-5 border-2 border-pearl-white/80 text-pearl-white hover:bg-pearl-white hover:text-deep-navy transition-all duration-300 backdrop-blur-sm bg-pearl-white/10"
                  >
                    <Users className="w-6 h-6 mr-3" />
                    Join Community
                  </Button>
                </>
              )}
            </div>

            {/* Registration Status - Enhanced */}
            <div className="flex justify-center">
              {!user ? (
                <div className="bg-gradient-to-r from-deep-ocean/50 to-deep-navy/50 backdrop-blur-md inline-flex items-center gap-4 px-8 py-5 rounded-3xl border border-soft-teal/30 shadow-glow-dark">
                  <div className="w-12 h-12 bg-soft-teal/20 rounded-2xl flex items-center justify-center border border-soft-teal/30">
                    <Lock className="w-6 h-6 text-soft-teal" />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-pearl-white text-lg">Registration Required</div>
                    <div className="text-sm text-pearl-white/80">Access premium AI analysis & full features</div>
                  </div>
                </div>
              ) : (
                <div className="bg-gradient-to-r from-soft-mint/20 to-soft-mint/10 backdrop-blur-md inline-flex items-center gap-4 px-8 py-5 rounded-3xl border border-soft-mint/40 shadow-glow-dark">
                  <div className="w-12 h-12 bg-soft-mint/20 rounded-2xl flex items-center justify-center border border-soft-mint/40">
                    <Unlock className="w-6 h-6 text-soft-mint" />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-pearl-white text-lg">✅ Premium Access Unlocked!</div>
                    <div className="text-sm text-pearl-white/80">Welcome back, {user.name || 'Premium Member'}!</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Live AI Signals Status Banner - Enhanced */}
      <div className="bg-gradient-to-r from-deep-ocean via-deep-ocean-light to-deep-ocean border-y border-soft-teal/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-5">
                <div className="w-16 h-16 bg-gradient-to-br from-soft-teal to-soft-teal-dark rounded-3xl flex items-center justify-center animate-pulse-glow shadow-glow-dark">
                  <Brain className="w-10 h-10 text-pearl-white animate-float" />
                </div>
                <div className="text-pearl-white">
                  <div className="font-bold text-3xl flex items-center gap-3 mb-2">
                    AI Trading Signals LIVE
                    <div className="status-online animate-pulse"></div>
                  </div>
                  <div className="text-pearl-white/90 text-base">
                    <span className="font-bold text-soft-teal">247+ Daily Signals</span> • 
                    <span className="font-bold text-soft-mint"> 84% Accuracy</span> • 
                    <span className="font-semibold"> Multi-Asset Coverage</span> • 
                    {user ? (
                      <span className="text-soft-mint font-bold"> ✅ Full Access Enabled</span>
                    ) : (
                      <span className="text-warning-amber font-bold"> 🔐 Registration Required</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Enhanced Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-pearl-white">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-soft-mint rounded-full animate-pulse"></div>
                <span className="font-semibold">Real-time Updates</span>
              </div>
              <div className="flex items-center gap-3">
                <Trophy className="w-5 h-5 text-warning-amber" />
                <span className="font-semibold">AI Powered</span>
              </div>
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-soft-mint" />
                <span className="font-semibold">84% Win Rate</span>
              </div>
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-soft-teal" />
                <span className="font-semibold">125k+ Users</span>
              </div>
            </div>
            
            {/* Enhanced Action Buttons */}
            <div className="flex gap-4">
              <Button
                onClick={() => onSetActiveTab('signals')}
                className="bg-pearl-white/20 hover:bg-pearl-white/30 text-pearl-white border-2 border-pearl-white/30 hover:border-pearl-white/50 font-bold px-8 py-4 backdrop-blur-sm transition-all duration-200"
              >
                <Signal className="w-5 h-5 mr-2" />
                View Signals
              </Button>
              {!user && (
                <Button
                  onClick={onShowAuthModal}
                  className="bg-gradient-to-r from-soft-teal to-soft-teal-light hover:from-soft-teal-light hover:to-soft-teal text-deep-navy font-bold px-8 py-4 shadow-glow transition-all duration-200"
                >
                  <Zap className="w-5 h-5 mr-2" />
                  Register Free
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Bonus Features Strip - Fixed colors */}
      <div className="bg-gradient-to-r from-pearl-white via-pearl-gray to-pearl-white border-b border-soft-teal/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="flex items-center justify-center gap-5 group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-soft-mint to-soft-mint-light rounded-2xl flex items-center justify-center shadow-soft group-hover:shadow-medium transition-all duration-300 group-hover:scale-105">
                <Gift className="w-8 h-8 text-pearl-white" />
              </div>
              <div className="text-left">
                <div className="font-bold text-xl text-deep-navy group-hover:text-soft-mint transition-colors duration-300">$100 Trading Bonus</div>
                <div className="text-base text-warm-slate-dark font-medium">Exclusive Binance referral offer</div>
              </div>
            </div>
            
            <div className="flex items-center justify-center gap-5 group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-subtle-lavender to-subtle-lavender-light rounded-2xl flex items-center justify-center shadow-soft group-hover:shadow-medium transition-all duration-300 group-hover:scale-105">
                <MessageCircle className="w-8 h-8 text-pearl-white" />
              </div>
              <div className="text-left">
                <div className="font-bold text-xl text-deep-navy group-hover:text-subtle-lavender transition-colors duration-300">Community Access</div>
                <div className="text-base text-warm-slate-dark font-medium">125k+ active traders & investors</div>
              </div>
            </div>
            
            <div className="flex items-center justify-center gap-5 group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-br from-soft-teal to-soft-teal-light rounded-2xl flex items-center justify-center shadow-soft group-hover:shadow-medium transition-all duration-300 group-hover:scale-105">
                <Star className="w-8 h-8 text-pearl-white" />
              </div>
              <div className="text-left">
                <div className="font-bold text-xl text-deep-navy group-hover:text-soft-teal transition-colors duration-300">100% Free Platform</div>
                <div className="text-base text-warm-slate-dark font-medium">No hidden fees, forever free</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}