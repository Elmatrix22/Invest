import React, { useState } from 'react';
import { Mail, CheckCircle, Gift, TrendingUp, Star, ExternalLink } from 'lucide-react';
import { toast } from "sonner@2.0.3";

interface NewsletterSectionProps {
  translations: any;
  binanceReferralUrl: string;
  className?: string;
}

export default function NewsletterSection({ 
  translations, 
  binanceReferralUrl, 
  className = "" 
}: NewsletterSectionProps) {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showBonusOffer, setShowBonusOffer] = useState(false);

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim()) {
      toast.error('Please enter your email address');
      return;
    }

    if (!validateEmail(email)) {
      toast.error('Please enter a valid email address');
      return;
    }

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Store subscription in localStorage
      const subscriber = {
        email,
        subscribedAt: Date.now(),
        bonusOffered: true
      };
      
      localStorage.setItem('newsletter-subscription', JSON.stringify(subscriber));
      
      setIsSubscribed(true);
      
      // Show bonus offer after a brief delay
      setTimeout(() => {
        setShowBonusOffer(true);
        toast.success('🎉 Welcome! Your exclusive $100 bonus is ready!', {
          duration: 5000,
        });
      }, 1000);
      
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      toast.error('Subscription failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClaimBonus = () => {
    // Track bonus claim
    const bonusClaim = {
      email,
      claimedAt: Date.now(),
      referralUrl: binanceReferralUrl
    };
    
    localStorage.setItem('bonus-claim', JSON.stringify(bonusClaim));
    
    // Open Binance referral link
    window.open(binanceReferralUrl, '_blank');
    
    toast.success('🚀 Opening Binance - Your $100 bonus awaits!', {
      duration: 4000,
    });
  };

  const resetSubscription = () => {
    setIsSubscribed(false);
    setShowBonusOffer(false);
    setEmail('');
    localStorage.removeItem('newsletter-subscription');
  };

  // Check if user is already subscribed on component mount
  React.useEffect(() => {
    const existingSubscription = localStorage.getItem('newsletter-subscription');
    if (existingSubscription) {
      try {
        const subscription = JSON.parse(existingSubscription);
        if (subscription.email && subscription.bonusOffered) {
          setEmail(subscription.email);
          setIsSubscribed(true);
          setShowBonusOffer(true);
        }
      } catch (error) {
        console.error('Error parsing existing subscription:', error);
      }
    }
  }, []);

  if (isSubscribed && showBonusOffer) {
    return (
      <div className={`newsletter-bonus-section ${className}`}>
        <div className="newsletter-bonus-content">
          {/* Success Header */}
          <div className="newsletter-success-header">
            <div className="newsletter-success-icon">
              <CheckCircle className="w-8 h-8 text-success-green" />
            </div>
            <h3 className="newsletter-success-title">
              🎉 Welcome to Invest-Free Premium!
            </h3>
            <p className="newsletter-success-subtitle">
              Thank you for subscribing, {email.split('@')[0]}! Your exclusive bonus is ready.
            </p>
          </div>

          {/* Bonus Offer Card */}
          <div className="newsletter-bonus-card">
            <div className="newsletter-bonus-header">
              <div className="newsletter-bonus-icon">
                <Gift className="w-6 h-6 text-pearl-white" />
              </div>
              <div className="newsletter-bonus-amount">
                <span className="newsletter-bonus-currency">$</span>
                <span className="newsletter-bonus-value">100</span>
                <span className="newsletter-bonus-label">USD Trading Bonus</span>
              </div>
            </div>

            <div className="newsletter-bonus-details">
              <h4 className="newsletter-bonus-details-title">
                🚀 Exclusive Binance Trading Bonus
              </h4>
              <div className="newsletter-bonus-features">
                <div className="newsletter-bonus-feature">
                  <Star className="w-4 h-4 text-warning-amber" />
                  <span>$100 USD Trading Credit</span>
                </div>
                <div className="newsletter-bonus-feature">
                  <TrendingUp className="w-4 h-4 text-success-green" />
                  <span>Access to Premium AI Signals</span>
                </div>
                <div className="newsletter-bonus-feature">
                  <CheckCircle className="w-4 h-4 text-soft-teal" />
                  <span>Verified Binance Partnership</span>
                </div>
              </div>
              
              <div className="newsletter-bonus-terms">
                <p className="newsletter-bonus-terms-text">
                  <strong>How it works:</strong> Sign up through our exclusive link, complete verification, and receive your $100 trading bonus directly in your Binance account. Valid for new Binance users only.
                </p>
              </div>
            </div>

            <div className="newsletter-bonus-actions">
              <button
                onClick={handleClaimBonus}
                className="newsletter-bonus-button-primary"
              >
                <Gift className="w-5 h-5" />
                Claim My $100 Bonus Now
                <ExternalLink className="w-4 h-4" />
              </button>
              
              <div className="newsletter-bonus-security">
                <div className="newsletter-security-badge">
                  <CheckCircle className="w-4 h-4 text-success-green" />
                  <span>Secure & Verified Partnership</span>
                </div>
                <p className="newsletter-security-text">
                  Official Binance referral program. Your bonus is guaranteed upon account verification.
                </p>
              </div>
            </div>
          </div>

          {/* Additional Benefits */}
          <div className="newsletter-additional-benefits">
            <h5 className="newsletter-benefits-title">
              Plus, enjoy these premium benefits:
            </h5>
            <div className="newsletter-benefits-grid">
              <div className="newsletter-benefit-item">
                <TrendingUp className="w-5 h-5 text-soft-teal" />
                <div>
                  <h6>Daily AI Signals</h6>
                  <p>Receive our best trading signals directly to your inbox</p>
                </div>
              </div>
              <div className="newsletter-benefit-item">
                <Star className="w-5 h-5 text-warning-amber" />
                <div>
                  <h6>Market Analysis</h6>
                  <p>Weekly market insights and trend predictions</p>
                </div>
              </div>
              <div className="newsletter-benefit-item">
                <Mail className="w-5 h-5 text-subtle-lavender" />
                <div>
                  <h6>Exclusive Content</h6>
                  <p>Early access to new features and trading strategies</p>
                </div>
              </div>
            </div>
          </div>

          {/* Reset Option */}
          <div className="newsletter-reset-section">
            <button
              onClick={resetSubscription}
              className="newsletter-reset-button"
            >
              Subscribe Different Email
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`newsletter-section ${className}`}>
      <div className="newsletter-content">
        {/* Header */}
        <div className="newsletter-header">
          <div className="newsletter-badge">
            📧 Free Newsletter
          </div>
          <h3 className="newsletter-title">
            Get Exclusive Trading Insights + $100 Bonus
          </h3>
          <p className="newsletter-subtitle">
            Join 50,000+ traders receiving daily AI signals, market analysis, and exclusive Binance trading bonus worth $100 USD.
          </p>
        </div>

        {/* Subscription Form */}
        <div className="newsletter-form-container">
          <form onSubmit={handleSubscribe} className="newsletter-form">
            <div className="newsletter-input-group">
              <div className="newsletter-input-wrapper">
                <Mail className="newsletter-input-icon" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="newsletter-input"
                  disabled={isLoading}
                />
              </div>
              <button
                type="submit"
                disabled={isLoading || !email.trim()}
                className="newsletter-submit-button"
              >
                {isLoading ? (
                  <>
                    <div className="newsletter-loading-spinner" />
                    Subscribing...
                  </>
                ) : (
                  <>
                    <Gift className="w-5 h-5" />
                    Get $100 Bonus
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Benefits Preview */}
          <div className="newsletter-benefits-preview">
            <div className="newsletter-benefit-preview">
              <CheckCircle className="w-4 h-4 text-success-green" />
              <span>$100 Binance Trading Bonus</span>
            </div>
            <div className="newsletter-benefit-preview">
              <CheckCircle className="w-4 h-4 text-success-green" />
              <span>Daily AI Trading Signals</span>
            </div>
            <div className="newsletter-benefit-preview">
              <CheckCircle className="w-4 h-4 text-success-green" />
              <span>Weekly Market Analysis</span>
            </div>
            <div className="newsletter-benefit-preview">
              <CheckCircle className="w-4 h-4 text-success-green" />
              <span>Unsubscribe Anytime</span>
            </div>
          </div>

          {/* Trust Indicators */}
          <div className="newsletter-trust-indicators">
            <div className="newsletter-trust-item">
              <Star className="w-4 h-4 text-warning-amber" />
              <span>50,000+ Subscribers</span>
            </div>
            <div className="newsletter-trust-item">
              <CheckCircle className="w-4 h-4 text-success-green" />
              <span>Official Binance Partner</span>
            </div>
            <div className="newsletter-trust-item">
              <Mail className="w-4 h-4 text-soft-teal" />
              <span>No Spam Guarantee</span>
            </div>
          </div>
        </div>

        {/* Privacy Notice */}
        <div className="newsletter-privacy">
          <p className="newsletter-privacy-text">
            🔒 Your privacy is protected. We never share your email and you can unsubscribe anytime. 
            By subscribing, you agree to receive trading insights and promotional offers from Invest-Free.com.
          </p>
        </div>
      </div>
    </div>
  );
}