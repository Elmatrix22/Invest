import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Bell, 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  Target, 
  Trash2,
  Settings,
  Smartphone,
  Mail,
  ExternalLink,
  Zap
} from 'lucide-react';

interface PriceAlert {
  id: string;
  coin: string;
  symbol: string;
  targetPrice: number;
  currentPrice: number;
  condition: 'above' | 'below';
  isActive: boolean;
  createdAt: string;
  triggeredAt?: string;
}

interface PriceAlertsProps {
  translations: any;
  binanceReferralUrl: string;
}

export function PriceAlerts({ translations, binanceReferralUrl }: PriceAlertsProps) {
  const [alerts, setAlerts] = useState<PriceAlert[]>([
    {
      id: '1',
      coin: 'Bitcoin',
      symbol: 'BTC',
      targetPrice: 105000,
      currentPrice: 98750,
      condition: 'above',
      isActive: true,
      createdAt: '2025-01-15T10:00:00Z'
    },
    {
      id: '2',
      coin: 'Ethereum',
      symbol: 'ETH',
      targetPrice: 3200,
      currentPrice: 3456,
      condition: 'below',
      isActive: true,
      createdAt: '2025-01-15T09:30:00Z'
    },
    {
      id: '3',
      coin: 'Solana',
      symbol: 'SOL',
      targetPrice: 250,
      currentPrice: 235,
      condition: 'above',
      isActive: false,
      createdAt: '2025-01-14T15:20:00Z',
      triggeredAt: '2025-01-15T08:45:00Z'
    }
  ]);

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newAlert, setNewAlert] = useState({
    coin: '',
    symbol: '',
    targetPrice: '',
    condition: 'above' as 'above' | 'below'
  });

  const [notificationSettings, setNotificationSettings] = useState({
    pushNotifications: true,
    emailNotifications: false,
    smsNotifications: false,
    soundEnabled: true
  });

  const [recentTriggers, setRecentTriggers] = useState([
    { coin: 'BTC', price: 100000, time: '2 hours ago', change: '+1.2%' },
    { coin: 'ETH', price: 3500, time: '4 hours ago', change: '+2.8%' },
    { coin: 'SOL', price: 250, time: '6 hours ago', change: '+6.4%' }
  ]);

  const topCoins = [
    { name: 'Bitcoin', symbol: 'BTC', price: 98750, change: '+2.4%' },
    { name: 'Ethereum', symbol: 'ETH', price: 3456, change: '+1.8%' },
    { name: 'Solana', symbol: 'SOL', price: 235, change: '+4.2%' },
    { name: 'Cardano', symbol: 'ADA', price: 0.89, change: '+3.1%' },
    { name: 'Polygon', symbol: 'MATIC', price: 1.25, change: '+5.7%' },
    { name: 'Chainlink', symbol: 'LINK', price: 23.45, change: '+2.9%' }
  ];

  // Simulate real-time price updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Update current prices with random fluctuations
      setAlerts(prev => prev.map(alert => ({
        ...alert,
        currentPrice: alert.currentPrice * (1 + (Math.random() - 0.5) * 0.02) // ±1% fluctuation
      })));

      // Simulate alert triggers
      if (Math.random() > 0.95) { // 5% chance every 5 seconds
        const triggeredAlert = {
          coin: ['BTC', 'ETH', 'SOL', 'ADA'][Math.floor(Math.random() * 4)],
          price: Math.random() * 100000,
          time: 'Just now',
          change: `+${(Math.random() * 10).toFixed(1)}%`
        };
        setRecentTriggers(prev => [triggeredAlert, ...prev.slice(0, 4)]);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleCreateAlert = () => {
    if (!newAlert.coin || !newAlert.targetPrice) return;

    const alert: PriceAlert = {
      id: Date.now().toString(),
      coin: newAlert.coin,
      symbol: newAlert.symbol,
      targetPrice: parseFloat(newAlert.targetPrice),
      currentPrice: Math.random() * 100000, // Mock current price
      condition: newAlert.condition,
      isActive: true,
      createdAt: new Date().toISOString()
    };

    setAlerts(prev => [alert, ...prev]);
    setNewAlert({ coin: '', symbol: '', targetPrice: '', condition: 'above' });
    setShowCreateModal(false);
  };

  const handleToggleAlert = (id: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === id ? { ...alert, isActive: !alert.isActive } : alert
    ));
  };

  const handleDeleteAlert = (id: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== id));
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const activeAlerts = alerts.filter(alert => alert.isActive);
  const triggeredAlerts = alerts.filter(alert => !alert.isActive && alert.triggeredAt);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-old-money-navy flex items-center gap-2">
            <Bell className="w-6 h-6 text-old-money-burgundy" />
            Price Alerts
          </h2>
          <p className="text-old-money-warm-gray">
            Never miss a trading opportunity. Get instant alerts when your target prices are hit.
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setShowCreateModal(true)}
            className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Alert
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-navy">{activeAlerts.length}</div>
            <div className="text-sm text-old-money-warm-gray">Active Alerts</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-sage">{triggeredAlerts.length}</div>
            <div className="text-sm text-old-money-warm-gray">Triggered Today</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-burgundy">78%</div>
            <div className="text-sm text-old-money-warm-gray">Success Rate</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-gold">$2,340</div>
            <div className="text-sm text-old-money-warm-gray">Profits Captured</div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Triggers Alert */}
      {recentTriggers.length > 0 && (
        <Alert className="border-old-money-sage/30 bg-old-money-sage/10">
          <Zap className="h-4 w-4 text-old-money-sage" />
          <AlertDescription className="text-old-money-charcoal">
            <strong>Alert Triggered!</strong> {recentTriggers[0].coin} hit ${recentTriggers[0].price.toLocaleString()} ({recentTriggers[0].change}) {recentTriggers[0].time}
          </AlertDescription>
        </Alert>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Active Alerts */}
        <div className="lg:col-span-2">
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <Target className="w-5 h-5 text-old-money-burgundy" />
                Active Price Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              {activeAlerts.length === 0 ? (
                <div className="text-center py-8">
                  <Bell className="w-12 h-12 text-old-money-warm-gray mx-auto mb-4" />
                  <p className="text-old-money-warm-gray mb-4">No active alerts yet</p>
                  <Button
                    onClick={() => setShowCreateModal(true)}
                    className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
                  >
                    Create Your First Alert
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {activeAlerts.map((alert) => (
                    <div key={alert.id} className="flex items-center justify-between p-4 bg-old-money-cream-dark rounded-lg border border-old-money-beige">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-old-money-gold rounded-full flex items-center justify-center">
                          <span className="text-old-money-navy text-sm font-bold">{alert.symbol}</span>
                        </div>
                        <div>
                          <div className="font-medium text-old-money-navy">{alert.coin}</div>
                          <div className="text-sm text-old-money-warm-gray">
                            Alert when {alert.condition} ${alert.targetPrice.toLocaleString()}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="font-medium text-old-money-navy">
                            ${alert.currentPrice.toLocaleString()}
                          </div>
                          <div className={`text-sm flex items-center gap-1 ${
                            alert.condition === 'above' 
                              ? (alert.currentPrice >= alert.targetPrice ? 'text-old-money-sage' : 'text-old-money-warm-gray')
                              : (alert.currentPrice <= alert.targetPrice ? 'text-old-money-sage' : 'text-old-money-warm-gray')
                          }`}>
                            {alert.condition === 'above' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                            {alert.condition === 'above' ? 'Waiting for rise' : 'Waiting for dip'}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Switch
                            checked={alert.isActive}
                            onCheckedChange={() => handleToggleAlert(alert.id)}
                          />
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteAlert(alert.id)}
                            className="text-old-money-warm-gray hover:text-old-money-burgundy"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions & Popular Coins */}
        <div className="space-y-6">
          {/* Notification Settings */}
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <Settings className="w-5 h-5" />
                Alert Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-old-money-navy" />
                  <span className="text-sm text-old-money-navy">Push Notifications</span>
                </div>
                <Switch
                  checked={notificationSettings.pushNotifications}
                  onCheckedChange={(checked) => 
                    setNotificationSettings(prev => ({ ...prev, pushNotifications: checked }))
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-old-money-navy" />
                  <span className="text-sm text-old-money-navy">Email Alerts</span>
                </div>
                <Switch
                  checked={notificationSettings.emailNotifications}
                  onCheckedChange={(checked) => 
                    setNotificationSettings(prev => ({ ...prev, emailNotifications: checked }))
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-old-money-navy" />
                  <span className="text-sm text-old-money-navy">Sound Alerts</span>
                </div>
                <Switch
                  checked={notificationSettings.soundEnabled}
                  onCheckedChange={(checked) => 
                    setNotificationSettings(prev => ({ ...prev, soundEnabled: checked }))
                  }
                />
              </div>
            </CardContent>
          </Card>

          {/* Popular Coins */}
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="text-old-money-navy">Popular for Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {topCoins.slice(0, 4).map((coin) => (
                  <div key={coin.symbol} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-old-money-sage rounded-full flex items-center justify-center">
                        <span className="text-old-money-cream text-xs font-bold">{coin.symbol.charAt(0)}</span>
                      </div>
                      <span className="text-sm text-old-money-navy">{coin.symbol}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-old-money-navy">
                        ${coin.price.toLocaleString()}
                      </div>
                      <div className="text-xs text-old-money-sage">{coin.change}</div>
                    </div>
                  </div>
                ))}
              </div>
              
              <Button
                className="w-full mt-4 bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy"
                onClick={handleBinanceClick}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Trade on Binance
              </Button>
            </CardContent>
          </Card>

          {/* Recent Triggers */}
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="text-old-money-navy">Recent Triggers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentTriggers.map((trigger, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <div>
                      <span className="font-medium text-old-money-navy">{trigger.coin}</span>
                      <span className="text-old-money-warm-gray ml-2">{trigger.time}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-old-money-navy">
                        ${trigger.price.toLocaleString()}
                      </div>
                      <div className="text-old-money-sage">{trigger.change}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Create Alert Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="sm:max-w-md border-old-money-beige">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-old-money-navy">
              <Plus className="w-5 h-5" />
              Create Price Alert
            </DialogTitle>
            <DialogDescription className="text-old-money-warm-gray">
              Get notified when your target price is reached
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="coin" className="text-old-money-navy">Cryptocurrency</Label>
              <Select value={newAlert.symbol} onValueChange={(value) => {
                const coin = topCoins.find(c => c.symbol === value);
                setNewAlert(prev => ({ 
                  ...prev, 
                  coin: coin?.name || '', 
                  symbol: value 
                }));
              }}>
                <SelectTrigger className="border-old-money-warm-gray">
                  <SelectValue placeholder="Select cryptocurrency" />
                </SelectTrigger>
                <SelectContent>
                  {topCoins.map((coin) => (
                    <SelectItem key={coin.symbol} value={coin.symbol}>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{coin.symbol}</span>
                        <span className="text-old-money-warm-gray">- {coin.name}</span>
                        <span className="text-old-money-sage">${coin.price.toLocaleString()}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="condition" className="text-old-money-navy">Alert Condition</Label>
              <Select value={newAlert.condition} onValueChange={(value: 'above' | 'below') => 
                setNewAlert(prev => ({ ...prev, condition: value }))
              }>
                <SelectTrigger className="border-old-money-warm-gray">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="above">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-old-money-sage" />
                      Price goes above
                    </div>
                  </SelectItem>
                  <SelectItem value="below">
                    <div className="flex items-center gap-2">
                      <TrendingDown className="w-4 h-4 text-old-money-burgundy" />
                      Price goes below
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="targetPrice" className="text-old-money-navy">Target Price ($)</Label>
              <Input
                id="targetPrice"
                type="number"
                placeholder="Enter target price"
                value={newAlert.targetPrice}
                onChange={(e) => setNewAlert(prev => ({ ...prev, targetPrice: e.target.value }))}
                className="border-old-money-warm-gray focus:border-old-money-navy"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setShowCreateModal(false)}
                className="flex-1 border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateAlert}
                className="flex-1 bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
                disabled={!newAlert.coin || !newAlert.targetPrice}
              >
                <Bell className="w-4 h-4 mr-2" />
                Create Alert
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}