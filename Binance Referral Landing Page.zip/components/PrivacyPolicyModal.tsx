import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { 
  Shield, 
  Eye, 
  Lock, 
  Database, 
  Globe, 
  Mail, 
  AlertTriangle,
  Clock,
  FileText
} from 'lucide-react';

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  translations: any;
}

function PrivacyPolicyModal({ isOpen, onClose, translations }: PrivacyPolicyModalProps) {
  const lastUpdated = "January 15, 2025";

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl h-[80vh] border-old-money-beige">
        <DialogHeader className="pb-4">
          <DialogTitle className="flex items-center gap-2 text-old-money-navy">
            <Shield className="w-6 h-6" />
            {translations.privacyPolicyTitle || "Privacy Policy"}
          </DialogTitle>
          <div className="flex items-center gap-2 text-sm text-old-money-warm-gray">
            <Clock className="w-4 h-4" />
            {translations.lastUpdated || "Last updated:"} {lastUpdated}
          </div>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-8">
            {/* Introduction */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Eye className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">1. Introduction</h3>
              </div>
              <p className="text-old-money-charcoal mb-4">
                {translations.privacyIntro || "Invest-Free.com is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your information when you use our free trading signals and investment community platform."}
              </p>
              <div className="bg-old-money-cream-dark p-4 rounded-lg border border-old-money-beige">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-old-money-burgundy" />
                  <span className="font-medium text-old-money-burgundy">Important Notice</span>
                </div>
                <p className="text-sm text-old-money-charcoal">
                  We do not collect, store, or process any personally identifiable information (PII) beyond what is necessary for basic platform functionality. We are not designed for handling sensitive financial data.
                </p>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Information We Collect */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Database className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">2. Information We Collect</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">2.1 Account Information</h4>
                  <ul className="list-disc list-inside space-y-1 text-old-money-charcoal ml-4">
                    <li>Username and email address (for account creation)</li>
                    <li>Profile information (optional bio, favorite cryptocurrencies)</li>
                    <li>Authentication data (encrypted passwords or OAuth tokens)</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">2.2 Usage Data</h4>
                  <ul className="list-disc list-inside space-y-1 text-old-money-charcoal ml-4">
                    <li>Investment ideas and community posts you share</li>
                    <li>Chat messages in public community discussions</li>
                    <li>Likes, comments, and other community interactions</li>
                    <li>Platform usage statistics (anonymized)</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">2.3 Technical Data</h4>
                  <ul className="list-disc list-inside space-y-1 text-old-money-charcoal ml-4">
                    <li>Browser type and version</li>
                    <li>Device information and screen resolution</li>
                    <li>IP address (for security and analytics)</li>
                    <li>Cookies and local storage data</li>
                  </ul>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* How We Use Information */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Globe className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">3. How We Use Your Information</h3>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Badge className="bg-old-money-sage/10 text-old-money-sage shrink-0 mt-1">Core</Badge>
                  <div>
                    <p className="text-old-money-charcoal">
                      <strong>Platform Functionality:</strong> Provide trading signals, community features, user authentication, and basic platform operations.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Badge className="bg-old-money-burgundy/10 text-old-money-burgundy shrink-0 mt-1">Analytics</Badge>
                  <div>
                    <p className="text-old-money-charcoal">
                      <strong>Improvement & Analytics:</strong> Analyze platform usage to improve our services, optimize performance, and understand user preferences (anonymized data only).
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Badge className="bg-old-money-gold/10 text-old-money-gold shrink-0 mt-1">Communication</Badge>
                  <div>
                    <p className="text-old-money-charcoal">
                      <strong>Service Communications:</strong> Send important platform updates, security notifications, and optional trading insights (with your consent).
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <Badge className="bg-old-money-navy/10 text-old-money-navy shrink-0 mt-1">Legal</Badge>
                  <div>
                    <p className="text-old-money-charcoal">
                      <strong>Legal Compliance:</strong> Comply with applicable laws, prevent fraud, and maintain platform security.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Data Sharing */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Lock className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">4. Data Sharing and Disclosure</h3>
              </div>
              
              <div className="bg-old-money-sage/10 p-4 rounded-lg border border-old-money-sage/30 mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-old-money-sage" />
                  <span className="font-medium text-old-money-sage">Our Commitment</span>
                </div>
                <p className="text-sm text-old-money-charcoal">
                  We do not sell, trade, or rent your personal information to third parties. We only share data in the following limited circumstances:
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">4.1 Service Providers</h4>
                  <p className="text-old-money-charcoal text-sm">
                    We may share data with trusted service providers who help us operate the platform (hosting, analytics, email services) under strict confidentiality agreements.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">4.2 Legal Requirements</h4>
                  <p className="text-old-money-charcoal text-sm">
                    We may disclose information if required by law, legal process, or to protect the rights, property, or safety of our users and platform.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">4.3 Business Transfers</h4>
                  <p className="text-old-money-charcoal text-sm">
                    In the event of a merger, acquisition, or sale of assets, user data may be transferred as part of the business transaction, with continued privacy protection.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">4.4 Binance Partnership</h4>
                  <p className="text-old-money-charcoal text-sm">
                    When you use our Binance referral links, you are subject to Binance's privacy policy. We do not share your data with Binance beyond the standard referral tracking.
                  </p>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Your Rights */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Eye className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">5. Your Privacy Rights</h3>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-old-money-navy mb-1">Access & Portability</h4>
                    <p className="text-sm text-old-money-charcoal">Request copies of your personal data in a portable format.</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-old-money-navy mb-1">Correction</h4>
                    <p className="text-sm text-old-money-charcoal">Update or correct your personal information through your profile settings.</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-old-money-navy mb-1">Deletion</h4>
                    <p className="text-sm text-old-money-charcoal">Request deletion of your account and associated data (subject to legal requirements).</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-old-money-navy mb-1">Opt-out</h4>
                    <p className="text-sm text-old-money-charcoal">Unsubscribe from marketing communications at any time.</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-old-money-navy mb-1">Cookie Control</h4>
                    <p className="text-sm text-old-money-charcoal">Manage your cookie preferences through our cookie settings.</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-old-money-navy mb-1">Data Restriction</h4>
                    <p className="text-sm text-old-money-charcoal">Limit how we process your data in certain circumstances.</p>
                  </div>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Data Security */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Shield className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">6. Data Security</h3>
              </div>
              
              <div className="space-y-4">
                <p className="text-old-money-charcoal">
                  We implement appropriate technical and organizational security measures to protect your data against unauthorized access, alteration, disclosure, or destruction.
                </p>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-old-money-cream-dark p-3 rounded-lg">
                    <h4 className="font-medium text-old-money-navy mb-2">Technical Measures</h4>
                    <ul className="text-sm text-old-money-charcoal space-y-1">
                      <li>• SSL/TLS encryption</li>
                      <li>• Secure data storage</li>
                      <li>• Regular security audits</li>
                      <li>• Access controls</li>
                    </ul>
                  </div>

                  <div className="bg-old-money-cream-dark p-3 rounded-lg">
                    <h4 className="font-medium text-old-money-navy mb-2">Organizational Measures</h4>
                    <ul className="text-sm text-old-money-charcoal space-y-1">
                      <li>• Privacy by design</li>
                      <li>• Data minimization</li>
                      <li>• Staff training</li>
                      <li>• Incident response plan</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* International Transfers */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Globe className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">7. International Data Transfers</h3>
              </div>
              
              <p className="text-old-money-charcoal mb-3">
                Our services are provided globally. Your data may be transferred to and processed in countries other than your country of residence, including countries that may have different data protection laws.
              </p>

              <div className="bg-old-money-burgundy/10 p-4 rounded-lg border border-old-money-burgundy/30">
                <h4 className="font-medium text-old-money-burgundy mb-2">GDPR Compliance</h4>
                <p className="text-sm text-old-money-charcoal">
                  For users in the European Economic Area (EEA), we ensure adequate protection for international transfers through appropriate safeguards such as standard contractual clauses or adequacy decisions.
                </p>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Contact & Updates */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Mail className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">8. Contact Us & Policy Updates</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">Contact Information</h4>
                  <p className="text-old-money-charcoal text-sm mb-2">
                    If you have questions about this Privacy Policy or want to exercise your rights, contact us at:
                  </p>
                  <div className="bg-old-money-cream-dark p-3 rounded-lg text-sm">
                    <p>Email: privacy@invest-free.com</p>
                    <p>Address: Privacy Team, Invest-Free.com</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">Policy Updates</h4>
                  <p className="text-old-money-charcoal text-sm">
                    We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the new policy on our website and updating the "Last updated" date.
                  </p>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Disclaimer */}
            <section>
              <div className="bg-old-money-warm-gray/10 p-4 rounded-lg border border-old-money-warm-gray/30">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-old-money-warm-gray" />
                  <span className="font-medium text-old-money-warm-gray">Trading Disclaimer</span>
                </div>
                <p className="text-xs text-old-money-charcoal">
                  All trading signals and investment ideas shared on this platform are for educational and informational purposes only. 
                  They do not constitute financial advice. Trading involves risk, and you should consult with qualified financial advisors before making investment decisions.
                </p>
              </div>
            </section>
          </div>
        </ScrollArea>

        <div className="pt-4 border-t border-old-money-beige">
          <Button 
            onClick={onClose}
            className="w-full bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
          >
            <FileText className="w-4 h-4 mr-2" />
            I Understand
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default PrivacyPolicyModal;