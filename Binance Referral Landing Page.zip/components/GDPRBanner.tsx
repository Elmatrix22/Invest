import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { 
  Shield, 
  Cookie, 
  X, 
  Settings, 
  Info,
  Eye,
  Target,
  BarChart3
} from 'lucide-react';

interface GDPRBannerProps {
  translations: any;
}

interface CookiePreferences {
  essential: boolean;
  analytics: boolean;
  marketing: boolean;
}

function GDPRBanner({ translations }: GDPRBannerProps) {
  const [showBanner, setShowBanner] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [preferences, setPreferences] = useState<CookiePreferences>({
    essential: true, // Always true, cannot be disabled
    analytics: false,
    marketing: false
  });

  useEffect(() => {
    // Check if user has already made a choice
    const gdprConsent = localStorage.getItem('gdpr-consent');
    const cookiePreferences = localStorage.getItem('cookie-preferences');
    
    if (!gdprConsent) {
      // Show banner after a short delay
      const timer = setTimeout(() => {
        setShowBanner(true);
      }, 1000);
      
      return () => clearTimeout(timer);
    } else if (cookiePreferences) {
      // Load saved preferences
      setPreferences(JSON.parse(cookiePreferences));
    }
  }, []);

  const acceptAll = () => {
    const allAccepted: CookiePreferences = {
      essential: true,
      analytics: true,
      marketing: true
    };
    
    localStorage.setItem('gdpr-consent', 'accepted');
    localStorage.setItem('cookie-preferences', JSON.stringify(allAccepted));
    localStorage.setItem('consent-timestamp', new Date().toISOString());
    
    setPreferences(allAccepted);
    setShowBanner(false);
    
    // Initialize analytics and marketing scripts here
    initializeScripts(allAccepted);
  };

  const rejectAll = () => {
    const essentialOnly: CookiePreferences = {
      essential: true,
      analytics: false,
      marketing: false
    };
    
    localStorage.setItem('gdpr-consent', 'rejected');
    localStorage.setItem('cookie-preferences', JSON.stringify(essentialOnly));
    localStorage.setItem('consent-timestamp', new Date().toISOString());
    
    setPreferences(essentialOnly);
    setShowBanner(false);
  };

  const savePreferences = () => {
    localStorage.setItem('gdpr-consent', 'customized');
    localStorage.setItem('cookie-preferences', JSON.stringify(preferences));
    localStorage.setItem('consent-timestamp', new Date().toISOString());
    
    setShowBanner(false);
    setShowPreferences(false);
    
    // Initialize scripts based on preferences
    initializeScripts(preferences);
  };

  const initializeScripts = (prefs: CookiePreferences) => {
    // Analytics scripts (Google Analytics, etc.)
    if (prefs.analytics) {
      // Initialize analytics here
      console.log('Analytics enabled');
    }
    
    // Marketing scripts (Facebook Pixel, etc.)
    if (prefs.marketing) {
      // Initialize marketing scripts here
      console.log('Marketing cookies enabled');
    }
  };

  if (!showBanner) return null;

  return (
    <>
      {/* GDPR Banner */}
      <div className="fixed bottom-0 left-0 right-0 z-50 p-4">
        <Card className="border-old-money-navy shadow-2xl max-w-4xl mx-auto">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
              <div className="flex items-center gap-3 flex-1">
                <div className="w-10 h-10 bg-old-money-navy rounded-full flex items-center justify-center shrink-0">
                  <Shield className="w-5 h-5 text-old-money-cream" />
                </div>
                
                <div className="flex-1">
                  <h4 className="font-medium text-old-money-navy mb-1">
                    {translations.gdprTitle || "We Value Your Privacy"}
                  </h4>
                  <p className="text-sm text-old-money-warm-gray">
                    {translations.gdprMessage || "We use cookies and similar technologies to improve your experience, analyze traffic, and personalize content. By clicking 'Accept All', you consent to our use of cookies."}
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2 shrink-0">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowPreferences(true)}
                  className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark"
                >
                  <Settings className="w-4 h-4 mr-1" />
                  {translations.gdprManagePreferences || "Manage Preferences"}
                </Button>
                
                <Button
                  size="sm"
                  variant="outline"
                  onClick={rejectAll}
                  className="border-old-money-warm-gray text-old-money-warm-gray hover:bg-old-money-cream-dark"
                >
                  {translations.gdprRejectAll || "Reject All"}
                </Button>
                
                <Button
                  size="sm"
                  onClick={acceptAll}
                  className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
                >
                  <Cookie className="w-4 h-4 mr-1" />
                  {translations.gdprAcceptAll || "Accept All"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Cookie Preferences Modal */}
      <Dialog open={showPreferences} onOpenChange={setShowPreferences}>
        <DialogContent className="sm:max-w-2xl border-old-money-beige">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-old-money-navy">
              <Cookie className="w-5 h-5" />
              {translations.cookiePreferences || "Cookie Preferences"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <p className="text-sm text-old-money-warm-gray">
              {translations.cookiePreferencesDesc || "Manage your cookie preferences below. Some cookies are essential for the website to function properly."}
            </p>

            {/* Essential Cookies */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-old-money-sage/10 rounded-full flex items-center justify-center">
                    <Shield className="w-4 h-4 text-old-money-sage" />
                  </div>
                  <div>
                    <h4 className="font-medium text-old-money-navy">
                      {translations.essentialCookies || "Essential Cookies"}
                    </h4>
                    <Badge className="bg-old-money-sage/10 text-old-money-sage text-xs">
                      Always Active
                    </Badge>
                  </div>
                </div>
                <Switch checked={true} disabled />
              </div>
              <p className="text-sm text-old-money-warm-gray ml-11">
                {translations.essentialCookiesDesc || "These cookies are necessary for the website to function and cannot be switched off in our systems."}
              </p>
            </div>

            {/* Analytics Cookies */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-old-money-burgundy/10 rounded-full flex items-center justify-center">
                    <BarChart3 className="w-4 h-4 text-old-money-burgundy" />
                  </div>
                  <div>
                    <h4 className="font-medium text-old-money-navy">
                      {translations.analyticsCookies || "Analytics Cookies"}
                    </h4>
                    <Badge variant="outline" className="text-xs border-old-money-warm-gray text-old-money-warm-gray">
                      Optional
                    </Badge>
                  </div>
                </div>
                <Switch 
                  checked={preferences.analytics}
                  onCheckedChange={(checked) => 
                    setPreferences(prev => ({ ...prev, analytics: checked }))
                  }
                />
              </div>
              <p className="text-sm text-old-money-warm-gray ml-11">
                {translations.analyticsCookiesDesc || "These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site."}
              </p>
            </div>

            {/* Marketing Cookies */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-old-money-gold/10 rounded-full flex items-center justify-center">
                    <Target className="w-4 h-4 text-old-money-gold" />
                  </div>
                  <div>
                    <h4 className="font-medium text-old-money-navy">
                      {translations.marketingCookies || "Marketing Cookies"}
                    </h4>
                    <Badge variant="outline" className="text-xs border-old-money-warm-gray text-old-money-warm-gray">
                      Optional
                    </Badge>
                  </div>
                </div>
                <Switch 
                  checked={preferences.marketing}
                  onCheckedChange={(checked) => 
                    setPreferences(prev => ({ ...prev, marketing: checked }))
                  }
                />
              </div>
              <p className="text-sm text-old-money-warm-gray ml-11">
                {translations.marketingCookiesDesc || "These cookies may be set through our site by our advertising partners to build a profile of your interests."}
              </p>
            </div>

            {/* Privacy Notice */}
            <div className="bg-old-money-cream-dark p-4 rounded-lg border border-old-money-beige">
              <div className="flex items-center gap-2 mb-2">
                <Info className="w-4 h-4 text-old-money-navy" />
                <span className="text-sm font-medium text-old-money-navy">
                  Important Information
                </span>
              </div>
              <p className="text-xs text-old-money-warm-gray">
                We do not collect or store any personally identifiable information (PII) without your explicit consent. 
                All trading signals are provided for educational purposes only and do not constitute financial advice. 
                Please read our Privacy Policy for more details.
              </p>
            </div>
          </div>

          <div className="flex flex-col-reverse sm:flex-row gap-3 pt-4 border-t border-old-money-beige">
            <Button
              variant="outline"
              onClick={() => setShowPreferences(false)}
              className="flex-1 border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark"
            >
              {translations.cancel || "Cancel"}
            </Button>
            
            <Button
              onClick={savePreferences}
              className="flex-1 bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
            >
              <Shield className="w-4 h-4 mr-2" />
              {translations.savePreferences || "Save Preferences"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default GDPRBanner;