import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Check, Gift, Star, Zap, Crown, Heart } from 'lucide-react';

interface PricingSectionProps {
  translations: any;
}

export function PricingSection({ translations }: PricingSectionProps) {
  const freeFeatures = [
    { name: "$100 free money to start investing", included: true, highlight: true },
    { name: "Zero commission on all crypto trades", included: true, highlight: true },
    { name: "Trade 500+ cryptocurrencies free", included: true },
    { name: "Free crypto education worth $2,000+", included: true },
    { name: "Free mobile app with advanced tools", included: true },
    { name: "Free 24/7 expert support", included: true },
    { name: "Free real-time market data", included: true },
    { name: "Free portfolio tracking tools", included: true },
    { name: "Free market analysis & insights", included: true },
    { name: "Free crypto staking opportunities", included: true },
    { name: "Free high-yield crypto savings", included: true },
    { name: "Free access to new token launches", included: true },
    { name: "Free trading signals & alerts", included: true },
    { name: "Free tax reporting tools", included: true },
    { name: "Bank-level security (free)", included: true },
    { name: "Insurance protection up to $500K (free)", included: true }
  ];

  const whyFree = [
    {
      icon: Heart,
      title: "Our Mission",
      description: "We believe crypto investing should be accessible to everyone, regardless of financial background"
    },
    {
      icon: Gift,
      title: "Community Funded",
      description: "Supported by successful crypto investors who want to give back to newcomers"
    },
    {
      icon: Zap,
      title: "Volume Benefits",
      description: "Our massive user base allows us to offer everything free while maintaining quality"
    },
    {
      icon: Crown,
      title: "Future Vision",
      description: "Building the future of finance where everyone has equal access to investment opportunities"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-green-50 to-emerald-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <Badge className="bg-green-500 text-white text-lg px-6 py-2 mb-4">
            🎉 100% FREE FOREVER
          </Badge>
          <h2 className="text-3xl lg:text-4xl text-gray-900">
            {translations.pricingTitle || "Everything is 100% Free Forever"}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {translations.pricingSubtitle || "No hidden fees, no paid plans, no credit card required - truly free crypto investing"}
          </p>
          <p className="text-lg text-green-600 font-medium">
            Join 5+ million people getting free money and free crypto education!
          </p>
        </div>

        {/* Main Free Plan Card */}
        <div className="max-w-2xl mx-auto mb-16">
          <Card className="relative ring-4 ring-green-500 shadow-2xl transform hover:scale-105 transition-all duration-300">
            <div className="absolute -top-6 left-1/2 transform -translate-x-1/2">
              <Badge className="bg-green-500 text-white px-8 py-3 text-lg">
                <Gift className="w-5 h-5 mr-2" />
                MOST POPULAR - FREE FOREVER
              </Badge>
            </div>
            
            <CardHeader className="text-center space-y-6 pt-12">
              <div className="w-20 h-20 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto">
                <Star className="w-10 h-10 text-white" />
              </div>
              <div>
                <CardTitle className="text-3xl text-gray-900">
                  {translations.freePlan || "Free Forever Plan"}
                </CardTitle>
                <CardDescription className="mt-2 text-lg">
                  {translations.freeDesc || "Everything you need to succeed in crypto investing"}
                </CardDescription>
              </div>
              <div className="space-y-2">
                <div className="text-6xl font-bold text-green-600">FREE</div>
                <div className="text-lg text-gray-600">+ Get $100 free money to start</div>
                <div className="text-sm text-green-600">No credit card • No deposits • No catches</div>
              </div>
            </CardHeader>

            <CardContent className="space-y-8 px-8 pb-8">
              <Button 
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white py-4 text-lg"
                size="lg"
              >
                🎁 Claim Your Free $100 Now
              </Button>

              <div className="space-y-4">
                <h4 className="text-lg font-medium text-gray-900 border-b border-gray-200 pb-2">
                  Everything Included (Worth $5,000+ Normally)
                </h4>
                {freeFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500 shrink-0" />
                    <span className={`text-sm ${feature.highlight ? 'font-medium text-green-700' : 'text-gray-700'}`}>
                      {feature.name}
                    </span>
                    {feature.highlight && (
                      <Badge variant="outline" className="text-xs bg-green-50 text-green-600 border-green-200">
                        Most Popular
                      </Badge>
                    )}
                  </div>
                ))}
              </div>

              <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                <h5 className="font-medium text-green-800 mb-2">🚀 Limited Time Bonus</h5>
                <p className="text-sm text-green-700">
                  Sign up in the next 24 hours and get an additional $50 bonus + exclusive access to our VIP free crypto signals group!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Why Everything is Free */}
        <div className="mb-16">
          <h3 className="text-2xl text-center mb-12 text-gray-900">
            Why is Everything Completely Free?
          </h3>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {whyFree.map((reason, index) => (
              <Card key={index} className="text-center border-0 bg-white/80 backdrop-blur-sm hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <reason.icon className="w-6 h-6 text-green-600" />
                  </div>
                  <h4 className="text-lg mb-2 text-gray-900">{reason.title}</h4>
                  <p className="text-sm text-gray-600">{reason.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Success Stats */}
        <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-8 border border-green-200">
          <h3 className="text-xl text-center mb-8 text-gray-900">
            Free Members Success Stories
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold text-green-600 mb-1">5M+</div>
              <div className="text-sm text-gray-600">Free Members</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-600 mb-1">$2.5B+</div>
              <div className="text-sm text-gray-600">Free Money Given</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-600 mb-1">98%</div>
              <div className="text-sm text-gray-600">Success Rate</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-600 mb-1">24/7</div>
              <div className="text-sm text-gray-600">Free Support</div>
            </div>
          </div>
        </div>

        {/* Final CTA */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl p-8 text-white">
            <h3 className="text-2xl mb-4">Ready to Start Your Free Crypto Journey?</h3>
            <p className="text-green-100 mb-6 max-w-2xl mx-auto">
              Join millions who started with our free money and education. No risk, no fees, just pure opportunity to build wealth through cryptocurrency.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <Button size="lg" className="bg-white text-green-600 hover:bg-gray-100 flex-1">
                🎁 Get Free $100 Now
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-green-600 flex-1">
                📱 Download Free App
              </Button>
            </div>
            <p className="text-xs text-green-200 mt-4">
              ✅ No credit card required ✅ Instant access ✅ 100% free forever
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}