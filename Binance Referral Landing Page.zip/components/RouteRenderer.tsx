import React, { Suspense, lazy } from 'react';
import { ROUTES, RouteType } from '../utils/appConstants';
import NewsletterSection from './NewsletterSection';
import { LoadingSpinner } from './LoadingSpinner';

// Lazy load components for better performance
const HomePage = lazy(() => import('./HomePage'));
const TradingSignals = lazy(() => import('./EnhancedTradingSignalsV2'));
const CommunityFeed = lazy(() => import('./CommunityFeed'));
const CryptoNewsFeed = lazy(() => import('./EnhancedCryptoNewsFeed'));
const BlogArticles = lazy(() => import('./EnhancedBlogArticles'));
const MarketResearchHub = lazy(() => import('./MarketResearchHub'));

interface RouteRendererProps {
  currentRoute: RouteType;
  user: any;
  translations: any;
  binanceReferralUrl: string;
  onShowAuthModal: () => void;
  onRouteChange: (route: RouteType) => void;
  marketData: any;
  isMarketDataReady: boolean;
  marketDataService: any;
  onShowUserProfile: () => void;
}

export function RouteRenderer({
  currentRoute,
  user,
  translations,
  binanceReferralUrl,
  onShowAuthModal,
  onRouteChange,
  marketData,
  isMarketDataReady,
  marketDataService,
  onShowUserProfile
}: RouteRendererProps) {
  const commonProps = {
    translations,
    binanceReferralUrl,
    user,
    onShowAuthModal,
    onRouteChange,
    marketData,
    isMarketDataReady,
    marketDataService
  };

  try {
    // Home page doesn't need container wrapper as it has its own layout
    if (currentRoute === ROUTES.HOME) {
      return (
        <>
          <HomePage {...commonProps} />
          {/* Newsletter Section - prominently displayed on homepage */}
          <div className="bg-pearl-blue py-8">
            <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
              <NewsletterSection 
                translations={translations} 
                binanceReferralUrl={binanceReferralUrl}
              />
            </div>
          </div>
        </>
      );
    }

    // Profile route has special handling
    if (currentRoute === ROUTES.PROFILE && user) {
      return (
        <div className="page-container">
          <div className="page-content-narrow">
            <div className="page-header">
              <div className="page-badge">
                👑 Premium Member Dashboard
              </div>
              <h1 className="page-title">
                Welcome Back, {user.name || 'Premium Member'}!
              </h1>
              <p className="page-subtitle">
                Access your full dashboard and premium trading features
              </p>
            </div>
            <div className="page-section text-center">
              <button
                onClick={onShowUserProfile}
                className="btn-teal text-lg px-12 py-4 shadow-glow hover:shadow-deep transition-all duration-300 transform hover:scale-105"
              >
                Open Full Dashboard →
              </button>
            </div>
          </div>
        </div>
      );
    }

    // All other routes get wrapped in consistent container
    const getRouteComponent = () => {
      switch (currentRoute) {
        case ROUTES.SIGNALS:
          return (
            <>
              <TradingSignals {...commonProps} />
              {/* Newsletter Section for non-subscribers on signals page */}
              {!user && (
                <div className="mt-8">
                  <NewsletterSection 
                    translations={translations} 
                    binanceReferralUrl={binanceReferralUrl}
                  />
                </div>
              )}
            </>
          );
        case ROUTES.COMMUNITY:
          return (
            <>
              <CommunityFeed {...commonProps} />
              {/* Newsletter Section in community for engagement */}
              <div className="mt-8">
                <NewsletterSection 
                  translations={translations} 
                  binanceReferralUrl={binanceReferralUrl}
                />
              </div>
            </>
          );
        case ROUTES.NEWS:
          return (
            <>
              <CryptoNewsFeed {...commonProps} />
              {/* Newsletter Section after news content */}
              <div className="mt-8">
                <NewsletterSection 
                  translations={translations} 
                  binanceReferralUrl={binanceReferralUrl}
                />
              </div>
            </>
          );
        case ROUTES.EDUCATION:
          return (
            <div className="space-y-8">
              <BlogArticles {...commonProps} />
              <MarketResearchHub {...commonProps} />
              {/* Newsletter Section after educational content */}
              <NewsletterSection 
                translations={translations} 
                binanceReferralUrl={binanceReferralUrl}
              />
            </div>
          );
        default:
          return <HomePage {...commonProps} />;
      }
    };

    return (
      <div className="page-container">
        <div className="page-content">
          <Suspense fallback={
            <div className="min-h-screen flex items-center justify-center">
              <LoadingSpinner size="large" message="Loading content..." />
            </div>
          }>
            {getRouteComponent()}
          </Suspense>
        </div>
      </div>
    );
  } catch (error) {
    console.error('❌ Error rendering route:', error);
    return (
      <div className="page-container">
        <div className="page-content">
          <div className="page-section text-center">
            <h2 className="text-2xl font-bold mb-4">Something went wrong</h2>
            <p className="text-warm-slate mb-6">
              We're experiencing technical difficulties. Please try refreshing the page.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="btn-teal px-8 py-3"
            >
              Refresh Page
            </button>
          </div>
        </div>
      </div>
    );
  }
}