import { Loader2, TrendingUp, Brain, Activity } from 'lucide-react';

interface LoadingSpinnerProps {
  size?: 'small' | 'medium' | 'large';
  variant?: 'default' | 'trading' | 'ai' | 'minimal';
  message?: string;
  className?: string;
}

export function LoadingSpinner({ 
  size = 'medium', 
  variant = 'default',
  message,
  className = ''
}: LoadingSpinnerProps) {
  
  const sizeClasses = {
    small: 'w-4 h-4',
    medium: 'w-8 h-8',
    large: 'w-12 h-12'
  };

  const containerSizeClasses = {
    small: 'gap-2',
    medium: 'gap-3',
    large: 'gap-4'
  };

  const textSizeClasses = {
    small: 'text-sm',
    medium: 'text-base',
    large: 'text-lg'
  };

  const renderSpinner = () => {
    switch (variant) {
      case 'trading':
        return (
          <div className="relative">
            <TrendingUp className={`${sizeClasses[size]} text-soft-teal animate-bounce`} />
            <div className="absolute inset-0 border-2 border-soft-teal/20 border-t-soft-teal rounded-full animate-spin"></div>
          </div>
        );
        
      case 'ai':
        return (
          <div className="relative">
            <Brain className={`${sizeClasses[size]} text-subtle-lavender animate-pulse`} />
            <div className="absolute inset-0 border-2 border-subtle-lavender/20 border-t-subtle-lavender rounded-full animate-spin"></div>
          </div>
        );
        
      case 'minimal':
        return (
          <div className={`border-2 border-warm-slate/20 border-t-soft-teal rounded-full animate-spin ${sizeClasses[size]}`}></div>
        );
        
      default:
        return (
          <Loader2 className={`${sizeClasses[size]} animate-spin text-soft-teal`} />
        );
    }
  };

  return (
    <div className={`flex flex-col items-center justify-center ${containerSizeClasses[size]} ${className}`}>
      {renderSpinner()}
      {message && (
        <p className={`text-warm-slate font-medium ${textSizeClasses[size]} animate-pulse`}>
          {message}
        </p>
      )}
    </div>
  );
}

// Specialized loading components for different contexts
export function SignalLoadingSpinner({ message = "Generating AI signals..." }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center p-8">
      <div className="relative mb-4">
        <div className="w-16 h-16 border-4 border-soft-teal/20 border-t-soft-teal rounded-full animate-spin"></div>
        <Activity className="w-8 h-8 text-soft-teal absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 animate-pulse" />
      </div>
      <p className="text-warm-slate font-medium text-center">{message}</p>
      <div className="flex gap-1 mt-3">
        <div className="w-2 h-2 bg-soft-teal rounded-full animate-bounce"></div>
        <div className="w-2 h-2 bg-soft-teal rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
        <div className="w-2 h-2 bg-soft-teal rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
      </div>
    </div>
  );
}

export function PageLoadingSpinner() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-pearl-blue">
      <div className="text-center">
        <div className="relative mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-soft-teal to-soft-teal-light rounded-3xl flex items-center justify-center shadow-glow-dark animate-float">
            <TrendingUp className="w-10 h-10 text-pearl-white" />
          </div>
          <div className="absolute inset-0 border-4 border-soft-teal/20 border-t-soft-teal rounded-3xl animate-spin"></div>
        </div>
        <h2 className="text-2xl font-bold text-deep-ocean mb-2">
          Invest-Free<span className="text-soft-teal">.com</span>
        </h2>
        <p className="text-warm-slate font-medium">Loading your trading platform...</p>
      </div>
    </div>
  );
}