import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Play, BookOpen, TrendingUp, Shield, Zap } from 'lucide-react';

interface EducationSectionProps {
  translations: any;
}

export function EducationSection({ translations }: EducationSectionProps) {
  const features = [
    {
      icon: Shield,
      title: "Secure & Trusted",
      description: "Industry-leading security with SAFU fund protection"
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Execute trades in milliseconds with our advanced engine"
    },
    {
      icon: TrendingUp,
      title: "Low Fees",
      description: "Competitive trading fees starting from 0.1%"
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl text-gray-900">
            {translations.educationTitle}
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {translations.educationSubtitle}
          </p>
        </div>

        <div className="grid gap-12 lg:grid-cols-2 items-center">
          <div>
            <Card className="relative overflow-hidden border-0 shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-gray-800"></div>
              <CardContent className="relative p-0">
                <div className="aspect-video flex items-center justify-center text-white">
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto backdrop-blur-sm">
                      <Play className="w-8 h-8 ml-1" />
                    </div>
                    <div>
                      <h3 className="text-xl mb-2">What is Binance?</h3>
                      <p className="text-gray-300">Learn the basics in 3 minutes</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="mt-6 flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="flex-1">
                <Play className="w-4 h-4 mr-2" />
                {translations.watchVideo}
              </Button>
              <Button variant="outline" size="lg" className="flex-1">
                <BookOpen className="w-4 h-4 mr-2" />
                {translations.learnMore}
              </Button>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h3 className="text-2xl mb-6 text-gray-900">Why Choose Binance?</h3>
              <div className="space-y-6">
                {features.map((feature, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center shrink-0">
                      <feature.icon className="w-6 h-6 text-amber-600" />
                    </div>
                    <div>
                      <h4 className="text-lg mb-2 text-gray-900">{feature.title}</h4>
                      <p className="text-gray-600">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Card className="bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-amber-800">
                  <BookOpen className="w-5 h-5" />
                  Free Learning Resources
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-amber-700">
                  <li>• Crypto fundamentals course</li>
                  <li>• Trading strategies guide</li>
                  <li>• Risk management tutorials</li>
                  <li>• Market analysis tools</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}