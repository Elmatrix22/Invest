import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { 
  Search, 
  ChevronDown, 
  ChevronUp, 
  HelpCircle, 
  Brain, 
  DollarSign, 
  TrendingUp, 
  Users, 
  Shield, 
  ExternalLink,
  Lightbulb,
  Target,
  Clock,
  CheckCircle,
  MessageCircle
} from 'lucide-react';

interface FAQPageProps {
  translations: any;
  binanceReferralUrl: string;
  onShowAuthModal: () => void;
}

interface FAQItem {
  id: string;
  category: string;
  question: string;
  answer: string;
  popular: boolean;
}

export function FAQPage({ translations, binanceReferralUrl, onShowAuthModal }: FAQPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [expandedItems, setExpandedItems] = useState<string[]>(['faq-1', 'faq-2']); // Start with some expanded

  const faqData: FAQItem[] = [
    {
      id: 'faq-1',
      category: 'bonus',
      question: 'How do I claim my $100 Binance bonus?',
      answer: 'Getting your $100 bonus is simple! 1) Register for free on our platform, 2) Click any "Trade on Binance" button, 3) Complete Binance registration using our link, 4) Your bonus is automatically credited within 24 hours. No minimum deposit required!',
      popular: true
    },
    {
      id: 'faq-2',
      category: 'signals',
      question: 'Are your AI trading signals really free forever?',
      answer: 'Yes, absolutely! All our AI trading signals are 100% free with no hidden costs, subscription fees, or premium tiers. We make money through our Binance partnership when you trade, so we\'re aligned with your success. You get lifetime access to all signals just by registering.',
      popular: true
    },
    {
      id: 'faq-3',
      category: 'signals',
      question: 'What is your signal accuracy rate?',
      answer: 'Our current overall accuracy rate is 84% across all asset classes (crypto, forex, stocks, commodities). We track and publish all signal performance transparently. Crypto signals: 87%, Forex: 82%, Stocks: 85%, Commodities: 81%. All data is updated daily.',
      popular: true
    },
    {
      id: 'faq-4',
      category: 'platform',
      question: 'Do I need to use Binance to benefit from your signals?',
      answer: 'Not at all! While we recommend Binance for the best experience and $100 bonus, you can use our signals with any broker or exchange. Our signals include entry prices, targets, and stop-losses that work on any platform.',
      popular: false
    },
    {
      id: 'faq-5',
      category: 'business',
      question: 'How do I submit my business idea for investment?',
      answer: 'Go to the Business Ideas section and click "Share Your Project." Fill out the form with your project details, business model, funding needs, and upload photos/videos. Our team reviews submissions weekly for inclusion in the top 50 rotation.',
      popular: false
    },
    {
      id: 'faq-6',
      category: 'signals',
      question: 'How often do you post trading signals?',
      answer: 'We post 40-50 signals daily across all asset classes. Crypto: 15-20 signals, Forex: 10-15 signals, Stocks: 8-12 signals, Commodities: 5-8 signals. High-priority signals are sent via push notifications.',
      popular: true
    },
    {
      id: 'faq-7',
      category: 'platform',
      question: 'Is registration really required for signal access?',
      answer: 'Yes, registration is required to access our full signal database and business investment opportunities. This helps us provide personalized recommendations and track performance for you. Registration is free and takes only 2 minutes.',
      popular: false
    },
    {
      id: 'faq-8',
      category: 'bonus',
      question: 'Are there any restrictions on the $100 Binance bonus?',
      answer: 'The bonus has minimal restrictions: 1) Must be a new Binance user, 2) Complete KYC verification, 3) Bonus is credited as trading credits (not withdrawable cash), 4) Valid for all trading pairs. No minimum deposit or trading volume required.',
      popular: false
    },
    {
      id: 'faq-9',
      category: 'signals',
      question: 'What makes your AI signals different from others?',
      answer: 'Our AI analyzes 500+ market indicators in real-time, including technical patterns, sentiment analysis, whale movements, news impact, and macro economic factors. We use machine learning models trained on 10+ years of market data with continuous optimization.',
      popular: false
    },
    {
      id: 'faq-10',
      category: 'platform',
      question: 'Can I use the platform on mobile devices?',
      answer: 'Absolutely! Our platform is fully responsive and works perfectly on smartphones and tablets. We also have push notifications for urgent signals. The AI chat assistant is available 24/7 on mobile for instant help.',
      popular: false
    },
    {
      id: 'faq-11',
      category: 'business',
      question: 'What types of business ideas do you feature?',
      answer: 'We feature all types: Tech startups, crypto projects, real estate investments, e-commerce businesses, AI/ML ventures, green energy, fintech, and traditional businesses. Each week we rotate the top 50 most promising opportunities.',
      popular: false
    },
    {
      id: 'faq-12',
      category: 'signals',
      question: 'Do you provide risk management guidance?',
      answer: 'Yes! Every signal includes risk level assessment, recommended position size (% of portfolio), stop-loss levels, and risk-reward ratios. We also provide educational content on risk management best practices.',
      popular: false
    },
    {
      id: 'faq-13',
      category: 'platform',
      question: 'How do I contact support if I need help?',
      answer: 'Multiple ways: 1) AI chat assistant (24/7 instant help), 2) Live chat support, 3) Email support@invest-free.com, 4) Community forum. Average response time is under 2 hours, AI assistant responds immediately.',
      popular: false
    },
    {
      id: 'faq-14',
      category: 'bonus',
      question: 'Can I get multiple $100 bonuses?',
      answer: 'The $100 Binance bonus is a one-time offer per person. However, we occasionally run special promotions and referral bonuses. Following us and staying active in the community ensures you don\'t miss additional opportunities.',
      popular: false
    },
    {
      id: 'faq-15',
      category: 'signals',
      question: 'Do you offer signals for specific trading strategies?',
      answer: 'Yes! We categorize signals by strategy: Scalping (minutes-hours), Swing trading (days-weeks), Position trading (weeks-months), and DCA strategies. You can filter signals by your preferred trading style and timeframe.',
      popular: false
    }
  ];

  const categories = [
    { id: 'all', name: 'All Topics', icon: HelpCircle, count: faqData.length },
    { id: 'signals', name: 'Trading Signals', icon: TrendingUp, count: faqData.filter(f => f.category === 'signals').length },
    { id: 'bonus', name: '$100 Bonus', icon: DollarSign, count: faqData.filter(f => f.category === 'bonus').length },
    { id: 'platform', name: 'Platform', icon: Brain, count: faqData.filter(f => f.category === 'platform').length },
    { id: 'business', name: 'Business Ideas', icon: Lightbulb, count: faqData.filter(f => f.category === 'business').length }
  ];

  const filteredFAQs = faqData.filter(faq => {
    const matchesCategory = selectedCategory === 'all' || faq.category === selectedCategory;
    const matchesSearch = faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const popularFAQs = faqData.filter(faq => faq.popular);

  const toggleExpanded = (id: string) => {
    setExpandedItems(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-old-money-navy">Frequently Asked Questions</h1>
        <p className="text-xl text-old-money-warm-gray max-w-3xl mx-auto">
          Get instant answers to common questions about our FREE AI trading signals, 
          $100 Binance bonus, and business investment opportunities.
        </p>
        <Badge className="bg-old-money-sage text-old-money-cream">
          <Clock className="w-4 h-4 mr-2" />
          Updated Daily • 24/7 AI Support Available
        </Badge>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="text-center border-old-money-beige">
          <CardContent className="p-4">
            <HelpCircle className="w-6 h-6 text-old-money-navy mx-auto mb-2" />
            <div className="text-2xl font-bold text-old-money-navy">{faqData.length}</div>
            <div className="text-sm text-old-money-warm-gray">Total FAQs</div>
          </CardContent>
        </Card>
        <Card className="text-center border-old-money-beige">
          <CardContent className="p-4">
            <Users className="w-6 h-6 text-old-money-sage mx-auto mb-2" />
            <div className="text-2xl font-bold text-old-money-sage">125K+</div>
            <div className="text-sm text-old-money-warm-gray">Members Helped</div>
          </CardContent>
        </Card>
        <Card className="text-center border-old-money-beige">
          <CardContent className="p-4">
            <MessageCircle className="w-6 h-6 text-old-money-gold mx-auto mb-2" />
            <div className="text-2xl font-bold text-old-money-gold">24/7</div>
            <div className="text-sm text-old-money-warm-gray">AI Support</div>
          </CardContent>
        </Card>
        <Card className="text-center border-old-money-beige">
          <CardContent className="p-4">
            <CheckCircle className="w-6 h-6 text-old-money-burgundy mx-auto mb-2" />
            <div className="text-2xl font-bold text-old-money-burgundy">2 min</div>
            <div className="text-sm text-old-money-warm-gray">Avg Response</div>
          </CardContent>
        </Card>
      </div>

      {/* Popular FAQs */}
      <div>
        <h2 className="text-2xl font-bold text-old-money-navy mb-6 flex items-center gap-2">
          <Target className="w-6 h-6 text-old-money-burgundy" />
          Most Popular Questions
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          {popularFAQs.slice(0, 4).map((faq) => (
            <Card key={faq.id} className="border-old-money-beige hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <h3 className="font-bold text-old-money-navy mb-3 flex items-start gap-2">
                  <Badge className="bg-old-money-burgundy text-old-money-cream text-xs">Popular</Badge>
                  {faq.question}
                </h3>
                <p className="text-old-money-warm-gray text-sm leading-relaxed">{faq.answer}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Search and Filter */}
      <div className="space-y-4">
        <div className="relative max-w-lg mx-auto">
          <Search className="absolute left-3 top-3 h-5 w-5 text-old-money-warm-gray" />
          <Input
            placeholder="Search FAQ questions and answers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 border-2 border-old-money-warm-gray focus:border-old-money-gold"
          />
        </div>

        <div className="flex flex-wrap gap-2 justify-center">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center gap-2 ${
                selectedCategory === category.id 
                  ? 'bg-old-money-navy text-old-money-cream' 
                  : 'border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark'
              }`}
            >
              <category.icon className="w-4 h-4" />
              {category.name}
              <Badge variant="secondary" className="text-xs ml-1">
                {category.count}
              </Badge>
            </Button>
          ))}
        </div>
      </div>

      {/* FAQ List */}
      <div>
        <h2 className="text-2xl font-bold text-old-money-navy mb-6">
          All Questions ({filteredFAQs.length})
        </h2>
        
        {filteredFAQs.length === 0 ? (
          <Card className="text-center p-12 border-old-money-beige">
            <HelpCircle className="w-16 h-16 text-old-money-warm-gray mx-auto mb-4" />
            <h3 className="text-xl font-medium text-old-money-navy mb-2">No matching questions found</h3>
            <p className="text-old-money-warm-gray mb-4">Try adjusting your search or browse different categories</p>
            <Button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
            >
              Reset Filters
            </Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredFAQs.map((faq) => (
              <Card key={faq.id} className="border-old-money-beige">
                <CardContent className="p-0">
                  <button
                    onClick={() => toggleExpanded(faq.id)}
                    className="w-full p-6 text-left hover:bg-old-money-cream-dark transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="flex-shrink-0 mt-1">
                          {faq.popular && (
                            <Badge className="bg-old-money-burgundy text-old-money-cream text-xs mr-2">
                              Popular
                            </Badge>
                          )}
                          <Badge variant="outline" className="text-xs border-old-money-warm-gray">
                            {categories.find(c => c.id === faq.category)?.name}
                          </Badge>
                        </div>
                        <h3 className="font-bold text-old-money-navy text-lg leading-tight">
                          {faq.question}
                        </h3>
                      </div>
                      <div className="flex-shrink-0 ml-4">
                        {expandedItems.includes(faq.id) ? (
                          <ChevronUp className="w-5 h-5 text-old-money-warm-gray" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-old-money-warm-gray" />
                        )}
                      </div>
                    </div>
                  </button>
                  
                  {expandedItems.includes(faq.id) && (
                    <div className="px-6 pb-6">
                      <div className="border-t border-old-money-beige pt-4">
                        <p className="text-old-money-warm-gray leading-relaxed">
                          {faq.answer}
                        </p>
                        
                        {/* Action buttons for specific categories */}
                        {faq.category === 'bonus' && (
                          <div className="mt-4">
                            <Button
                              onClick={handleBinanceClick}
                              className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy"
                            >
                              <ExternalLink className="w-4 h-4 mr-2" />
                              Claim $100 Bonus Now
                            </Button>
                          </div>
                        )}
                        
                        {faq.category === 'signals' && (
                          <div className="mt-4">
                            <Button
                              onClick={onShowAuthModal}
                              className="bg-old-money-burgundy hover:bg-old-money-burgundy-light text-old-money-cream"
                            >
                              <TrendingUp className="w-4 h-4 mr-2" />
                              Get Free Signals
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* CTA Section */}
      <Card className="bg-gradient-to-r from-old-money-burgundy to-old-money-sage text-old-money-cream">
        <CardContent className="p-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Still Have Questions?</h2>
          <p className="text-xl mb-6 max-w-2xl mx-auto">
            Our AI assistant is available 24/7 for instant help, or join our community 
            of 125,000+ traders for peer support.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-old-money-cream hover:bg-white text-old-money-burgundy font-bold px-8 py-4"
            >
              <MessageCircle className="w-6 h-6 mr-3" />
              Chat with AI Assistant
            </Button>
            <Button
              size="lg"
              onClick={onShowAuthModal}
              variant="outline"
              className="border-old-money-cream text-old-money-cream hover:bg-old-money-cream hover:text-old-money-burgundy font-bold px-8 py-4"
            >
              <Users className="w-6 h-6 mr-3" />
              Join Community
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}