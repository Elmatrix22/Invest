import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar } from './ui/calendar';
import { BlogArticleCard } from './BlogArticleCard';
import { BlogArticleModal } from './BlogArticleModal';
import { blogArticles, blogCategories, BlogArticle } from '../utils/blogData';
import { 
  BookOpen,
  Eye,
  Star,
  ExternalLink,
  Signal,
  Search,
  Calendar as CalendarIcon,
  Archive,
  TrendingUp,
  Clock,
  Filter,
  ChevronRight,
  Newspaper,
  Brain,
  Gift,
  Zap
} from 'lucide-react';

interface BlogArticlesProps {
  translations: any;
  binanceReferralUrl: string;
}

interface DateArchive {
  month: string;
  year: number;
  count: number;
  articles: BlogArticle[];
}

// Generate additional blog articles for weekly rotation
const generateWeeklyBlogArticles = (): BlogArticle[] => {
  const weeklyTopics = [
    // Week 1 - Current market analysis
    {
      title: "Crypto Market Weekly Outlook: Bullish Signals Emerge",
      category: "Market Analysis",
      excerpt: "Technical analysis shows bullish momentum building across major cryptocurrencies. Key support levels hold strong while institutional buying continues.",
      author: "MarketAnalyst2025"
    },
    // Week 2 - Trading strategies
    {
      title: "Advanced Scalping Strategy: 1-Minute Chart Mastery",
      category: "Technical Analysis", 
      excerpt: "Master profitable scalping with our proven 1-minute chart strategy. Learn entry signals, risk management, and optimal timeframes for day trading success.",
      author: "ScalpingPro"
    },
    // Week 3 - DeFi updates
    {
      title: "New DeFi Opportunities: Yield Farming Strategies for 2025",
      category: "DeFi",
      excerpt: "Discover emerging DeFi protocols offering 20%+ APY safely. Complete guide to new yield farming opportunities and risk assessment.",
      author: "DeFiResearcher"
    },
    // Week 4 - Psychology and mindset
    {
      title: "The Millionaire Trader Mindset: 7 Habits of Highly Successful Traders",
      category: "Psychology",
      excerpt: "Learn the mental frameworks and daily habits that separate millionaire traders from the masses. Psychology accounts for 80% of trading success.",
      author: "TradingMentorPro"
    }
  ];

  const currentWeek = Math.floor(Date.now() / (7 * 24 * 60 * 60 * 1000)) % 4;
  const weeklyArticles: BlogArticle[] = [];
  
  // Generate 12 weeks worth of articles (3 months rotation)
  for (let week = 0; week < 12; week++) {
    const topicIndex = week % weeklyTopics.length;
    const topic = weeklyTopics[topicIndex];
    const weekOffset = week - currentWeek;
    const publishDate = new Date();
    publishDate.setDate(publishDate.getDate() + (weekOffset * 7));
    
    weeklyArticles.push({
      id: 1000 + week,
      title: `${topic.title} - Week ${week + 1}`,
      slug: `${topic.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-week-${week + 1}`,
      excerpt: topic.excerpt,
      content: `
        <h2>${topic.title}</h2>
        <p>This week's analysis focuses on current market conditions and emerging opportunities.</p>
        <h3>Key Highlights This Week</h3>
        <ul>
          <li>Market sentiment analysis and trend assessment</li>
          <li>New trading opportunities identified</li>
          <li>Risk management updates and alerts</li>
          <li>Platform updates and feature releases</li>
        </ul>
        <div class="cta-box">
          <h4>Stay Updated with Weekly Insights</h4>
          <p>Join our community to receive weekly market analysis and trading opportunities delivered to your inbox.</p>
        </div>
      `,
      author: topic.author,
      publishDate: publishDate.toISOString().split('T')[0],
      readTime: `${8 + week % 5} min`,
      category: topic.category,
      tags: ['weekly update', 'market analysis', 'trading signals'],
      featured: week < 3, // Feature latest 3 weeks
      views: Math.floor(Math.random() * 5000) + 1000,
      seoTitle: `${topic.title} | Weekly Market Update | Trading Insights`,
      seoDescription: topic.excerpt,
      seoKeywords: ['weekly analysis', 'crypto market', 'trading signals', 'market outlook']
    });
  }
  
  return weeklyArticles;
};

function BlogArticles({ translations, binanceReferralUrl }: BlogArticlesProps) {
  const [selectedArticle, setSelectedArticle] = useState<BlogArticle | null>(null);
  const [showArticle, setShowArticle] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [activeTab, setActiveTab] = useState('latest');
  const [allArticles, setAllArticles] = useState<BlogArticle[]>([]);
  const [dateArchives, setDateArchives] = useState<DateArchive[]>([]);

  // Initialize articles with weekly updates
  useEffect(() => {
    const weeklyArticles = generateWeeklyBlogArticles();
    const combinedArticles = [...weeklyArticles, ...blogArticles].sort((a, b) => 
      new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime()
    );
    setAllArticles(combinedArticles);

    // Generate date archives
    const archives: { [key: string]: DateArchive } = {};
    combinedArticles.forEach(article => {
      const date = new Date(article.publishDate);
      const monthKey = `${date.getFullYear()}-${date.getMonth()}`;
      const monthName = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      
      if (!archives[monthKey]) {
        archives[monthKey] = {
          month: monthName,
          year: date.getFullYear(),
          count: 0,
          articles: []
        };
      }
      archives[monthKey].count++;
      archives[monthKey].articles.push(article);
    });

    setDateArchives(Object.values(archives).sort((a, b) => 
      new Date(b.year, b.month.indexOf(' ')) - new Date(a.year, a.month.indexOf(' '))
    ));
  }, []);

  // Auto-update every week
  useEffect(() => {
    const checkForWeeklyUpdate = () => {
      const lastUpdate = localStorage.getItem('blogLastUpdate');
      const currentTime = Date.now();
      const oneWeek = 7 * 24 * 60 * 60 * 1000;
      
      if (!lastUpdate || currentTime - parseInt(lastUpdate) > oneWeek) {
        // Simulate new weekly content
        const weeklyArticles = generateWeeklyBlogArticles();
        const combinedArticles = [...weeklyArticles, ...blogArticles].sort((a, b) => 
          new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime()
        );
        setAllArticles(combinedArticles);
        localStorage.setItem('blogLastUpdate', currentTime.toString());
      }
    };

    checkForWeeklyUpdate();
    const interval = setInterval(checkForWeeklyUpdate, 24 * 60 * 60 * 1000); // Check daily
    return () => clearInterval(interval);
  }, []);

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  // Filter articles based on search, category, and date
  const filteredArticles = allArticles.filter(article => {
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    const matchesSearch = searchQuery === '' || 
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesDate = !selectedDate || 
      new Date(article.publishDate).toDateString() === selectedDate.toDateString();
    
    return matchesCategory && matchesSearch && matchesDate;
  });

  const featuredArticles = allArticles.filter(article => article.featured).slice(0, 6);
  const recentArticles = allArticles.slice(0, 12);
  const popularArticles = allArticles.sort((a, b) => b.views - a.views).slice(0, 8);

  const handleReadMore = (article: BlogArticle) => {
    setSelectedArticle(article);
    setShowArticle(true);
  };

  const handleShare = (article: BlogArticle) => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.excerpt,
        url: window.location.href + '#' + article.slug
      });
    } else {
      navigator.clipboard.writeText(window.location.href + '#' + article.slug);
    }
  };

  const totalViews = allArticles.reduce((sum, article) => sum + article.views, 0);
  const weeklyArticles = allArticles.filter(article => {
    const articleDate = new Date(article.publishDate);
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return articleDate > weekAgo;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Enhanced Blog Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="w-12 h-12 bg-gradient-to-br from-old-money-burgundy to-old-money-sage rounded-full flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-old-money-cream" />
          </div>
          <h1 className="text-4xl font-bold text-old-money-navy">Trading & Investment Blog</h1>
          <Badge className="bg-old-money-sage text-old-money-cream">
            <Zap className="w-3 h-3 mr-1" />
            Updated Weekly
          </Badge>
        </div>
        <p className="text-xl text-old-money-warm-gray max-w-4xl mx-auto mb-6">
          Expert insights, strategies, and education to master crypto, forex, and binary options trading. 
          Fresh content added every week with the latest market analysis and trading opportunities.
        </p>
        
        {/* Enhanced Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
          <Card className="border-old-money-beige">
            <CardContent className="p-4 text-center">
              <BookOpen className="w-6 h-6 text-old-money-burgundy mx-auto mb-2" />
              <div className="text-2xl font-bold text-old-money-navy">{allArticles.length}</div>
              <div className="text-sm text-old-money-warm-gray">Total Articles</div>
            </CardContent>
          </Card>
          <Card className="border-old-money-beige">
            <CardContent className="p-4 text-center">
              <Eye className="w-6 h-6 text-old-money-sage mx-auto mb-2" />
              <div className="text-2xl font-bold text-old-money-navy">{Math.round(totalViews / 1000)}K+</div>
              <div className="text-sm text-old-money-warm-gray">Monthly Readers</div>
            </CardContent>
          </Card>
          <Card className="border-old-money-beige">
            <CardContent className="p-4 text-center">
              <Clock className="w-6 h-6 text-old-money-gold mx-auto mb-2" />
              <div className="text-2xl font-bold text-old-money-navy">{weeklyArticles.length}</div>
              <div className="text-sm text-old-money-warm-gray">This Week</div>
            </CardContent>
          </Card>
          <Card className="border-old-money-beige">
            <CardContent className="p-4 text-center">
              <Star className="w-6 h-6 text-old-money-burgundy mx-auto mb-2" />
              <div className="text-2xl font-bold text-old-money-navy">Expert</div>
              <div className="text-sm text-old-money-warm-gray">Analysis</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Weekly Update Banner */}
      <Card className="mb-8 bg-gradient-to-r from-old-money-sage/10 to-old-money-burgundy/10 border-old-money-sage">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-old-money-sage rounded-full flex items-center justify-center">
                <Newspaper className="w-6 h-6 text-old-money-cream" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-old-money-navy">🔄 Weekly Auto-Updates</h3>
                <p className="text-old-money-warm-gray">
                  Fresh trading insights and market analysis added every Monday. 
                  {weeklyArticles.length} new articles this week!
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-old-money-sage">{weeklyArticles.length}</div>
              <div className="text-sm text-old-money-warm-gray">New This Week</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filters */}
      <div className="mb-8 space-y-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-old-money-warm-gray" />
              <Input
                placeholder="Search articles by title, content, or tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-2 border-old-money-warm-gray focus:border-old-money-sage"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-old-money-warm-gray" />
            <span className="text-sm font-medium text-old-money-navy">Filters:</span>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2">
          {blogCategories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className={selectedCategory === category 
                ? 'bg-old-money-navy text-old-money-cream' 
                : 'border-old-money-warm-gray text-old-money-warm-gray hover:bg-old-money-cream-dark'
              }
            >
              {category === 'all' ? 'All Categories' : category}
              <Badge variant="secondary" className="text-xs ml-2">
                {category === 'all' 
                  ? allArticles.length 
                  : allArticles.filter(a => a.category === category).length
                }
              </Badge>
            </Button>
          ))}
        </div>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 max-w-lg mx-auto mb-8 bg-old-money-cream-dark border border-old-money-beige">
          <TabsTrigger value="latest" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Latest
          </TabsTrigger>
          <TabsTrigger value="featured" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Featured
          </TabsTrigger>
          <TabsTrigger value="popular" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Popular
          </TabsTrigger>
          <TabsTrigger value="archive" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Archive
          </TabsTrigger>
        </TabsList>

        <TabsContent value="latest">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles.slice(0, 12).map((article) => (
              <BlogArticleCard
                key={article.id}
                article={article}
                onReadMore={handleReadMore}
                onShare={handleShare}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="featured">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredArticles.map((article) => (
              <BlogArticleCard
                key={article.id}
                article={article}
                onReadMore={handleReadMore}
                onShare={handleShare}
                featured={true}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="popular">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {popularArticles.map((article) => (
              <BlogArticleCard
                key={article.id}
                article={article}
                onReadMore={handleReadMore}
                onShare={handleShare}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="archive">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Date Archive Sidebar */}
            <div className="lg:col-span-1">
              <Card className="border-old-money-beige">
                <CardHeader>
                  <CardTitle className="text-old-money-navy flex items-center gap-2">
                    <Archive className="w-5 h-5" />
                    Date Archive
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {dateArchives.map((archive, index) => (
                      <div key={index} className="border-b border-old-money-beige pb-3 last:border-b-0">
                        <div className="flex items-center justify-between">
                          <button className="text-left hover:text-old-money-sage transition-colors">
                            <div className="font-medium text-old-money-navy">{archive.month}</div>
                            <div className="text-sm text-old-money-warm-gray">{archive.count} articles</div>
                          </button>
                          <ChevronRight className="w-4 h-4 text-old-money-warm-gray" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Calendar Widget */}
              <Card className="border-old-money-beige mt-6">
                <CardHeader>
                  <CardTitle className="text-old-money-navy flex items-center gap-2">
                    <CalendarIcon className="w-5 h-5" />
                    Browse by Date
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    className="rounded-md border border-old-money-beige"
                  />
                  {selectedDate && (
                    <div className="mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedDate(undefined)}
                        className="w-full border-old-money-warm-gray"
                      >
                        Clear Date Filter
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Archive Articles */}
            <div className="lg:col-span-3">
              {selectedDate ? (
                <div>
                  <h3 className="text-xl font-bold text-old-money-navy mb-6">
                    Articles from {selectedDate.toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    {filteredArticles.map((article) => (
                      <BlogArticleCard
                        key={article.id}
                        article={article}
                        onReadMore={handleReadMore}
                        onShare={handleShare}
                      />
                    ))}
                  </div>
                  {filteredArticles.length === 0 && (
                    <div className="text-center py-12">
                      <CalendarIcon className="w-16 h-16 text-old-money-warm-gray mx-auto mb-4" />
                      <h3 className="text-xl font-medium text-old-money-navy mb-2">No articles found</h3>
                      <p className="text-old-money-warm-gray">No articles were published on this date</p>
                    </div>
                  )}
                </div>
              ) : (
                <div>
                  <h3 className="text-xl font-bold text-old-money-navy mb-6">
                    Browse Articles by Month
                  </h3>
                  <div className="space-y-8">
                    {dateArchives.map((archive, index) => (
                      <div key={index}>
                        <h4 className="text-lg font-medium text-old-money-navy mb-4 flex items-center gap-2">
                          <CalendarIcon className="w-5 h-5" />
                          {archive.month}
                          <Badge variant="outline" className="text-xs border-old-money-warm-gray">
                            {archive.count} articles
                          </Badge>
                        </h4>
                        <div className="grid md:grid-cols-2 gap-4">
                          {archive.articles.slice(0, 4).map((article) => (
                            <BlogArticleCard
                              key={article.id}
                              article={article}
                              onReadMore={handleReadMore}
                              onShare={handleShare}
                            />
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Load More Button */}
      {activeTab === 'latest' && filteredArticles.length > 12 && (
        <div className="text-center mt-8">
          <Button variant="outline" size="lg" className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark">
            Load More Articles
          </Button>
        </div>
      )}

      {/* Enhanced CTA Section */}
      <div className="mt-12 space-y-6">
        {/* Trading CTA */}
        <Card className="bg-gradient-to-r from-old-money-navy to-old-money-charcoal text-old-money-cream">
          <CardContent className="p-8 text-center">
            <Brain className="w-16 h-16 mx-auto mb-6 text-old-money-gold" />
            <h3 className="text-3xl font-bold mb-4">Ready to Apply What You've Learned?</h3>
            <p className="text-xl mb-6 max-w-3xl mx-auto">
              Turn knowledge into profit with our FREE AI trading signals and start trading on the world's most trusted exchange.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={handleBinanceClick}
                className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy font-bold px-8 py-4"
              >
                <ExternalLink className="w-6 h-6 mr-3" />
                Start Trading on Binance + $100 Bonus
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-old-money-cream text-old-money-cream hover:bg-old-money-cream hover:text-old-money-navy font-bold px-8 py-4"
              >
                <Signal className="w-6 h-6 mr-3" />
                Get Free Trading Signals
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Newsletter Signup */}
        <Card className="bg-gradient-to-r from-old-money-sage/10 to-old-money-gold/10 border-old-money-sage">
          <CardContent className="p-8 text-center">
            <Newspaper className="w-12 h-12 text-old-money-sage mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-old-money-navy mb-4">
              📧 Get Weekly Trading Insights
            </h3>
            <p className="text-old-money-warm-gray mb-6 max-w-2xl mx-auto">
              Never miss our weekly market analysis, new trading strategies, and exclusive insights. 
              Join 125,000+ traders getting our free newsletter every Monday.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <Input
                placeholder="Enter your email address"
                className="border-old-money-sage focus:border-old-money-gold"
              />
              <Button className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream">
                <Gift className="w-4 h-4 mr-2" />
                Subscribe Free
              </Button>
            </div>
            <div className="text-sm text-old-money-warm-gray mt-3">
              ✅ Weekly market updates • ✅ Exclusive trading tips • ✅ No spam, unsubscribe anytime
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Article Reader Modal */}
      <BlogArticleModal
        article={selectedArticle}
        isOpen={showArticle}
        onClose={() => setShowArticle(false)}
      />
    </div>
  );
}

export default BlogArticles;