import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { 
  Signal, 
  TrendingUp, 
  TrendingDown, 
  Target, 
  Clock, 
  ExternalLink,
  Filter,
  BarChart3,
  Zap,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Star,
  Crown,
  Flame
} from 'lucide-react';

interface TradingSignal {
  id: string;
  coin: string;
  symbol: string;
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  currentPrice: number;
  entryPrice: number;
  targetPrice: number;
  stopLoss: number;
  platform: 'Binance' | 'KuCoin' | 'Bybit' | 'Coinbase';
  timeframe: '1h' | '4h' | '1d' | '1w';
  timestamp: string;
  change24h: number;
  volume: number;
  analysis: string;
  riskLevel: 'Low' | 'Medium' | 'High';
  accuracy?: number;
}

interface EnhancedTradingSignalsProps {
  translations: any;
  binanceReferralUrl: string;
}

export function EnhancedTradingSignals({ translations, binanceReferralUrl }: EnhancedTradingSignalsProps) {
  const [signals, setSignals] = useState<TradingSignal[]>([
    {
      id: '1',
      coin: 'Bitcoin',
      symbol: 'BTC',
      signal: 'BUY',
      confidence: 87,
      currentPrice: 98750,
      entryPrice: 98500,
      targetPrice: 105000,
      stopLoss: 95000,
      platform: 'Binance',
      timeframe: '4h',
      timestamp: new Date().toISOString(),
      change24h: 2.4,
      volume: 1250000000,
      analysis: 'Strong bullish momentum with institutional buying pressure. RSI oversold recovery expected.',
      riskLevel: 'Medium',
      accuracy: 89
    },
    {
      id: '2',
      coin: 'Ethereum',
      symbol: 'ETH',
      signal: 'BUY',
      confidence: 79,
      currentPrice: 3456,
      entryPrice: 3440,
      targetPrice: 3750,
      stopLoss: 3200,
      platform: 'Binance',
      timeframe: '1d',
      timestamp: new Date(Date.now() - 300000).toISOString(),
      change24h: 1.8,
      volume: 890000000,
      analysis: 'Breaking above key resistance. DeFi activity increasing significantly.',
      riskLevel: 'Low',
      accuracy: 82
    },
    {
      id: '3',
      coin: 'BNB',
      symbol: 'BNB',
      signal: 'HOLD',
      confidence: 65,
      currentPrice: 635,
      entryPrice: 630,
      targetPrice: 680,
      stopLoss: 600,
      platform: 'Binance',
      timeframe: '1h',
      timestamp: new Date(Date.now() - 600000).toISOString(),
      change24h: 0.8,
      volume: 45000000,
      analysis: 'Consolidating near resistance. Waiting for clearer direction signal.',
      riskLevel: 'Low',
      accuracy: 91
    },
    {
      id: '4',
      coin: 'Solana',
      symbol: 'SOL',
      signal: 'BUY',
      confidence: 84,
      currentPrice: 235,
      entryPrice: 232,
      targetPrice: 265,
      stopLoss: 220,
      platform: 'KuCoin',
      timeframe: '4h',
      timestamp: new Date(Date.now() - 900000).toISOString(),
      change24h: 4.2,
      volume: 78000000,
      analysis: 'DeFi ecosystem growth driving strong fundamentals. Technical breakout confirmed.',
      riskLevel: 'Medium',
      accuracy: 76
    },
    {
      id: '5',
      coin: 'Cardano',
      symbol: 'ADA',
      signal: 'SELL',
      confidence: 72,
      currentPrice: 0.89,
      entryPrice: 0.92,
      targetPrice: 0.82,
      stopLoss: 0.95,
      platform: 'Coinbase',
      timeframe: '1d',
      timestamp: new Date(Date.now() - 1200000).toISOString(),
      change24h: -2.1,
      volume: 156000000,
      analysis: 'Bearish divergence on daily chart. Profit-taking recommended.',
      riskLevel: 'High',
      accuracy: 68
    }
  ]);

  const [selectedPlatform, setSelectedPlatform] = useState('All');
  const [selectedTimeframe, setSelectedTimeframe] = useState('All');
  const [filteredSignals, setFilteredSignals] = useState(signals);

  // Performance data for charts
  const [performanceData] = useState([
    { day: 'Mon', winRate: 78, totalSignals: 45 },
    { day: 'Tue', winRate: 82, totalSignals: 52 },
    { day: 'Wed', winRate: 75, totalSignals: 48 },
    { day: 'Thu', winRate: 88, totalSignals: 41 },
    { day: 'Fri', winRate: 84, totalSignals: 55 },
    { day: 'Sat', winRate: 79, totalSignals: 38 },
    { day: 'Sun', winRate: 86, totalSignals: 42 }
  ]);

  const [platformStats] = useState([
    { platform: 'Binance', accuracy: 84, signals: 145, volume: '$2.1B' },
    { platform: 'KuCoin', accuracy: 79, signals: 89, volume: '$890M' },
    { platform: 'Bybit', accuracy: 81, signals: 76, volume: '$654M' },
    { platform: 'Coinbase', accuracy: 77, signals: 62, volume: '$567M' }
  ]);

  useEffect(() => {
    let filtered = signals;

    if (selectedPlatform !== 'All') {
      filtered = filtered.filter(signal => signal.platform === selectedPlatform);
    }

    if (selectedTimeframe !== 'All') {
      filtered = filtered.filter(signal => signal.timeframe === selectedTimeframe);
    }

    setFilteredSignals(filtered);
  }, [selectedPlatform, selectedTimeframe, signals]);

  // Simulate real-time price updates
  useEffect(() => {
    const interval = setInterval(() => {
      setSignals(prev => prev.map(signal => ({
        ...signal,
        currentPrice: signal.currentPrice * (1 + (Math.random() - 0.5) * 0.002), // ±0.1% fluctuation
        change24h: signal.change24h + (Math.random() - 0.5) * 0.1,
        timestamp: new Date().toISOString()
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case 'BUY': return 'bg-old-money-sage text-old-money-cream';
      case 'SELL': return 'bg-old-money-burgundy text-old-money-cream';
      case 'HOLD': return 'bg-old-money-gold text-old-money-navy';
      default: return 'bg-old-money-warm-gray text-old-money-cream';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Low': return 'text-old-money-sage';
      case 'Medium': return 'text-old-money-gold';
      case 'High': return 'text-old-money-burgundy';
      default: return 'text-old-money-warm-gray';
    }
  };

  const getPlatformIcon = (platform: string) => {
    // You could replace these with actual platform logos
    return platform.charAt(0);
  };

  const totalSignals = filteredSignals.length;
  const buySignals = filteredSignals.filter(s => s.signal === 'BUY').length;
  const avgAccuracy = filteredSignals.reduce((acc, signal) => acc + (signal.accuracy || 0), 0) / totalSignals || 0;
  const avgConfidence = filteredSignals.reduce((acc, signal) => acc + signal.confidence, 0) / totalSignals || 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-old-money-navy flex items-center gap-2">
            <Signal className="w-6 h-6 text-old-money-burgundy animate-pulse" />
            Live Trading Signals
          </h2>
          <p className="text-old-money-warm-gray">
            AI-powered signals with 84% accuracy across multiple platforms. Real-time analysis updated every minute.
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={handleBinanceClick}
            className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy font-bold"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Trade on Binance
          </Button>
        </div>
      </div>

      {/* Performance Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-sage">{totalSignals}</div>
            <div className="text-sm text-old-money-warm-gray">Active Signals</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-navy">{buySignals}</div>
            <div className="text-sm text-old-money-warm-gray">Buy Signals</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-burgundy">{avgAccuracy.toFixed(0)}%</div>
            <div className="text-sm text-old-money-warm-gray">Avg Accuracy</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-old-money-gold">{avgConfidence.toFixed(0)}%</div>
            <div className="text-sm text-old-money-warm-gray">Avg Confidence</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="signals" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-md bg-old-money-cream-dark border border-old-money-beige">
          <TabsTrigger value="signals" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Live Signals
          </TabsTrigger>
          <TabsTrigger value="performance" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Performance
          </TabsTrigger>
          <TabsTrigger value="platforms" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Platforms
          </TabsTrigger>
        </TabsList>

        <TabsContent value="signals" className="space-y-6">
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-old-money-warm-gray" />
              <span className="text-sm font-medium text-old-money-navy">Filters:</span>
            </div>
            
            <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
              <SelectTrigger className="w-[180px] border-old-money-warm-gray">
                <SelectValue placeholder="Select Platform" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Platforms</SelectItem>
                <SelectItem value="Binance">Binance</SelectItem>
                <SelectItem value="KuCoin">KuCoin</SelectItem>
                <SelectItem value="Bybit">Bybit</SelectItem>
                <SelectItem value="Coinbase">Coinbase</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-[180px] border-old-money-warm-gray">
                <SelectValue placeholder="Select Timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Timeframes</SelectItem>
                <SelectItem value="1h">1 Hour</SelectItem>
                <SelectItem value="4h">4 Hours</SelectItem>
                <SelectItem value="1d">1 Day</SelectItem>
                <SelectItem value="1w">1 Week</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center gap-2 ml-auto">
              <div className="w-2 h-2 bg-old-money-sage rounded-full animate-pulse"></div>
              <span className="text-sm text-old-money-warm-gray">Live Updates</span>
            </div>
          </div>

          {/* Signals Table */}
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <Target className="w-5 h-5 text-old-money-burgundy" />
                Live Trading Signals
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredSignals.map((signal) => (
                  <div key={signal.id} className="border border-old-money-beige rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="grid md:grid-cols-6 gap-4 items-center">
                      {/* Coin Info */}
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-old-money-gold rounded-full flex items-center justify-center">
                          <span className="text-old-money-navy text-sm font-bold">{signal.symbol}</span>
                        </div>
                        <div>
                          <div className="font-medium text-old-money-navy">{signal.coin}</div>
                          <div className="text-sm text-old-money-warm-gray">{signal.platform}</div>
                        </div>
                      </div>

                      {/* Signal & Confidence */}
                      <div className="text-center">
                        <Badge className={`${getSignalColor(signal.signal)} mb-1`}>
                          {signal.signal}
                        </Badge>
                        <div className="text-sm text-old-money-warm-gray">
                          {signal.confidence}% confidence
                        </div>
                        <Progress value={signal.confidence} className="h-2 mt-1" />
                      </div>

                      {/* Price Info */}
                      <div className="text-center">
                        <div className="font-bold text-old-money-navy">
                          ${signal.currentPrice.toLocaleString()}
                        </div>
                        <div className={`text-sm ${signal.change24h >= 0 ? 'text-old-money-sage' : 'text-old-money-burgundy'}`}>
                          {signal.change24h >= 0 ? '+' : ''}{signal.change24h.toFixed(1)}%
                        </div>
                      </div>

                      {/* Targets */}
                      <div className="text-center">
                        <div className="text-sm text-old-money-warm-gray">Target</div>
                        <div className="font-medium text-old-money-sage">
                          ${signal.targetPrice.toLocaleString()}
                        </div>
                        <div className="text-xs text-old-money-warm-gray">
                          SL: ${signal.stopLoss.toLocaleString()}
                        </div>
                      </div>

                      {/* Risk & Accuracy */}
                      <div className="text-center">
                        <div className={`text-sm font-medium ${getRiskColor(signal.riskLevel)}`}>
                          {signal.riskLevel} Risk
                        </div>
                        {signal.accuracy && (
                          <div className="text-sm text-old-money-warm-gray">
                            {signal.accuracy}% accurate
                          </div>
                        )}
                        <div className="text-xs text-old-money-warm-gray">
                          {signal.timeframe}
                        </div>
                      </div>

                      {/* Action */}
                      <div className="text-center">
                        <Button
                          size="sm"
                          onClick={handleBinanceClick}
                          className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream mb-2"
                        >
                          Trade Now
                        </Button>
                        <div className="text-xs text-old-money-warm-gray">
                          {new Date(signal.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>

                    {/* Analysis */}
                    <div className="mt-4 pt-4 border-t border-old-money-beige">
                      <div className="text-sm text-old-money-warm-gray">
                        <strong>Analysis:</strong> {signal.analysis}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          {/* 7-Day Performance Chart */}
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <BarChart3 className="w-5 h-5 text-old-money-sage" />
                7-Day Win Rate Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e8e2db" />
                    <XAxis dataKey="day" stroke="#8b8680" />
                    <YAxis stroke="#8b8680" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#f5f4f2', 
                        border: '1px solid #e8e2db',
                        borderRadius: '8px',
                        color: '#2c2b28'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="winRate" 
                      stroke="#8a9a85" 
                      strokeWidth={3}
                      dot={{ fill: "#8a9a85", strokeWidth: 2, r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Signal Volume Chart */}
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <BarChart3 className="w-5 h-5 text-old-money-burgundy" />
                Daily Signal Volume
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e8e2db" />
                    <XAxis dataKey="day" stroke="#8b8680" />
                    <YAxis stroke="#8b8680" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#f5f4f2', 
                        border: '1px solid #e8e2db',
                        borderRadius: '8px',
                        color: '#2c2b28'
                      }}
                    />
                    <Bar dataKey="totalSignals" fill="#7a4a47" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Performance Summary */}
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="border-old-money-beige bg-old-money-sage/10">
              <CardContent className="p-6 text-center">
                <CheckCircle className="w-12 h-12 text-old-money-sage mx-auto mb-4" />
                <div className="text-3xl font-bold text-old-money-sage mb-2">84%</div>
                <div className="text-old-money-navy font-medium">Overall Win Rate</div>
                <div className="text-sm text-old-money-warm-gray">Last 30 days</div>
              </CardContent>
            </Card>

            <Card className="border-old-money-beige bg-old-money-gold/10">
              <CardContent className="p-6 text-center">
                <Star className="w-12 h-12 text-old-money-gold mx-auto mb-4" />
                <div className="text-3xl font-bold text-old-money-gold mb-2">321</div>
                <div className="text-old-money-navy font-medium">Total Signals</div>
                <div className="text-sm text-old-money-warm-gray">This week</div>
              </CardContent>
            </Card>

            <Card className="border-old-money-beige bg-old-money-burgundy/10">
              <CardContent className="p-6 text-center">
                <Flame className="w-12 h-12 text-old-money-burgundy mx-auto mb-4" />
                <div className="text-3xl font-bold text-old-money-burgundy mb-2">12</div>
                <div className="text-old-money-navy font-medium">Win Streak</div>
                <div className="text-sm text-old-money-warm-gray">Current record</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="platforms" className="space-y-6">
          {/* Platform Comparison */}
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <Crown className="w-5 h-5 text-old-money-gold" />
                Platform Performance Comparison
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {platformStats.map((platform) => (
                  <div key={platform.platform} className="border border-old-money-beige rounded-lg p-4">
                    <div className="grid md:grid-cols-4 gap-4 items-center">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-old-money-navy rounded-full flex items-center justify-center">
                          <span className="text-old-money-cream font-bold">
                            {getPlatformIcon(platform.platform)}
                          </span>
                        </div>
                        <div>
                          <div className="font-medium text-old-money-navy">{platform.platform}</div>
                          <div className="text-sm text-old-money-warm-gray">
                            {platform.signals} signals
                          </div>
                        </div>
                      </div>

                      <div className="text-center">
                        <div className="text-2xl font-bold text-old-money-sage">
                          {platform.accuracy}%
                        </div>
                        <div className="text-sm text-old-money-warm-gray">Accuracy</div>
                        <Progress value={platform.accuracy} className="h-2 mt-2" />
                      </div>

                      <div className="text-center">
                        <div className="text-lg font-bold text-old-money-navy">
                          {platform.volume}
                        </div>
                        <div className="text-sm text-old-money-warm-gray">24h Volume</div>
                      </div>

                      <div className="text-center">
                        <Button
                          size="sm"
                          onClick={handleBinanceClick}
                          className={`${
                            platform.platform === 'Binance' 
                              ? 'bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy' 
                              : 'bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream'
                          }`}
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Trade
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Platform Benefits */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border-old-money-gold bg-old-money-gold/10">
              <CardHeader>
                <CardTitle className="text-old-money-navy">Why Choose Binance?</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-old-money-charcoal">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-old-money-sage" />
                    Lowest trading fees (0.1%)
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-old-money-sage" />
                    Highest liquidity & fastest execution
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-old-money-sage" />
                    Most comprehensive trading tools
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-old-money-sage" />
                    Best mobile trading experience
                  </li>
                </ul>
                <Button
                  className="w-full mt-4 bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy font-bold"
                  onClick={handleBinanceClick}
                >
                  Start Trading on Binance
                </Button>
              </CardContent>
            </Card>

            <Card className="border-old-money-beige">
              <CardHeader>
                <CardTitle className="text-old-money-navy">Signal Success Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-old-money-charcoal">
                  <li className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-old-money-burgundy" />
                    Always set stop-losses as recommended
                  </li>
                  <li className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-old-money-burgundy" />
                    Act quickly on high-confidence signals
                  </li>
                  <li className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-old-money-burgundy" />
                    Never risk more than 2% per trade
                  </li>
                  <li className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-old-money-burgundy" />
                    Track your performance consistently
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}