import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { MessageCircle, Phone, Mail } from 'lucide-react';

interface FAQSectionProps {
  translations: any;
}

export function FAQSection({ translations }: FAQSectionProps) {
  const faqData = [
    {
      category: "Getting Started",
      questions: [
        {
          question: "How do I claim my $100 welcome bonus?",
          answer: "Simply sign up for a free account, complete identity verification, and make your first deposit of $50 or more. Your $100 bonus will be automatically credited to your account within 24 hours."
        },
        {
          question: "What documents do I need for verification?",
          answer: "You'll need a valid government-issued photo ID (passport, driver's license, or national ID) and proof of address (utility bill or bank statement from the last 3 months)."
        },
        {
          question: "How long does account verification take?",
          answer: "Most accounts are verified within 24 hours. In some cases, it may take up to 3 business days. You'll receive email updates throughout the process."
        },
        {
          question: "What's the minimum deposit amount?",
          answer: "The minimum deposit is $50 for most payment methods. However, some methods may have different minimums. Check our payment methods page for specific details."
        }
      ]
    },
    {
      category: "Trading & Investing",
      questions: [
        {
          question: "What assets can I trade on Invest-Free.com?",
          answer: "You can trade stocks, ETFs, cryptocurrencies, commodities, and forex. We offer access to over 5,000 instruments across global markets."
        },
        {
          question: "Are there really no commission fees?",
          answer: "Correct! We charge zero commission on stock and ETF trades. For cryptocurrency, we charge a small spread. Forex and CFD trades have competitive spreads with no additional commissions."
        },
        {
          question: "Can I trade outside market hours?",
          answer: "Yes, we offer extended hours trading for stocks and 24/7 trading for cryptocurrencies. Forex markets are available 24/5 (Monday to Friday)."
        },
        {
          question: "What risk management tools do you provide?",
          answer: "We offer stop-loss orders, take-profit orders, position sizing calculators, portfolio diversification analysis, and real-time risk metrics."
        }
      ]
    },
    {
      category: "Account & Security",
      questions: [
        {
          question: "How is my money protected?",
          answer: "Your funds are held in segregated accounts with tier-1 banks. We're regulated by major financial authorities and carry insurance coverage up to $500,000 per account."
        },
        {
          question: "Do you offer two-factor authentication?",
          answer: "Yes, we strongly recommend enabling 2FA. We support SMS, authenticator apps, and hardware security keys for maximum account protection."
        },
        {
          question: "Can I withdraw my money anytime?",
          answer: "Absolutely. You can withdraw your funds anytime with no restrictions. Withdrawals are typically processed within 1-3 business days depending on the method."
        },
        {
          question: "What if I forget my password?",
          answer: "Simply click 'Forgot Password' on the login page. We'll send you a secure reset link via email. For additional security, you may need to verify your identity."
        }
      ]
    },
    {
      category: "Fees & Pricing",
      questions: [
        {
          question: "What fees do you charge?",
          answer: "Stock and ETF trades are commission-free. We charge small spreads on crypto (typically 0.5-1%), forex spreads starting from 0.8 pips, and standard withdrawal fees depending on the method."
        },
        {
          question: "Are there any hidden fees?",
          answer: "No hidden fees, ever. All costs are clearly displayed before you execute any trade. We believe in complete transparency in our fee structure."
        },
        {
          question: "Do you charge monthly account fees?",
          answer: "Our basic account is completely free with no monthly maintenance fees. Premium plans have monthly fees but offer additional features and benefits."
        },
        {
          question: "How do currency conversions work?",
          answer: "Currency conversions are done at real-time market rates with a small conversion fee (typically 0.5%). You can hold multiple currencies in your account to avoid frequent conversions."
        }
      ]
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl text-gray-900">
            {translations.faqTitle || "Frequently Asked Questions"}
          </h2>
          <p className="text-xl text-gray-600">
            {translations.faqSubtitle || "Get answers to common questions"}
          </p>
        </div>

        <div className="space-y-8">
          {faqData.map((category, categoryIndex) => (
            <div key={categoryIndex} className="space-y-4">
              <div className="flex items-center gap-3 mb-6">
                <Badge variant="outline" className="text-amber-600 border-amber-200">
                  {category.category}
                </Badge>
                <div className="h-px bg-gray-200 flex-1"></div>
              </div>

              <Accordion type="single" collapsible className="space-y-2">
                {category.questions.map((faq, questionIndex) => (
                  <AccordionItem 
                    key={questionIndex} 
                    value={`${categoryIndex}-${questionIndex}`}
                    className="border border-gray-200 rounded-lg px-6"
                  >
                    <AccordionTrigger className="text-left hover:no-underline py-6">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600 pb-6">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}
        </div>

        {/* Contact Support */}
        <div className="mt-16 bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-8 text-center">
          <h3 className="text-xl mb-4 text-gray-900">Still have questions?</h3>
          <p className="text-gray-600 mb-6">Our support team is here to help you 24/7</p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="outline" className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4" />
              Live Chat
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Email Support
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Call Us
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}