import { Button } from './ui/button';
import { 
  TrendingUp, 
  ExternalLink,
  Home,
  Users,
  Newspaper,
  GraduationCap,
  Signal,
  Mail,
  MessageCircle,
  Star,
  Shield
} from 'lucide-react';

interface AppFooterProps {
  translations: any;
  onRouteChange: (route: string) => void;
  onBinanceReferral: () => void;
}

export function AppFooter({
  translations: t,
  onRouteChange,
  onBinanceReferral
}: AppFooterProps) {
  const currentYear = new Date().getFullYear();

  const footerSections = [
    {
      title: 'Platform',
      links: [
        { label: 'Home', icon: Home, action: () => onRouteChange('home') },
        { label: 'AI Trading Signals', icon: Signal, action: () => onRouteChange('signals') },
        { label: 'Community', icon: Users, action: () => onRouteChange('community') },
        { label: 'Market News', icon: Newspaper, action: () => onRouteChange('news') },
        { label: 'Trading Education', icon: GraduationCap, action: () => onRouteChange('education') }
      ]
    },
    {
      title: 'Features',
      links: [
        { label: 'Free AI Signals', icon: TrendingUp },
        { label: '84% Accuracy Rate', icon: Star },
        { label: '125k+ Community', icon: Users },
        { label: '24/7 Global Coverage', icon: Shield }
      ]
    },
    {
      title: 'Trading',
      links: [
        { label: 'Get $100 Binance Bonus', icon: ExternalLink, action: onBinanceReferral },
        { label: 'Crypto Signals', icon: TrendingUp },
        { label: 'Forex Signals', icon: TrendingUp },
        { label: 'Stock Analysis', icon: TrendingUp }
      ]
    },
    {
      title: 'Support',
      links: [
        { label: 'Contact Us', icon: Mail },
        { label: 'Community Chat', icon: MessageCircle },
        { label: 'FAQ & Help', icon: MessageCircle },
        { label: 'Trading Guides', icon: GraduationCap }
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto">
      {/* Main Footer Content */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
        {footerSections.map((section, index) => (
          <div key={index} className="space-y-6">
            <h3 className="text-xl font-bold text-pearl-white mb-4">
              {section.title}
            </h3>
            <ul className="space-y-3">
              {section.links.map((link, linkIndex) => {
                const IconComponent = link.icon;
                return (
                  <li key={linkIndex}>
                    {link.action ? (
                      <button
                        onClick={link.action}
                        className="flex items-center gap-3 text-pearl-white/80 hover:text-soft-teal transition-colors duration-200 group"
                      >
                        <IconComponent className="w-4 h-4 group-hover:scale-110 transition-transform duration-200" />
                        <span className="group-hover:underline">{link.label}</span>
                      </button>
                    ) : (
                      <div className="flex items-center gap-3 text-pearl-white/80">
                        <IconComponent className="w-4 h-4" />
                        <span>{link.label}</span>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>

      {/* Company Info Section */}
      <div className="border-t border-pearl-white/20 pt-12 mb-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-soft-teal to-soft-teal-light rounded-2xl flex items-center justify-center shadow-glow">
                <TrendingUp className="w-7 h-7 text-pearl-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-pearl-white">
                  Invest-Free<span className="text-soft-teal">.com</span>
                </h2>
                <p className="text-pearl-white/70 text-sm">
                  Free AI Trading Platform
                </p>
              </div>
            </div>
            
            <p className="text-pearl-white/80 leading-relaxed max-w-md">
              Join over 125,000 successful traders worldwide. Get free AI-powered trading signals 
              with 84% accuracy across crypto, forex, stocks, and commodities. 
              <span className="text-soft-teal font-semibold"> 100% Free Forever.</span>
            </p>
          </div>

          {/* CTA */}
          <div className="text-center lg:text-right">
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-pearl-white">
                Ready to Start Trading?
              </h3>
              <p className="text-pearl-white/80 mb-6">
                Get your $100 trading bonus and join our community
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-end">
                <Button
                  onClick={onBinanceReferral}
                  className="bg-gradient-to-r from-warning-amber to-warning-amber/80 hover:from-warning-amber/90 hover:to-warning-amber text-pearl-white font-bold shadow-glow hover:shadow-deep transition-all duration-200 transform hover:scale-105"
                >
                  <ExternalLink className="w-5 h-5 mr-2" />
                  Get $100 Bonus Now
                </Button>
                <Button
                  onClick={() => onRouteChange('signals')}
                  variant="outline"
                  className="border-2 border-pearl-white/30 text-pearl-white hover:bg-pearl-white hover:text-deep-navy transition-all duration-200"
                >
                  <Signal className="w-5 h-5 mr-2" />
                  View Live Signals
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>



      {/* Bottom Bar */}
      <div className="border-t border-pearl-white/20 pt-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Copyright */}
          <div className="text-center md:text-left">
            <p className="text-pearl-white/70 text-sm">
              © {currentYear} Invest-Free.com. All rights reserved.
            </p>
            <p className="text-pearl-white/60 text-xs mt-1">
              Professional AI trading platform - Educational purposes only
            </p>
          </div>

          {/* Legal Links */}
          <div className="flex items-center gap-6 text-sm">
            <button className="text-pearl-white/70 hover:text-soft-teal transition-colors duration-200">
              Privacy Policy
            </button>
            <button className="text-pearl-white/70 hover:text-soft-teal transition-colors duration-200">
              Terms of Service
            </button>
            <button className="text-pearl-white/70 hover:text-soft-teal transition-colors duration-200">
              Risk Disclaimer
            </button>
          </div>
        </div>
      </div>

      {/* Risk Disclaimer */}
      <div className="mt-8 p-6 bg-deep-ocean/50 rounded-xl border border-soft-teal/20">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-warning-amber mt-1 flex-shrink-0" />
          <div className="text-xs text-pearl-white/80 leading-relaxed">
            <strong className="text-warning-amber">Risk Disclaimer:</strong> Trading cryptocurrencies, 
            forex, stocks, and other financial instruments involves substantial risk and may not be suitable 
            for all investors. Past performance is not indicative of future results. Only trade with money 
            you can afford to lose. This platform provides educational content and signals for informational 
            purposes only and does not constitute financial advice.
          </div>
        </div>
      </div>
    </div>
  );
}