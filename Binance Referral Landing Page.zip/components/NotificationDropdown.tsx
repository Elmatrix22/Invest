import { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Card, CardContent } from './ui/card';
import { 
  Bell, 
  Heart, 
  UserPlus, 
  DollarSign, 
  TrendingUp,
  X,
  CheckCircle,
  Circle
} from 'lucide-react';

interface Notification {
  id: number;
  message: string;
  unread: boolean;
  type?: 'like' | 'follow' | 'earning' | 'signal' | 'general';
  timestamp?: string;
}

interface NotificationDropdownProps {
  notifications: Notification[];
  onMarkAsRead: (id: number) => void;
  onMarkAllAsRead: () => void;
  onDeleteNotification: (id: number) => void;
}

export function NotificationDropdown({ 
  notifications, 
  onMarkAsRead, 
  onMarkAllAsRead, 
  onDeleteNotification 
}: NotificationDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const unreadCount = notifications.filter(n => n.unread).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like':
        return <Heart className="w-4 h-4 text-old-money-burgundy" />;
      case 'follow':
        return <UserPlus className="w-4 h-4 text-old-money-sage" />;
      case 'earning':
        return <DollarSign className="w-4 h-4 text-old-money-gold" />;
      case 'signal':
        return <TrendingUp className="w-4 h-4 text-old-money-navy" />;
      default:
        return <Bell className="w-4 h-4 text-old-money-warm-gray" />;
    }
  };

  const handleMarkAsRead = (id: number, event: React.MouseEvent) => {
    event.stopPropagation();
    onMarkAsRead(id);
  };

  const handleDelete = (id: number, event: React.MouseEvent) => {
    event.stopPropagation();
    onDeleteNotification(id);
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative hover:bg-old-money-cream-dark">
          <Bell className="w-4 h-4 text-old-money-navy" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 bg-old-money-burgundy text-old-money-cream text-xs flex items-center justify-center">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      
      <PopoverContent className="w-80 p-0 bg-white border-old-money-beige shadow-xl" align="end">
        <div className="p-4 border-b border-old-money-beige">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-old-money-navy">Notifications</h3>
            <div className="flex items-center gap-2">
              {unreadCount > 0 && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={onMarkAllAsRead}
                  className="text-xs text-old-money-warm-gray hover:text-old-money-navy"
                >
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Mark all read
                </Button>
              )}
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setIsOpen(false)}
                className="text-old-money-warm-gray hover:text-old-money-navy"
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </div>

        <div className="max-h-96 overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="p-8 text-center">
              <Bell className="w-8 h-8 text-old-money-warm-gray mx-auto mb-2 opacity-50" />
              <p className="text-old-money-warm-gray text-sm">No notifications yet</p>
              <p className="text-old-money-warm-gray text-xs mt-1">
                We'll notify you when something interesting happens
              </p>
            </div>
          ) : (
            <div className="divide-y divide-old-money-beige">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 transition-colors hover:bg-old-money-cream-dark group ${
                    notification.unread 
                      ? 'bg-old-money-sage/5' 
                      : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="shrink-0 mt-1">
                      {getNotificationIcon(notification.type || 'general')}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm leading-5 ${
                        notification.unread ? 'text-old-money-navy font-medium' : 'text-old-money-charcoal'
                      }`}>
                        {notification.message}
                      </p>
                      {notification.timestamp && (
                        <p className="text-xs text-old-money-warm-gray mt-1">
                          {notification.timestamp}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      {notification.unread && (
                        <div className="w-2 h-2 bg-old-money-burgundy rounded-full"></div>
                      )}
                      
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {notification.unread ? (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => handleMarkAsRead(notification.id, e)}
                            className="h-6 w-6 p-0 text-old-money-warm-gray hover:text-old-money-sage"
                            title="Mark as read"
                          >
                            <CheckCircle className="w-3 h-3" />
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => handleMarkAsRead(notification.id, e)}
                            className="h-6 w-6 p-0 text-old-money-warm-gray hover:text-old-money-burgundy"
                            title="Mark as unread"
                          >
                            <Circle className="w-3 h-3" />
                          </Button>
                        )}
                        
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => handleDelete(notification.id, e)}
                          className="h-6 w-6 p-0 text-old-money-warm-gray hover:text-old-money-burgundy"
                          title="Delete notification"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {notifications.length > 0 && (
          <div className="p-3 border-t border-old-money-beige bg-old-money-cream-dark">
            <Button 
              variant="ghost" 
              className="w-full text-old-money-navy hover:bg-old-money-beige text-sm"
              onClick={() => setIsOpen(false)}
            >
              View All Notifications
            </Button>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}