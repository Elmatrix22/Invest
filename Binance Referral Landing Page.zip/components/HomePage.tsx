import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Users, 
  TrendingUp, 
  Signal, 
  ExternalLink,
  Zap,
  Shield,
  Trophy,
  MessageCircle,
  Gift,
  Brain,
  Lock,
  Unlock,
  DollarSign,
  Euro,
  Activity,
  Target,
  Sparkles,
  Globe,
  Star,
  CheckCircle,
  Wifi,
  WifiOff,
  ArrowRight,
  Play,
  ChevronDown
} from 'lucide-react';

interface HomePageProps {
  translations: any;
  binanceReferralUrl: string;
  user: any;
  onShowAuthModal: () => void;
  onRouteChange: (route: string) => void;
  marketData: any;
  isMarketDataReady: boolean;
}

export default function HomePage({ 
  translations: t, 
  binanceReferralUrl,
  user, 
  onShowAuthModal, 
  onRouteChange,
  marketData,
  isMarketDataReady 
}: HomePageProps) {

  const marketStats = {
    totalPrices: Object.keys(marketData.prices).length,
    livePrices: Object.values(marketData.prices).filter(p => p.source !== 'Fallback').length,
    lastUpdate: new Date(marketData.lastUpdate),
    isDataFresh: marketData.lastUpdate > 0 && (Date.now() - marketData.lastUpdate) < 300000
  };

  // Scroll to next section for better UX
  const scrollToFeatures = () => {
    const featuresSection = document.getElementById('features-section');
    if (featuresSection) {
      featuresSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section - Enhanced for better conversion */}
      <section className="relative bg-gradient-to-br from-deep-navy via-deep-ocean to-deep-navy py-24 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(78,205,196,0.15),transparent_60%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(139,92,246,0.15),transparent_60%)]"></div>
        
        <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            
            {/* Enhanced Heading with better CTAs */}
            <div className="mb-10">
              <div className="inline-flex items-center gap-3 bg-soft-teal/20 border border-soft-teal/30 rounded-full px-6 py-3 mb-8 backdrop-blur-sm">
                <Sparkles className="w-5 h-5 text-soft-teal animate-pulse" />
                <span className="text-pearl-white font-semibold">🎯 Free AI Trading Platform</span>
                <Badge className="bg-soft-teal text-deep-navy text-xs font-bold animate-bounce">LIVE NOW</Badge>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-pearl-white mb-8 leading-tight">
                Get FREE AI Trading Signals for{' '}
                <span className="bg-gradient-to-r from-soft-teal via-soft-teal-light to-subtle-lavender bg-clip-text text-transparent">
                  Everything
                </span>
              </h1>
              
              <p className="text-xl sm:text-2xl text-pearl-white/90 mb-6 max-w-4xl mx-auto leading-relaxed">
                🚀 <span className="font-bold text-soft-teal">Crypto • Forex • Stocks • Commodities • Indices</span>
              </p>
              
              <p className="text-lg text-pearl-white/80 max-w-3xl mx-auto mb-10">
                AI-powered signals with <span className="font-bold text-soft-mint">84% accuracy</span>. 
                Daily updates. Beginner to Professional levels.
                {!user && (
                  <span className="block mt-3 font-semibold text-soft-teal text-xl animate-pulse">
                    🔥 Join 125,000+ Successful Traders - FREE Forever!
                  </span>
                )}
              </p>
            </div>
            
            {/* Enhanced Asset Class Icons */}
            <div className="mb-16">
              <div className="grid grid-cols-5 gap-4 sm:gap-8 max-w-3xl mx-auto">
                {[
                  { icon: DollarSign, label: 'Crypto', color: 'from-soft-teal to-soft-teal-dark', count: '50+' },
                  { icon: Euro, label: 'Forex', color: 'from-subtle-lavender to-subtle-lavender-light', count: '30+' },
                  { icon: TrendingUp, label: 'Stocks', color: 'from-soft-mint to-soft-mint-light', count: '100+' },
                  { icon: Target, label: 'Commodities', color: 'from-warning-amber to-warning-amber/80', count: '20+' },
                  { icon: Activity, label: 'Indices', color: 'from-deep-ocean-light to-deep-ocean', count: '15+' }
                ].map(({ icon: Icon, label, color, count }, index) => (
                  <div key={index} className="flex flex-col items-center group cursor-pointer">
                    <div className={`w-16 sm:w-20 h-16 sm:h-20 bg-gradient-to-br ${color} rounded-3xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110 group-hover:shadow-glow-dark border-2 border-soft-teal/30 group-hover:border-soft-teal relative`}>
                      <Icon className="w-8 sm:w-10 h-8 sm:h-10 text-pearl-white" />
                      <div className="absolute -top-2 -right-2 bg-soft-mint text-pearl-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center">
                        {count}
                      </div>
                    </div>
                    <span className="text-sm font-semibold text-pearl-white text-center">{label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Enhanced Call to Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-16">
              {!user ? (
                <>
                  <Button
                    onClick={onShowAuthModal}
                    size="lg"
                    className="bg-gradient-to-r from-soft-teal to-soft-teal-light hover:from-soft-teal-light hover:to-soft-teal text-deep-navy font-bold text-xl px-12 py-6 shadow-glow-dark hover:shadow-deep transition-all duration-300 transform hover:scale-105 relative overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
                    <Zap className="w-6 h-6 mr-3" />
                    Start Free Now - Get AI Signals
                    <ArrowRight className="w-6 h-6 ml-3" />
                  </Button>
                  <Button
                    onClick={() => onRouteChange('signals')}
                    variant="outline"
                    size="lg"
                    className="text-xl px-12 py-6 border-2 border-pearl-white/80 text-pearl-white hover:bg-pearl-white hover:text-deep-navy transition-all duration-300 backdrop-blur-sm bg-pearl-white/10"
                  >
                    <Play className="w-6 h-6 mr-3" />
                    View Live Signals
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    onClick={() => onRouteChange('signals')}
                    size="lg"
                    className="bg-gradient-to-r from-soft-teal to-soft-teal-light hover:from-soft-teal-light hover:to-soft-teal text-deep-navy font-bold text-xl px-12 py-6 shadow-glow-dark hover:shadow-deep transition-all duration-300 transform hover:scale-105"
                  >
                    <Signal className="w-6 h-6 mr-3" />
                    Access Your AI Signals
                    <ArrowRight className="w-6 h-6 ml-3" />
                  </Button>
                  <Button
                    onClick={() => onRouteChange('community')}
                    variant="outline"
                    size="lg"
                    className="text-xl px-12 py-6 border-2 border-pearl-white/80 text-pearl-white hover:bg-pearl-white hover:text-deep-navy transition-all duration-300 backdrop-blur-sm bg-pearl-white/10"
                  >
                    <Users className="w-6 h-6 mr-3" />
                    Join Community
                  </Button>
                </>
              )}
            </div>

            {/* Enhanced Registration Status */}
            <div className="flex justify-center mb-8">
              {!user ? (
                <div className="bg-gradient-to-r from-deep-ocean/50 to-deep-navy/50 backdrop-blur-md inline-flex items-center gap-4 px-8 py-5 rounded-3xl border border-soft-teal/30 shadow-glow-dark">
                  <div className="w-12 h-12 bg-soft-teal/20 rounded-2xl flex items-center justify-center border border-soft-teal/30">
                    <Lock className="w-6 h-6 text-soft-teal" />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-pearl-white text-lg">🔥 Limited Time - Join Free!</div>
                    <div className="text-sm text-pearl-white/80">Get premium AI signals + $100 trading bonus</div>
                  </div>
                </div>
              ) : (
                <div className="bg-gradient-to-r from-soft-mint/20 to-soft-mint/10 backdrop-blur-md inline-flex items-center gap-4 px-8 py-5 rounded-3xl border border-soft-mint/40 shadow-glow-dark">
                  <div className="w-12 h-12 bg-soft-mint/20 rounded-2xl flex items-center justify-center border border-soft-mint/40">
                    <Unlock className="w-6 h-6 text-soft-mint" />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-pearl-white text-lg">✅ Premium Access Active!</div>
                    <div className="text-sm text-pearl-white/80">Welcome back, {user.name || 'Premium Member'}! 🎉</div>
                  </div>
                </div>
              )}
            </div>

            {/* Scroll Down Indicator */}
            <button
              onClick={scrollToFeatures}
              className="inline-flex flex-col items-center gap-2 text-pearl-white/70 hover:text-pearl-white transition-colors duration-200 animate-bounce"
            >
              <span className="text-sm font-medium">Discover Features</span>
              <ChevronDown className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Trust Indicators - Enhanced */}
      <section className="py-16 bg-pearl-white border-y border-pearl-gray" id="features-section">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-deep-ocean mb-4">
              Trusted by 125,000+ Traders Worldwide
            </h2>
            <p className="text-warm-slate text-lg">
              Join the largest free AI trading community
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { icon: CheckCircle, value: '247+', label: 'Daily AI Signals', color: 'text-soft-mint', desc: 'Generated 24/7' },
              { icon: Users, value: '125k+', label: 'Active Traders', color: 'text-soft-teal', desc: 'Global community' },
              { icon: Star, value: '84%', label: 'Signal Accuracy', color: 'text-warning-amber', desc: 'Proven results' },
              { icon: Globe, value: '24/7', label: 'Global Coverage', color: 'text-subtle-lavender', desc: 'Never miss a trade' }
            ].map(({ icon: Icon, value, label, color, desc }, index) => (
              <div key={index} className="space-y-4 group cursor-pointer">
                <div className={`w-20 h-20 ${color.replace('text-', 'bg-')}/10 rounded-3xl flex items-center justify-center mx-auto group-hover:scale-110 transition-all duration-300 shadow-soft group-hover:shadow-medium`}>
                  <Icon className={`w-10 h-10 ${color}`} />
                </div>
                <div>
                  <div className="text-3xl font-bold text-deep-ocean">{value}</div>
                  <div className="text-base font-semibold text-warm-slate">{label}</div>
                  <div className="text-sm text-warm-slate/70">{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Live Market Data Status - Enhanced */}
      {isMarketDataReady && (
        <section className="py-16 section-dark">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-pearl-white mb-4">
                🔥 Live Market Data Connected
              </h2>
              <p className="text-pearl-white/80 text-xl max-w-3xl mx-auto">
                Real-time price feeds from Binance, Forex brokers, and major exchanges ensuring 
                accurate AI signal generation
              </p>
            </div>
            
            <div className="card-glass-dark p-8 lg:p-12">
              <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-4">
                    {marketStats.livePrices > 10 ? (
                      <div className="relative">
                        <div className="w-24 h-24 bg-soft-mint/20 rounded-3xl flex items-center justify-center animate-pulse-glow">
                          <Wifi className="w-12 h-12 text-soft-mint" />
                        </div>
                        <div className="status-online absolute -top-2 -right-2 w-8 h-8 animate-ping" />
                      </div>
                    ) : (
                      <div className="relative">
                        <div className="w-24 h-24 bg-danger-coral/20 rounded-3xl flex items-center justify-center">
                          <WifiOff className="w-12 h-12 text-danger-coral" />
                        </div>
                        <div className="status-warning absolute -top-2 -right-2 w-8 h-8" />
                      </div>
                    )}
                    <div>
                      <h3 className="text-3xl font-bold text-pearl-white">
                        {marketStats.livePrices > 10 ? '✅ Connected & Syncing' : '⚠️ Limited Connection'}
                      </h3>
                      <p className="text-pearl-white/70 text-lg">Market data status</p>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
                  <div className="space-y-2">
                    <div className="text-4xl font-bold text-soft-teal">{marketStats.livePrices}</div>
                    <div className="text-base text-pearl-white/80 font-medium">Live Feeds</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-4xl font-bold text-subtle-lavender">{marketStats.totalPrices}</div>
                    <div className="text-base text-pearl-white/80 font-medium">Total Assets</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-4xl font-bold text-warning-amber">
                      {marketStats.isDataFresh ? 
                        new Date(marketData.lastUpdate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 
                        'Loading...'
                      }
                    </div>
                    <div className="text-base text-pearl-white/80 font-medium">Last Update</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Market Data Loading Alert - Enhanced */}
      {!isMarketDataReady && (
        <section className="py-16 section-gradient-light">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <Alert className="border-soft-teal/30 bg-soft-teal/5 card-glass p-8 lg:p-12">
              <div className="flex items-center gap-6">
                <div className="w-20 h-20 bg-soft-teal/20 rounded-3xl flex items-center justify-center">
                  <Activity className="h-10 w-10 animate-pulse-glow text-soft-teal" />
                </div>
                <AlertDescription className="flex-1">
                  <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-2xl font-bold text-deep-ocean mb-2">
                        🔄 Connecting to Live Market Data
                      </h3>
                      <p className="text-warm-slate text-lg">
                        Establishing secure connections to Binance, Forex APIs, and major exchange feeds...
                      </p>
                    </div>
                    <div className="bg-pearl-white px-8 py-4 rounded-2xl shadow-soft">
                      <span className="text-base font-semibold text-deep-ocean">
                        ⏳ AI signals will activate after connection
                      </span>
                    </div>
                  </div>
                </AlertDescription>
              </div>
            </Alert>
          </div>
        </section>
      )}

      {/* Services Preview - Enhanced */}
      <section className="py-20 section-light">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-soft-teal/10 border border-soft-teal/20 rounded-full px-6 py-3 mb-8">
              <Shield className="w-5 h-5 text-soft-teal" />
              <span className="text-deep-ocean font-semibold">🚀 Professional Trading Platform</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold text-deep-ocean mb-6">
              Everything You Need to Trade Successfully
            </h2>
            <p className="text-xl text-warm-slate max-w-4xl mx-auto leading-relaxed">
              Access AI-powered signals, join our investment community, stay updated with market news, 
              and enhance your trading education - all in one comprehensive platform
            </p>
          </div>
          
          {/* Service Cards - Enhanced */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: 'AI Trading Signals',
                description: 'Real-time AI powered trading opportunities with 84% accuracy',
                icon: TrendingUp,
                color: 'text-soft-teal',
                bgColor: 'bg-soft-teal/10',
                route: 'signals',
                badge: '247+ Daily'
              },
              {
                title: 'Investment Community',
                description: 'Connect with 125k+ successful traders and share strategies',
                icon: Users,
                color: 'text-subtle-lavender',
                bgColor: 'bg-subtle-lavender/10',
                route: 'community',
                badge: '125k Members'
              },
              {
                title: 'Market News',
                description: 'Latest financial updates and expert market analysis',
                icon: MessageCircle,
                color: 'text-warning-amber',
                bgColor: 'bg-warning-amber/10',
                route: 'news',
                badge: 'Breaking News'
              },
              {
                title: 'Trading Education',
                description: 'Master trading with comprehensive guides and tutorials',
                icon: Trophy,
                color: 'text-deep-ocean',
                bgColor: 'bg-deep-ocean/10',
                route: 'education',
                badge: 'Free Courses'
              }
            ].map((service, index) => {
              const IconComponent = service.icon;
              return (
                <div key={index} className="card-modern p-8 text-center group cursor-pointer hover:shadow-deep transform hover:scale-105 transition-all duration-300" onClick={() => onRouteChange(service.route)}>
                  <div className="relative mb-6">
                    <div className={`w-20 h-20 ${service.bgColor} rounded-3xl flex items-center justify-center mx-auto group-hover:scale-110 transition-all duration-300 shadow-soft group-hover:shadow-medium`}>
                      <IconComponent className={`w-10 h-10 ${service.color}`} />
                    </div>
                    <Badge className="absolute -top-2 -right-2 bg-soft-teal text-white text-xs font-bold">
                      {service.badge}
                    </Badge>
                  </div>
                  <h3 className="text-xl font-bold text-deep-ocean mb-4">{service.title}</h3>
                  <p className="text-warm-slate leading-relaxed mb-4">{service.description}</p>
                  <ArrowRight className="w-5 h-5 mx-auto text-soft-teal group-hover:translate-x-1 transition-transform duration-200" />
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Enhanced Bonus Features */}
      <section className="py-20 bg-gradient-to-r from-pearl-white via-pearl-gray to-pearl-white border-y border-soft-teal/20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-deep-ocean mb-4">
              🎁 Exclusive Member Benefits
            </h2>
            <p className="text-warm-slate text-lg">
              Get more value with our premium partnerships
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {[
              {
                icon: Gift,
                title: '$100 Trading Bonus',
                description: 'Exclusive Binance referral offer to boost your trading capital',
                color: 'from-soft-mint to-soft-mint-light',
                action: () => window.open(binanceReferralUrl, '_blank')
              },
              {
                icon: MessageCircle,
                title: 'VIP Community Access',
                description: '125k+ active traders sharing winning strategies daily',
                color: 'from-subtle-lavender to-subtle-lavender-light',
                action: () => onRouteChange('community')
              },
              {
                icon: Star,
                title: '100% Free Forever',
                description: 'No hidden fees, no subscriptions - completely free platform',
                color: 'from-soft-teal to-soft-teal-light',
                action: () => onShowAuthModal()
              }
            ].map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <div key={index} className="flex items-center justify-center gap-6 group cursor-pointer p-6 rounded-2xl hover:bg-white transition-all duration-300" onClick={feature.action}>
                  <div className={`w-20 h-20 bg-gradient-to-br ${feature.color} rounded-3xl flex items-center justify-center shadow-soft group-hover:shadow-medium transition-all duration-300 group-hover:scale-110`}>
                    <IconComponent className="w-10 h-10 text-pearl-white" />
                  </div>
                  <div className="text-left flex-1">
                    <div className="font-bold text-xl text-deep-navy group-hover:text-soft-teal transition-colors duration-300 mb-2">{feature.title}</div>
                    <div className="text-base text-warm-slate-dark font-medium leading-relaxed">{feature.description}</div>
                  </div>
                  <ArrowRight className="w-6 h-6 text-soft-teal group-hover:translate-x-1 transition-transform duration-200" />
                </div>
              );
            })}
          </div>
        </div>
      </section>


    </div>
  );
}