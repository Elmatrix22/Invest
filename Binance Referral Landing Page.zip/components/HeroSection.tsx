import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HeroSectionProps {
  translations: any;
}

export function HeroSection({ translations }: HeroSectionProps) {
  const handleSignUp = () => {
    // In a real implementation, this would redirect to the actual Binance referral link
    window.open('https://accounts.binance.com/register', '_blank');
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 py-20">
      <div className="absolute inset-0 bg-grid-black/[0.02] bg-[size:60px_60px]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center rounded-full bg-amber-100 px-3 py-1 text-sm">
                <span className="mr-2">🎉</span>
                <span className="text-amber-800">Limited Time Offer</span>
              </div>
              <h1 className="text-4xl lg:text-6xl tracking-tight text-gray-900">
                {translations.heroTitle}
              </h1>
              <p className="text-xl text-gray-600 max-w-2xl">
                {translations.heroSubtitle}
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={handleSignUp}
                size="lg"
                className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-4 text-lg"
              >
                {translations.signUpButton}
              </Button>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <span>✓</span>
                <span>No hidden fees</span>
                <span>•</span>
                <span>✓</span>
                <span>Instant bonus</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-gray-200">
              <div className="text-center">
                <div className="text-2xl font-semibold text-gray-900">350M+</div>
                <div className="text-sm text-gray-600">Registered Users</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-semibold text-gray-900">$76B</div>
                <div className="text-sm text-gray-600">24h Volume</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-semibold text-gray-900">350+</div>
                <div className="text-sm text-gray-600">Listed Coins</div>
              </div>
            </div>
          </div>

          <div className="lg:pl-12">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-amber-400 to-orange-500 rounded-3xl transform rotate-6"></div>
              <div className="relative bg-white p-8 rounded-3xl shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1639762681485-074b7f938ba0?q=80&w=1000"
                  alt="Binance Trading Interface"
                  className="w-full h-64 object-cover rounded-xl"
                />
                <div className="mt-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Your Bonus</span>
                    <span className="text-2xl font-bold text-green-600">+$100</span>
                  </div>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-green-800 text-sm">Bonus activated upon first deposit</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}