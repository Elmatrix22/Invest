import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  Crown, 
  Star, 
  TrendingUp, 
  Target, 
  Users, 
  Gift,
  Medal,
  Trophy,
  Award,
  ChevronRight
} from 'lucide-react';

interface LeaderboardProps {
  translations: any;
}

export function Leaderboard({ translations }: LeaderboardProps) {
  const [activeTab, setActiveTab] = useState('accuracy');

  const topAccuracy = [
    {
      rank: 1,
      username: 'CryptoProphet',
      avatar: 'CP',
      accuracy: 92.5,
      totalPredictions: 87,
      successfulPredictions: 80,
      isExpert: true,
      isVip: true,
      badge: 'Oracle',
      joinDate: '2023-01-15'
    },
    {
      rank: 2,
      username: 'BlockchainMaster',
      avatar: 'BM',
      accuracy: 89.8,
      totalPredictions: 156,
      successfulPredictions: 140,
      isExpert: true,
      isVip: true,
      badge: 'Sage',
      joinDate: '2023-03-22'
    },
    {
      rank: 3,
      username: 'AltcoinGuru',
      avatar: 'AG',
      accuracy: 87.2,
      totalPredictions: 203,
      successfulPredictions: 177,
      isExpert: true,
      isVip: true,
      badge: 'Master',
      joinDate: '2023-02-08'
    },
    {
      rank: 4,
      username: 'DeFiAnalyst',
      avatar: 'DA',
      accuracy: 84.6,
      totalPredictions: 112,
      successfulPredictions: 95,
      isExpert: false,
      isVip: true,
      badge: 'Pro',
      joinDate: '2023-04-12'
    },
    {
      rank: 5,
      username: 'TradingWizard',
      avatar: 'TW',
      accuracy: 83.1,
      totalPredictions: 178,
      successfulPredictions: 148,
      isExpert: true,
      isVip: false,
      badge: 'Expert',
      joinDate: '2023-01-30'
    }
  ];

  const mostLiked = [
    {
      rank: 1,
      username: 'CommunityFav',
      avatar: 'CF',
      likes: 2847,
      posts: 234,
      avgLikes: 12.2,
      isExpert: false,
      isVip: true,
      badge: 'Popular',
      joinDate: '2023-02-14'
    },
    {
      rank: 2,
      username: 'InsightfulTrader',
      avatar: 'IT',
      likes: 2634,
      posts: 189,
      avgLikes: 13.9,
      isExpert: true,
      isVip: true,
      badge: 'Favorite',
      joinDate: '2023-01-20'
    },
    {
      rank: 3,
      username: 'MarketMentor',
      avatar: 'MM',
      likes: 2456,
      posts: 167,
      avgLikes: 14.7,
      isExpert: true,
      isVip: false,
      badge: 'Beloved',
      joinDate: '2023-03-05'
    }
  ];

  const topReferrers = [
    {
      rank: 1,
      username: 'ReferralKing',
      avatar: 'RK',
      referrals: 1247,
      activeReferrals: 1089,
      earnings: 62350,
      isVip: true,
      badge: 'Ambassador',
      joinDate: '2023-01-10'
    },
    {
      rank: 2,
      username: 'NetworkBuilder',
      avatar: 'NB',
      referrals: 987,
      activeReferrals: 834,
      earnings: 49350,
      isVip: true,
      badge: 'Influencer',
      joinDate: '2023-01-25'
    },
    {
      rank: 3,
      username: 'CommunityGrower',
      avatar: 'CG',
      referrals: 756,
      activeReferrals: 623,
      earnings: 37800,
      isVip: true,
      badge: 'Recruiter',
      joinDate: '2023-02-18'
    }
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-6 h-6 text-old-money-gold" />;
      case 2:
        return <Medal className="w-6 h-6 text-old-money-warm-gray" />;
      case 3:
        return <Award className="w-6 h-6 text-old-money-burgundy" />;
      default:
        return (
          <div className="w-6 h-6 bg-old-money-warm-gray/20 rounded-full flex items-center justify-center">
            <span className="text-sm font-bold text-old-money-warm-gray">{rank}</span>
          </div>
        );
    }
  };

  const getBadgeColor = (badge: string) => {
    const colors: {[key: string]: string} = {
      'Oracle': 'bg-old-money-burgundy/10 text-old-money-burgundy',
      'Sage': 'bg-old-money-navy/10 text-old-money-navy',
      'Master': 'bg-old-money-sage/10 text-old-money-sage',
      'Pro': 'bg-old-money-gold/10 text-old-money-gold',
      'Expert': 'bg-old-money-charcoal/10 text-old-money-charcoal',
      'Popular': 'bg-old-money-burgundy-light/10 text-old-money-burgundy-light',
      'Favorite': 'bg-old-money-sage-light/10 text-old-money-sage-light',
      'Beloved': 'bg-old-money-navy-light/10 text-old-money-navy-light',
      'Ambassador': 'bg-old-money-gold-light/10 text-old-money-gold-light',
      'Influencer': 'bg-old-money-burgundy/10 text-old-money-burgundy',
      'Recruiter': 'bg-old-money-sage/10 text-old-money-sage'
    };
    return colors[badge] || 'bg-old-money-warm-gray/10 text-old-money-warm-gray';
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-old-money-navy mb-4">
          🏆 Community Leaderboard
        </h1>
        <p className="text-old-money-warm-gray max-w-2xl mx-auto">
          Discover our top performers and learn from the best crypto investors in our community
        </p>
      </div>

      {/* Top 3 Podium */}
      <div className="mb-12">
        <h2 className="text-xl font-bold text-center mb-6 text-old-money-navy">Top Prediction Accuracy</h2>
        <div className="flex justify-center items-end gap-8">
          {/* 2nd Place */}
          <div className="text-center">
            <div className="bg-gradient-to-t from-old-money-warm-gray to-old-money-warm-gray-light rounded-t-2xl p-6 mb-4 h-32 flex flex-col justify-end">
              <div className="bg-white rounded-xl p-4 shadow-lg border border-old-money-beige">
                <Avatar className="w-16 h-16 mx-auto mb-2">
                  <AvatarFallback className="bg-old-money-warm-gray/10 text-old-money-warm-gray text-lg">
                    {topAccuracy[1].avatar}
                  </AvatarFallback>
                </Avatar>
                <h3 className="font-bold text-sm text-old-money-navy">{topAccuracy[1].username}</h3>
                <p className="text-2xl font-bold text-old-money-warm-gray">{topAccuracy[1].accuracy}%</p>
              </div>
            </div>
            <Medal className="w-8 h-8 text-old-money-warm-gray mx-auto" />
          </div>

          {/* 1st Place */}
          <div className="text-center">
            <div className="bg-gradient-to-t from-old-money-gold to-old-money-gold-light rounded-t-2xl p-6 mb-4 h-40 flex flex-col justify-end">
              <div className="bg-white rounded-xl p-4 shadow-lg border border-old-money-beige">
                <Avatar className="w-20 h-20 mx-auto mb-2">
                  <AvatarFallback className="bg-old-money-gold/10 text-old-money-gold text-xl">
                    {topAccuracy[0].avatar}
                  </AvatarFallback>
                </Avatar>
                <h3 className="font-bold text-old-money-navy">{topAccuracy[0].username}</h3>
                <p className="text-3xl font-bold text-old-money-gold">{topAccuracy[0].accuracy}%</p>
              </div>
            </div>
            <Trophy className="w-10 h-10 text-old-money-gold mx-auto" />
          </div>

          {/* 3rd Place */}
          <div className="text-center">
            <div className="bg-gradient-to-t from-old-money-burgundy to-old-money-burgundy-light rounded-t-2xl p-6 mb-4 h-28 flex flex-col justify-end">
              <div className="bg-white rounded-xl p-4 shadow-lg border border-old-money-beige">
                <Avatar className="w-14 h-14 mx-auto mb-2">
                  <AvatarFallback className="bg-old-money-burgundy/10 text-old-money-burgundy">
                    {topAccuracy[2].avatar}
                  </AvatarFallback>
                </Avatar>
                <h3 className="font-bold text-sm text-old-money-navy">{topAccuracy[2].username}</h3>
                <p className="text-xl font-bold text-old-money-burgundy">{topAccuracy[2].accuracy}%</p>
              </div>
            </div>
            <Award className="w-7 h-7 text-old-money-burgundy mx-auto" />
          </div>
        </div>
      </div>

      {/* Detailed Leaderboards */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 max-w-md mx-auto mb-8 bg-old-money-cream-dark border border-old-money-beige">
          <TabsTrigger value="accuracy" className="flex items-center gap-2 data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            <Target className="w-4 h-4" />
            Accuracy
          </TabsTrigger>
          <TabsTrigger value="popular" className="flex items-center gap-2 data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            <Star className="w-4 h-4" />
            Most Liked
          </TabsTrigger>
          <TabsTrigger value="referrals" className="flex items-center gap-2 data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            <Users className="w-4 h-4" />
            Referrals
          </TabsTrigger>
        </TabsList>

        <TabsContent value="accuracy">
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <Target className="w-5 h-5 text-old-money-sage" />
                Most Accurate Predictors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topAccuracy.map((user) => (
                  <div key={user.rank} className="flex items-center gap-4 p-4 bg-old-money-cream-dark rounded-lg hover:bg-old-money-beige transition-colors">
                    <div className="flex items-center gap-3">
                      {getRankIcon(user.rank)}
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className={`${
                          user.rank <= 3 ? 'bg-gradient-to-r from-old-money-gold to-old-money-gold-light text-old-money-navy' : 'bg-old-money-sage-light text-old-money-navy'
                        }`}>
                          {user.avatar}
                        </AvatarFallback>
                      </Avatar>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-old-money-navy">{user.username}</h4>
                        {user.isExpert && <Crown className="w-4 h-4 text-old-money-burgundy" />}
                        {user.isVip && <Star className="w-4 h-4 text-old-money-gold" />}
                        <Badge className={getBadgeColor(user.badge)}>
                          {user.badge}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-old-money-warm-gray">
                        <span>{user.successfulPredictions}/{user.totalPredictions} predictions</span>
                        <span>•</span>
                        <span>Joined {new Date(user.joinDate).toLocaleDateString()}</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-2xl font-bold text-old-money-sage">{user.accuracy}%</div>
                      <div className="text-sm text-old-money-warm-gray">accuracy</div>
                    </div>

                    <Button variant="ghost" size="sm" className="text-old-money-warm-gray hover:text-old-money-navy">
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="popular">
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <Star className="w-5 h-5 text-old-money-burgundy" />
                Most Liked Members
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mostLiked.map((user) => (
                  <div key={user.rank} className="flex items-center gap-4 p-4 bg-old-money-cream-dark rounded-lg hover:bg-old-money-beige transition-colors">
                    <div className="flex items-center gap-3">
                      {getRankIcon(user.rank)}
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className={`${
                          user.rank <= 3 ? 'bg-gradient-to-r from-old-money-burgundy to-old-money-burgundy-light text-old-money-cream' : 'bg-old-money-sage-light text-old-money-navy'
                        }`}>
                          {user.avatar}
                        </AvatarFallback>
                      </Avatar>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-old-money-navy">{user.username}</h4>
                        {user.isExpert && <Crown className="w-4 h-4 text-old-money-burgundy" />}
                        {user.isVip && <Star className="w-4 h-4 text-old-money-gold" />}
                        <Badge className={getBadgeColor(user.badge)}>
                          {user.badge}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-old-money-warm-gray">
                        <span>{user.posts} posts</span>
                        <span>•</span>
                        <span>{user.avgLikes} avg likes/post</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-2xl font-bold text-old-money-burgundy">{user.likes.toLocaleString()}</div>
                      <div className="text-sm text-old-money-warm-gray">total likes</div>
                    </div>

                    <Button variant="ghost" size="sm" className="text-old-money-warm-gray hover:text-old-money-navy">
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="referrals">
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-old-money-navy">
                <Users className="w-5 h-5 text-old-money-navy" />
                Top Referrers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topReferrers.map((user) => (
                  <div key={user.rank} className="flex items-center gap-4 p-4 bg-old-money-cream-dark rounded-lg hover:bg-old-money-beige transition-colors">
                    <div className="flex items-center gap-3">
                      {getRankIcon(user.rank)}
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className={`${
                          user.rank <= 3 ? 'bg-gradient-to-r from-old-money-navy to-old-money-charcoal text-old-money-cream' : 'bg-old-money-sage-light text-old-money-navy'
                        }`}>
                          {user.avatar}
                        </AvatarFallback>
                      </Avatar>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-old-money-navy">{user.username}</h4>
                        <Star className="w-4 h-4 text-old-money-gold" />
                        <Badge className={getBadgeColor(user.badge)}>
                          {user.badge}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-old-money-warm-gray">
                        <span>{user.activeReferrals} active members</span>
                        <span>•</span>
                        <span>${user.earnings.toLocaleString()} earned</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-2xl font-bold text-old-money-navy">{user.referrals.toLocaleString()}</div>
                      <div className="text-sm text-old-money-warm-gray">referrals</div>
                    </div>

                    <Button variant="ghost" size="sm" className="text-old-money-warm-gray hover:text-old-money-navy">
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Call to Action */}
      <div className="mt-12 text-center">
        <Card className="bg-gradient-to-r from-old-money-sage/10 to-old-money-sage-light/10 border-old-money-sage/30">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold mb-4 text-old-money-navy">Want to Join the Leaderboard?</h3>
            <p className="text-old-money-warm-gray mb-6 max-w-2xl mx-auto">
              Start sharing your crypto predictions and insights. Build your reputation and earn rewards while helping the community grow.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream">
                <Gift className="w-5 h-5 mr-2" />
                Get Your $100 Bonus
              </Button>
              <Button size="lg" variant="outline" className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark">
                <TrendingUp className="w-5 h-5 mr-2" />
                Share Your First Prediction
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}