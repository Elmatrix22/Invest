import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Coins, PiggyBank, TrendingUp, Rocket, ChevronRight } from 'lucide-react';

interface InvestmentSectionProps {
  translations: any;
}

export function InvestmentSection({ translations }: InvestmentSectionProps) {
  const products = [
    {
      icon: Rocket,
      title: translations.launchpool,
      description: translations.launchpoolDesc,
      apy: "Up to 50% APY",
      risk: "Medium",
      color: "bg-blue-500"
    },
    {
      icon: Coins,
      title: translations.staking,
      description: translations.stakingDesc,
      apy: "5-20% APY",
      risk: "Low",
      color: "bg-green-500"
    },
    {
      icon: PiggyBank,
      title: translations.savings,
      description: translations.savingsDesc,
      apy: "3-8% APY",
      risk: "Low",
      color: "bg-purple-500"
    },
    {
      icon: TrendingUp,
      title: translations.trending,
      description: translations.trendingDesc,
      apy: "Variable",
      risk: "High",
      color: "bg-orange-500"
    }
  ];

  const trendingCoins = [
    { name: "Bitcoin", symbol: "BTC", change: "+2.4%" },
    { name: "Ethereum", symbol: "ETH", change: "+1.8%" },
    { name: "Binance Coin", symbol: "BNB", change: "+3.2%" },
    { name: "Cardano", symbol: "ADA", change: "+0.9%" }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl text-gray-900">
            {translations.investmentTitle}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {translations.investmentSubtitle}
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-12">
          {products.map((product, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
              <CardHeader className="space-y-4">
                <div className={`w-12 h-12 ${product.color} rounded-lg flex items-center justify-center`}>
                  <product.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-lg group-hover:text-amber-600 transition-colors">
                    {product.title}
                  </CardTitle>
                  <CardDescription className="mt-2">
                    {product.description}
                  </CardDescription>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    {product.apy}
                  </Badge>
                  <Badge variant="outline">
                    {product.risk} Risk
                  </Badge>
                </div>
                <Button variant="ghost" className="w-full justify-between group-hover:bg-amber-50">
                  Learn More
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-gradient-to-r from-gray-50 to-gray-100 border-0">
          <CardHeader>
            <CardTitle className="text-center text-2xl text-gray-900">Live Market Data</CardTitle>
            <CardDescription className="text-center">
              Real-time prices of trending cryptocurrencies
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {trendingCoins.map((coin, index) => (
                <div key={index} className="bg-white rounded-lg p-4 text-center">
                  <div className="text-lg font-semibold text-gray-900">{coin.name}</div>
                  <div className="text-sm text-gray-600 mb-2">{coin.symbol}</div>
                  <div className="text-green-600 font-medium">{coin.change}</div>
                </div>
              ))}
            </div>
            <div className="text-center mt-6">
              <Button variant="outline">
                View All Markets
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}