import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Users, 
  Target, 
  TrendingUp, 
  Shield, 
  Zap, 
  Brain, 
  DollarSign, 
  ExternalLink,
  CheckCircle,
  Award,
  Globe,
  Heart,
  Lightbulb,
  Star
} from 'lucide-react';

interface AboutPageProps {
  translations: any;
  binanceReferralUrl: string;
  onShowAuthModal: () => void;
}

export function AboutPage({ translations, binanceReferralUrl, onShowAuthModal }: AboutPageProps) {
  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const stats = [
    { icon: Users, label: 'Active Members', value: '125,847+', color: 'text-old-money-sage' },
    { icon: TrendingUp, label: 'Signal Accuracy', value: '84%', color: 'text-old-money-gold' },
    { icon: DollarSign, label: 'Bonus Distributed', value: '$12M+', color: 'text-old-money-burgundy' },
    { icon: Globe, label: 'Countries Served', value: '150+', color: 'text-old-money-navy' }
  ];

  const features = [
    {
      icon: Brain,
      title: 'AI-Powered Analysis',
      description: 'Advanced artificial intelligence analyzes market patterns 24/7 to deliver high-accuracy trading signals across all major asset classes.'
    },
    {
      icon: Shield,
      title: '100% Free Platform',
      description: 'No hidden fees, no subscription costs. Access premium trading signals and investment opportunities completely free forever.'
    },
    {
      icon: Zap,
      title: 'Real-Time Signals',
      description: 'Instant notifications for crypto, forex, stocks, and commodities. Never miss a profitable trading opportunity again.'
    },
    {
      icon: Lightbulb,
      title: 'Business Investment Ideas',
      description: 'Discover 50+ weekly curated business projects and investment opportunities. From startups to established businesses.'
    },
    {
      icon: Target,
      title: 'Binance Partnership',
      description: 'Official Binance partner offering exclusive $100 bonus for new traders. Start trading with reduced fees and premium tools.'
    },
    {
      icon: Users,
      title: 'Global Community',
      description: 'Join 125,000+ active traders and investors sharing insights, strategies, and opportunities in our vibrant community.'
    }
  ];

  const team = [
    {
      name: 'Alex Chen',
      role: 'Founder & CEO',
      avatar: 'AC',
      bio: 'Former Goldman Sachs quantitative analyst with 15+ years in algorithmic trading and AI development.'
    },
    {
      name: 'Sarah Johnson',
      role: 'Head of AI Research',
      avatar: 'SJ',
      bio: 'PhD in Machine Learning from MIT. Led AI teams at top fintech companies building trading algorithms.'
    },
    {
      name: 'Marcus Rodriguez',
      role: 'Community Director',
      avatar: 'MR',
      bio: 'Built and managed trading communities for 10+ years. Expert in user engagement and education.'
    },
    {
      name: 'Dr. Lisa Wang',
      role: 'Chief Investment Officer',
      avatar: 'LW',
      bio: 'Former hedge fund manager with $2B+ AUM. Specialist in global markets and risk management.'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-6">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="w-16 h-16 bg-gradient-to-br from-old-money-navy to-old-money-burgundy rounded-full flex items-center justify-center">
            <span className="text-old-money-cream font-bold text-2xl">IF</span>
          </div>
          <div>
            <h1 className="text-4xl font-bold text-old-money-navy">Invest-Free.com</h1>
            <Badge className="bg-old-money-sage text-old-money-cream mt-2">
              Since 2024 • 100% Free
            </Badge>
          </div>
        </div>
        
        <p className="text-xl text-old-money-warm-gray max-w-3xl mx-auto leading-relaxed">
          The world's largest free crypto investment community. Get AI-powered trading signals, 
          discover business investment opportunities, and join 125,000+ successful traders worldwide.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            size="lg"
            onClick={onShowAuthModal}
            className="bg-old-money-burgundy hover:bg-old-money-burgundy-light text-old-money-cream font-bold px-8 py-4"
          >
            <Users className="w-6 h-6 mr-3" />
            Join Our Community
          </Button>
          <Button
            size="lg"
            onClick={handleBinanceClick}
            className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy font-bold px-8 py-4"
          >
            <ExternalLink className="w-6 h-6 mr-3" />
            Get $100 Bonus
          </Button>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="text-center border-old-money-beige">
            <CardContent className="p-6">
              <stat.icon className={`w-8 h-8 mx-auto mb-3 ${stat.color}`} />
              <div className="text-3xl font-bold text-old-money-navy">{stat.value}</div>
              <div className="text-sm text-old-money-warm-gray">{stat.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Mission Statement */}
      <Card className="bg-gradient-to-r from-old-money-gold/10 to-old-money-sage/10 border-old-money-gold">
        <CardContent className="p-8 text-center">
          <Award className="w-12 h-12 text-old-money-gold mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-old-money-navy mb-4">Our Mission</h2>
          <p className="text-lg text-old-money-warm-gray max-w-4xl mx-auto leading-relaxed">
            To democratize access to professional-grade trading signals and investment opportunities. 
            We believe everyone deserves access to the same quality financial tools and insights that 
            were once exclusive to institutional investors. Through AI technology and community wisdom, 
            we're leveling the playing field for retail traders and investors worldwide.
          </p>
        </CardContent>
      </Card>

      {/* Features Grid */}
      <div>
        <h2 className="text-3xl font-bold text-old-money-navy text-center mb-8">
          Why Choose Invest-Free.com?
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-old-money-beige hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-old-money-navy rounded-full flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-old-money-cream" />
                </div>
                <CardTitle className="text-old-money-navy">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-old-money-warm-gray leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Team Section */}
      <div>
        <h2 className="text-3xl font-bold text-old-money-navy text-center mb-8">
          Meet Our Expert Team
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member, index) => (
            <Card key={index} className="text-center border-old-money-beige">
              <CardContent className="p-6">
                <div className="w-20 h-20 bg-gradient-to-br from-old-money-sage to-old-money-sage-light rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-old-money-cream font-bold text-xl">{member.avatar}</span>
                </div>
                <h3 className="font-bold text-old-money-navy mb-1">{member.name}</h3>
                <p className="text-old-money-burgundy font-medium text-sm mb-3">{member.role}</p>
                <p className="text-old-money-warm-gray text-sm leading-relaxed">{member.bio}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Values Section */}
      <Card className="bg-old-money-navy text-old-money-cream">
        <CardContent className="p-8">
          <h2 className="text-3xl font-bold text-center mb-8">Our Core Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <Heart className="w-8 h-8 text-old-money-gold mx-auto mb-4" />
              <h3 className="font-bold mb-2">Community First</h3>
              <p className="text-old-money-cream/80">We prioritize our members' success above everything else. Your profits are our success.</p>
            </div>
            <div className="text-center">
              <Shield className="w-8 h-8 text-old-money-sage mx-auto mb-4" />
              <h3 className="font-bold mb-2">Transparency</h3>
              <p className="text-old-money-cream/80">No hidden agendas. All our signal performance is tracked and publicly available.</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-old-money-gold mx-auto mb-4" />
              <h3 className="font-bold mb-2">Excellence</h3>
              <p className="text-old-money-cream/80">We continuously improve our AI algorithms to deliver the highest accuracy signals.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Timeline/History */}
      <div>
        <h2 className="text-3xl font-bold text-old-money-navy text-center mb-8">Our Journey</h2>
        <div className="space-y-6">
          {[
            { year: '2024', title: 'Platform Launch', description: 'Invest-Free.com goes live with free AI trading signals for crypto markets.' },
            { year: 'Q2 2024', title: 'Multi-Asset Expansion', description: 'Added forex, stocks, and commodities signals. Reached 10,000 members.' },
            { year: 'Q3 2024', title: 'Binance Partnership', description: 'Became official Binance partner, offering exclusive $100 bonus to members.' },
            { year: 'Q4 2024', title: 'Business Ideas Platform', description: 'Launched investment opportunities section with 50+ weekly business projects.' },
            { year: '2025', title: 'Global Expansion', description: 'Reached 125,000+ members across 150+ countries with 84% signal accuracy.' }
          ].map((milestone, index) => (
            <Card key={index} className="border-old-money-beige">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 bg-old-money-burgundy rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-old-money-cream font-bold text-sm">{milestone.year}</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-old-money-navy mb-2">{milestone.title}</h3>
                    <p className="text-old-money-warm-gray">{milestone.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <Card className="bg-gradient-to-r from-old-money-burgundy to-old-money-sage text-old-money-cream">
        <CardContent className="p-8 text-center">
          <Brain className="w-16 h-16 mx-auto mb-6 animate-pulse" />
          <h2 className="text-3xl font-bold mb-4">Ready to Join Our Success Story?</h2>
          <p className="text-xl mb-6 max-w-2xl mx-auto">
            Start your journey with FREE AI trading signals, business investment opportunities, 
            and a $100 Binance bonus. No credit card required.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              onClick={onShowAuthModal}
              className="bg-old-money-cream hover:bg-white text-old-money-burgundy font-bold px-8 py-4"
            >
              <CheckCircle className="w-6 h-6 mr-3" />
              Get Started Free
            </Button>
            <Button
              size="lg"
              onClick={handleBinanceClick}
              variant="outline"
              className="border-old-money-cream text-old-money-cream hover:bg-old-money-cream hover:text-old-money-burgundy font-bold px-8 py-4"
            >
              <ExternalLink className="w-6 h-6 mr-3" />
              Claim $100 Bonus
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}