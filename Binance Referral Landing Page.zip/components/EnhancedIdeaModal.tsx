import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Label } from './ui/label';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Upload, 
  X, 
  TrendingUp, 
  TrendingDown,
  Target,
  DollarSign,
  Clock,
  AlertTriangle,
  Search,
  Image,
  BarChart3,
  Bitcoin,
  TradingView,
  Activity,
  ExternalLink
} from 'lucide-react';

interface EnhancedIdeaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (idea: IdeaPost) => void;
  binanceReferralUrl: string;
}

interface IdeaPost {
  id: string;
  author: string;
  avatar: string;
  timeAgo: string;
  assetType: 'crypto' | 'forex' | 'binary';
  assetName: string;
  assetSymbol: string;
  analysis: string;
  prediction: 'bullish' | 'bearish' | 'neutral';
  entryPrice: string;
  targetPrice: string;
  stopLoss: string;
  timeframe: string;
  riskReward: string;
  images: string[];
  tags: string[];
  likes: number;
  comments: number;
  isLiked: boolean;
}

export function EnhancedIdeaModal({ isOpen, onClose, onSubmit, binanceReferralUrl }: EnhancedIdeaModalProps) {
  const [activeTab, setActiveTab] = useState<'crypto' | 'forex' | 'binary'>('crypto');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAsset, setSelectedAsset] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [prediction, setPrediction] = useState<'bullish' | 'bearish' | 'neutral'>('bullish');
  const [entryPrice, setEntryPrice] = useState('');
  const [targetPrice, setTargetPrice] = useState('');
  const [stopLoss, setStopLoss] = useState('');
  const [timeframe, setTimeframe] = useState('');
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [tags, setTags] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Asset databases
  const cryptoAssets = [
    { name: 'Bitcoin', symbol: 'BTC', price: '$99,250' },
    { name: 'Ethereum', symbol: 'ETH', price: '$3,650' },
    { name: 'Binance Coin', symbol: 'BNB', price: '$685' },
    { name: 'Solana', symbol: 'SOL', price: '$235' },
    { name: 'XRP', symbol: 'XRP', price: '$2.45' },
    { name: 'Cardano', symbol: 'ADA', price: '$1.28' },
    { name: 'Avalanche', symbol: 'AVAX', price: '$48.50' },
    { name: 'Polkadot', symbol: 'DOT', price: '$9.85' },
    { name: 'Chainlink', symbol: 'LINK', price: '$25.60' },
    { name: 'Polygon', symbol: 'MATIC', price: '$0.58' },
    { name: 'Cosmos', symbol: 'ATOM', price: '$12.40' },
    { name: 'Near Protocol', symbol: 'NEAR', price: '$8.95' },
    { name: 'Algorand', symbol: 'ALGO', price: '$0.45' },
    { name: 'VeChain', symbol: 'VET', price: '$0.085' },
    { name: 'Filecoin', symbol: 'FIL', price: '$7.20' }
  ];

  const forexPairs = [
    { name: 'EUR/USD', symbol: 'EURUSD', price: '1.0485' },
    { name: 'GBP/USD', symbol: 'GBPUSD', price: '1.2650' },
    { name: 'USD/JPY', symbol: 'USDJPY', price: '158.25' },
    { name: 'USD/CHF', symbol: 'USDCHF', price: '0.8920' },
    { name: 'AUD/USD', symbol: 'AUDUSD', price: '0.6285' },
    { name: 'USD/CAD', symbol: 'USDCAD', price: '1.4125' },
    { name: 'NZD/USD', symbol: 'NZDUSD', price: '0.5685' },
    { name: 'EUR/GBP', symbol: 'EURGBP', price: '0.8285' },
    { name: 'EUR/JPY', symbol: 'EURJPY', price: '165.85' },
    { name: 'GBP/JPY', symbol: 'GBPJPY', price: '200.15' },
    { name: 'AUD/JPY', symbol: 'AUDJPY', price: '99.45' },
    { name: 'USD/ZAR', symbol: 'USDZAR', price: '18.25' },
    { name: 'USD/MXN', symbol: 'USDMXN', price: '20.15' },
    { name: 'EUR/CAD', symbol: 'EURCAD', price: '1.4820' },
    { name: 'GBP/CAD', symbol: 'GBPCAD', price: '1.7865' }
  ];

  const binaryOptions = [
    { name: 'Gold vs USD', symbol: 'XAUUSD', price: '$2,685' },
    { name: 'Silver vs USD', symbol: 'XAGUSD', price: '$30.85' },
    { name: 'Oil Brent', symbol: 'BRENT', price: '$74.20' },
    { name: 'Oil WTI', symbol: 'WTI', price: '$69.85' },
    { name: 'S&P 500', symbol: 'SPX500', price: '5,975' },
    { name: 'NASDAQ 100', symbol: 'NAS100', price: '21,250' },
    { name: 'Dow Jones', symbol: 'US30', price: '44,850' },
    { name: 'FTSE 100', symbol: 'UK100', price: '8,285' },
    { name: 'DAX 40', symbol: 'GER40', price: '20,125' },
    { name: 'Nikkei 225', symbol: 'JPN225', price: '39,850' },
    { name: 'Apple Inc', symbol: 'AAPL', price: '$245.50' },
    { name: 'Tesla Inc', symbol: 'TSLA', price: '$385.20' },
    { name: 'Microsoft', symbol: 'MSFT', price: '$445.75' },
    { name: 'Amazon', symbol: 'AMZN', price: '$218.90' },
    { name: 'Google', symbol: 'GOOGL', price: '$178.25' }
  ];

  const getCurrentAssets = () => {
    switch (activeTab) {
      case 'crypto': return cryptoAssets;
      case 'forex': return forexPairs;
      case 'binary': return binaryOptions;
      default: return cryptoAssets;
    }
  };

  const filteredAssets = getCurrentAssets().filter(asset =>
    asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    asset.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      // Simulate image upload - in real app would upload to cloud storage
      const newImages = Array.from(files).map(file => URL.createObjectURL(file));
      setUploadedImages(prev => [...prev, ...newImages].slice(0, 4)); // Max 4 images
    }
  };

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const calculateRiskReward = () => {
    if (!entryPrice || !targetPrice || !stopLoss) return '';
    
    const entry = parseFloat(entryPrice);
    const target = parseFloat(targetPrice);
    const stop = parseFloat(stopLoss);
    
    if (entry <= 0 || target <= 0 || stop <= 0) return '';
    
    const reward = Math.abs(target - entry);
    const risk = Math.abs(entry - stop);
    
    if (risk === 0) return '';
    
    const ratio = (reward / risk).toFixed(2);
    return `1:${ratio}`;
  };

  const handleSubmit = async () => {
    if (!selectedAsset || !analysis || !entryPrice) return;

    setIsSubmitting(true);

    const selectedAssetData = getCurrentAssets().find(a => a.name === selectedAsset);
    
    const newIdea: IdeaPost = {
      id: Date.now().toString(),
      author: 'You', // Would be actual user name
      avatar: 'YU',
      timeAgo: 'Just now',
      assetType: activeTab,
      assetName: selectedAsset,
      assetSymbol: selectedAssetData?.symbol || '',
      analysis,
      prediction,
      entryPrice,
      targetPrice,
      stopLoss,
      timeframe,
      riskReward: calculateRiskReward(),
      images: uploadedImages,
      tags,
      likes: 0,
      comments: 0,
      isLiked: false
    };

    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API call
    
    onSubmit(newIdea);
    
    // Reset form
    setSelectedAsset('');
    setAnalysis('');
    setPrediction('bullish');
    setEntryPrice('');
    setTargetPrice('');
    setStopLoss('');
    setTimeframe('');
    setUploadedImages([]);
    setTags([]);
    setIsSubmitting(false);
    onClose();
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto border-old-money-beige">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-old-money-navy">
            <div className="w-10 h-10 bg-gradient-to-r from-old-money-navy to-old-money-charcoal rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-old-money-cream" />
            </div>
            Share Your Trading Idea
          </DialogTitle>
          <DialogDescription className="text-old-money-warm-gray">
            Share detailed analysis across Crypto, Forex & Binary Options with image uploads
          </DialogDescription>
        </DialogHeader>

        {/* Binance Trading Banner */}
        <Card className="bg-gradient-to-r from-old-money-gold/10 to-old-money-gold-light/10 border-old-money-gold/30 mb-6">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-old-money-gold rounded-full flex items-center justify-center">
                  <span className="text-old-money-navy font-bold text-sm">B</span>
                </div>
                <div>
                  <h4 className="font-medium text-old-money-navy">Execute Your Ideas on Binance</h4>
                  <p className="text-sm text-old-money-warm-gray">Share ideas, then trade them on the world's #1 exchange</p>
                </div>
              </div>
              <Button
                onClick={handleBinanceClick}
                className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Trade Now
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          {/* Asset Type Selection */}
          <div>
            <Label className="text-old-money-navy mb-3 block">Select Market Type</Label>
            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-old-money-cream-dark border border-old-money-beige">
                <TabsTrigger 
                  value="crypto" 
                  className="flex items-center gap-2 data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream"
                >
                  <Bitcoin className="w-4 h-4" />
                  Cryptocurrency
                </TabsTrigger>
                <TabsTrigger 
                  value="forex" 
                  className="flex items-center gap-2 data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream"
                >
                  <DollarSign className="w-4 h-4" />
                  Forex Pairs
                </TabsTrigger>
                <TabsTrigger 
                  value="binary" 
                  className="flex items-center gap-2 data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream"
                >
                  <Activity className="w-4 h-4" />
                  Binary Options
                </TabsTrigger>
              </TabsList>

              {/* Asset Selection for all tabs */}
              <div className="mt-6 space-y-4">
                {/* Search Asset */}
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-old-money-warm-gray" />
                  <Input
                    placeholder={`Search ${activeTab === 'crypto' ? 'cryptocurrencies' : activeTab === 'forex' ? 'currency pairs' : 'binary options'}...`}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 border-old-money-warm-gray focus:border-old-money-navy"
                  />
                </div>

                {/* Asset Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-64 overflow-y-auto">
                  {filteredAssets.map((asset) => (
                    <Card
                      key={asset.symbol}
                      className={`cursor-pointer transition-all hover:shadow-md ${
                        selectedAsset === asset.name 
                          ? 'border-old-money-navy bg-old-money-navy/5' 
                          : 'border-old-money-beige hover:border-old-money-warm-gray'
                      }`}
                      onClick={() => setSelectedAsset(asset.name)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium text-old-money-navy text-sm">{asset.symbol}</div>
                            <div className="text-xs text-old-money-warm-gray">{asset.name}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium text-old-money-charcoal">{asset.price}</div>
                            {selectedAsset === asset.name && (
                              <Badge className="bg-old-money-sage text-old-money-cream text-xs mt-1">Selected</Badge>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </Tabs>
          </div>

          {/* Trading Details */}
          {selectedAsset && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-old-money-navy">Market Prediction</Label>
                <Select value={prediction} onValueChange={(value: any) => setPrediction(value)}>
                  <SelectTrigger className="border-old-money-warm-gray focus:border-old-money-navy">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-old-money-beige">
                    <SelectItem value="bullish">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-old-money-sage" />
                        <span>Bullish (Up)</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="bearish">
                      <div className="flex items-center gap-2">
                        <TrendingDown className="w-4 h-4 text-old-money-burgundy" />
                        <span>Bearish (Down)</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="neutral">
                      <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-old-money-warm-gray" />
                        <span>Neutral (Sideways)</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-old-money-navy">Entry Price</Label>
                <Input
                  placeholder="Entry point"
                  value={entryPrice}
                  onChange={(e) => setEntryPrice(e.target.value)}
                  className="border-old-money-warm-gray focus:border-old-money-navy"
                />
              </div>

              <div>
                <Label className="text-old-money-navy">Time Frame</Label>
                <Select value={timeframe} onValueChange={setTimeframe}>
                  <SelectTrigger className="border-old-money-warm-gray focus:border-old-money-navy">
                    <SelectValue placeholder="Select timeframe" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-old-money-beige">
                    <SelectItem value="scalping">Scalping (1-15min)</SelectItem>
                    <SelectItem value="intraday">Intraday (1-4h)</SelectItem>
                    <SelectItem value="swing">Swing (1-7 days)</SelectItem>
                    <SelectItem value="position">Position (weeks-months)</SelectItem>
                    <SelectItem value="longterm">Long-term (months-years)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Price Targets & Risk Management */}
          {selectedAsset && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-old-money-navy">Target Price</Label>
                <Input
                  placeholder="Take profit level"
                  value={targetPrice}
                  onChange={(e) => setTargetPrice(e.target.value)}
                  className="border-old-money-warm-gray focus:border-old-money-navy"
                />
              </div>

              <div>
                <Label className="text-old-money-navy">Stop Loss</Label>
                <Input
                  placeholder="Risk management level"
                  value={stopLoss}
                  onChange={(e) => setStopLoss(e.target.value)}
                  className="border-old-money-warm-gray focus:border-old-money-navy"
                />
              </div>

              <div>
                <Label className="text-old-money-navy">Risk:Reward Ratio</Label>
                <div className="h-10 px-3 py-2 border border-old-money-warm-gray rounded-md bg-old-money-cream-dark flex items-center">
                  <span className="text-old-money-charcoal">
                    {calculateRiskReward() || 'Auto-calculated'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Analysis Text */}
          {selectedAsset && (
            <div>
              <Label className="text-old-money-navy">Detailed Analysis</Label>
              <Textarea
                placeholder="Share your technical analysis, fundamental reasons, market conditions, and any other insights that support your prediction..."
                value={analysis}
                onChange={(e) => setAnalysis(e.target.value)}
                rows={6}
                className="resize-none border-old-money-warm-gray focus:border-old-money-navy"
              />
            </div>
          )}

          {/* Image Upload */}
          {selectedAsset && (
            <div>
              <Label className="text-old-money-navy mb-3 block">Chart Analysis Images (Optional)</Label>
              
              <div className="border-2 border-dashed border-old-money-warm-gray rounded-lg p-6 text-center">
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                <label htmlFor="image-upload" className="cursor-pointer">
                  <div className="flex flex-col items-center gap-2">
                    <Upload className="w-8 h-8 text-old-money-warm-gray" />
                    <div className="text-old-money-warm-gray">
                      <span className="font-medium">Click to upload</span> or drag and drop
                    </div>
                    <div className="text-xs text-old-money-warm-gray">
                      PNG, JPG up to 5MB (Max 4 images)
                    </div>
                  </div>
                </label>
              </div>

              {/* Uploaded Images Preview */}
              {uploadedImages.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
                  {uploadedImages.map((image, index) => (
                    <div key={index} className="relative group">
                      <ImageWithFallback
                        src={image}
                        alt={`Analysis ${index + 1}`}
                        className="w-full h-24 object-cover rounded-lg border border-old-money-beige"
                      />
                      <Button
                        size="sm"
                        variant="destructive"
                        className="absolute -top-2 -right-2 w-6 h-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => removeImage(index)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-6 border-t border-old-money-beige">
            <div className="flex items-center gap-2 text-sm text-old-money-warm-gray">
              <AlertTriangle className="w-4 h-4" />
              <span>Not financial advice. Trade at your own risk.</span>
            </div>
            
            <div className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={onClose}
                className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleSubmit}
                disabled={!selectedAsset || !analysis || !entryPrice || isSubmitting}
                className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
              >
                {isSubmitting ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-old-money-cream border-t-transparent rounded-full animate-spin" />
                    Posting...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    Share Analysis
                  </div>
                )}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}