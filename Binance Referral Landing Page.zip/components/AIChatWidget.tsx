import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  MessageCircle, 
  X, 
  Send, 
  Bot, 
  User, 
  Minimize2,
  Maximize2,
  Brain,
  Sparkles,
  TrendingUp,
  DollarSign,
  BarChart3,
  Lightbulb,
  Clock,
  Zap,
  Target,
  Shield,
  AlertCircle,
  CheckCircle,
  Loader2,
  ChevronDown,
  Star,
  ThumbsUp,
  Copy,
  ExternalLink
} from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  category?: 'trading' | 'general' | 'signals' | 'education';
  isTyping?: boolean;
  actions?: {
    label: string;
    action: () => void;
    icon?: React.ReactNode;
  }[];
}

interface AIChatWidgetProps {
  translations: any;
  user?: any;
  onShowAuthModal?: () => void;
  binanceReferralUrl: string;
}

// AI Response Generator - Professional Trading Assistant
const generateAIResponse = (message: string, user: any): Promise<Message> => {
  return new Promise((resolve) => {
    const lowerMessage = message.toLowerCase();
    
    setTimeout(() => {
      let response: Message;
      
      // Trading Signal Requests
      if (lowerMessage.includes('signal') || lowerMessage.includes('buy') || lowerMessage.includes('sell')) {
        response = {
          id: Date.now().toString(),
          type: 'ai',
          content: `🚀 **AI Trading Analysis**

Based on current market conditions, here are my top recommendations:

**🔥 High Confidence Signals:**
• **BTC/USDT**: Strong BUY at $98,750 - Target: $105,000 (6.3% gain)
• **ETH/USDT**: BUY on dips to $3,400 - Target: $3,850 (13.2% gain)  
• **AAPL**: Position BUY - Target: $245 (8.5% gain)

**⚠️ Risk Management:**
- Never risk more than 3-5% per trade
- Always set stop-losses
- Diversify across asset classes

Would you like detailed analysis for any specific asset?`,
          timestamp: new Date(),
          category: 'signals',
          actions: [
            {
              label: 'View All Signals',
              action: () => window.location.hash = '#signals',
              icon: <TrendingUp className="w-4 h-4" />
            },
            {
              label: 'Start Trading',
              action: () => window.open('https://accounts.binance.com/register?ref=775659502', '_blank'),
              icon: <ExternalLink className="w-4 h-4" />
            }
          ]
        };
      }
      
      // Market Analysis Requests
      else if (lowerMessage.includes('market') || lowerMessage.includes('analysis') || lowerMessage.includes('forecast')) {
        response = {
          id: Date.now().toString(),
          type: 'ai',
          content: `📊 **Live Market Analysis**

**Current Market Sentiment**: BULLISH 🟢
**Fear & Greed Index**: 78 (Extreme Greed)

**🔍 Key Market Insights:**
• **Crypto**: Bitcoin testing $100K resistance, altseason beginning
• **Stocks**: S&P 500 near ATH, tech earnings driving momentum  
• **Forex**: USD strength continuing, EUR/USD bearish
• **Commodities**: Gold breaking $2,700, inflation hedge active

**📈 This Week's Focus:**
1. Bitcoin $100K breakout attempt
2. FOMC meeting impact on rates
3. Big Tech earnings (NVDA, MSFT)
4. Jobs report on Friday

Market volatility expected to increase. Perfect for swing trading opportunities!`,
          timestamp: new Date(),
          category: 'trading',
          actions: [
            {
              label: 'Market News',
              action: () => window.location.hash = '#news',
              icon: <BarChart3 className="w-4 h-4" />
            }
          ]
        };
      }
      
      // Education & Learning
      else if (lowerMessage.includes('learn') || lowerMessage.includes('how') || lowerMessage.includes('beginner') || lowerMessage.includes('start')) {
        response = {
          id: Date.now().toString(),
          type: 'ai',
          content: `🎓 **Trading Education Hub**

**For Beginners - Start Here:**

**📚 Essential Steps:**
1. **Risk Management** - Never risk more than you can afford to lose
2. **Asset Allocation** - Diversify: 60% safe assets, 40% growth
3. **Dollar Cost Averaging** - Invest consistently over time
4. **Paper Trading** - Practice before using real money

**🔰 Beginner-Friendly Investments:**
• **S&P 500 ETF (SPY)** - Safest long-term growth
• **Bitcoin** - Digital gold for portfolio (5-10% max)
• **Apple/Microsoft** - Quality blue-chip stocks

**📖 Learning Resources:**
• Free signals with explanations
• Business learning articles
• Community discussions
• Step-by-step tutorials

Ready to start your investment journey?`,
          timestamp: new Date(),
          category: 'education',
          actions: [
            {
              label: 'Learning Center',
              action: () => window.location.hash = '#blog',
              icon: <Lightbulb className="w-4 h-4" />
            },
            {
              label: 'Beginner Signals',
              action: () => window.location.hash = '#signals',
              icon: <Shield className="w-4 h-4" />
            }
          ]
        };
      }
      
      // Crypto Specific
      else if (lowerMessage.includes('crypto') || lowerMessage.includes('bitcoin') || lowerMessage.includes('btc') || lowerMessage.includes('ethereum')) {
        response = {
          id: Date.now().toString(),
          type: 'ai',
          content: `₿ **Crypto Market Update**

**Bitcoin Analysis:**
• **Price**: $98,750 (+2.4% today)
• **Resistance**: $100,000 (psychological level)
• **Support**: $95,000 (strong institutional buying)
• **Prediction**: 65% chance of $100K break this month

**🔥 Top Crypto Opportunities:**
1. **BTC** - Digital gold narrative strengthening
2. **ETH** - Ethereum 2.0 staking at 28% supply
3. **Stablecoins** - 8-12% yield opportunities

**⚡ Market Catalysts:**
• BlackRock ETF inflows: $2.1B this week
• MicroStrategy bought 15,400 BTC
• Fed policy turning crypto-friendly

**🛡️ Safety First:**
- Only invest 5-15% in crypto
- Use Binance for security & liquidity
- Set stop-losses on all positions

Crypto winter is over - bull market confirmed! 🚀`,
          timestamp: new Date(),
          category: 'trading',
          actions: [
            {
              label: 'Crypto Signals',
              action: () => window.location.hash = '#signals',
              icon: <TrendingUp className="w-4 h-4" />
            },
            {
              label: 'Trade Crypto',
              action: () => window.open('https://accounts.binance.com/register?ref=775659502', '_blank'),
              icon: <ExternalLink className="w-4 h-4" />
            }
          ]
        };
      }
      
      // Account/Profile Related
      else if (lowerMessage.includes('account') || lowerMessage.includes('profile') || lowerMessage.includes('premium')) {
        response = {
          id: Date.now().toString(),
          type: 'ai',
          content: user ? 
            `👤 **Account Status**: Premium Member ✨

**Your Benefits:**
• ✅ Unlimited AI signal generation
• ✅ Real-time market alerts  
• ✅ Professional analysis access
• ✅ Priority customer support
• ✅ Trading competitions entry

**📊 Your Stats:**
• Member since: ${new Date().toLocaleDateString()}
• Signals accessed: 247
• Community posts: ${Math.floor(Math.random() * 20) + 5}
• Accuracy rate: 89%

**🎯 Recommendations:**
1. Enable push notifications for hot signals
2. Join our Telegram VIP group
3. Link your Binance account for easier trading

Keep up the great work! 🚀` :
            `🔐 **Account Registration Required**

**Join FREE to unlock:**
• 🎯 Unlimited AI trading signals
• 📊 Real-time market analysis
• 💬 VIP community access
• 🚨 Custom price alerts
• 📚 Premium education content

**🎁 Welcome Bonus:**
• $100 Binance trading credit
• First week: 10 exclusive AI signals daily
• Direct access to pro traders
• Risk management course (FREE)

**⏱️ 30-Second Registration:**
Just email + password, no credit card required!

Ready to join 50,000+ successful traders?`,
          timestamp: new Date(),
          category: 'general',
          actions: user ? [
            {
              label: 'View Profile',
              action: () => window.location.hash = '#profile',
              icon: <User className="w-4 h-4" />
            }
          ] : [
            {
              label: 'Join Free',
              action: () => {},
              icon: <Star className="w-4 h-4" />
            }
          ]
        };
      }
      
      // Default helpful response
      else {
        response = {
          id: Date.now().toString(),
          type: 'ai',
          content: `🤖 **AI Trading Assistant Ready!**

I'm here to help you with:

**📈 Trading Signals**
• Real-time buy/sell recommendations
• Risk management advice
• Market timing insights

**📊 Market Analysis** 
• Live price updates
• Trend predictions
• Economic calendar events

**🎓 Education**
• Beginner trading guides
• Advanced strategies
• Risk management tips

**💬 Quick Commands:**
• "Show me signals" - Latest trading opportunities
• "Market analysis" - Current market overview
• "How to start" - Beginner's guide
• "Crypto update" - Bitcoin & altcoin insights

**🚀 Popular Right Now:**
• Bitcoin approaching $100K
• AI stocks (NVDA, MSFT) surging
• Gold breaking all-time highs

What would you like to explore first?`,
          timestamp: new Date(),
          category: 'general',
          actions: [
            {
              label: 'View Signals',
              action: () => window.location.hash = '#signals',
              icon: <TrendingUp className="w-4 h-4" />
            },
            {
              label: 'Market News',
              action: () => window.location.hash = '#news', 
              icon: <BarChart3 className="w-4 h-4" />
            }
          ]
        };
      }
      
      resolve(response);
    }, Math.random() * 2000 + 1000); // 1-3 second realistic delay
  });
};

// Quick suggestion buttons
const quickSuggestions = [
  { text: "Show me today's best signals", icon: <TrendingUp className="w-4 h-4" /> },
  { text: "What's happening in crypto?", icon: <DollarSign className="w-4 h-4" /> },
  { text: "How do I start trading?", icon: <Lightbulb className="w-4 h-4" /> },
  { text: "Current market analysis", icon: <BarChart3 className="w-4 h-4" /> },
  { text: "Risk management tips", icon: <Shield className="w-4 h-4" /> },
  { text: "Binance trading guide", icon: <Target className="w-4 h-4" /> }
];

export default function AIChatWidget({ translations, user, onShowAuthModal, binanceReferralUrl }: AIChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: `👋 **Welcome to AI Trading Assistant!**

I'm your 24/7 trading companion powered by advanced AI. I can help you with:

• 🎯 **Live trading signals** with 90%+ accuracy
• 📊 **Real-time market analysis** and forecasts  
• 🎓 **Trading education** for all skill levels
• 💡 **Investment strategies** and risk management

**🔥 Today's Market Highlights:**
• Bitcoin testing $100K resistance 
• AI stocks hitting new highs
• Gold breaking records

Type your question or choose a quick option below! 🚀`,
      timestamp: new Date(Date.now() - 30000),
      category: 'general'
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  // Handle new message when widget is closed
  useEffect(() => {
    if (!isOpen && messages.length > 1) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.type === 'ai') {
        setUnreadCount(prev => prev + 1);
      }
    } else if (isOpen) {
      setUnreadCount(0);
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (messageText?: string) => {
    const text = messageText || inputMessage.trim();
    if (!text) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: text,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    try {
      const aiResponse = await generateAIResponse(text, user);
      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      const errorResponse: Message = {
        id: Date.now().toString(),
        type: 'ai',
        content: "I'm experiencing some technical difficulties. Please try again or contact our support team.",
        timestamp: new Date(),
        category: 'general'
      };
      setMessages(prev => [...prev, errorResponse]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleQuickSuggestion = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  // Widget toggle button
  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="relative w-14 h-14 rounded-full bg-gradient-to-r from-old-money-navy to-old-money-burgundy hover:from-old-money-navy-light hover:to-old-money-burgundy-light text-old-money-cream shadow-lg hover:shadow-xl transition-all duration-300 group"
        >
          <div className="relative">
            <MessageCircle className="w-6 h-6" />
            <Sparkles className="w-3 h-3 absolute -top-1 -right-1 text-old-money-gold animate-pulse" />
            {unreadCount > 0 && (
              <Badge className="absolute -top-2 -right-2 w-5 h-5 text-xs bg-old-money-gold text-old-money-navy p-0 flex items-center justify-center">
                {unreadCount}
              </Badge>
            )}
          </div>
          
          {/* Floating help text */}
          <div className="absolute bottom-full right-0 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
            <div className="bg-old-money-navy text-old-money-cream text-sm px-3 py-2 rounded-lg whitespace-nowrap">
              💬 AI Trading Assistant
              <div className="absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-old-money-navy"></div>
            </div>
          </div>
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className={`w-96 ${isMinimized ? 'h-16' : 'h-[600px]'} bg-old-money-cream border-old-money-beige shadow-2xl transition-all duration-300`}>
        {/* Header */}
        <CardHeader className="bg-gradient-to-r from-old-money-navy to-old-money-burgundy text-old-money-cream p-4 rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-8 h-8 rounded-full bg-old-money-gold/20 flex items-center justify-center">
                  <Brain className="w-4 h-4 text-old-money-gold" />
                </div>
                <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-old-money-navy"></div>
              </div>
              
              {!isMinimized && (
                <div>
                  <CardTitle className="text-lg font-bold">AI Trading Assistant</CardTitle>
                  <p className="text-xs opacity-90">
                    {isTyping ? '🤖 AI is typing...' : '✨ Powered by advanced AI • Always online'}
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMinimized(!isMinimized)}
                className="text-old-money-cream hover:bg-old-money-navy-light p-1 h-8 w-8"
              >
                {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="text-old-money-cream hover:bg-old-money-navy-light p-1 h-8 w-8"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        {!isMinimized && (
          <CardContent className="p-0 flex flex-col h-[536px]">
            {/* Messages Area */}
            <ScrollArea ref={scrollAreaRef} className="flex-1 p-4 space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] ${message.type === 'user' ? 'order-2' : 'order-1'}`}>
                    {/* Message bubble */}
                    <div className={`rounded-lg p-3 ${
                      message.type === 'user' 
                        ? 'bg-old-money-navy text-old-money-cream ml-auto' 
                        : 'bg-old-money-beige text-old-money-navy'
                    }`}>
                      {/* Avatar */}
                      <div className={`flex items-start gap-2 ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                          message.type === 'user' ? 'bg-old-money-gold/20' : 'bg-old-money-navy/10'
                        }`}>
                          {message.type === 'user' ? 
                            <User className="w-3 h-3" /> : 
                            <Bot className="w-3 h-3 text-old-money-navy" />
                          }
                        </div>
                        
                        <div className="flex-1">
                          {/* Message content */}
                          <div className="prose prose-sm max-w-none">
                            <div className="whitespace-pre-wrap text-sm leading-relaxed">
                              {message.content}
                            </div>
                          </div>
                          
                          {/* Action buttons */}
                          {message.actions && message.actions.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-3">
                              {message.actions.map((action, index) => (
                                <Button
                                  key={index}
                                  variant="outline"
                                  size="sm"
                                  onClick={action.action}
                                  className="text-xs h-7 bg-old-money-cream hover:bg-old-money-cream-dark border-old-money-warm-gray text-old-money-navy"
                                >
                                  {action.icon}
                                  {action.label}
                                </Button>
                              ))}
                            </div>
                          )}
                          
                          {/* Message metadata */}
                          <div className={`flex items-center gap-2 mt-2 text-xs opacity-70 ${
                            message.type === 'user' ? 'justify-end' : 'justify-start'
                          }`}>
                            <Clock className="w-3 h-3" />
                            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            
                            {message.type === 'ai' && (
                              <>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => copyMessage(message.content)}
                                  className="p-0 h-4 w-4 hover:bg-transparent"
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="p-0 h-4 w-4 hover:bg-transparent"
                                >
                                  <ThumbsUp className="w-3 h-3" />
                                </Button>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-old-money-beige text-old-money-navy rounded-lg p-3 max-w-[85%]">
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4" />
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm">AI is analyzing your request...</span>
                    </div>
                  </div>
                </div>
              )}
            </ScrollArea>

            <Separator />

            {/* Quick suggestions */}
            <div className="p-3 bg-old-money-cream-dark">
              <div className="flex flex-wrap gap-1 mb-3">
                {quickSuggestions.slice(0, 3).map((suggestion, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickSuggestion(suggestion.text)}
                    className="text-xs h-6 bg-old-money-cream hover:bg-old-money-beige border-old-money-warm-gray/30 text-old-money-navy"
                  >
                    {suggestion.icon}
                    {suggestion.text.slice(0, 20)}...
                  </Button>
                ))}
              </div>
            </div>

            {/* Input area */}
            <div className="p-4 bg-old-money-cream border-t border-old-money-beige">
              <div className="flex gap-2">
                <Input
                  ref={inputRef}
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me about trading, signals, market analysis..."
                  className="flex-1 border-old-money-warm-gray/30 focus:border-old-money-navy"
                  disabled={isTyping}
                />
                <Button
                  onClick={() => handleSendMessage()}
                  disabled={!inputMessage.trim() || isTyping}
                  className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream px-3"
                >
                  {isTyping ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </Button>
              </div>
              
              {/* Status bar */}
              <div className="flex items-center justify-between mt-2 text-xs text-old-money-warm-gray">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>AI Online • Response time: &lt;3s</span>
                </div>
                <div className="flex items-center gap-1">
                  <Shield className="w-3 h-3" />
                  <span>Secure & Private</span>
                </div>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}