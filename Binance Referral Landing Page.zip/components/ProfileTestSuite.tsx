import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  CheckCircle, 
  XCircle, 
  Clock,
  User,
  MessageCircle,
  Heart,
  Share2,
  Target,
  Gift,
  ExternalLink,
  Play,
  TestTube
} from 'lucide-react';

interface TestResult {
  id: string;
  name: string;
  description: string;
  status: 'pending' | 'running' | 'passed' | 'failed';
  duration?: number;
  error?: string;
  details?: string;
}

export function ProfileTestSuite() {
  const [isRunning, setIsRunning] = useState(false);
  const [currentTest, setCurrentTest] = useState(0);
  const [testResults, setTestResults] = useState<TestResult[]>([
    {
      id: 'auth-modal',
      name: 'Authentication Modal',
      description: 'Test user registration and login functionality',
      status: 'pending'
    },
    {
      id: 'user-registration',
      name: 'User Registration',
      description: 'Create new user account with validation',
      status: 'pending'
    },
    {
      id: 'user-login',
      name: 'User Login',
      description: 'Authenticate existing user',
      status: 'pending'
    },
    {
      id: 'profile-creation',
      name: 'Profile Creation',
      description: 'Create user profile with all required data',
      status: 'pending'
    },
    {
      id: 'idea-posting',
      name: 'Investment Idea Posting',
      description: 'Share new investment idea in community feed',
      status: 'pending'
    },
    {
      id: 'idea-interaction',
      name: 'Idea Interactions',
      description: 'Like, comment, and share investment ideas',
      status: 'pending'
    },
    {
      id: 'profile-dashboard',
      name: 'Profile Dashboard',
      description: 'Display user stats and recent activity',
      status: 'pending'
    },
    {
      id: 'profile-editing',
      name: 'Profile Editing',
      description: 'Update user profile information',
      status: 'pending'
    },
    {
      id: 'referral-system',
      name: 'Referral System',
      description: 'Generate and track referral links',
      status: 'pending'
    },
    {
      id: 'binance-integration',
      name: 'Binance Integration',
      description: 'Test Binance referral link functionality',
      status: 'pending'
    },
    {
      id: 'data-persistence',
      name: 'Data Persistence',
      description: 'Ensure user data persists across sessions',
      status: 'pending'
    },
    {
      id: 'achievements',
      name: 'Achievement System',
      description: 'Track user progress and unlock achievements',
      status: 'pending'
    }
  ]);

  const simulateTest = async (testId: string): Promise<{ success: boolean; duration: number; error?: string; details?: string }> => {
    const startTime = Date.now();
    await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 1000));
    const duration = Date.now() - startTime;

    // Test implementations
    switch (testId) {
      case 'auth-modal':
        try {
          // Test if AuthModal component exists and renders
          const authModalExists = typeof require('../components/AuthModal').AuthModal === 'function';
          return {
            success: authModalExists,
            duration,
            details: authModalExists ? 'AuthModal component loaded successfully' : 'AuthModal component not found'
          };
        } catch (error) {
          return { success: false, duration, error: 'AuthModal import failed', details: 'Component may be missing or have syntax errors' };
        }

      case 'user-registration':
        try {
          // Simulate user registration
          const testUser = {
            id: Date.now(),
            username: 'TestUser123',
            email: 'test@example.com',
            avatar: 'TU',
            isVip: false,
            isExpert: false,
            referralCode: 'REFTEST123',
            bonusAmount: 100,
            joinDate: new Date().toISOString(),
            totalPosts: 0,
            totalLikes: 0,
            successfulPredictions: 0,
            rank: 'Beginner',
            binanceLinked: false,
            bio: '',
            favoriteCoins: ['BTC', 'ETH']
          };
          
          localStorage.setItem('test-user', JSON.stringify(testUser));
          const saved = localStorage.getItem('test-user');
          
          return {
            success: !!saved,
            duration,
            details: saved ? 'User registration completed successfully' : 'Failed to save user data'
          };
        } catch (error) {
          return { success: false, duration, error: 'Registration simulation failed' };
        }

      case 'user-login':
        try {
          // Test user login simulation
          const savedUser = localStorage.getItem('test-user');
          if (savedUser) {
            const user = JSON.parse(savedUser);
            return {
              success: true,
              duration,
              details: `Login successful for user: ${user.username}`
            };
          }
          return { success: false, duration, error: 'No user found to login' };
        } catch (error) {
          return { success: false, duration, error: 'Login simulation failed' };
        }

      case 'profile-creation':
        try {
          const savedUser = localStorage.getItem('test-user');
          if (savedUser) {
            const user = JSON.parse(savedUser);
            // Verify all required profile fields exist
            const requiredFields = ['id', 'username', 'email', 'avatar', 'referralCode', 'bonusAmount'];
            const hasAllFields = requiredFields.every(field => user[field] !== undefined);
            
            return {
              success: hasAllFields,
              duration,
              details: hasAllFields ? 'Profile has all required fields' : 'Missing required profile fields'
            };
          }
          return { success: false, duration, error: 'No user profile found' };
        } catch (error) {
          return { success: false, duration, error: 'Profile creation test failed' };
        }

      case 'idea-posting':
        try {
          // Simulate posting an investment idea
          const testIdea = {
            id: Date.now().toString(),
            author: 'TestUser123',
            avatar: 'TU',
            timeAgo: 'Just now',
            coin: 'Bitcoin',
            coinSymbol: 'BTC',
            advice: 'Test investment idea: BTC looking bullish, expecting $120k by March. Strong support at $95k.',
            target: '$120,000 by March 2025',
            currentPrice: '$99,250',
            prediction: 'bullish' as const,
            likes: 0,
            comments: 0,
            isLiked: false
          };
          
          const existingPosts = JSON.parse(localStorage.getItem('test-posts') || '[]');
          existingPosts.push(testIdea);
          localStorage.setItem('test-posts', JSON.stringify(existingPosts));
          
          return {
            success: true,
            duration,
            details: 'Investment idea posted successfully'
          };
        } catch (error) {
          return { success: false, duration, error: 'Failed to post investment idea' };
        }

      case 'idea-interaction':
        try {
          // Test liking and interaction with ideas
          const posts = JSON.parse(localStorage.getItem('test-posts') || '[]');
          if (posts.length > 0) {
            posts[0].likes += 1;
            posts[0].isLiked = true;
            localStorage.setItem('test-posts', JSON.stringify(posts));
            
            return {
              success: true,
              duration,
              details: 'Idea interaction (like) successful'
            };
          }
          return { success: false, duration, error: 'No ideas found to interact with' };
        } catch (error) {
          return { success: false, duration, error: 'Idea interaction test failed' };
        }

      case 'profile-dashboard':
        try {
          const savedUser = localStorage.getItem('test-user');
          const posts = JSON.parse(localStorage.getItem('test-posts') || '[]');
          
          if (savedUser) {
            const user = JSON.parse(savedUser);
            const userPosts = posts.filter((post: any) => post.author === user.username);
            const totalLikes = userPosts.reduce((sum: number, post: any) => sum + post.likes, 0);
            
            return {
              success: true,
              duration,
              details: `Dashboard showing ${userPosts.length} posts with ${totalLikes} total likes`
            };
          }
          return { success: false, duration, error: 'No user profile for dashboard' };
        } catch (error) {
          return { success: false, duration, error: 'Dashboard test failed' };
        }

      case 'profile-editing':
        try {
          const savedUser = localStorage.getItem('test-user');
          if (savedUser) {
            const user = JSON.parse(savedUser);
            user.bio = 'Updated bio: Experienced crypto trader focusing on DeFi protocols.';
            user.favoriteCoins = ['BTC', 'ETH', 'SOL'];
            localStorage.setItem('test-user', JSON.stringify(user));
            
            return {
              success: true,
              duration,
              details: 'Profile updated successfully'
            };
          }
          return { success: false, duration, error: 'No user profile to edit' };
        } catch (error) {
          return { success: false, duration, error: 'Profile editing test failed' };
        }

      case 'referral-system':
        try {
          const savedUser = localStorage.getItem('test-user');
          if (savedUser) {
            const user = JSON.parse(savedUser);
            const referralLink = `https://invest-free.com/ref/${user.referralCode}`;
            
            // Simulate referral tracking
            const referralStats = {
              totalReferrals: 5,
              activeReferrals: 4,
              totalEarned: 250,
              thisMonth: 100
            };
            
            localStorage.setItem('referral-stats', JSON.stringify(referralStats));
            
            return {
              success: true,
              duration,
              details: `Referral system working. Link: ${referralLink}`
            };
          }
          return { success: false, duration, error: 'No user for referral system' };
        } catch (error) {
          return { success: false, duration, error: 'Referral system test failed' };
        }

      case 'binance-integration':
        try {
          const binanceUrl = 'https://www.binance.com/activity/referral-entry/CPA?ref=CPA_005R7YO1ZW';
          // Test URL format
          const urlValid = binanceUrl.includes('binance.com') && binanceUrl.includes('ref=');
          
          return {
            success: urlValid,
            duration,
            details: urlValid ? 'Binance referral URL is valid' : 'Invalid Binance URL format'
          };
        } catch (error) {
          return { success: false, duration, error: 'Binance integration test failed' };
        }

      case 'data-persistence':
        try {
          // Test if data persists
          const user = localStorage.getItem('test-user');
          const posts = localStorage.getItem('test-posts');
          const referrals = localStorage.getItem('referral-stats');
          
          const allDataExists = !!(user && posts && referrals);
          
          return {
            success: allDataExists,
            duration,
            details: allDataExists ? 'All data persisted successfully' : 'Some data failed to persist'
          };
        } catch (error) {
          return { success: false, duration, error: 'Data persistence test failed' };
        }

      case 'achievements':
        try {
          const savedUser = localStorage.getItem('test-user');
          const posts = JSON.parse(localStorage.getItem('test-posts') || '[]');
          
          if (savedUser) {
            const user = JSON.parse(savedUser);
            const userPosts = posts.filter((post: any) => post.author === user.username);
            
            // Simulate achievement system
            const achievements = [];
            if (userPosts.length >= 1) achievements.push('First Post');
            if (user.totalLikes >= 10) achievements.push('Popular');
            if (user.referralCode) achievements.push('Referrer');
            
            return {
              success: true,
              duration,
              details: `User has ${achievements.length} achievements: ${achievements.join(', ')}`
            };
          }
          return { success: false, duration, error: 'No user for achievements' };
        } catch (error) {
          return { success: false, duration, error: 'Achievement system test failed' };
        }

      default:
        return { success: false, duration, error: 'Unknown test' };
    }
  };

  const runTests = async () => {
    setIsRunning(true);
    setCurrentTest(0);
    
    // Reset test results
    setTestResults(prev => prev.map(test => ({ ...test, status: 'pending' as const })));

    for (let i = 0; i < testResults.length; i++) {
      setCurrentTest(i);
      
      // Update test status to running
      setTestResults(prev => prev.map((test, index) => 
        index === i ? { ...test, status: 'running' as const } : test
      ));

      try {
        const result = await simulateTest(testResults[i].id);
        
        // Update test result
        setTestResults(prev => prev.map((test, index) => 
          index === i ? {
            ...test,
            status: result.success ? 'passed' as const : 'failed' as const,
            duration: result.duration,
            error: result.error,
            details: result.details
          } : test
        ));
      } catch (error) {
        setTestResults(prev => prev.map((test, index) => 
          index === i ? {
            ...test,
            status: 'failed' as const,
            error: 'Test execution failed'
          } : test
        ));
      }
    }

    setIsRunning(false);
    setCurrentTest(-1);
  };

  const cleanupTestData = () => {
    localStorage.removeItem('test-user');
    localStorage.removeItem('test-posts');
    localStorage.removeItem('referral-stats');
    setTestResults(prev => prev.map(test => ({ ...test, status: 'pending' as const })));
  };

  const passedTests = testResults.filter(test => test.status === 'passed').length;
  const failedTests = testResults.filter(test => test.status === 'failed').length;
  const progressPercentage = Math.round((passedTests + failedTests) / testResults.length * 100);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Card className="mb-8 border-old-money-beige">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-old-money-navy">
            <div className="w-10 h-10 bg-gradient-to-r from-old-money-navy to-old-money-charcoal rounded-xl flex items-center justify-center">
              <TestTube className="w-5 h-5 text-old-money-cream" />
            </div>
            Profile & Community Function Test Suite
          </CardTitle>
          <div className="text-old-money-warm-gray">
            Comprehensive testing of all user profile and idea sharing functionality
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="flex items-center justify-between mb-6">
            <div className="flex gap-4">
              <Button 
                onClick={runTests} 
                disabled={isRunning}
                className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
              >
                {isRunning ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-old-money-cream border-t-transparent rounded-full animate-spin" />
                    Running Tests...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Play className="w-4 h-4" />
                    Run All Tests
                  </div>
                )}
              </Button>
              
              <Button 
                variant="outline" 
                onClick={cleanupTestData}
                className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark"
              >
                Clear Test Data
              </Button>
            </div>
            
            <div className="text-right">
              <div className="text-sm text-old-money-warm-gray">Progress</div>
              <div className="flex items-center gap-2">
                <Progress value={progressPercentage} className="w-32" />
                <span className="text-sm font-medium text-old-money-navy">{progressPercentage}%</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="bg-old-money-sage/10 border-old-money-sage/30">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-old-money-sage">{passedTests}</div>
                <div className="text-sm text-old-money-charcoal">Passed</div>
              </CardContent>
            </Card>
            
            <Card className="bg-old-money-burgundy/10 border-old-money-burgundy/30">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-old-money-burgundy">{failedTests}</div>
                <div className="text-sm text-old-money-charcoal">Failed</div>
              </CardContent>
            </Card>
            
            <Card className="bg-old-money-warm-gray/10 border-old-money-warm-gray/30">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-old-money-warm-gray">{testResults.length - passedTests - failedTests}</div>
                <div className="text-sm text-old-money-charcoal">Pending</div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        {testResults.map((test, index) => (
          <Card 
            key={test.id} 
            className={`border-l-4 transition-all duration-200 ${
              test.status === 'passed' ? 'border-l-old-money-sage bg-old-money-sage/5' :
              test.status === 'failed' ? 'border-l-old-money-burgundy bg-old-money-burgundy/5' :
              test.status === 'running' ? 'border-l-old-money-navy bg-old-money-navy/5' :
              'border-l-old-money-warm-gray bg-old-money-cream-dark'
            }`}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full">
                    {test.status === 'passed' && <CheckCircle className="w-6 h-6 text-old-money-sage" />}
                    {test.status === 'failed' && <XCircle className="w-6 h-6 text-old-money-burgundy" />}
                    {test.status === 'running' && <div className="w-5 h-5 border-2 border-old-money-navy border-t-transparent rounded-full animate-spin" />}
                    {test.status === 'pending' && <Clock className="w-6 h-6 text-old-money-warm-gray" />}
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-old-money-navy">{test.name}</h3>
                    <p className="text-sm text-old-money-warm-gray">{test.description}</p>
                    {test.details && (
                      <p className="text-xs text-old-money-charcoal mt-1">{test.details}</p>
                    )}
                    {test.error && (
                      <p className="text-xs text-old-money-burgundy mt-1">Error: {test.error}</p>
                    )}
                  </div>
                </div>
                
                <div className="text-right">
                  <Badge 
                    className={
                      test.status === 'passed' ? 'bg-old-money-sage text-old-money-cream' :
                      test.status === 'failed' ? 'bg-old-money-burgundy text-old-money-cream' :
                      test.status === 'running' ? 'bg-old-money-navy text-old-money-cream' :
                      'bg-old-money-warm-gray text-old-money-cream'
                    }
                  >
                    {test.status.toUpperCase()}
                  </Badge>
                  {test.duration && (
                    <div className="text-xs text-old-money-warm-gray mt-1">
                      {test.duration}ms
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Real Function Tests */}
      <Card className="mt-8 border-old-money-beige">
        <CardHeader>
          <CardTitle className="text-old-money-navy">Manual Function Verification</CardTitle>
          <div className="text-old-money-warm-gray">Test these functions manually to verify they work properly</div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-old-money-navy mb-3">User Authentication</h4>
              <ul className="text-sm text-old-money-charcoal space-y-2">
                <li>✓ Click "Join Free" to open registration modal</li>
                <li>✓ Fill out registration form with valid data</li>
                <li>✓ Submit form and verify user creation</li>
                <li>✓ Test login with created credentials</li>
                <li>✓ Verify user avatar appears in header</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-old-money-navy mb-3">Idea Sharing</h4>
              <ul className="text-sm text-old-money-charcoal space-y-2">
                <li>✓ Navigate to "Ideas" tab</li>
                <li>✓ Click "Share Your Idea" button</li>
                <li>✓ Select cryptocurrency from dropdown</li>
                <li>✓ Write investment advice and target</li>
                <li>✓ Submit and verify idea appears in feed</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-old-money-navy mb-3">Profile Functions</h4>
              <ul className="text-sm text-old-money-charcoal space-y-2">
                <li>✓ Click on user avatar to open profile</li>
                <li>✓ Verify dashboard shows correct stats</li>
                <li>✓ Test profile editing functionality</li>
                <li>✓ Check referral link generation</li>
                <li>✓ Verify achievement tracking</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-old-money-navy mb-3">Binance Integration</h4>
              <ul className="text-sm text-old-money-charcoal space-y-2">
                <li>✓ Click any "Trade on Binance" button</li>
                <li>✓ Verify new tab opens to Binance</li>
                <li>✓ Check referral URL is correct</li>
                <li>✓ Test Binance CTA in all components</li>
                <li>✓ Verify referral tracking works</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}