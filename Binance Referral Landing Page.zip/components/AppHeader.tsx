import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { 
  User, 
  LogOut, 
  Crown, 
  ExternalLink,
  Home,
  TrendingUp,
  Users,
  Newspaper,
  GraduationCap,
  Menu,
  X,
  Globe
} from 'lucide-react';
import { useState } from 'react';

interface AppHeaderProps {
  currentLanguage: string;
  user: any;
  translations: any;
  binanceReferralUrl: string;
  currentRoute: string;
  onLanguageChange: (lang: string) => void;
  onRouteChange: (route: string) => void;
  onShowAuthModal: () => void;
  onShowUserProfile: () => void;
  onLogout: () => void;
}

const navigationItems = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'signals', label: 'AI Signals', icon: TrendingUp, badge: 'Live' },
  { id: 'community', label: 'Community', icon: Users, badge: '125k+' },
  { id: 'news', label: 'News', icon: Newspaper, badge: 'Breaking' },
  { id: 'education', label: 'Education', icon: GraduationCap, badge: 'Free' }
];

// Language options with proper names and flags
const languageOptions = [
  { code: 'en', name: 'English', flag: '🇺🇸', nativeName: 'English' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸', nativeName: 'Español' },
  { code: 'fr', name: 'French', flag: '🇫🇷', nativeName: 'Français' },
  { code: 'de', name: 'German', flag: '🇩🇪', nativeName: 'Deutsch' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳', nativeName: '中文' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵', nativeName: '日本語' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷', nativeName: '한국어' }
];

export function AppHeader({
  currentLanguage,
  user,
  translations: t,
  binanceReferralUrl,
  currentRoute,
  onLanguageChange,
  onRouteChange,
  onShowAuthModal,
  onShowUserProfile,
  onLogout
}: AppHeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleRouteChange = (route: string) => {
    onRouteChange(route);
    setIsMobileMenuOpen(false);
  };

  const currentLanguageData = languageOptions.find(lang => lang.code === currentLanguage) || languageOptions[0];

  return (
    <>
      {/* Main Header Container - Fixed Height and Perfect Alignment */}
      <div className="flex items-center justify-between h-20 w-full">
        
        {/* Logo Section - Fixed Width for Consistency */}
        <div className="flex items-center gap-3 flex-shrink-0 min-w-0">
          <div 
            className="w-12 h-12 bg-gradient-to-br from-soft-teal to-soft-teal-light rounded-2xl flex items-center justify-center cursor-pointer shadow-glow transition-all duration-200 hover:scale-105 flex-shrink-0"
            onClick={() => handleRouteChange('home')}
          >
            <TrendingUp className="w-7 h-7 text-pearl-white" />
          </div>
          <div 
            className="cursor-pointer min-w-0 flex-shrink-0"
            onClick={() => handleRouteChange('home')}
          >
            <h1 className="text-xl sm:text-2xl font-bold text-deep-ocean leading-tight">
              Invest-Free<span className="text-soft-teal">.com</span>
            </h1>
            <p className="text-xs text-warm-slate font-medium -mt-0.5 leading-tight">
              Free AI Trading Platform
            </p>
          </div>
        </div>

        {/* Center Navigation - Flexible Space */}
        <nav className="hidden lg:flex items-center justify-center gap-1 flex-1 px-8">
          {navigationItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = currentRoute === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => handleRouteChange(item.id)}
                className={`
                  relative flex items-center gap-2 px-4 xl:px-6 py-3 rounded-xl transition-all duration-200 font-medium
                  min-h-[44px] whitespace-nowrap
                  ${isActive 
                    ? 'bg-soft-teal text-pearl-white shadow-glow transform scale-105' 
                    : 'text-deep-ocean hover:bg-soft-teal/10 hover:text-soft-teal'
                  }
                `}
              >
                <IconComponent className="w-5 h-5 flex-shrink-0" />
                <span className="hidden xl:block text-sm font-semibold">{item.label}</span>
                {item.badge && (
                  <Badge 
                    className={`
                      text-xs font-bold px-2 py-0.5 absolute -top-1 -right-1 xl:static xl:ml-2
                      ${isActive 
                        ? 'bg-pearl-white/20 text-pearl-white border-pearl-white/30' 
                        : 'bg-soft-teal/10 text-soft-teal border-soft-teal/20'
                      }
                    `}
                  >
                    {item.badge}
                  </Badge>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Side Actions - Fixed Width and Proper Alignment */}
        <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
          
          {/* Language Selector - Consistent Height */}
          <div className="hidden sm:block">
            <Select value={currentLanguage} onValueChange={onLanguageChange}>
              <SelectTrigger className="w-[120px] lg:w-[140px] h-11 bg-white/90 backdrop-blur-sm border-2 border-soft-teal/20 hover:border-soft-teal/40 transition-all duration-200 focus:border-soft-teal shadow-soft hover:shadow-medium">
                <div className="flex items-center gap-2 text-left">
                  <Globe className="w-4 h-4 text-soft-teal flex-shrink-0" />
                  <span className="text-base font-medium flex-shrink-0">{currentLanguageData.flag}</span>
                  <span className="text-sm font-medium text-deep-ocean hidden lg:block truncate">
                    {currentLanguageData.code.toUpperCase()}
                  </span>
                </div>
              </SelectTrigger>
              <SelectContent className="bg-white/95 backdrop-blur-md border-2 border-soft-teal/20 shadow-deep min-w-[200px]">
                {languageOptions.map((language) => (
                  <SelectItem 
                    key={language.code} 
                    value={language.code}
                    className="cursor-pointer hover:bg-soft-teal/10 focus:bg-soft-teal/10 transition-all duration-200"
                  >
                    <div className="flex items-center gap-3 py-1 w-full">
                      <span className="text-lg flex-shrink-0">{language.flag}</span>
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="font-medium text-deep-ocean truncate">{language.name}</span>
                        <span className="text-xs text-warm-slate truncate">{language.nativeName}</span>
                      </div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Binance CTA - Consistent Height */}
          <Button
            onClick={() => window.open(binanceReferralUrl, '_blank')}
            size="sm"
            className="hidden md:flex h-11 bg-gradient-to-r from-warning-amber to-warning-amber/80 hover:from-warning-amber/90 hover:to-warning-amber text-pearl-white font-bold shadow-soft hover:shadow-medium transition-all duration-200 px-4"
          >
            <ExternalLink className="w-4 h-4 mr-2 flex-shrink-0" />
            <span className="whitespace-nowrap">$100 Bonus</span>
          </Button>

          {/* User Actions - Consistent Height and Alignment */}
          {user ? (
            <div className="flex items-center gap-2">
              <Button
                onClick={onShowUserProfile}
                variant="outline"
                size="sm"
                className="hidden sm:flex items-center gap-2 h-11 border-2 border-soft-teal/20 text-deep-ocean hover:bg-soft-teal/10 hover:border-soft-teal/40 px-4"
              >
                <Crown className="w-4 h-4 text-soft-teal flex-shrink-0" />
                <span className="font-medium truncate max-w-[80px] lg:max-w-none">
                  {user.name || 'Premium'}
                </span>
              </Button>
              <Button
                onClick={onLogout}
                variant="ghost"
                size="sm"
                className="h-11 w-11 p-0 text-warm-slate hover:text-danger-coral hover:bg-danger-coral/10 flex-shrink-0"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <Button
              onClick={onShowAuthModal}
              size="sm"
              className="h-11 bg-gradient-to-r from-soft-teal to-soft-teal-light hover:from-soft-teal-light hover:to-soft-teal text-deep-navy font-bold shadow-glow hover:shadow-medium transition-all duration-200 transform hover:scale-105 px-4"
            >
              <User className="w-4 h-4 mr-2 flex-shrink-0" />
              <span className="whitespace-nowrap hidden sm:inline">Join Free</span>
              <span className="whitespace-nowrap sm:hidden">Join</span>
            </Button>
          )}

          {/* Mobile Menu Toggle - Consistent Height */}
          <button
            onClick={toggleMobileMenu}
            className="lg:hidden h-11 w-11 p-0 text-deep-ocean hover:text-soft-teal transition-colors duration-200 flex items-center justify-center rounded-xl hover:bg-soft-teal/10 flex-shrink-0"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Enhanced Mobile Menu with Better Alignment */}
      {isMobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-pearl-white/98 backdrop-blur-md border-t border-soft-teal/20 shadow-deep z-50 animate-slide-up">
          <div className="container mx-auto px-4 py-6 max-w-md">
            
            {/* Mobile Navigation */}
            <div className="space-y-2 mb-6">
              {navigationItems.map((item) => {
                const IconComponent = item.icon;
                const isActive = currentRoute === item.id;
                
                return (
                  <button
                    key={item.id}
                    onClick={() => handleRouteChange(item.id)}
                    className={`
                      w-full flex items-center gap-4 px-6 py-4 rounded-xl transition-all duration-200 font-medium text-left
                      ${isActive 
                        ? 'bg-soft-teal text-pearl-white shadow-glow' 
                        : 'text-deep-ocean hover:bg-soft-teal/10 hover:text-soft-teal'
                      }
                    `}
                  >
                    <IconComponent className="w-5 h-5 flex-shrink-0" />
                    <span className="flex-1 font-semibold">{item.label}</span>
                    {item.badge && (
                      <Badge 
                        className={`
                          text-xs font-bold px-2 py-1 flex-shrink-0
                          ${isActive 
                            ? 'bg-pearl-white/20 text-pearl-white border-pearl-white/30' 
                            : 'bg-soft-teal/10 text-soft-teal border-soft-teal/20'
                          }
                        `}
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </button>
                );
              })}
            </div>
            
            {/* Mobile Language Selector */}
            <div className="py-4 border-t border-soft-teal/20 mb-4">
              <label className="block text-sm font-medium text-deep-ocean mb-3">
                🌐 Language / Idioma
              </label>
              <Select value={currentLanguage} onValueChange={onLanguageChange}>
                <SelectTrigger className="w-full h-14 bg-white border-2 border-soft-teal/20 hover:border-soft-teal/40 transition-all duration-200">
                  <div className="flex items-center gap-3 text-left">
                    <span className="text-xl flex-shrink-0">{currentLanguageData.flag}</span>
                    <div className="flex flex-col items-start min-w-0 flex-1">
                      <span className="font-semibold text-deep-ocean truncate w-full">{currentLanguageData.name}</span>
                      <span className="text-sm text-warm-slate truncate w-full">{currentLanguageData.nativeName}</span>
                    </div>
                  </div>
                </SelectTrigger>
                <SelectContent className="bg-white border-2 border-soft-teal/20 shadow-deep">
                  {languageOptions.map((language) => (
                    <SelectItem 
                      key={language.code} 
                      value={language.code}
                      className="cursor-pointer hover:bg-soft-teal/10 focus:bg-soft-teal/10 py-3"
                    >
                      <div className="flex items-center gap-3 py-1 w-full">
                        <span className="text-xl flex-shrink-0">{language.flag}</span>
                        <div className="flex flex-col min-w-0 flex-1">
                          <span className="font-medium text-deep-ocean truncate">{language.name}</span>
                          <span className="text-sm text-warm-slate truncate">{language.nativeName}</span>
                        </div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {/* Mobile Auth Actions */}
            <div className="space-y-3 pt-4 border-t border-soft-teal/20">
              {user ? (
                <>
                  <Button
                    onClick={() => {
                      onShowUserProfile();
                      setIsMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full h-12 justify-start gap-3 border-2 border-soft-teal/20 text-deep-ocean hover:bg-soft-teal/10 text-left"
                  >
                    <Crown className="w-5 h-5 text-soft-teal flex-shrink-0" />
                    <span className="font-medium truncate">
                      View Profile ({user.name || 'Premium Member'})
                    </span>
                  </Button>
                  <Button
                    onClick={() => {
                      onLogout();
                      setIsMobileMenuOpen(false);
                    }}
                    variant="ghost"
                    className="w-full h-12 justify-start gap-3 text-danger-coral hover:bg-danger-coral/10 text-left"
                  >
                    <LogOut className="w-5 h-5 flex-shrink-0" />
                    <span className="font-medium">Logout</span>
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => {
                    onShowAuthModal();
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full h-12 bg-gradient-to-r from-soft-teal to-soft-teal-light text-deep-navy font-bold shadow-glow justify-start"
                >
                  <User className="w-5 h-5 mr-3 flex-shrink-0" />
                  <span className="font-semibold">Join Free - Get AI Signals</span>
                </Button>
              )}
              
              <Button
                onClick={() => {
                  window.open(binanceReferralUrl, '_blank');
                  setIsMobileMenuOpen(false);
                }}
                variant="outline"
                className="w-full h-12 justify-start gap-3 border-2 border-warning-amber/30 text-warning-amber hover:bg-warning-amber/10 text-left"
              >
                <ExternalLink className="w-5 h-5 flex-shrink-0" />
                <span className="font-medium">Get $100 Binance Bonus</span>
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}