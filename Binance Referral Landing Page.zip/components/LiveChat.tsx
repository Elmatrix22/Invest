import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  Send, 
  Users, 
  TrendingUp, 
  Zap,
  MessageCircle,
  Crown,
  Star,
  ExternalLink
} from 'lucide-react';

interface LiveChatProps {
  translations: any;
  binanceReferralUrl: string;
}

interface ChatMessage {
  id: string;
  author: string;
  avatar: string;
  message: string;
  timestamp: string;
  isVip?: boolean;
  isExpert?: boolean;
  coinMention?: string;
}

export function LiveChat({ translations, binanceReferralUrl }: LiveChatProps) {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      author: 'CryptoKing',
      avatar: 'CK',
      message: 'BTC just broke $99k! This is the start of the final rally to $120k 🚀',
      timestamp: '2:34 PM',
      isExpert: true,
      coinMention: 'BTC'
    },
    {
      id: '2',
      author: 'AltcoinGuru',
      avatar: 'AG',
      message: 'Anyone else seeing the SOL pump incoming? Volume is crazy high',
      timestamp: '2:35 PM',
      isVip: true,
      coinMention: 'SOL'
    },
    {
      id: '3',
      author: 'NewTrader',
      avatar: 'NT',
      message: 'Thanks for the free signals everyone! Made my first profit on Binance today 💪',
      timestamp: '2:36 PM'
    },
    {
      id: '4',
      author: 'DeFiExpert',
      avatar: 'DE',
      message: 'ETH gas fees dropping, perfect time for DeFi plays. Check out the new yield farms',
      timestamp: '2:37 PM',
      isExpert: true,
      coinMention: 'ETH'
    },
    {
      id: '5',
      author: 'HODLer2021',
      avatar: 'H2',
      message: 'Been holding since 2021, finally in massive profit! Thanks community! 🙏',
      timestamp: '2:38 PM'
    }
  ]);

  const [onlineUsers] = useState(1247);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Simulate new messages
  useEffect(() => {
    const interval = setInterval(() => {
      const newMessages = [
        "DOGE looking ready for a breakout! 🐕",
        "Just started trading on Binance, the platform is amazing!",
        "ADA accumulation phase complete, ready for next leg up",
        "Thanks for the BTC call @CryptoKing, perfect entry on Binance!",
        "LINK breaking out of the triangle pattern 📈",
        "Binance has the best fees, switched from other exchanges",
        "Free community + Binance = Perfect combo for profits!"
      ];
      
      const randomMessage = newMessages[Math.floor(Math.random() * newMessages.length)];
      const authors = ['Trader123', 'CryptoNoob', 'DiamondHands', 'MoonSeeker', 'BullRun2025', 'BinanceUser'];
      const randomAuthor = authors[Math.floor(Math.random() * authors.length)];
      
      const newMsg: ChatMessage = {
        id: Date.now().toString(),
        author: randomAuthor,
        avatar: randomAuthor.substring(0, 2).toUpperCase(),
        message: randomMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isVip: Math.random() > 0.8,
        coinMention: Math.random() > 0.7 ? ['BTC', 'ETH', 'SOL', 'ADA'][Math.floor(Math.random() * 4)] : undefined
      };
      
      setMessages(prev => [...prev.slice(-20), newMsg]); // Keep last 20 messages
    }, 8000); // New message every 8 seconds

    return () => clearInterval(interval);
  }, []);

  const handleSendMessage = () => {
    if (!message.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      author: 'You',
      avatar: 'YU',
      message: message,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, newMessage]);
    setMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 mb-8">
      <Card className="h-[450px] flex flex-col border-old-money-beige">
        <CardHeader className="flex-shrink-0 bg-gradient-to-r from-old-money-navy to-old-money-charcoal text-old-money-cream rounded-t-lg py-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg">
              <MessageCircle className="w-5 h-5" />
              {translations.chatTitle || "Live Investor Chat"}
            </CardTitle>
            <div className="flex items-center gap-3">
              <Badge className="bg-old-money-cream/20 text-old-money-cream text-xs">
                <Users className="w-3 h-3 mr-1" />
                {onlineUsers.toLocaleString()} online
              </Badge>
              <Badge className="bg-old-money-cream/20 text-old-money-cream text-xs">
                <Zap className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </div>
          </div>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0 min-h-0">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3 min-h-0">
            {messages.map((msg) => (
              <div key={msg.id} className="flex items-start gap-2">
                <Avatar className="w-7 h-7 shrink-0">
                  <AvatarFallback className={`text-xs ${
                    msg.isExpert ? 'bg-old-money-burgundy/10 text-old-money-burgundy' :
                    msg.isVip ? 'bg-old-money-gold/10 text-old-money-gold' : 
                    'bg-old-money-sage-light text-old-money-navy'
                  }`}>
                    {msg.avatar}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="font-medium text-sm text-old-money-navy">{msg.author}</span>
                    {msg.isExpert && (
                      <Badge className="text-xs bg-old-money-burgundy/10 text-old-money-burgundy px-1 py-0">
                        <Crown className="w-2 h-2 mr-1" />
                        Expert
                      </Badge>
                    )}
                    {msg.isVip && (
                      <Badge className="text-xs bg-old-money-gold/10 text-old-money-gold px-1 py-0">
                        <Star className="w-2 h-2 mr-1" />
                        VIP
                      </Badge>
                    )}
                    {msg.coinMention && (
                      <Badge variant="outline" className="text-xs border-old-money-warm-gray text-old-money-warm-gray px-1 py-0">
                        {msg.coinMention}
                      </Badge>
                    )}
                    <span className="text-xs text-old-money-warm-gray">{msg.timestamp}</span>
                  </div>
                  <p className="text-sm text-old-money-charcoal break-words">{msg.message}</p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Compact Binance Trading Banner */}
          <div className="mx-3 mb-3 p-3 bg-gradient-to-r from-old-money-gold/10 to-old-money-gold-light/10 border border-old-money-gold/30 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-old-money-gold rounded-full flex items-center justify-center">
                  <span className="text-old-money-navy font-bold text-sm">B</span>
                </div>
                <div>
                  <div className="font-medium text-old-money-navy text-sm">
                    🎉 Trade coins discussed here
                  </div>
                  <div className="text-xs text-old-money-warm-gray">
                    Join Binance - Low fees & secure trading
                  </div>
                </div>
              </div>
              <Button 
                size="sm" 
                onClick={handleBinanceClick}
                className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy font-medium text-xs px-3 py-1"
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                Trade
              </Button>
            </div>
          </div>

          {/* Message Input */}
          <div className="p-3 border-t border-old-money-beige">
            <div className="flex gap-2 mb-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={translations.chatPlaceholder || "Type your message..."}
                className="flex-1 border-old-money-warm-gray focus:border-old-money-navy text-sm"
                maxLength={200}
              />
              <Button 
                onClick={handleSendMessage}
                disabled={!message.trim()}
                className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream px-3"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-xs text-old-money-warm-gray">
                💡 Share crypto insights & help the community!
              </p>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBinanceClick}
                className="text-xs text-old-money-gold hover:text-old-money-gold-light px-2 py-1"
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                Binance
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}