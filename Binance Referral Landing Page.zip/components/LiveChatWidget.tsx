import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { ScrollArea } from './ui/scroll-area';
import { 
  MessageCircle, 
  X, 
  Send, 
  Users, 
  Minimize2, 
  Maximize2,
  Edit3,
  Crown,
  Star
} from 'lucide-react';

interface LiveChatWidgetProps {
  translations: any;
  binanceReferralUrl: string;
  user?: any;
}

interface ChatMessage {
  id: string;
  user: string;
  message: string;
  timestamp: Date;
  isVip: boolean;
  isGuest: boolean;
}

// Generate simple chat messages
const generateChatMessages = (): ChatMessage[] => {
  const messages = [
    "BTC looking strong today! 💪",
    "ETH breaking out nicely",
    "Good time to buy SOL",
    "DOGE pumping again 🚀",
    "Market is bullish",
    "Perfect dip to buy",
    "ADA showing strength",
    "BNB holding well",
    "Great signals today!",
    "Thanks for the tips!",
    "Anyone trading today?",
    "Nice analysis guys",
    "Loving this community!",
    "When moon? 🌙",
    "LFG! 🔥"
  ];

  const users = [
    { name: 'CryptoKing', isVip: true, isGuest: false },
    { name: 'MoonHunter', isVip: false, isGuest: false },
    { name: 'TradePro', isVip: true, isGuest: false },
    { name: 'DiamondHands', isVip: false, isGuest: false },
    { name: 'Guest_1247', isVip: false, isGuest: true },
    { name: 'BullRun2024', isVip: false, isGuest: false },
    { name: 'Guest_8392', isVip: false, isGuest: true },
    { name: 'SignalPro', isVip: false, isGuest: false },
    { name: 'ChartMaster', isVip: true, isGuest: false },
    { name: 'Guest_5731', isVip: false, isGuest: true }
  ];

  return Array.from({ length: 15 }, (_, i) => {
    const userData = users[Math.floor(Math.random() * users.length)];
    return {
      id: `msg_${i}`,
      user: userData.name,
      message: messages[Math.floor(Math.random() * messages.length)],
      timestamp: new Date(Date.now() - Math.random() * 3600000 * 2),
      isVip: userData.isVip,
      isGuest: userData.isGuest
    };
  }).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
};

export function LiveChatWidget({ translations, binanceReferralUrl, user }: LiveChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>(() => generateChatMessages());
  const [newMessage, setNewMessage] = useState('');
  const [guestName, setGuestName] = useState('');
  const [hasSetGuestName, setHasSetGuestName] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState(1247);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load saved guest name for non-members only
  useEffect(() => {
    if (!user) {
      const savedGuestName = localStorage.getItem('guestChatName');
      if (savedGuestName) {
        setGuestName(savedGuestName);
        setHasSetGuestName(true);
      }
    }
  }, [user]);

  // Simulate new messages
  useEffect(() => {
    if (!isOpen) return;
    
    const interval = setInterval(() => {
      const newMsg = generateChatMessages()[0];
      newMsg.id = `msg_${Date.now()}`;
      newMsg.timestamp = new Date();
      
      setMessages(prev => [newMsg, ...prev.slice(0, 14)]);
    }, Math.random() * 20000 + 10000);

    return () => clearInterval(interval);
  }, [isOpen]);

  const handleSetGuestName = () => {
    if (!guestName.trim()) return;
    
    const finalGuestName = guestName.trim() || `Guest_${Math.floor(Math.random() * 9999)}`;
    setGuestName(finalGuestName);
    setHasSetGuestName(true);
    
    // Save guest name
    localStorage.setItem('guestChatName', finalGuestName);
  };

  const handleSendMessage = () => {
    // FIXED LOGIC: Members use user.name directly, guests use guestName
    const currentUser = user ? user.name : guestName;
    
    if (!newMessage.trim() || !currentUser) return;
    
    const userMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      user: currentUser,
      message: newMessage,
      timestamp: new Date(),
      isVip: user?.isVip || false,
      isGuest: !user // If no user, it's a guest
    };

    setMessages(prev => [userMessage, ...prev]);
    setNewMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      // FIXED LOGIC: Members can send directly, guests need name first
      if (user) {
        handleSendMessage();
      } else if (!hasSetGuestName) {
        handleSetGuestName();
      } else {
        handleSendMessage();
      }
    }
  };

  // SIMPLIFIED LOGIC: Members can always chat, guests need name setup
  const canChat = user || hasSetGuestName;
  const needsGuestSetup = !user && !hasSetGuestName;

  if (!isOpen) {
    return (
      <div className="fixed bottom-24 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream shadow-2xl rounded-full w-16 h-16 flex items-center justify-center relative group"
          aria-label="Open live chat"
        >
          <MessageCircle className="w-8 h-8" />
          <Badge className="absolute -top-2 -right-2 bg-old-money-burgundy text-old-money-cream text-xs px-2 py-1 rounded-full animate-pulse">
            {onlineUsers}
          </Badge>
          <div className="absolute bottom-full right-0 mb-2 opacity-0 group-hover:opacity-100 transition-opacity bg-old-money-navy text-old-money-cream text-sm px-3 py-2 rounded-lg whitespace-nowrap">
            Live Chat ({onlineUsers} online)
          </div>
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className={`bg-old-money-cream border-2 border-old-money-navy shadow-2xl transition-all duration-300 ${
        isMinimized ? 'w-80 h-16' : 'w-96 h-[650px]'
      }`}>
        {/* Header */}
        <CardHeader className="pb-2 bg-old-money-navy text-old-money-cream rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              <div>
                <CardTitle className="text-base">Live Community Chat</CardTitle>
                <div className="text-xs text-old-money-cream/80">{onlineUsers} online • Open to all</div>
              </div>
            </div>
            <div className="flex gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMinimized(!isMinimized)}
                className="text-old-money-cream hover:bg-old-money-navy-light p-1"
              >
                {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="text-old-money-cream hover:bg-old-money-navy-light p-1"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        {!isMinimized && (
          <CardContent className="p-0 flex flex-col h-[calc(100%-70px)]">
            {/* Messages - Smaller to make room for HUGE input */}
            <ScrollArea className="flex-1 p-3" style={{ maxHeight: '250px' }}>
              <div className="space-y-2">
                {messages.map((msg) => (
                  <div key={msg.id} className="p-2 rounded bg-white border border-old-money-beige">
                    <div className="flex items-center gap-2 text-xs mb-1">
                      <Avatar className="w-5 h-5">
                        <AvatarFallback className={`text-xs ${
                          msg.isVip 
                            ? 'bg-old-money-gold text-old-money-navy' 
                            : msg.isGuest
                            ? 'bg-old-money-sage text-old-money-cream'
                            : 'bg-old-money-warm-gray text-old-money-cream'
                        }`}>
                          {msg.user.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <span className="font-medium text-old-money-navy">
                        {msg.user}
                      </span>
                      {msg.isVip && (
                        <Crown className="w-3 h-3 text-old-money-gold" />
                      )}
                      {msg.isGuest && (
                        <Badge className="text-xs px-1 py-0 bg-old-money-sage/20 text-old-money-sage">
                          Guest
                        </Badge>
                      )}
                      <span className="text-xs text-old-money-warm-gray ml-auto">
                        {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="text-sm text-old-money-charcoal pl-7">
                      {msg.message}
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* MASSIVE INPUT SECTION - TAKES UP MOST OF THE WIDGET */}
            <div className="bg-old-money-gold/30 border-t-8 border-old-money-gold" style={{ minHeight: '320px' }}>
              <div className="p-6">
                {/* HUGE Welcome Banner */}
                <div className="mb-6 text-center p-6 bg-white rounded-2xl border-4 border-old-money-gold shadow-2xl">
                  <div className="flex items-center justify-center gap-3 text-old-money-navy mb-3">
                    <Edit3 className="w-10 h-10" />
                    <span className="font-bold text-2xl">
                      {user ? `WELCOME ${user.name.toUpperCase()}!` : 
                       canChat ? `CHATTING AS ${guestName.toUpperCase()}` : 
                       'JOIN THE CONVERSATION!'}
                    </span>
                    {user && <Crown className="w-8 h-8 text-old-money-gold" />}
                  </div>
                  
                  <div className="text-old-money-burgundy font-bold text-xl mb-3">
                    💬 {needsGuestSetup ? 'CHOOSE YOUR CHAT NAME' : 'TYPE YOUR MESSAGE BELOW'} 💬
                  </div>
                  
                  <div className="text-old-money-warm-gray text-lg">
                    {user ? 'You can chat immediately as a registered member' :
                     needsGuestSetup ? 'Enter any nickname to start chatting instantly' : 
                     'Press Enter or click Send to chat with the community'}
                  </div>
                  
                  {user && (
                    <div className="mt-3 flex items-center justify-center gap-2">
                      <Star className="w-5 h-5 text-old-money-gold" />
                      <span className="text-old-money-navy font-bold">Member Privileges Active</span>
                      <Star className="w-5 h-5 text-old-money-gold" />
                    </div>
                  )}
                </div>

                {/* MASSIVE INPUT SECTION */}
                <div className="space-y-4">
                  {needsGuestSetup ? (
                    // Guest name setup - ONLY for non-members who haven't set name
                    <>
                      <div className="text-center text-old-money-navy font-bold text-xl mb-4">
                        ✨ No Registration Required - Chat Instantly! ✨
                      </div>
                      <div className="flex gap-4">
                        <Input
                          value={guestName}
                          onChange={(e) => setGuestName(e.target.value)}
                          onKeyPress={handleKeyPress}
                          placeholder="Enter your nickname (e.g. CryptoFan123)"
                          className="flex-1 border-8 border-old-money-navy focus:border-old-money-gold text-xl py-8 px-8 bg-white rounded-2xl shadow-2xl"
                          style={{ 
                            fontSize: '20px', 
                            height: '80px',
                            fontWeight: '600'
                          }}
                        />
                        <Button
                          onClick={handleSetGuestName}
                          disabled={!guestName.trim()}
                          className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy px-10 py-8 h-[80px] font-bold text-xl shadow-2xl rounded-2xl"
                          style={{ minWidth: '120px' }}
                        >
                          Start Chatting!
                        </Button>
                      </div>
                      <div className="text-center text-old-money-warm-gray text-base bg-old-money-cream/80 rounded-xl p-4">
                        💡 Choose any name you like! No email, password, or personal info needed.
                      </div>
                    </>
                  ) : (
                    // Chat input - FOR MEMBERS AND GUESTS WITH NAMES
                    <>
                      <div className="text-center text-old-money-navy font-bold text-xl mb-4">
                        🎯 YOUR MESSAGE WILL APPEAR INSTANTLY BELOW 🎯
                      </div>
                      <div className="flex gap-4">
                        <Input
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          onKeyPress={handleKeyPress}
                          placeholder="Type your message here..."
                          className="flex-1 border-8 border-old-money-navy focus:border-old-money-gold text-xl py-8 px-8 bg-white rounded-2xl shadow-2xl"
                          style={{ 
                            fontSize: '20px', 
                            height: '80px',
                            fontWeight: '600'
                          }}
                        />
                        <Button
                          onClick={handleSendMessage}
                          disabled={!newMessage.trim()}
                          className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy px-10 py-8 h-[80px] font-bold text-xl shadow-2xl rounded-2xl"
                          style={{ minWidth: '100px' }}
                        >
                          <Send className="w-8 h-8" />
                        </Button>
                      </div>
                    </>
                  )}
                  
                  {/* Status Display */}
                  <div className="text-center text-old-money-cream bg-old-money-navy/90 rounded-2xl p-4 shadow-xl">
                    <div className="font-bold text-lg">
                      {user ? (
                        <>✨ Chatting as Member: {user.name} ✨</>
                      ) : canChat ? (
                        <>🎭 Chatting as Guest: {guestName} 🎭</>
                      ) : (
                        <>👋 Welcome! Join our friendly community chat 👋</>
                      )}
                    </div>
                    <div className="text-sm text-old-money-cream/80 mt-2">
                      {user ? 'Enjoy premium member status and VIP features' :
                       canChat ? 'Share your thoughts with traders worldwide' : 
                       'No registration required - start chatting instantly!'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}

export default LiveChatWidget;