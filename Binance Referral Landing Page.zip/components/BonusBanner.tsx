import { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { 
  Gift, 
  ExternalLink, 
  Sparkles, 
  Clock, 
  Star, 
  X,
  Zap,
  DollarSign,
  Crown
} from 'lucide-react';

interface BonusBannerProps {
  binanceReferralUrl: string;
  variant?: 'hero' | 'floating' | 'inline' | 'modal';
  onClose?: () => void;
  showCloseButton?: boolean;
}

export function BonusBanner({ 
  binanceReferralUrl, 
  variant = 'inline', 
  onClose, 
  showCloseButton = false 
}: BonusBannerProps) {
  const [isVisible, setIsVisible] = useState(true);

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const handleClose = () => {
    setIsVisible(false);
    onClose?.();
  };

  if (!isVisible) return null;

  // Hero variant - Large banner for hero section
  if (variant === 'hero') {
    return (
      <div className="relative overflow-hidden bg-gradient-to-r from-old-money-gold via-old-money-gold-light to-old-money-gold text-old-money-navy py-8 px-6 rounded-2xl shadow-2xl">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-4 -right-4 w-24 h-24 bg-old-money-navy/10 rounded-full animate-bounce"></div>
          <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-old-money-burgundy/10 rounded-full animate-pulse"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-white/10 rounded-full animate-ping"></div>
        </div>
        
        <div className="relative z-10 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-16 h-16 bg-old-money-navy rounded-full flex items-center justify-center">
              <Gift className="w-8 h-8 text-old-money-gold animate-bounce" />
            </div>
            <div className="text-left">
              <Badge className="bg-old-money-burgundy text-old-money-cream text-lg px-4 py-2 mb-2">
                🎁 LIMITED TIME OFFER
              </Badge>
              <div className="text-5xl font-bold flex items-center gap-2">
                <DollarSign className="w-12 h-12" />
                100
                <span className="text-3xl">BONUS</span>
              </div>
            </div>
          </div>
          
          <h3 className="text-2xl font-bold mb-4">
            🚀 Get $100 FREE When You Join Binance Through Our Link!
          </h3>
          
          <div className="grid md:grid-cols-3 gap-4 mb-6 text-sm">
            <div className="bg-old-money-navy/10 rounded-lg p-4">
              <Zap className="w-6 h-6 mx-auto mb-2" />
              <div className="font-bold">Instant Bonus</div>
              <div>$100 credited immediately</div>
            </div>
            <div className="bg-old-money-navy/10 rounded-lg p-4">
              <Star className="w-6 h-6 mx-auto mb-2" />
              <div className="font-bold">Zero Fees</div>
              <div>Lowest trading costs</div>
            </div>
            <div className="bg-old-money-navy/10 rounded-lg p-4">
              <Crown className="w-6 h-6 mx-auto mb-2" />
              <div className="font-bold">VIP Access</div>
              <div>Premium features included</div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={handleBinanceClick}
              className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-gold font-bold text-lg px-8 py-4 rounded-xl shadow-lg transform hover:scale-105 transition-all"
            >
              <Gift className="w-6 h-6 mr-3" />
              Claim $100 Bonus Now
              <ExternalLink className="w-5 h-5 ml-3" />
            </Button>
          </div>
          
          <div className="mt-4 text-sm opacity-80">
            ⏰ Bonus expires in 24 hours • No deposit required • Available to new users only
          </div>
        </div>
      </div>
    );
  }

  // Floating variant - Sticky banner
  if (variant === 'floating') {
    return (
      <div className="fixed top-20 right-6 z-40 max-w-sm">
        <Card className="border-old-money-gold bg-gradient-to-br from-old-money-gold to-old-money-gold-light text-old-money-navy shadow-2xl">
          <CardContent className="p-4">
            {showCloseButton && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClose}
                className="absolute top-2 right-2 text-old-money-navy hover:bg-old-money-navy/20"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
            
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-old-money-navy rounded-full flex items-center justify-center">
                <Gift className="w-6 h-6 text-old-money-gold animate-pulse" />
              </div>
              <div>
                <div className="text-2xl font-bold">$100 FREE</div>
                <div className="text-sm opacity-80">Binance Bonus</div>
              </div>
            </div>
            
            <p className="text-sm mb-4">
              🎁 Get $100 instantly when you sign up through our exclusive link!
            </p>
            
            <Button
              onClick={handleBinanceClick}
              className="w-full bg-old-money-navy hover:bg-old-money-navy-light text-old-money-gold font-bold"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Claim Now
            </Button>
            
            <div className="mt-2 text-xs text-center opacity-70">
              ⏰ Limited time offer
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Modal variant - Full-screen promotional modal
  if (variant === 'modal') {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="bg-gradient-to-br from-old-money-gold via-old-money-gold-light to-old-money-gold rounded-2xl p-8 max-w-2xl w-full relative overflow-hidden shadow-2xl">
          {/* Animated sparkles */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <Sparkles className="absolute top-4 left-4 w-6 h-6 text-old-money-navy/30 animate-bounce" />
            <Sparkles className="absolute top-8 right-8 w-4 h-4 text-old-money-navy/30 animate-pulse" />
            <Sparkles className="absolute bottom-6 left-8 w-5 h-5 text-old-money-navy/30 animate-bounce delay-100" />
            <Sparkles className="absolute bottom-8 right-6 w-6 h-6 text-old-money-navy/30 animate-pulse delay-200" />
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClose}
            className="absolute top-4 right-4 text-old-money-navy hover:bg-old-money-navy/20"
          >
            <X className="w-6 h-6" />
          </Button>
          
          <div className="text-center text-old-money-navy">
            <div className="flex justify-center mb-6">
              <div className="w-24 h-24 bg-old-money-navy rounded-full flex items-center justify-center">
                <Gift className="w-12 h-12 text-old-money-gold animate-bounce" />
              </div>
            </div>
            
            <Badge className="bg-old-money-burgundy text-old-money-cream text-xl px-6 py-3 mb-4">
              🎉 EXCLUSIVE BONUS ALERT
            </Badge>
            
            <h2 className="text-5xl font-bold mb-4">
              Get $100 FREE!
            </h2>
            
            <p className="text-xl mb-6">
              Sign up for Binance through our exclusive link and receive an instant $100 bonus!
            </p>
            
            <div className="grid md:grid-cols-3 gap-4 mb-8 text-sm">
              <div className="bg-old-money-navy/10 rounded-lg p-4">
                <DollarSign className="w-8 h-8 mx-auto mb-2" />
                <div className="font-bold text-lg">$100 Instant</div>
                <div>Credited to your account immediately upon signup</div>
              </div>
              <div className="bg-old-money-navy/10 rounded-lg p-4">
                <Zap className="w-8 h-8 mx-auto mb-2" />
                <div className="font-bold text-lg">Zero Fees</div>
                <div>Lowest trading fees in the industry</div>
              </div>
              <div className="bg-old-money-navy/10 rounded-lg p-4">
                <Crown className="w-8 h-8 mx-auto mb-2" />
                <div className="font-bold text-lg">VIP Status</div>
                <div>Access to premium trading features</div>
              </div>
            </div>
            
            <Button
              onClick={handleBinanceClick}
              className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-gold font-bold text-xl px-12 py-6 rounded-xl shadow-lg transform hover:scale-105 transition-all"
            >
              <Gift className="w-8 h-8 mr-4" />
              Claim Your $100 Bonus
              <ExternalLink className="w-6 h-6 ml-4" />
            </Button>
            
            <div className="mt-6 flex items-center justify-center gap-2 text-sm">
              <Clock className="w-4 h-4" />
              <span>⏰ This exclusive offer expires in 24 hours!</span>
            </div>
            
            <div className="mt-4 text-xs opacity-70">
              * Terms and conditions apply. Bonus for new users only. No deposit required to claim.
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Inline variant - Default banner for content areas
  return (
    <div className="bg-gradient-to-r from-old-money-gold to-old-money-gold-light rounded-xl p-6 shadow-lg relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_20%_20%,_var(--old-money-navy)_1px,_transparent_1px)] bg-[size:20px_20px]"></div>
      </div>
      
      <div className="relative z-10 flex items-center justify-between text-old-money-navy">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-old-money-navy rounded-full flex items-center justify-center">
            <Gift className="w-8 h-8 text-old-money-gold animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge className="bg-old-money-burgundy text-old-money-cream">
                🎁 BONUS ALERT
              </Badge>
              <Sparkles className="w-5 h-5 animate-spin" />
            </div>
            <h3 className="text-2xl font-bold">Get $100 FREE Bonus!</h3>
            <p className="text-sm opacity-80">
              Join Binance through our link & receive instant $100 bonus
            </p>
          </div>
        </div>
        
        <div className="text-right">
          <Button
            onClick={handleBinanceClick}
            className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-gold font-bold px-6 py-3 rounded-lg shadow-md transform hover:scale-105 transition-all"
          >
            <ExternalLink className="w-5 h-5 mr-2" />
            Claim $100 Now
          </Button>
          <div className="mt-2 text-xs opacity-70">
            ⏰ Limited time • New users only
          </div>
        </div>
      </div>
    </div>
  );
}