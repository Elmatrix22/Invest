import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { 
  Share2, 
  Twitter, 
  MessageCircle, 
  Copy, 
  Check, 
  ExternalLink,
  Users,
  TrendingUp,
  Gift,
  Zap,
  Target,
  Signal
} from 'lucide-react';

interface SocialShareProps {
  translations: any;
  binanceReferralUrl: string;
  content?: {
    type: 'signal' | 'idea' | 'achievement' | 'referral' | 'general';
    title?: string;
    description?: string;
    coin?: string;
    target?: string;
    accuracy?: number;
  };
}

export function SocialShare({ translations, binanceReferralUrl, content }: SocialShareProps) {
  const [showShareModal, setShowShareModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [customMessage, setCustomMessage] = useState('');

  const generateShareText = () => {
    const baseText = "🚀 Just discovered Invest-Free.com - the best FREE crypto, forex & binary signals community!\n\n";
    
    if (content) {
      switch (content.type) {
        case 'signal':
          return `${baseText}📊 New ${content.coin} signal: ${content.title}\n🎯 Target: ${content.target}\n💡 Join 125k+ traders getting FREE signals!\n\n#CryptoSignals #${content.coin} #TradingCommunity`;
        
        case 'idea':
          return `${baseText}💡 Shared my ${content.coin} analysis: "${content.title}"\n🎯 Target: ${content.target}\n📈 Accuracy: ${content.accuracy}%\n\n#CryptoTrading #InvestmentIdeas #${content.coin}`;
        
        case 'achievement':
          return `${baseText}🏆 Just hit ${content.accuracy}% prediction accuracy!\n💎 ${content.title}\n🔥 Free signals are working!\n\n#TradingSuccess #CryptoWins #ProfitableSignals`;
        
        case 'referral':
          return `${baseText}🎁 Get $100 bonus + FREE crypto signals!\n📈 Join 125k+ successful traders\n🚀 Binance partnership for instant trading\n💰 Start making money today!\n\n#FreeMoney #CryptoBonus #TradingCommunity`;
        
        default:
          return `${baseText}✅ FREE crypto, forex & binary signals\n🎯 78% accuracy rate proven\n💰 $100 welcome bonus\n📱 125k+ active traders\n🔥 Binance integration\n\n#FreeSignals #CryptoCommunity #TradingSuccess`;
      }
    }
    
    return `${baseText}✅ FREE signals with 78% accuracy\n💰 $100 welcome bonus\n🎯 Crypto, Forex & Binary Options\n🚀 Join 125k+ successful traders!\n\n#FreeSignals #CryptoCommunity #TradingSuccess`;
  };

  const shareUrls = {
    twitter: (text: string) => `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent('https://invest-free.com')}&hashtags=CryptoSignals,FreeTrading,InvestmentCommunity`,
    telegram: (text: string) => `https://t.me/share/url?url=${encodeURIComponent('https://invest-free.com')}&text=${encodeURIComponent(text)}`,
    whatsapp: (text: string) => `https://wa.me/?text=${encodeURIComponent(text + '\n\nhttps://invest-free.com')}`,
    reddit: (text: string) => `https://reddit.com/submit?url=${encodeURIComponent('https://invest-free.com')}&title=${encodeURIComponent(text)}`,
    linkedin: (text: string) => `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent('https://invest-free.com')}&summary=${encodeURIComponent(text)}`,
    facebook: (text: string) => `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent('https://invest-free.com')}&quote=${encodeURIComponent(text)}`
  };

  const handleShare = (platform: keyof typeof shareUrls) => {
    const shareText = customMessage || generateShareText();
    window.open(shareUrls[platform](shareText), '_blank', 'width=600,height=400');
  };

  const handleCopyLink = () => {
    const shareText = customMessage || generateShareText();
    const fullText = `${shareText}\n\nhttps://invest-free.com`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const quickShareButtons = [
    { 
      name: 'Twitter', 
      icon: Twitter, 
      color: 'bg-blue-500 hover:bg-blue-600 text-white', 
      key: 'twitter' as const
    },
    { 
      name: 'Telegram', 
      icon: MessageCircle, 
      color: 'bg-blue-400 hover:bg-blue-500 text-white', 
      key: 'telegram' as const
    },
    { 
      name: 'WhatsApp', 
      icon: MessageCircle, 
      color: 'bg-green-500 hover:bg-green-600 text-white', 
      key: 'whatsapp' as const
    },
    { 
      name: 'Reddit', 
      icon: Share2, 
      color: 'bg-orange-500 hover:bg-orange-600 text-white', 
      key: 'reddit' as const
    }
  ];

  const socialStats = {
    totalShares: 15647,
    todayShares: 234,
    viralPosts: 89,
    reachMultiplier: '12.5x'
  };

  return (
    <>
      {/* Quick Share Button */}
      <Button
        onClick={() => setShowShareModal(true)}
        className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
      >
        <Share2 className="w-4 h-4 mr-2" />
        Share & Earn
      </Button>

      {/* Share Modal */}
      <Dialog open={showShareModal} onOpenChange={setShowShareModal}>
        <DialogContent className="sm:max-w-2xl border-old-money-beige">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-old-money-navy">
              <Share2 className="w-6 h-6 text-old-money-sage" />
              Share & Earn Rewards
            </DialogTitle>
            <DialogDescription className="text-old-money-warm-gray">
              Share Invest-Free.com and earn $50 for each person who joins with your referral!
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Sharing Incentives */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="border-old-money-beige bg-old-money-sage/10">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-old-money-sage">${socialStats.totalShares}</div>
                  <div className="text-xs text-old-money-warm-gray">Total Earnings</div>
                </CardContent>
              </Card>
              
              <Card className="border-old-money-beige bg-old-money-gold/10">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-old-money-gold">{socialStats.todayShares}</div>
                  <div className="text-xs text-old-money-warm-gray">Shares Today</div>
                </CardContent>
              </Card>
              
              <Card className="border-old-money-beige bg-old-money-burgundy/10">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-old-money-burgundy">{socialStats.viralPosts}</div>
                  <div className="text-xs text-old-money-warm-gray">Viral Posts</div>
                </CardContent>
              </Card>
              
              <Card className="border-old-money-beige bg-old-money-navy/10">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-old-money-navy">{socialStats.reachMultiplier}</div>
                  <div className="text-xs text-old-money-warm-gray">Reach Boost</div>
                </CardContent>
              </Card>
            </div>

            {/* Earning Opportunity Banner */}
            <div className="bg-gradient-to-r from-old-money-gold/10 to-old-money-gold-light/10 border border-old-money-gold/30 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-old-money-gold rounded-full flex items-center justify-center">
                  <Gift className="w-5 h-5 text-old-money-navy" />
                </div>
                <div>
                  <h4 className="font-medium text-old-money-navy">Earn $50 Per Referral</h4>
                  <p className="text-sm text-old-money-warm-gray">Plus they get $100 welcome bonus!</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-white/50 rounded p-2">
                  <div className="flex items-center gap-1 text-old-money-sage">
                    <Users className="w-3 h-3" />
                    <span>Friend joins community</span>
                  </div>
                </div>
                <div className="bg-white/50 rounded p-2">
                  <div className="flex items-center gap-1 text-old-money-burgundy">
                    <Target className="w-3 h-3" />
                    <span>You earn $50 bonus</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Pre-written Message */}
            <div>
              <label className="text-sm font-medium text-old-money-navy mb-2 block">
                Share Message (Customize or use our proven template)
              </label>
              <Textarea
                placeholder="Write your own message or use our template..."
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
                rows={4}
                className="border-old-money-warm-gray focus:border-old-money-navy"
              />
              <div className="mt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCustomMessage(generateShareText())}
                  className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark"
                >
                  Use Proven Template
                </Button>
              </div>
            </div>

            {/* Social Platform Buttons */}
            <div>
              <h4 className="text-sm font-medium text-old-money-navy mb-3">Share on Social Media</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {quickShareButtons.map((platform) => (
                  <Button
                    key={platform.key}
                    onClick={() => handleShare(platform.key)}
                    className={platform.color}
                  >
                    <platform.icon className="w-4 h-4 mr-2" />
                    {platform.name}
                  </Button>
                ))}
              </div>
            </div>

            {/* Advanced Sharing Options */}
            <div className="border-t border-old-money-beige pt-4">
              <h4 className="text-sm font-medium text-old-money-navy mb-3">More Platforms</h4>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => handleShare('facebook')}
                  className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark"
                >
                  Facebook
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleShare('linkedin')}
                  className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark"
                >
                  LinkedIn
                </Button>
              </div>
            </div>

            {/* Copy Link */}
            <div>
              <label className="text-sm font-medium text-old-money-navy mb-2 block">
                Or Copy Link to Share Anywhere
              </label>
              <div className="flex gap-2">
                <Input
                  value="https://invest-free.com"
                  readOnly
                  className="border-old-money-warm-gray bg-old-money-cream-dark"
                />
                <Button
                  onClick={handleCopyLink}
                  className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            {/* Binance CTA */}
            <div className="bg-gradient-to-r from-old-money-burgundy/10 to-old-money-burgundy-light/10 border border-old-money-burgundy/30 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium text-old-money-navy">Share Trading Success Stories</h4>
                  <p className="text-sm text-old-money-warm-gray">
                    Show your Binance profits to attract more referrals
                  </p>
                </div>
                <Button
                  onClick={handleBinanceClick}
                  className="bg-old-money-burgundy hover:bg-old-money-burgundy-light text-old-money-cream"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open Binance
                </Button>
              </div>
            </div>

            {/* Success Tips */}
            <div className="bg-old-money-cream-dark rounded-lg p-4">
              <h4 className="font-medium text-old-money-navy mb-2">💡 Sharing Tips for Maximum Impact</h4>
              <ul className="text-sm text-old-money-warm-gray space-y-1">
                <li>• Share during market hours for higher engagement</li>
                <li>• Include specific profit amounts or percentages</li>
                <li>• Tag crypto influencers and communities</li>
                <li>• Share successful signal screenshots</li>
                <li>• Post in relevant crypto/trading groups</li>
              </ul>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setShowShareModal(false)}
                className="flex-1 border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark"
              >
                Close
              </Button>
              <Button
                onClick={handleCopyLink}
                className="flex-1 bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Copy & Share Now
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}