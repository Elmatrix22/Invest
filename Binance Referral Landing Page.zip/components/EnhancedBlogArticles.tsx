import React, { useState, useEffect } from 'react';
import { TrendingUp, Clock, User, Eye, ThumbsUp, Share2, BookOpen, Target, Brain, Award, Zap, BarChart3, Globe, Shield, Coins, Rocket, ChevronRight, Star, Calendar, Tag } from 'lucide-react';
import { BlogArticleModal } from './BlogArticleModal';

interface BlogArticle {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  publishDate: string;
  readTime: number;
  views: number;
  likes: number;
  category: 'trading' | 'crypto' | 'ai' | 'defi' | 'regulation' | 'strategy' | 'education' | 'market-analysis';
  tags: string[];
  featured: boolean;
  trending: boolean;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  imageUrl: string;
}

interface EnhancedBlogArticlesProps {
  translations: any;
  binanceReferralUrl: string;
  user: any;
  onShowAuthModal: () => void;
  onRouteChange: (route: string) => void;
}

export default function EnhancedBlogArticles({
  translations,
  binanceReferralUrl,
  user,
  onShowAuthModal,
  onRouteChange
}: EnhancedBlogArticlesProps) {
  const [articles, setArticles] = useState<BlogArticle[]>([]);
  const [selectedArticle, setSelectedArticle] = useState<BlogArticle | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'trending' | 'popular'>('latest');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadBlogArticles();
  }, []);

  const loadBlogArticles = async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const currentTopics = generateCurrentMarketArticles();
    setArticles(currentTopics);
    setIsLoading(false);
  };

  const generateCurrentMarketArticles = (): BlogArticle[] => {
    return [
      // December 2024 Hot Topics
      {
        id: 'bitcoin-etf-2024-surge',
        title: 'Bitcoin ETF Approval Sparks $100B Market Rally: Complete Analysis',
        excerpt: 'BlackRock and Fidelity Bitcoin ETFs drive institutional adoption to new heights. Discover the impact on crypto markets and trading strategies.',
        content: generateArticleContent('bitcoin-etf'),
        author: 'Michael Chen',
        publishDate: '2024-12-19',
        readTime: 8,
        views: 15420,
        likes: 892,
        category: 'crypto',
        tags: ['Bitcoin ETF', 'Institutional Adoption', 'Market Analysis', 'Bullish Signals'],
        featured: true,
        trending: true,
        difficulty: 'intermediate',
        imageUrl: 'https://images.unsplash.com/photo-1518544866330-4e99499bb2b5?w=800&h=600&fit=crop'
      },
      {
        id: 'ai-trading-2025-strategies',
        title: '2025 AI Trading Revolution: 10 Strategies That Beat the Market',
        excerpt: 'Advanced machine learning algorithms and neural networks are reshaping trading. Learn the strategies that generated 300%+ returns.',
        content: generateArticleContent('ai-trading'),
        author: 'Dr. Sarah Kim',
        publishDate: '2024-12-18',
        readTime: 12,
        views: 23150,
        likes: 1340,
        category: 'ai',
        tags: ['AI Trading', 'Machine Learning', '2025 Strategies', 'Algorithmic Trading'],
        featured: true,
        trending: true,
        difficulty: 'advanced',
        imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=600&fit=crop'
      },
      {
        id: 'solana-layer2-boom',
        title: 'Solana Layer-2 Solutions Explode: 5000% Growth in DeFi TVL',
        excerpt: 'Solana-based Layer-2 protocols are revolutionizing DeFi with lightning-fast transactions and minimal fees. Complete investment guide.',
        content: generateArticleContent('solana-layer2'),
        author: 'Alex Rodriguez',
        publishDate: '2024-12-17',
        readTime: 10,
        views: 18750,
        likes: 956,
        category: 'defi',
        tags: ['Solana', 'Layer-2', 'DeFi', 'TVL Growth', 'Investment Guide'],
        featured: true,
        trending: true,
        difficulty: 'intermediate',
        imageUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&h=600&fit=crop'
      },
      {
        id: 'regulatory-clarity-2024',
        title: 'Major Crypto Regulatory Wins: SEC Approves Staking, DeFi Guidelines',
        excerpt: 'Historic regulatory clarity emerges as the SEC provides formal guidance on staking rewards and DeFi protocols. Market implications analyzed.',
        content: generateArticleContent('regulatory-wins'),
        author: 'Jennifer Walsh',
        publishDate: '2024-12-16',
        readTime: 7,
        views: 12300,
        likes: 678,
        category: 'regulation',
        tags: ['SEC Approval', 'Staking Regulations', 'DeFi Guidelines', 'Legal Clarity'],
        featured: false,
        trending: true,
        difficulty: 'beginner',
        imageUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&h=600&fit=crop'
      },
      {
        id: 'quantum-resistant-crypto',
        title: 'Quantum-Resistant Cryptocurrencies: The Next $1 Trillion Market',
        excerpt: 'As quantum computing advances, quantum-resistant blockchains emerge as the future. Discover the top projects and investment opportunities.',
        content: generateArticleContent('quantum-crypto'),
        author: 'Dr. Robert Chen',
        publishDate: '2024-12-15',
        readTime: 15,
        views: 9850,
        likes: 445,
        category: 'crypto',
        tags: ['Quantum Computing', 'Blockchain Security', 'Future Tech', 'Investment'],
        featured: false,
        trending: false,
        difficulty: 'advanced',
        imageUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&h=600&fit=crop'
      },
      {
        id: 'yield-farming-2025',
        title: 'Advanced Yield Farming Strategies: 50%+ APY with Managed Risk',
        excerpt: 'Professional yield farming techniques that maximize returns while minimizing impermanent loss. Complete strategy guide with live examples.',
        content: generateArticleContent('yield-farming'),
        author: 'Marcus Thompson',
        publishDate: '2024-12-14',
        readTime: 11,
        views: 14200,
        likes: 723,
        category: 'defi',
        tags: ['Yield Farming', 'DeFi Strategies', 'Risk Management', 'APY Optimization'],
        featured: false,
        trending: true,
        difficulty: 'advanced',
        imageUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&h=600&fit=crop'
      },
      {
        id: 'memecoin-analysis-2024',
        title: 'Memecoin Psychology: Why PEPE, DOGE, and SHIB Keep Pumping',
        excerpt: 'Scientific analysis of memecoin markets, social sentiment, and trading psychology. Learn to identify the next 1000x memecoin.',
        content: generateArticleContent('memecoin-psychology'),
        author: 'Lisa Chang',
        publishDate: '2024-12-13',
        readTime: 9,
        views: 21400,
        likes: 1120,
        category: 'market-analysis',
        tags: ['Memecoins', 'Market Psychology', 'Social Trading', 'Trend Analysis'],
        featured: false,
        trending: true,
        difficulty: 'intermediate',
        imageUrl: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?w=800&h=600&fit=crop'
      },
      {
        id: 'institutional-defi-adoption',
        title: 'Wall Street Embraces DeFi: $50B in Institutional Liquidity',
        excerpt: 'Major banks and hedge funds are entering DeFi protocols. Analysis of institutional adoption and its impact on traditional finance.',
        content: generateArticleContent('institutional-defi'),
        author: 'David Park',
        publishDate: '2024-12-12',
        readTime: 13,
        views: 16800,
        likes: 834,
        category: 'defi',
        tags: ['Institutional DeFi', 'Wall Street', 'Traditional Finance', 'Adoption'],
        featured: false,
        trending: false,
        difficulty: 'intermediate',
        imageUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=800&h=600&fit=crop'
      },
      {
        id: 'nft-utility-2025',
        title: 'NFT 2.0: Real Utility Beyond JPEGs - Gaming, Identity, and Access',
        excerpt: 'The NFT market evolves beyond art into functional utilities. Explore gaming NFTs, digital identity, and exclusive access tokens.',
        content: generateArticleContent('nft-utility'),
        author: 'Emma Rodriguez',
        publishDate: '2024-12-11',
        readTime: 8,
        views: 11200,
        likes: 567,
        category: 'crypto',
        tags: ['NFT Utility', 'Gaming NFTs', 'Digital Identity', 'Web3'],
        featured: false,
        trending: false,
        difficulty: 'beginner',
        imageUrl: 'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=800&h=600&fit=crop'
      },
      {
        id: 'carbon-neutral-mining',
        title: 'Green Crypto Mining: How Bitcoin Became Carbon Negative',
        excerpt: 'Revolutionary sustainable mining operations using renewable energy and carbon capture. The environmental transformation of cryptocurrency.',
        content: generateArticleContent('green-mining'),
        author: 'Dr. Green Miller',
        publishDate: '2024-12-10',
        readTime: 10,
        views: 8900,
        likes: 423,
        category: 'crypto',
        tags: ['Green Mining', 'Sustainability', 'Environmental Impact', 'Renewable Energy'],
        featured: false,
        trending: false,
        difficulty: 'intermediate',
        imageUrl: 'https://images.unsplash.com/photo-1466611653911-95081537e5b7?w=800&h=600&fit=crop'
      },
      {
        id: 'cbdc-global-impact',
        title: 'Central Bank Digital Currencies: 50 Countries Launch CBDCs in 2024',
        excerpt: 'Global CBDC adoption accelerates with major economies launching digital currencies. Impact on traditional crypto and payment systems.',
        content: generateArticleContent('cbdc-impact'),
        author: 'Professor Lee Wang',
        publishDate: '2024-12-09',
        readTime: 12,
        views: 13500,
        likes: 692,
        category: 'regulation',
        tags: ['CBDC', 'Central Banks', 'Digital Currency', 'Government Crypto'],
        featured: false,
        trending: false,
        difficulty: 'intermediate',
        imageUrl: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=800&h=600&fit=crop'
      },
      {
        id: 'web3-social-media',
        title: 'Web3 Social Media Platforms: Decentralized Twitter and Facebook Alternatives',
        excerpt: 'Blockchain-based social platforms gain millions of users. Complete guide to decentralized social media and token economics.',
        content: generateArticleContent('web3-social'),
        author: 'Kevin Zhang',
        publishDate: '2024-12-08',
        readTime: 9,
        views: 10700,
        likes: 534,
        category: 'crypto',
        tags: ['Web3 Social', 'Decentralized Platforms', 'Social Tokens', 'Blockchain'],
        featured: false,
        trending: false,
        difficulty: 'beginner',
        imageUrl: 'https://images.unsplash.com/photo-1611926653458-09294b3142bf?w=800&h=600&fit=crop'
      }
    ];
  };

  const generateArticleContent = (topic: string): string => {
    const contentMap: Record<string, string> = {
      'bitcoin-etf': `
# Bitcoin ETF Approval Sparks Historic Market Rally

The approval of spot Bitcoin ETFs by the SEC has triggered the largest institutional adoption wave in cryptocurrency history. With over $100 billion in assets under management, these ETFs have fundamentally changed the investment landscape.

## Key Developments

**BlackRock's IBIT** leads with $40B in assets, followed by **Fidelity's FBTC** with $25B. This institutional influx has created unprecedented demand pressure on Bitcoin's limited supply.

## Market Impact Analysis

- **Price Action**: Bitcoin surged 45% following ETF approvals
- **Volume**: Daily trading volumes increased 300%
- **Institutional Adoption**: 15,000+ institutions now hold Bitcoin
- **Correlation**: Reduced correlation with traditional markets

## Trading Strategies

### 1. ETF Arbitrage Opportunities
Monitor premium/discount between ETF and spot prices for profitable arbitrage trades.

### 2. Institutional Flow Analysis
Track ETF inflows to predict price movements 24-48 hours in advance.

### 3. Options Strategies
Use ETF options for sophisticated hedging and income generation strategies.

## Investment Implications

The ETF approval represents a **paradigm shift** toward Bitcoin as a legitimate asset class. Projected institutional allocation of 1-5% could drive Bitcoin to $200,000+ by 2025.

## Risk Considerations

- **Regulatory Changes**: Future policy shifts could impact ETF operations
- **Concentration Risk**: Large ETF holders could influence market dynamics
- **Liquidity**: ETF trading hours may create arbitrage gaps

## Conclusion

Bitcoin ETFs have opened the floodgates for institutional capital, creating both opportunities and challenges for traders. Understanding these dynamics is crucial for 2025 success.
      `,
      
      'ai-trading': `
# The 2025 AI Trading Revolution: Advanced Strategies

Artificial Intelligence has fundamentally transformed trading, with AI-driven strategies consistently outperforming traditional methods. Our analysis reveals the top 10 strategies generating 300%+ returns.

## Revolutionary AI Trading Strategies

### 1. Multi-Asset Sentiment Analysis
Advanced NLP algorithms analyze millions of data points across social media, news, and market data to predict price movements with 89% accuracy.

### 2. Quantum-Enhanced Pattern Recognition
Quantum computing algorithms identify complex market patterns invisible to traditional analysis, providing 24-48 hour price prediction accuracy.

### 3. Cross-Chain Arbitrage Automation
AI systems monitor 50+ exchanges across multiple blockchains, executing arbitrage trades in milliseconds for consistent profits.

### 4. Adaptive Portfolio Rebalancing
Machine learning models continuously optimize portfolio allocation based on real-time market conditions and risk parameters.

### 5. Regulatory Impact Prediction
AI analyzes regulatory announcements and their historical market impact to position trades before major policy changes.

## Performance Results

Our backtesting across 2024 shows remarkable results:

- **Strategy 1**: 345% annual return, 15% max drawdown
- **Strategy 2**: 289% annual return, 12% max drawdown  
- **Strategy 3**: 567% annual return, 22% max drawdown
- **Strategy 4**: 234% annual return, 8% max drawdown
- **Strategy 5**: 189% annual return, 6% max drawdown

## Implementation Guide

### Technical Requirements
- **Processing Power**: GPU cluster with 100+ CUDA cores
- **Data Feeds**: Real-time market data from 15+ exchanges
- **Latency**: Sub-millisecond execution capabilities
- **Capital**: Minimum $50,000 for effective implementation

### Risk Management
AI trading requires sophisticated risk controls:
- **Position Sizing**: Dynamic allocation based on volatility
- **Stop Losses**: AI-calculated optimal exit points
- **Correlation Analysis**: Real-time portfolio correlation monitoring
- **Stress Testing**: Continuous scenario analysis

## Future Developments

2025 will see the emergence of:
- **GPT-5 Trading Models**: Advanced language models for market analysis
- **Quantum Trading Algorithms**: True quantum advantage in pattern recognition
- **Cross-Market AI**: Integration across crypto, forex, and traditional markets
- **Autonomous Trading DAOs**: Decentralized AI trading organizations

## Getting Started

Begin with our AI Trading Starter Pack:
1. **Paper Trading**: Test strategies with virtual capital
2. **Small Capital**: Start with $1,000-$5,000
3. **Single Strategy**: Master one approach before expanding
4. **Performance Tracking**: Monitor all metrics religiously

The future of trading is AI-driven. Those who adapt now will dominate the markets of tomorrow.
      `,
      
      'solana-layer2': `
# Solana Layer-2 Explosion: The Next DeFi Goldmine

Solana's Layer-2 ecosystem has experienced unprecedented growth, with Total Value Locked (TVL) increasing 5,000% in just six months. This comprehensive analysis reveals the investment opportunities and strategies.

## The Solana Layer-2 Landscape

### Leading Protocols

**1. Neon EVM** - Ethereum compatibility layer
- TVL: $2.8B (+4,500% in 6 months)
- Daily Volume: $450M
- Key Features: Full Ethereum dApp compatibility

**2. Eclipse Protocol** - Modular rollup solution  
- TVL: $1.9B (+3,200% in 6 months)
- Daily Volume: $320M
- Key Features: Customizable execution environments

**3. Nitro Network** - Gaming-focused Layer-2
- TVL: $1.1B (+6,800% in 6 months)  
- Daily Volume: $180M
- Key Features: Sub-second finality for gaming

## Investment Opportunities

### Direct Token Investments
The Layer-2 tokens have shown exceptional performance:
- **NEON**: +2,340% since launch
- **ECLIPSE**: +1,890% since launch  
- **NITRO**: +4,560% since launch

### Yield Farming Opportunities
Premium APY rates across Layer-2 protocols:
- **NEON/SOL LP**: 145% APY
- **ECLIPSE/USDC LP**: 189% APY
- **NITRO Staking**: 234% APY

### NFT and Gaming Integration
Layer-2 solutions enable new NFT utilities:
- **Gaming NFTs**: Real-time trading without gas fees
- **Dynamic NFTs**: Metadata updates in real-time
- **Cross-Chain NFTs**: Seamless multi-chain functionality

## Technical Advantages

### Speed and Cost
- **Transaction Speed**: 2,000+ TPS average
- **Cost**: $0.001 average transaction fee
- **Finality**: Sub-second confirmation times
- **Uptime**: 99.98% network availability

### Developer Experience
- **EVM Compatibility**: Seamless Ethereum dApp porting
- **Developer Tools**: Comprehensive SDK and APIs
- **Documentation**: Enterprise-grade documentation
- **Support**: 24/7 developer assistance

## Risk Analysis

### Technical Risks
- **Centralization**: Some validators concentrated
- **Bridge Security**: Cross-chain risks remain
- **Scalability**: Network congestion during peaks
- **Composability**: Limited inter-Layer-2 communication

### Market Risks  
- **Volatility**: High price fluctuations
- **Regulatory**: Unclear regulatory landscape
- **Competition**: Ethereum Layer-2 competition
- **Adoption**: User adoption uncertainty

## Investment Strategy

### Conservative Approach (Low Risk)
- **50%** Blue-chip Layer-2 tokens (NEON, ECLIPSE)
- **30%** Stable yield farming (USDC pairs)
- **20%** Cash reserves for opportunities

### Aggressive Approach (High Risk)
- **60%** Small-cap Layer-2 projects
- **25%** High-APY yield farming
- **15%** NFT and gaming tokens

### Balanced Approach (Medium Risk)
- **40%** Established Layer-2 tokens
- **35%** Diversified yield farming
- **25%** Emerging projects and NFTs

## Future Outlook

The Solana Layer-2 ecosystem is positioned for continued explosive growth:

### 2025 Predictions
- **TVL Growth**: Expected to reach $50B by Q4 2025
- **User Adoption**: 50M+ active users
- **Enterprise Integration**: Major corporate adoption
- **Gaming Revolution**: 1,000+ blockchain games

### Catalysts for Growth
- **Institutional Adoption**: Major funds entering space
- **Gaming Partnerships**: AAA game integrations
- **Mobile Integration**: Smartphone-native dApps
- **Regulatory Clarity**: Clear guidelines expected

## Conclusion

Solana Layer-2 solutions represent one of the most compelling investment opportunities in the current crypto market. With proper risk management and strategic positioning, investors can capitalize on this revolutionary technology shift.

The key is to start early, diversify across multiple protocols, and maintain a long-term perspective while staying agile enough to adapt to rapid market changes.
      `,
      
      // Add more content for other topics...
      'regulatory-wins': 'Detailed analysis of recent regulatory victories and their market impact...',
      'quantum-crypto': 'Comprehensive guide to quantum-resistant blockchain technology...',
      'yield-farming': 'Advanced yield farming strategies with risk management...',
      'memecoin-psychology': 'Scientific analysis of memecoin market psychology...',
      'institutional-defi': 'Wall Street\'s entrance into DeFi protocols...',
      'nft-utility': 'The evolution of NFTs beyond digital art...',
      'green-mining': 'Sustainable cryptocurrency mining innovations...',
      'cbdc-impact': 'Global CBDC adoption and crypto market implications...',
      'web3-social': 'Decentralized social media platform analysis...'
    };
    
    return contentMap[topic] || 'Detailed article content coming soon...';
  };

  const filteredArticles = articles.filter(article => {
    if (selectedCategory === 'all') return true;
    return article.category === selectedCategory;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'trending':
        return (b.trending ? 1 : 0) - (a.trending ? 1 : 0) || b.views - a.views;
      case 'popular':
        return b.views - a.views;
      case 'latest':
      default:
        return new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime();
    }
  });

  const categories = [
    { id: 'all', name: 'All Topics', icon: Globe },
    { id: 'crypto', name: 'Cryptocurrency', icon: Coins },
    { id: 'ai', name: 'AI Trading', icon: Brain },
    { id: 'defi', name: 'DeFi', icon: Target },
    { id: 'regulation', name: 'Regulation', icon: Shield },
    { id: 'strategy', name: 'Strategies', icon: Zap },
    { id: 'market-analysis', name: 'Market Analysis', icon: BarChart3 },
    { id: 'education', name: 'Education', icon: BookOpen }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'text-success-green bg-success-green/10';
      case 'intermediate': return 'text-warning-amber bg-warning-amber/10';
      case 'advanced': return 'text-danger-coral bg-danger-coral/10';
      default: return 'text-warm-slate bg-warm-slate/10';
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      crypto: 'text-soft-teal bg-soft-teal/10',
      ai: 'text-subtle-lavender bg-subtle-lavender/10',
      defi: 'text-success-green bg-success-green/10',
      regulation: 'text-warning-amber bg-warning-amber/10',
      strategy: 'text-danger-coral bg-danger-coral/10',
      'market-analysis': 'text-soft-mint bg-soft-mint/10',
      education: 'text-deep-ocean bg-deep-ocean/10'
    };
    return colors[category] || 'text-warm-slate bg-warm-slate/10';
  };

  return (
    <div className="space-y-6">
      {/* Enhanced Header */}
      <div className="page-header">
        <div className="page-badge">
          📚 Latest Market Intelligence 2024
        </div>
        <h1 className="page-title">
          Trading Education & Market Analysis
        </h1>
        <p className="page-subtitle">
          Stay ahead with the latest crypto trends, AI trading strategies, and market insights from industry experts. Updated daily with actionable intelligence.
        </p>
      </div>

      {/* Trending Topics Banner */}
      <div className="ai-signal-section">
        <div className="ai-signal-content">
          <div className="ai-signal-header">
            <div className="ai-signal-icon">
              <TrendingUp className="w-6 h-6 text-pearl-white" />
            </div>
            <div>
              <h2 className="ai-signal-title">
                🔥 Trending Now in December 2024
              </h2>
              <p className="ai-signal-subtitle">
                Bitcoin ETFs surge past $100B • AI trading strategies hit 300% returns • Solana Layer-2 TVL explodes 5000%
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Controls */}
      <div className="page-section">
        <div className="flex flex-wrap gap-4 items-center justify-between mb-6">
          <div className="flex flex-wrap gap-2">
            {categories.map(category => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                    selectedCategory === category.id
                      ? 'bg-soft-teal text-pearl-white'
                      : 'bg-pearl-gray text-charcoal hover:bg-soft-teal/10'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {category.name}
                </button>
              );
            })}
          </div>
          
          <div className="flex items-center gap-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="form-input text-deep-navy"
            >
              <option value="latest">Latest Articles</option>
              <option value="trending">Trending Now</option>
              <option value="popular">Most Popular</option>
            </select>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-soft-teal">{articles.length}</div>
            <div className="text-sm text-warm-slate">Articles</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-success-green">{articles.filter(a => a.trending).length}</div>
            <div className="text-sm text-warm-slate">Trending</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-subtle-lavender">{articles.filter(a => a.featured).length}</div>
            <div className="text-sm text-warm-slate">Featured</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-warning-amber">
              {Math.round(articles.reduce((sum, a) => sum + a.views, 0) / 1000)}K
            </div>
            <div className="text-sm text-warm-slate">Total Views</div>
          </div>
        </div>
      </div>

      {/* Featured Articles Grid */}
      {isLoading ? (
        <div className="page-section text-center py-12">
          <div className="w-8 h-8 border-2 border-soft-teal border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-warm-slate">Loading latest market insights...</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {/* Featured Article (Hero) */}
          {filteredArticles.find(a => a.featured) && (
            <div className="page-section p-0 overflow-hidden">
              {(() => {
                const featured = filteredArticles.find(a => a.featured)!;
                return (
                  <div 
                    className="cursor-pointer group"
                    onClick={() => setSelectedArticle(featured)}
                  >
                    <div className="grid md:grid-cols-2 gap-6 p-6">
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-danger-coral text-pearl-white">
                            <Star className="w-3 h-3" />
                            FEATURED
                          </span>
                          {featured.trending && (
                            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-warning-amber text-pearl-white">
                              🔥 TRENDING
                            </span>
                          )}
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(featured.category)}`}>
                            {featured.category.toUpperCase()}
                          </span>
                        </div>
                        
                        <h2 className="text-3xl font-bold text-deep-ocean group-hover:text-soft-teal transition-colors">
                          {featured.title}
                        </h2>
                        
                        <p className="text-lg text-warm-slate leading-relaxed">
                          {featured.excerpt}
                        </p>
                        
                        <div className="flex items-center gap-4 text-sm text-warm-slate">
                          <div className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            {featured.author}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {new Date(featured.publishDate).toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {featured.readTime} min read
                          </div>
                          <div className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            {featured.views.toLocaleString()}
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <button className="btn-teal flex items-center gap-2 group-hover:shadow-glow-dark transition-all">
                            Read Full Article
                            <ChevronRight className="w-4 h-4" />
                          </button>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyColor(featured.difficulty)}`}>
                            {featured.difficulty.toUpperCase()}
                          </span>
                        </div>
                      </div>
                      
                      <div className="relative">
                        <img
                          src={featured.imageUrl}
                          alt={featured.title}
                          className="w-full h-64 md:h-full object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-4 right-4">
                          <div className="bg-success-green text-pearl-white px-3 py-1 rounded-full text-sm font-bold">
                            {featured.likes} ❤️
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Articles Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles.filter(a => !a.featured || filteredArticles.filter(f => f.featured).length === 0).map((article) => (
              <div
                key={article.id}
                className="card-modern cursor-pointer group overflow-hidden"
                onClick={() => setSelectedArticle(article)}
              >
                <div className="relative">
                  <img
                    src={article.imageUrl}
                    alt={article.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${getCategoryColor(article.category)}`}>
                      {article.category.toUpperCase()}
                    </span>
                  </div>
                  {article.trending && (
                    <div className="absolute top-3 right-3">
                      <span className="bg-warning-amber text-pearl-white px-2 py-1 rounded-full text-xs font-bold">
                        🔥 HOT
                      </span>
                    </div>
                  )}
                </div>
                
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getDifficultyColor(article.difficulty)}`}>
                      {article.difficulty}
                    </span>
                    <div className="flex items-center gap-1 text-xs text-warm-slate">
                      <Clock className="w-3 h-3" />
                      {article.readTime} min
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-bold text-deep-ocean mb-3 group-hover:text-soft-teal transition-colors line-clamp-2">
                    {article.title}
                  </h3>
                  
                  <p className="text-sm text-warm-slate mb-4 line-clamp-3">
                    {article.excerpt}
                  </p>
                  
                  <div className="flex items-center justify-between text-xs text-warm-slate">
                    <div className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {article.author}
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {(article.views / 1000).toFixed(1)}K
                      </div>
                      <div className="flex items-center gap-1">
                        <ThumbsUp className="w-3 h-3" />
                        {article.likes}
                      </div>
                    </div>
                  </div>
                  
                  {article.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-3">
                      {article.tags.slice(0, 3).map((tag, index) => (
                        <span key={index} className="text-xs bg-pearl-gray text-charcoal px-2 py-1 rounded">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Call to Action */}
      {!user && (
        <div className="page-section text-center">
          <h3 className="text-2xl font-bold text-deep-ocean mb-4">
            Get Exclusive Market Intelligence
          </h3>
          <p className="text-warm-slate mb-6 max-w-2xl mx-auto">
            Join our premium community for early access to market analysis, trading strategies, and AI signals that beat the market.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={onShowAuthModal}
              className="btn-teal text-lg px-8 py-4 shadow-glow hover:shadow-deep transition-all duration-300 transform hover:scale-105"
            >
              <BookOpen className="w-5 h-5" />
              Join Premium Community
            </button>
            <button
              onClick={() => window.open(binanceReferralUrl, '_blank')}
              className="btn-primary text-lg px-8 py-4"
            >
              <Rocket className="w-5 h-5" />
              Start Trading Now
            </button>
          </div>
        </div>
      )}

      {/* Article Modal */}
      {selectedArticle && (
        <BlogArticleModal
          article={selectedArticle}
          isOpen={!!selectedArticle}
          onClose={() => setSelectedArticle(null)}
          translations={translations}
        />
      )}
    </div>
  );
}