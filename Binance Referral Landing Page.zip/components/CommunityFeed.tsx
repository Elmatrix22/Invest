import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { ScrollArea } from './ui/scroll-area';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  TrendingUp, 
  DollarSign,
  Plus,
  ThumbsUp,
  Clock,
  ExternalLink,
  Eye,
  Search,
  Filter,
  Star,
  Bookmark,
  FileText,
  Users,
  Target,
  Zap,
  Award,
  Building,
  Lightbulb,
  Smartphone,
  Globe,
  ShoppingCart,
  Home,
  Coins,
  Brain,
  Gift,
  Calendar,
  MapPin,
  Link,
  Send,
  X,
  ChevronRight,
  BarChart3,
  Activity,
  Sparkles,
  Briefcase,
  PieChart,
  LineChart,
  TrendingDown,
  CheckCircle,
  AlertCircle,
  Calculator,
  Database,
  Rocket,
  Shield,
  BookOpen,
  GraduationCap,
  Info
} from 'lucide-react';

interface BusinessIdea {
  id: string;
  title: string;
  description: string;
  category: 'tech' | 'crypto' | 'real-estate' | 'startup' | 'product' | 'service' | 'ecommerce' | 'fintech' | 'ai' | 'green-energy';
  author: {
    name: string;
    avatar: string;
    verified: boolean;
    reputation: number;
    experience: string;
    expertise: string;
  };
  marketAnalysis: {
    marketSize: string;
    growthRate: string;
    competition: string;
    opportunity: string;
  };
  businessModel: {
    type: string;
    revenueStreams: string[];
    keyResources: string[];
    targetCustomers: string;
  };
  learningPoints: {
    keyInsights: string[];
    successFactors: string[];
    challenges: string[];
    lessons: string[];
  };
  educationalContent: {
    whatYouLearn: string;
    industryTrends: string;
    marketOpportunities: string;
    businessStrategy: string;
  };
  caseStudy: {
    problem: string;
    solution: string;
    implementation: string;
    results: string;
  };
  metrics: {
    views: number;
    likes: number;
    comments: number;
    bookmarks: number;
    shares: number;
  };
  tags: string[];
  location: string;
  website?: string;
  demo?: string;
  pitch: string;
  timeline: string;
  complexity: 'Beginner' | 'Intermediate' | 'Advanced';
  stage: 'Concept' | 'Research' | 'Analysis' | 'Case Study' | 'Deep Dive';
  isHot: boolean;
  isFeatured: boolean;
  isLiked: boolean;
  isBookmarked: boolean;
  createdAt: string;
  updatedAt: string;
  weeklyRank?: number;
}

interface CommunityFeedProps {
  translations: any;
  binanceReferralUrl: string;
}

// Generate comprehensive business education data
const generateBusinessIdeas = (): BusinessIdea[] => {
  const categories: BusinessIdea['category'][] = ['tech', 'crypto', 'real-estate', 'startup', 'product', 'service', 'ecommerce', 'fintech', 'ai', 'green-energy'];
  const stages: BusinessIdea['stage'][] = ['Concept', 'Research', 'Analysis', 'Case Study', 'Deep Dive'];
  const complexities: BusinessIdea['complexity'][] = ['Beginner', 'Intermediate', 'Advanced'];
  
  const detailedBusinessIdeas = [
    {
      title: "AI-Powered Trading Systems: Market Analysis & Business Model Study",
      description: "Deep dive into how AI trading systems work, their market potential, and business model analysis. Learn about machine learning in finance, market opportunities, and the competitive landscape in automated trading.",
      category: 'crypto' as const,
      pitch: "Understand the $3.2B AI trading market and learn how these systems generate revenue.",
      marketAnalysis: {
        marketSize: "$3.2 billion AI trading market by 2025, growing at 11.1% CAGR",
        growthRate: "11.1% annual growth driven by institutional adoption",
        competition: "3Commas, TradeSanta, Pionex dominating retail space",
        opportunity: "Institutional and retail crossover creating new niches"
      },
      businessModel: {
        type: "SaaS + Performance Revenue Model",
        revenueStreams: ["Monthly subscriptions", "Performance fees", "Enterprise licensing", "API access fees"],
        keyResources: ["AI algorithms", "Market data feeds", "Cloud infrastructure", "Regulatory compliance"],
        targetCustomers: "Retail traders, fund managers, institutional investors"
      },
      learningPoints: {
        keyInsights: ["AI accuracy rates determine pricing power", "Regulatory compliance is crucial", "Real-time data processing is competitive advantage"],
        successFactors: ["Proven track record", "Transparent performance metrics", "Strong risk management", "User-friendly interface"],
        challenges: ["Market volatility affects performance", "High competition", "Regulatory changes", "Technical complexity"],
        lessons: ["Start with proven strategies", "Focus on risk management", "Build trust through transparency", "Scale gradually"]
      },
      educationalContent: {
        whatYouLearn: "Understanding AI trading algorithms, market analysis, business model design, and competitive positioning",
        industryTrends: "Increasing institutional adoption, regulatory frameworks evolving, integration with traditional finance",
        marketOpportunities: "Emerging markets adoption, retail investor education, cross-asset trading expansion",
        businessStrategy: "Build trust through performance, focus on risk management, develop proprietary algorithms"
      },
      caseStudy: {
        problem: "Retail traders struggle with emotional trading and lack 24/7 market monitoring",
        solution: "AI system provides emotionless trading with continuous market analysis and risk management",
        implementation: "Machine learning models trained on historical data with real-time execution capabilities",
        results: "85% win rate demonstrated over 12 months with maximum 5% drawdown protection"
      }
    },
    {
      title: "Sustainable Urban Farming: Business Model & Market Analysis",
      description: "Comprehensive analysis of the vertical farming industry, business models, and market opportunities. Learn about sustainable agriculture, urban food production, and the economics of modern farming.",
      category: 'green-energy' as const,
      pitch: "Explore the $15.7B vertical farming market and sustainable agriculture business models.",
      marketAnalysis: {
        marketSize: "$15.7 billion vertical farming market by 2025, 24% CAGR",
        growthRate: "24% annual growth driven by sustainability concerns",
        competition: "AeroFarms, Plenty, Bowery Farming leading innovation",
        opportunity: "Urban food security and climate-resistant agriculture"
      },
      businessModel: {
        type: "B2B2C Equipment + Marketplace Model",
        revenueStreams: ["Equipment sales", "Subscription monitoring", "Marketplace commissions", "Consulting services"],
        keyResources: ["IoT technology", "Agricultural expertise", "Supply chain network", "Sustainability certifications"],
        targetCustomers: "Restaurants, grocery chains, urban developers, municipalities"
      },
      learningPoints: {
        keyInsights: ["Technology reduces costs but requires high initial investment", "Local food movement drives demand", "Sustainability credentials command premium pricing"],
        successFactors: ["Proven yield improvements", "Cost-effective operations", "Strong supply chain", "Sustainability focus"],
        challenges: ["High capital requirements", "Energy costs", "Technical complexity", "Market education needed"],
        lessons: ["Start with high-value crops", "Focus on local markets", "Build sustainability story", "Prove unit economics first"]
      },
      educationalContent: {
        whatYouLearn: "Vertical farming technology, sustainable business models, market analysis, and supply chain optimization",
        industryTrends: "Automation increasing, costs decreasing, urban integration growing, sustainability focus intensifying",
        marketOpportunities: "Food security concerns, urban development, climate change adaptation, health-conscious consumers",
        businessStrategy: "Prove sustainability impact, target premium markets, build local partnerships, focus on efficiency"
      },
      caseStudy: {
        problem: "Traditional farming faces climate challenges, water scarcity, and transportation costs",
        solution: "Vertical farms use 90% less water, eliminate pesticides, and reduce transportation distance",
        implementation: "IoT-controlled growing systems with data analytics for optimization and resource management",
        results: "400% higher yield per square foot with 95% reduction in water usage and year-round production"
      }
    },
    {
      title: "Blockchain Real Estate: Fractional Ownership Business Model Analysis",
      description: "Study how blockchain technology transforms real estate investment through fractional ownership. Learn about tokenization, regulatory frameworks, and market dynamics in proptech.",
      category: 'real-estate' as const,
      pitch: "Analyze the $280B real estate crowdfunding market and blockchain innovation opportunities.",
      marketAnalysis: {
        marketSize: "$280 billion real estate crowdfunding market globally",
        growthRate: "48% growth in real estate tokenization projects",
        competition: "Fundrise, RealtyMogul competing with traditional models",
        opportunity: "Blockchain enables true fractional ownership and liquidity"
      },
      businessModel: {
        type: "Platform + Transaction Fee Model",
        revenueStreams: ["Transaction fees", "Management fees", "Platform subscriptions", "Advisory services"],
        keyResources: ["Blockchain technology", "Legal compliance", "Property network", "User platform"],
        targetCustomers: "Retail investors, international buyers, property developers, institutional investors"
      },
      learningPoints: {
        keyInsights: ["Regulatory compliance is critical", "Liquidity is key value proposition", "International access drives adoption"],
        successFactors: ["Strong legal framework", "Quality property selection", "User-friendly platform", "Transparent operations"],
        challenges: ["Regulatory complexity", "Market education", "Technology adoption", "Traditional industry resistance"],
        lessons: ["Start with clear regulations", "Focus on education", "Build trust gradually", "Prove liquidity benefits"]
      },
      educationalContent: {
        whatYouLearn: "Blockchain technology applications, real estate tokenization, regulatory compliance, and market analysis",
        industryTrends: "Tokenization growing, regulations clarifying, institutional adoption increasing, global access expanding",
        marketOpportunities: "Emerging markets, younger investors, international diversification, liquidity provision",
        businessStrategy: "Navigate regulations carefully, educate market, build trust, focus on user experience"
      },
      caseStudy: {
        problem: "Real estate investment requires large capital, lacks liquidity, and has geographical limitations",
        solution: "Blockchain tokenization enables fractional ownership, instant liquidity, and global access",
        implementation: "Smart contracts automate ownership, payments, and transfers with full transparency",
        results: "$100 minimum investment unlocks premium real estate with instant tradability and global diversification"
      }
    },
    {
      title: "VR Gaming Metaverse: Economy Design & Business Model Study",
      description: "Explore virtual economy design, play-to-earn mechanics, and the business models driving the metaverse. Learn about digital asset creation, virtual real estate, and community monetization.",
      category: 'tech' as const,
      pitch: "Study the $165B gaming + $47B metaverse market convergence and virtual economy design.",
      marketAnalysis: {
        marketSize: "$165 billion gaming + $47 billion metaverse market convergence",
        growthRate: "101% growth in play-to-earn gaming revenue",
        competition: "Decentraland, The Sandbox, Axie Infinity pioneering space",
        opportunity: "Virtual economies creating real-world value for players"
      },
      businessModel: {
        type: "Virtual Economy + Asset Marketplace Model",
        revenueStreams: ["Virtual land sales", "Asset marketplace fees", "Gaming transactions", "Advertising revenue"],
        keyResources: ["VR/AR technology", "Game development", "Blockchain infrastructure", "Community management"],
        targetCustomers: "Gamers, content creators, brands, virtual world builders"
      },
      learningPoints: {
        keyInsights: ["Virtual economies require careful balance", "Community engagement drives value", "True ownership changes gaming dynamics"],
        successFactors: ["Engaging gameplay", "Sustainable economy", "Strong community", "Cross-platform compatibility"],
        challenges: ["Technology barriers", "Market education", "Regulatory uncertainty", "Competition with traditional gaming"],
        lessons: ["Focus on fun first", "Build sustainable economics", "Grow community organically", "Prepare for mainstream adoption"]
      },
      educationalContent: {
        whatYouLearn: "Virtual economy design, metaverse business models, community building, and digital asset monetization",
        industryTrends: "VR adoption accelerating, play-to-earn growing, brands entering metaverse, cross-platform integration",
        marketOpportunities: "Gaming evolution, virtual events, digital fashion, virtual real estate, creator economy",
        businessStrategy: "Create engaging experiences, build sustainable economies, foster communities, enable creator monetization"
      },
      caseStudy: {
        problem: "Traditional gaming generates value only for developers, not players who invest time and money",
        solution: "Play-to-earn mechanics allow players to own, trade, and monetize their gaming achievements",
        implementation: "Blockchain-based virtual world with NFT assets and cryptocurrency rewards for gameplay",
        results: "Players earning $500-2000 monthly while top land owners generate six-figure annual revenues"
      }
    },
    {
      title: "AI Mental Health Platforms: Healthcare Business Model Analysis",
      description: "Examine the intersection of AI and mental healthcare, analyzing business models, regulatory considerations, and market opportunities in digital health services.",
      category: 'ai' as const,
      pitch: "Explore the $240B mental health market and AI-driven healthcare innovation opportunities.",
      marketAnalysis: {
        marketSize: "$240 billion global mental health market growing rapidly",
        growthRate: "16.3% CAGR driven by awareness and accessibility needs",
        competition: "BetterHelp, Talkspace dominating traditional telehealth",
        opportunity: "AI enables 24/7 access and personalized care at scale"
      },
      businessModel: {
        type: "Subscription + B2B Healthcare Model",
        revenueStreams: ["Consumer subscriptions", "B2B healthcare partnerships", "Insurance reimbursements", "Enterprise wellness"],
        keyResources: ["AI technology", "Clinical expertise", "Regulatory compliance", "Data security"],
        targetCustomers: "Individuals, healthcare providers, employers, insurance companies"
      },
      learningPoints: {
        keyInsights: ["Clinical validation is essential", "Privacy and security are critical", "Human oversight required for AI"],
        successFactors: ["Proven clinical outcomes", "Strong privacy protection", "Professional oversight", "User engagement"],
        challenges: ["Regulatory approval", "Clinical validation", "Privacy concerns", "Professional acceptance"],
        lessons: ["Start with professional oversight", "Prove clinical efficacy", "Build trust gradually", "Focus on specific use cases"]
      },
      educationalContent: {
        whatYouLearn: "Healthcare AI applications, regulatory compliance, clinical validation, and digital health business models",
        industryTrends: "AI acceptance growing, regulations evolving, telehealth normalizing, personalization increasing",
        marketOpportunities: "Global healthcare access, personalized medicine, preventive care, workplace wellness",
        businessStrategy: "Prioritize safety and efficacy, build clinical partnerships, navigate regulations, focus on outcomes"
      },
      caseStudy: {
        problem: "Mental healthcare has long wait times, high costs, and limited availability, especially in crisis situations",
        solution: "AI companion provides 24/7 support, crisis detection, and personalized interventions with human oversight",
        implementation: "HIPAA-compliant platform with natural language processing and crisis intervention protocols",
        results: "40% reduction in crisis escalations with 24/7 availability and 80% user satisfaction scores"
      }
    }
  ];

  return Array.from({ length: 52 }, (_, i) => {
    const baseIdea = detailedBusinessIdeas[i % detailedBusinessIdeas.length];
    const category = categories[Math.floor(Math.random() * categories.length)];
    const stage = stages[Math.floor(Math.random() * stages.length)];
    const complexity = complexities[Math.floor(Math.random() * complexities.length)];
    
    return {
      id: `idea_${i + 1}`,
      title: i < detailedBusinessIdeas.length ? baseIdea.title : `${baseIdea.title} - Case Study ${i + 1}`,
      description: baseIdea.description,
      category: i < detailedBusinessIdeas.length ? baseIdea.category : category,
      author: {
        name: `${['Dr. Alex', 'Prof. Sarah', 'David', 'Maria', 'James', 'Emma', 'Michael', 'Lisa'][i % 8]} ${['Johnson', 'Smith', 'Williams', 'Brown', 'Davis', 'Miller', 'Wilson', 'Garcia'][i % 8]}`,
        avatar: `${['Dr. Alex', 'Prof. Sarah', 'David', 'Maria', 'James', 'Emma', 'Michael', 'Lisa'][i % 8][0]}${['Johnson', 'Smith', 'Williams', 'Brown', 'Davis', 'Miller', 'Wilson', 'Garcia'][i % 8][0]}`,
        verified: Math.random() > 0.2,
        reputation: Math.floor(Math.random() * 1000) + 200,
        experience: ['Business Analyst', 'Market Researcher', 'Industry Expert', 'Strategy Consultant', 'Academic Researcher'][Math.floor(Math.random() * 5)],
        expertise: ['Market Analysis', 'Business Strategy', 'Financial Modeling', 'Industry Research', 'Case Study Development'][Math.floor(Math.random() * 5)]
      },
      marketAnalysis: i < detailedBusinessIdeas.length ? baseIdea.marketAnalysis : {
        marketSize: `$${Math.floor(Math.random() * 100)}B market opportunity globally`,
        growthRate: `${Math.floor(Math.random() * 30) + 5}% annual growth rate`,
        competition: "Established players with room for innovation",
        opportunity: "Market gaps and emerging trends create opportunities"
      },
      businessModel: i < detailedBusinessIdeas.length ? baseIdea.businessModel : {
        type: ["SaaS Model", "Marketplace Model", "Subscription Model", "Freemium Model"][Math.floor(Math.random() * 4)],
        revenueStreams: ["Subscriptions", "Transaction fees", "Premium features", "Partnerships"],
        keyResources: ["Technology platform", "User base", "Data analytics", "Brand reputation"],
        targetCustomers: "Growth-focused businesses and consumers"
      },
      learningPoints: i < detailedBusinessIdeas.length ? baseIdea.learningPoints : {
        keyInsights: ["Market timing is crucial", "User experience drives adoption", "Scalability requires planning"],
        successFactors: ["Strong value proposition", "Effective marketing", "Operational efficiency", "Customer satisfaction"],
        challenges: ["Market competition", "Technology complexity", "Resource requirements", "Market education"],
        lessons: ["Validate early", "Focus on core value", "Build incrementally", "Listen to customers"]
      },
      educationalContent: i < detailedBusinessIdeas.length ? baseIdea.educationalContent : {
        whatYouLearn: "Business model analysis, market research, competitive positioning, and strategic planning",
        industryTrends: "Digital transformation, automation, sustainability, personalization",
        marketOpportunities: "Emerging technologies, changing consumer behavior, global expansion",
        businessStrategy: "Differentiation, customer focus, innovation, strategic partnerships"
      },
      caseStudy: i < detailedBusinessIdeas.length ? baseIdea.caseStudy : {
        problem: "Traditional approach has limitations and inefficiencies",
        solution: "Innovative approach addresses core issues with technology",
        implementation: "Systematic rollout with testing and optimization",
        results: "Measurable improvements in key metrics and outcomes"
      },
      metrics: {
        views: Math.floor(Math.random() * 50000) + 1000,
        likes: Math.floor(Math.random() * 1000) + 50,
        comments: Math.floor(Math.random() * 200) + 15,
        bookmarks: Math.floor(Math.random() * 500) + 25,
        shares: Math.floor(Math.random() * 100) + 10
      },
      tags: ['Business Analysis', 'Market Research', 'Strategy', 'Case Study', 'Learning', 'Innovation', 'Growth'].slice(0, Math.floor(Math.random() * 4) + 3),
      location: ['Global', 'North America', 'Europe', 'Asia-Pacific', 'Multiple Markets'][Math.floor(Math.random() * 5)],
      website: Math.random() > 0.6 ? `https://casestudy${i}.business-learning.com` : undefined,
      demo: Math.random() > 0.8 ? `https://demo.business-case-${i}.com` : undefined,
      pitch: i < detailedBusinessIdeas.length ? baseIdea.pitch : `Learn about ${category} business models and market opportunities through real-world analysis.`,
      timeline: ['Ongoing Study', 'Recent Analysis', 'Updated Research', 'Current Case'][Math.floor(Math.random() * 4)],
      complexity,
      stage,
      isHot: Math.random() > 0.8,
      isFeatured: Math.random() > 0.9,
      isLiked: Math.random() > 0.7,
      isBookmarked: Math.random() > 0.8,
      createdAt: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: new Date().toISOString(),
      weeklyRank: i < 50 ? i + 1 : undefined
    };
  });
};

function CommunityFeed({ translations, binanceReferralUrl }: CommunityFeedProps) {
  const [businessIdeas, setBusinessIdeas] = useState<BusinessIdea[]>(generateBusinessIdeas());
  const [filteredIdeas, setFilteredIdeas] = useState<BusinessIdea[]>(businessIdeas);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStage, setSelectedStage] = useState('all');
  const [selectedComplexity, setSelectedComplexity] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'popular' | 'educational' | 'trending'>('trending');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedIdea, setSelectedIdea] = useState<BusinessIdea | null>(null);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Auto-rotate weekly top 50 ideas
  useEffect(() => {
    const rotateWeek = () => {
      setCurrentWeek(prev => prev === 52 ? 1 : prev + 1);
      // Simulate getting new top 50 ideas each week
      const shuffled = [...businessIdeas].sort(() => Math.random() - 0.5);
      setBusinessIdeas(shuffled.slice(0, 50));
    };

    // Rotate weekly (for demo, we'll use 30 seconds)
    const interval = setInterval(rotateWeek, 30000);
    return () => clearInterval(interval);
  }, [businessIdeas]);

  // Filter and search logic
  useEffect(() => {
    let filtered = businessIdeas.slice(0, 50); // Only show top 50 weekly

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(idea => idea.category === selectedCategory);
    }

    if (selectedStage !== 'all') {
      filtered = filtered.filter(idea => idea.stage === selectedStage);
    }

    if (selectedComplexity !== 'all') {
      filtered = filtered.filter(idea => idea.complexity === selectedComplexity);
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(idea => 
        idea.title.toLowerCase().includes(query) ||
        idea.description.toLowerCase().includes(query) ||
        idea.tags.some(tag => tag.toLowerCase().includes(query)) ||
        idea.author.name.toLowerCase().includes(query)
      );
    }

    // Sort
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'popular':
          return (b.metrics.likes + b.metrics.views) - (a.metrics.likes + a.metrics.views);
        case 'educational':
          return (b.metrics.bookmarks + b.metrics.shares) - (a.metrics.bookmarks + a.metrics.shares);
        case 'trending':
          return (b.metrics.views + b.metrics.shares * 10) - (a.metrics.views + a.metrics.shares * 10);
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });

    setFilteredIdeas(filtered);
  }, [businessIdeas, selectedCategory, selectedStage, selectedComplexity, searchQuery, sortBy]);

  const handleLike = (ideaId: string) => {
    setBusinessIdeas(prev => prev.map(idea => 
      idea.id === ideaId 
        ? { 
            ...idea, 
            isLiked: !idea.isLiked,
            metrics: { 
              ...idea.metrics, 
              likes: idea.isLiked ? idea.metrics.likes - 1 : idea.metrics.likes + 1 
            }
          }
        : idea
    ));
  };

  const handleBookmark = (ideaId: string) => {
    setBusinessIdeas(prev => prev.map(idea => 
      idea.id === ideaId 
        ? { 
            ...idea, 
            isBookmarked: !idea.isBookmarked,
            metrics: { 
              ...idea.metrics, 
              bookmarks: idea.isBookmarked ? idea.metrics.bookmarks - 1 : idea.metrics.bookmarks + 1 
            }
          }
        : idea
    ));
  };

  const handleShare = (ideaId: string) => {
    setBusinessIdeas(prev => prev.map(idea => 
      idea.id === ideaId 
        ? { 
            ...idea, 
            metrics: { 
              ...idea.metrics, 
              shares: idea.metrics.shares + 1 
            }
          }
        : idea
    ));
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const getCategoryIcon = (category: string) => {
    const icons = {
      tech: Brain,
      crypto: Coins,
      'real-estate': Home,
      startup: Zap,
      product: ShoppingCart,
      service: Users,
      ecommerce: Globe,
      fintech: DollarSign,
      ai: Sparkles,
      'green-energy': Lightbulb
    };
    const Icon = icons[category as keyof typeof icons] || Building;
    return <Icon className="w-4 h-4" />;
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      tech: 'bg-blue-100 text-blue-700 border-blue-200',
      crypto: 'bg-old-money-gold/10 text-old-money-gold border-old-money-gold/30',
      'real-estate': 'bg-green-100 text-green-700 border-green-200',
      startup: 'bg-purple-100 text-purple-700 border-purple-200',
      product: 'bg-orange-100 text-orange-700 border-orange-200',
      service: 'bg-indigo-100 text-indigo-700 border-indigo-200',
      ecommerce: 'bg-pink-100 text-pink-700 border-pink-200',
      fintech: 'bg-old-money-navy/10 text-old-money-navy border-old-money-navy/30',
      ai: 'bg-old-money-burgundy/10 text-old-money-burgundy border-old-money-burgundy/30',
      'green-energy': 'bg-old-money-sage/10 text-old-money-sage border-old-money-sage/30'
    };
    return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case 'Beginner': return 'text-old-money-sage';
      case 'Intermediate': return 'text-old-money-gold';
      case 'Advanced': return 'text-old-money-burgundy';
      default: return 'text-old-money-warm-gray';
    }
  };

  // Component for displaying project with professional category-based visuals
  const ProjectImage = ({ idea, className = "" }: { idea: BusinessIdea; className?: string }) => {
    // Generate professional category-based image
    const defaultImageSrc = `https://images.unsplash.com/photo-${
      1600000000000 + idea.category.charCodeAt(0) * 1000000 + parseInt(idea.id.replace('idea_', '')) * 1000
    }?w=600&h=400&fit=crop&auto=format&q=80`;
    
    const CategoryIcon = getCategoryIcon(idea.category).type;
    
    return (
      <div className={`relative rounded-lg overflow-hidden ${className}`}>
        <ImageWithFallback
          src={defaultImageSrc}
          alt={`${idea.category} business analysis`}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-old-money-navy/20 to-old-money-burgundy/30 flex items-center justify-center">
          <div className="text-center text-old-money-cream">
            <div className="w-16 h-16 mx-auto mb-3 bg-old-money-cream/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <CategoryIcon className="w-8 h-8" />
            </div>
            <div className="text-sm font-medium bg-old-money-navy/50 px-3 py-1 rounded-full backdrop-blur-sm">
              {idea.category.charAt(0).toUpperCase() + idea.category.slice(1).replace('-', ' ')} Analysis
            </div>
          </div>
        </div>
      </div>
    );
  };

  const categories = [
    { id: 'all', name: 'All Industries', icon: Building },
    { id: 'tech', name: 'Technology', icon: Brain },
    { id: 'crypto', name: 'Crypto/Web3', icon: Coins },
    { id: 'ai', name: 'AI/ML', icon: Sparkles },
    { id: 'fintech', name: 'FinTech', icon: DollarSign },
    { id: 'real-estate', name: 'Real Estate', icon: Home },
    { id: 'green-energy', name: 'Green Energy', icon: Lightbulb },
    { id: 'ecommerce', name: 'E-commerce', icon: Globe },
    { id: 'startup', name: 'Startups', icon: Zap },
    { id: 'product', name: 'Products', icon: ShoppingCart }
  ];

  const weeklyStats = {
    totalIdeas: filteredIdeas.length,
    totalViews: filteredIdeas.reduce((sum, idea) => sum + idea.metrics.views, 0),
    avgComplexity: filteredIdeas.filter(idea => idea.complexity === 'Advanced').length / filteredIdeas.length * 100,
    hotIdeas: filteredIdeas.filter(idea => idea.isHot).length
  };

  return (
    <div className="space-y-6">
      {/* Enhanced Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-old-money-navy flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-old-money-burgundy to-old-money-sage rounded-full flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-old-money-cream" />
            </div>
            Business Learning Hub & Market Analysis
            <Badge className="bg-old-money-sage text-old-money-cream">
              Week {currentWeek} Top 50
            </Badge>
          </h2>
          <p className="text-old-money-warm-gray flex items-center gap-2 mt-2">
            📚 Learn business models & market analysis • 🎯 No investment required • 💡 Educational content to help you understand opportunities
            <Badge className="bg-old-money-gold text-old-money-navy ml-2">
              100% Educational
            </Badge>
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setShowCreateModal(true)}
            className="bg-old-money-burgundy hover:bg-old-money-burgundy-light text-old-money-cream font-bold"
          >
            <Plus className="w-5 h-5 mr-2" />
            Submit Business Analysis
          </Button>
        </div>
      </div>

      {/* Educational Purpose Notice */}
      <Card className="border-old-money-navy border-2 bg-gradient-to-r from-old-money-navy/5 to-old-money-sage/5">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-old-money-navy rounded-full flex items-center justify-center">
              <Info className="w-6 h-6 text-old-money-cream" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-old-money-navy mb-2">
                📚 Educational Platform - Learn, Don't Invest Here
              </h3>
              <p className="text-old-money-warm-gray">
                This platform is designed to help you <strong>learn about business models, market analysis, and investment strategies</strong>. 
                We do not collect money or facilitate investments in these projects. Use this knowledge to make informed decisions 
                when you invest through proper channels like our Binance partnership for trading.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weekly Stats Dashboard */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-old-money-beige bg-old-money-sage/10">
          <CardContent className="p-4 text-center">
            <BookOpen className="w-6 h-6 mx-auto mb-2 text-old-money-sage" />
            <div className="text-2xl font-bold text-old-money-sage">{weeklyStats.totalIdeas}</div>
            <div className="text-sm text-old-money-warm-gray">Learning Cases</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige bg-old-money-gold/10">
          <CardContent className="p-4 text-center">
            <Eye className="w-6 h-6 mx-auto mb-2 text-old-money-gold" />
            <div className="text-2xl font-bold text-old-money-gold">{(weeklyStats.totalViews / 1000).toFixed(0)}K</div>
            <div className="text-sm text-old-money-warm-gray">Study Views</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige bg-old-money-navy/10">
          <CardContent className="p-4 text-center">
            <GraduationCap className="w-6 h-6 mx-auto mb-2 text-old-money-navy" />
            <div className="text-2xl font-bold text-old-money-navy">{weeklyStats.avgComplexity.toFixed(0)}%</div>
            <div className="text-sm text-old-money-warm-gray">Advanced Content</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige bg-old-money-burgundy/10">
          <CardContent className="p-4 text-center">
            <Zap className="w-6 h-6 mx-auto mb-2 text-old-money-burgundy" />
            <div className="text-2xl font-bold text-old-money-burgundy">{weeklyStats.hotIdeas}</div>
            <div className="text-sm text-old-money-warm-gray">Trending Topics</div>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Rotation Banner */}
      <Card className="border-old-money-gold border-2 bg-gradient-to-r from-old-money-gold/10 to-old-money-sage/10">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-old-money-gold rounded-full flex items-center justify-center animate-pulse">
                <Calendar className="w-6 h-6 text-old-money-navy" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-old-money-navy flex items-center gap-2">
                  🔄 Weekly Learning Rotation
                  <Badge className="bg-old-money-burgundy text-old-money-cream">Live</Badge>
                </h3>
                <p className="text-old-money-warm-gray">
                  New batch of 50 best business case studies and market analyses updated every week. 
                  Current rotation: Week {currentWeek} of 52
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-old-money-navy">{filteredIdeas.length}/50</div>
              <div className="text-sm text-old-money-warm-gray">Cases This Week</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-old-money-warm-gray" />
              <Input
                placeholder="Search business analyses, market studies, case studies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-2 border-old-money-warm-gray focus:border-old-money-gold text-lg py-3"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
              className={viewMode === 'grid' ? 'bg-old-money-navy text-old-money-cream' : ''}
            >
              Grid
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
              className={viewMode === 'list' ? 'bg-old-money-navy text-old-money-cream' : ''}
            >
              List
            </Button>
          </div>
        </div>
        
        {/* Category Filters */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className={`whitespace-nowrap flex items-center gap-2 ${
                selectedCategory === category.id 
                  ? 'bg-old-money-navy text-old-money-cream' 
                  : 'border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark'
              }`}
            >
              <category.icon className="w-4 h-4" />
              {category.name}
              {category.id !== 'all' && (
                <Badge variant="secondary" className="text-xs ml-1">
                  {businessIdeas.filter(idea => idea.category === category.id).length}
                </Badge>
              )}
            </Button>
          ))}
        </div>

        {/* Additional Filters */}
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-old-money-warm-gray" />
            <span className="text-sm font-medium text-old-money-navy">Filters:</span>
          </div>
          
          <Select value={selectedStage} onValueChange={setSelectedStage}>
            <SelectTrigger className="w-[140px] border-old-money-warm-gray">
              <SelectValue placeholder="Study Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Concept">💡 Concept</SelectItem>
              <SelectItem value="Research">🔍 Research</SelectItem>
              <SelectItem value="Analysis">📊 Analysis</SelectItem>
              <SelectItem value="Case Study">📋 Case Study</SelectItem>
              <SelectItem value="Deep Dive">🎯 Deep Dive</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedComplexity} onValueChange={setSelectedComplexity}>
            <SelectTrigger className="w-[140px] border-old-money-warm-gray">
              <SelectValue placeholder="Complexity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Levels</SelectItem>
              <SelectItem value="Beginner">🟢 Beginner</SelectItem>
              <SelectItem value="Intermediate">🟡 Intermediate</SelectItem>
              <SelectItem value="Advanced">🔴 Advanced</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={(value) => setSortBy(value as typeof sortBy)}>
            <SelectTrigger className="w-[140px] border-old-money-warm-gray">
              <SelectValue placeholder="Sort By" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="trending">🔥 Trending</SelectItem>
              <SelectItem value="popular">👥 Popular</SelectItem>
              <SelectItem value="educational">📚 Most Saved</SelectItem>
              <SelectItem value="newest">🆕 Newest</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Projects Grid */}
      <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
        {filteredIdeas.map((idea) => (
          <Card 
            key={idea.id} 
            className={`cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-old-money-gold ${
              idea.isFeatured ? 'ring-2 ring-old-money-gold ring-opacity-50' : ''
            } ${
              viewMode === 'list' ? 'flex flex-row' : ''
            }`}
            onClick={() => setSelectedIdea(idea)}
          >
            {viewMode === 'grid' ? (
              <>
                <div className="relative">
                  {idea.isHot && (
                    <Badge className="absolute top-3 left-3 z-10 bg-old-money-burgundy text-old-money-cream">
                      🔥 Trending
                    </Badge>
                  )}
                  {idea.isFeatured && (
                    <Badge className="absolute top-3 right-3 z-10 bg-old-money-gold text-old-money-navy">
                      ⭐ Featured
                    </Badge>
                  )}
                  <ProjectImage idea={idea} className="h-48 w-full" />
                </div>
                
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <Badge className={`${getCategoryColor(idea.category)} border text-xs px-2 py-1`}>
                      {getCategoryIcon(idea.category)}
                      <span className="ml-1">{idea.category.replace('-', ' ')}</span>
                    </Badge>
                    <Badge variant="outline" className={`text-xs ${getComplexityColor(idea.complexity)}`}>
                      {idea.complexity}
                    </Badge>
                  </div>
                  
                  <h3 className="text-lg font-bold text-old-money-navy mb-2 line-clamp-2">
                    {idea.title}
                  </h3>
                  
                  <p className="text-old-money-warm-gray text-sm mb-4 line-clamp-3">
                    {idea.description}
                  </p>

                  {/* Educational Metrics */}
                  <div className="grid grid-cols-2 gap-3 mb-4 p-3 bg-old-money-cream-dark rounded-lg">
                    <div>
                      <div className="text-xs text-old-money-warm-gray">Study Type</div>
                      <div className="text-lg font-bold text-old-money-burgundy">
                        {idea.stage}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-old-money-warm-gray">Complexity</div>
                      <div className="text-lg font-bold text-old-money-sage">
                        {idea.complexity}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-old-money-warm-gray">Market Size</div>
                      <div className="text-lg font-bold text-old-money-navy">
                        {idea.marketAnalysis.marketSize.slice(0, 15)}...
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-old-money-warm-gray">Industry</div>
                      <div className="text-lg font-bold text-old-money-gold">
                        {idea.category.charAt(0).toUpperCase() + idea.category.slice(1)}
                      </div>
                    </div>
                  </div>

                  {/* Author Info */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-old-money-navy text-old-money-cream text-xs">
                          {idea.author.avatar}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="text-sm font-medium text-old-money-navy flex items-center gap-1">
                          {idea.author.name}
                          {idea.author.verified && (
                            <CheckCircle className="w-3 h-3 text-old-money-sage" />
                          )}
                        </div>
                        <div className="text-xs text-old-money-warm-gray">{idea.author.experience}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-old-money-warm-gray">Expertise</div>
                      <div className="text-sm font-bold text-old-money-navy">{idea.author.expertise}</div>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 mb-4">
                    {idea.tags.slice(0, 3).map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {idea.tags.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{idea.tags.length - 3}
                      </Badge>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-between">
                    <div className="flex gap-3">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleLike(idea.id);
                        }}
                        className={`gap-1 ${idea.isLiked ? 'text-old-money-burgundy' : 'text-old-money-warm-gray'}`}
                      >
                        <Heart className={`w-4 h-4 ${idea.isLiked ? 'fill-current' : ''}`} />
                        {idea.metrics.likes}
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleBookmark(idea.id);
                        }}
                        className={`gap-1 ${idea.isBookmarked ? 'text-old-money-gold' : 'text-old-money-warm-gray'}`}
                      >
                        <Bookmark className={`w-4 h-4 ${idea.isBookmarked ? 'fill-current' : ''}`} />
                        {idea.metrics.bookmarks}
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="ghost"
                        className="gap-1 text-old-money-warm-gray"
                      >
                        <Eye className="w-4 h-4" />
                        {idea.metrics.views.toLocaleString()}
                      </Button>
                    </div>
                    
                    <Button
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleShare(idea.id);
                      }}
                      className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
                    >
                      <BookOpen className="w-4 h-4 mr-1" />
                      Study ({idea.metrics.shares})
                    </Button>
                  </div>
                </CardContent>
              </>
            ) : (
              // List view layout
              <div className="flex w-full">
                <div className="w-48 flex-shrink-0">
                  <ProjectImage idea={idea} className="h-32 w-full" />
                </div>
                <CardContent className="flex-1 p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-bold text-old-money-navy">{idea.title}</h3>
                    <div className="flex gap-2">
                      {idea.isHot && (
                        <Badge className="bg-old-money-burgundy text-old-money-cream">🔥 Trending</Badge>
                      )}
                      {idea.isFeatured && (
                        <Badge className="bg-old-money-gold text-old-money-navy">⭐ Featured</Badge>
                      )}
                    </div>
                  </div>
                  
                  <p className="text-old-money-warm-gray text-sm mb-3 line-clamp-2">
                    {idea.description}
                  </p>
                  
                  <div className="grid grid-cols-4 gap-4 mb-3">
                    <div>
                      <div className="text-xs text-old-money-warm-gray">Type</div>
                      <div className="font-bold text-old-money-burgundy">{idea.stage}</div>
                    </div>
                    <div>
                      <div className="text-xs text-old-money-warm-gray">Level</div>
                      <div className="font-bold text-old-money-sage">{idea.complexity}</div>
                    </div>
                    <div>
                      <div className="text-xs text-old-money-warm-gray">Views</div>
                      <div className="font-bold text-old-money-navy">{(idea.metrics.views / 1000).toFixed(0)}K</div>
                    </div>
                    <div>
                      <div className="text-xs text-old-money-warm-gray">Category</div>
                      <div className="font-bold text-old-money-gold">{idea.category}</div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback className="bg-old-money-navy text-old-money-cream text-xs">
                          {idea.author.avatar}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm text-old-money-navy">{idea.author.name}</span>
                      {idea.author.verified && (
                        <CheckCircle className="w-3 h-3 text-old-money-sage" />
                      )}
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleLike(idea.id);
                        }}
                        className={`gap-1 ${idea.isLiked ? 'text-old-money-burgundy' : 'text-old-money-warm-gray'}`}
                      >
                        <Heart className={`w-4 h-4 ${idea.isLiked ? 'fill-current' : ''}`} />
                        {idea.metrics.likes}
                      </Button>
                      
                      <Button
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleShare(idea.id);
                        }}
                        className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
                      >
                        Study Case
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </div>
            )}
          </Card>
        ))}
      </div>

      {filteredIdeas.length === 0 && (
        <div className="text-center py-12">
          <AlertCircle className="w-16 h-16 text-old-money-warm-gray mx-auto mb-4" />
          <h3 className="text-xl font-bold text-old-money-navy mb-2">No business analyses found</h3>
          <p className="text-old-money-warm-gray mb-4">
            Try adjusting your filters or search terms to find more learning opportunities.
          </p>
          <Button 
            onClick={() => {
              setSelectedCategory('all');
              setSelectedStage('all');
              setSelectedComplexity('all');
              setSearchQuery('');
            }}
            className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
          >
            Clear All Filters
          </Button>
        </div>
      )}

      {/* Detailed Analysis Modal */}
      {selectedIdea && (
        <Dialog open={!!selectedIdea} onOpenChange={() => setSelectedIdea(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <div className="flex items-start justify-between">
                <div>
                  <DialogTitle className="text-2xl font-bold text-old-money-navy flex items-center gap-3">
                    {selectedIdea.title}
                    {selectedIdea.author.verified && (
                      <CheckCircle className="w-6 h-6 text-old-money-sage" />
                    )}
                  </DialogTitle>
                  <DialogDescription className="mt-2 flex items-center gap-2">
                    <Badge className={`${getCategoryColor(selectedIdea.category)} border`}>
                      {getCategoryIcon(selectedIdea.category)}
                      <span className="ml-1">{selectedIdea.category.replace('-', ' ')}</span>
                    </Badge>
                    <Badge variant="outline" className={getComplexityColor(selectedIdea.complexity)}>
                      {selectedIdea.complexity} Level
                    </Badge>
                    <Badge variant="outline">{selectedIdea.stage}</Badge>
                    {selectedIdea.isHot && (
                      <Badge className="bg-old-money-burgundy text-old-money-cream">🔥 Trending</Badge>
                    )}
                  </DialogDescription>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedIdea(null)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </DialogHeader>

            <div className="space-y-6">
              {/* Project Image */}
              <ProjectImage idea={selectedIdea} className="h-64 w-full" />

              {/* Overview */}
              <div>
                <h3 className="text-lg font-bold text-old-money-navy mb-3">Business Analysis Overview</h3>
                <p className="text-old-money-warm-gray leading-relaxed mb-4">
                  {selectedIdea.description}
                </p>
                <blockquote className="border-l-4 border-old-money-gold pl-4 italic text-old-money-navy">
                  "{selectedIdea.pitch}"
                </blockquote>
              </div>

              <Tabs defaultValue="market-analysis" className="w-full">
                <TabsList className="grid w-full grid-cols-5">
                  <TabsTrigger value="market-analysis">Market Analysis</TabsTrigger>
                  <TabsTrigger value="business-model">Business Model</TabsTrigger>
                  <TabsTrigger value="learning-points">Key Learnings</TabsTrigger>
                  <TabsTrigger value="case-study">Case Study</TabsTrigger>
                  <TabsTrigger value="education">Educational Content</TabsTrigger>
                </TabsList>

                <TabsContent value="market-analysis" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <BarChart3 className="w-5 h-5 text-old-money-burgundy" />
                          Market Opportunity
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div>
                            <h4 className="font-semibold text-old-money-navy">Market Size</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.marketAnalysis.marketSize}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-navy">Growth Rate</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.marketAnalysis.growthRate}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Shield className="w-5 h-5 text-old-money-sage" />
                          Competitive Landscape
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div>
                            <h4 className="font-semibold text-old-money-navy">Competition</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.marketAnalysis.competition}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-navy">Market Opportunity</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.marketAnalysis.opportunity}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="business-model" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <DollarSign className="w-5 h-5 text-old-money-gold" />
                          Revenue Model
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div>
                            <h4 className="font-semibold text-old-money-navy">Model Type</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.businessModel.type}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-navy">Revenue Streams</h4>
                            <div className="space-y-1">
                              {selectedIdea.businessModel.revenueStreams.map((stream, index) => (
                                <div key={index} className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-old-money-sage" />
                                  <span className="text-old-money-warm-gray text-sm">{stream}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Users className="w-5 h-5 text-old-money-navy" />
                          Business Structure
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div>
                            <h4 className="font-semibold text-old-money-navy">Target Customers</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.businessModel.targetCustomers}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-navy">Key Resources</h4>
                            <div className="space-y-1">
                              {selectedIdea.businessModel.keyResources.map((resource, index) => (
                                <div key={index} className="flex items-center gap-2">
                                  <Zap className="w-4 h-4 text-old-money-gold" />
                                  <span className="text-old-money-warm-gray text-sm">{resource}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="learning-points" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Lightbulb className="w-5 h-5 text-old-money-burgundy" />
                          Key Insights & Success Factors
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-semibold text-old-money-burgundy mb-2">Key Insights</h4>
                            <div className="space-y-1">
                              {selectedIdea.learningPoints.keyInsights.map((insight, index) => (
                                <div key={index} className="flex items-start gap-2">
                                  <Brain className="w-4 h-4 text-old-money-burgundy mt-0.5" />
                                  <span className="text-old-money-warm-gray text-sm">{insight}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-sage mb-2">Success Factors</h4>
                            <div className="space-y-1">
                              {selectedIdea.learningPoints.successFactors.map((factor, index) => (
                                <div key={index} className="flex items-start gap-2">
                                  <CheckCircle className="w-4 h-4 text-old-money-sage mt-0.5" />
                                  <span className="text-old-money-warm-gray text-sm">{factor}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <AlertCircle className="w-5 h-5 text-old-money-navy" />
                          Challenges & Lessons
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-semibold text-old-money-navy mb-2">Key Challenges</h4>
                            <div className="space-y-1">
                              {selectedIdea.learningPoints.challenges.map((challenge, index) => (
                                <div key={index} className="flex items-start gap-2">
                                  <AlertCircle className="w-4 h-4 text-old-money-navy mt-0.5" />
                                  <span className="text-old-money-warm-gray text-sm">{challenge}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-gold mb-2">Lessons Learned</h4>
                            <div className="space-y-1">
                              {selectedIdea.learningPoints.lessons.map((lesson, index) => (
                                <div key={index} className="flex items-start gap-2">
                                  <GraduationCap className="w-4 h-4 text-old-money-gold mt-0.5" />
                                  <span className="text-old-money-warm-gray text-sm">{lesson}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="case-study" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Target className="w-5 h-5 text-old-money-burgundy" />
                          Problem & Solution
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div>
                            <h4 className="font-semibold text-old-money-burgundy">Problem Identified</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.caseStudy.problem}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-sage">Solution Approach</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.caseStudy.solution}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Rocket className="w-5 h-5 text-old-money-navy" />
                          Implementation & Results
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div>
                            <h4 className="font-semibold text-old-money-navy">Implementation</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.caseStudy.implementation}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-gold">Results Achieved</h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.caseStudy.results}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="education" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <GraduationCap className="w-5 h-5 text-old-money-burgundy" />
                        Educational Content & Learning Outcomes
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-semibold text-old-money-navy flex items-center gap-2">
                              <BookOpen className="w-4 h-4" />
                              What You'll Learn
                            </h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.educationalContent.whatYouLearn}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-sage flex items-center gap-2">
                              <TrendingUp className="w-4 h-4" />
                              Industry Trends
                            </h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.educationalContent.industryTrends}</p>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-semibold text-old-money-gold flex items-center gap-2">
                              <Target className="w-4 h-4" />
                              Market Opportunities
                            </h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.educationalContent.marketOpportunities}</p>
                          </div>
                          <div>
                            <h4 className="font-semibold text-old-money-burgundy flex items-center gap-2">
                              <Briefcase className="w-4 h-4" />
                              Business Strategy
                            </h4>
                            <p className="text-old-money-warm-gray">{selectedIdea.educationalContent.businessStrategy}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Author & Study Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Users className="w-5 h-5 text-old-money-navy" />
                          Author Information
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-3 mb-4">
                          <Avatar className="w-12 h-12">
                            <AvatarFallback className="bg-old-money-navy text-old-money-cream">
                              {selectedIdea.author.avatar}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-semibold text-old-money-navy flex items-center gap-2">
                              {selectedIdea.author.name}
                              {selectedIdea.author.verified && (
                                <CheckCircle className="w-4 h-4 text-old-money-sage" />
                              )}
                            </div>
                            <div className="text-sm text-old-money-warm-gray">{selectedIdea.author.experience}</div>
                            <div className="text-xs text-old-money-warm-gray">
                              Expertise: {selectedIdea.author.expertise}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <FileText className="w-5 h-5 text-old-money-gold" />
                          Study Details
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-old-money-warm-gray">Study Type</span>
                            <span className="font-semibold text-old-money-navy">{selectedIdea.stage}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-old-money-warm-gray">Complexity Level</span>
                            <span className="font-semibold text-old-money-sage">{selectedIdea.complexity}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-old-money-warm-gray">Market Scope</span>
                            <span className="font-semibold text-old-money-burgundy">{selectedIdea.location}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-old-money-warm-gray">Last Updated</span>
                            <span className="font-semibold text-old-money-gold">{selectedIdea.timeline}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="flex justify-center">
                    <Button
                      className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream px-8"
                      onClick={() => handleBookmark(selectedIdea.id)}
                    >
                      <Bookmark className="w-4 h-4 mr-2" />
                      Save for Later
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>

              {/* Study Stats */}
              <div className="grid grid-cols-5 gap-4 p-4 bg-old-money-cream-dark rounded-lg">
                <div className="text-center">
                  <Heart className="w-5 h-5 mx-auto mb-1 text-old-money-burgundy" />
                  <div className="font-bold text-old-money-navy">{selectedIdea.metrics.likes}</div>
                  <div className="text-xs text-old-money-warm-gray">Likes</div>
                </div>
                <div className="text-center">
                  <Eye className="w-5 h-5 mx-auto mb-1 text-old-money-sage" />
                  <div className="font-bold text-old-money-navy">{selectedIdea.metrics.views.toLocaleString()}</div>
                  <div className="text-xs text-old-money-warm-gray">Views</div>
                </div>
                <div className="text-center">
                  <MessageCircle className="w-5 h-5 mx-auto mb-1 text-old-money-gold" />
                  <div className="font-bold text-old-money-navy">{selectedIdea.metrics.comments}</div>
                  <div className="text-xs text-old-money-warm-gray">Comments</div>
                </div>
                <div className="text-center">
                  <Bookmark className="w-5 h-5 mx-auto mb-1 text-old-money-navy" />
                  <div className="font-bold text-old-money-navy">{selectedIdea.metrics.bookmarks}</div>
                  <div className="text-xs text-old-money-warm-gray">Saved</div>
                </div>
                <div className="text-center">
                  <Share2 className="w-5 h-5 mx-auto mb-1 text-old-money-burgundy" />
                  <div className="font-bold text-old-money-navy">{selectedIdea.metrics.shares}</div>
                  <div className="text-xs text-old-money-warm-gray">Shared</div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Submit Analysis Modal - Educational Focus */}
      {showCreateModal && (
        <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold text-old-money-navy">
                Submit Business Analysis or Case Study
              </DialogTitle>
              <DialogDescription>
                Share your business analysis, market research, or educational case study to help others learn about business models and opportunities.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-old-money-navy">Analysis Title</label>
                <Input 
                  placeholder="e.g., Fintech Market Analysis: Digital Banking Trends 2024" 
                  className="mt-1"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-old-money-navy">Industry Category</label>
                <Select>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select industry" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.slice(1).map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-old-money-navy">Business Analysis Description</label>
                <Textarea 
                  placeholder="Describe your business analysis, market research findings, case study insights, or educational content that would help others learn..." 
                  className="mt-1 min-h-[120px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-old-money-navy">Market Size/Scope</label>
                  <Input 
                    placeholder="e.g., $50B global market" 
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-old-money-navy">Growth Rate</label>
                  <Input 
                    placeholder="e.g., 25% annual growth" 
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-old-money-navy">Analysis Type</label>
                  <Select>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concept">💡 Concept Analysis</SelectItem>
                      <SelectItem value="research">🔍 Market Research</SelectItem>
                      <SelectItem value="analysis">📊 Business Analysis</SelectItem>
                      <SelectItem value="case-study">📋 Case Study</SelectItem>
                      <SelectItem value="deep-dive">🎯 Deep Dive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-old-money-navy">Complexity Level</label>
                  <Select>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">🟢 Beginner</SelectItem>
                      <SelectItem value="intermediate">🟡 Intermediate</SelectItem>
                      <SelectItem value="advanced">🔴 Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-old-money-navy">Learning Tags</label>
                <Input 
                  placeholder="market analysis, business model, case study, growth strategy (separate with commas)" 
                  className="mt-1"
                />
              </div>

              <Card className="bg-old-money-sage/10 border-old-money-sage">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-old-money-sage mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-old-money-navy mb-1">Educational Purpose</h4>
                      <p className="text-sm text-old-money-warm-gray">
                        Remember: This is an educational platform. We share business analyses and case studies to help people learn, 
                        not to collect investments. Focus on educational value and insights that help others understand business models and market opportunities.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-3 pt-4">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => setShowCreateModal(false)}
                >
                  Cancel
                </Button>
                <Button 
                  className="flex-1 bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
                  onClick={() => {
                    setShowCreateModal(false);
                    // Handle educational content submission
                  }}
                >
                  <Send className="w-4 h-4 mr-2" />
                  Submit Analysis
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

export default CommunityFeed;