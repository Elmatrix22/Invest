import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Users, 
  Award, 
  TrendingUp, 
  Shield, 
  Globe, 
  Heart,
  Target,
  Lightbulb,
  Clock
} from 'lucide-react';

interface AboutSectionProps {
  translations: any;
}

export function AboutSection({ translations }: AboutSectionProps) {
  const milestones = [
    { year: "2020", event: "Company Founded", description: "Started with a vision to democratize investing" },
    { year: "2021", event: "1M Users", description: "Reached our first million registered users" },
    { year: "2022", event: "Global Expansion", description: "Launched in 50+ countries worldwide" },
    { year: "2023", event: "Mobile App Launch", description: "Award-winning mobile app launched" },
    { year: "2024", event: "5M Users", description: "Became one of the fastest-growing platforms" },
    { year: "2025", event: "IPO Announced", description: "Going public to serve investors better" }
  ];

  const values = [
    {
      icon: Heart,
      title: "Customer First",
      description: "Every decision we make puts our users' success at the center"
    },
    {
      icon: Shield,
      title: "Trust & Security",
      description: "Your safety and privacy are our highest priorities"
    },
    {
      icon: Lightbulb,
      title: "Innovation",
      description: "We constantly innovate to make investing more accessible"
    },
    {
      icon: Globe,
      title: "Global Access",
      description: "Breaking down barriers to global investment opportunities"
    }
  ];

  const team = [
    {
      name: "Alex Johnson",
      role: "CEO & Founder",
      bio: "Former Goldman Sachs VP with 15 years in fintech",
      avatar: "AJ"
    },
    {
      name: "Sarah Kim",
      role: "CTO",
      bio: "Ex-Google engineer, expert in scalable platforms",
      avatar: "SK"
    },
    {
      name: "Michael Chen",
      role: "Chief Investment Officer", 
      bio: "20+ years in portfolio management and trading",
      avatar: "MC"
    },
    {
      name: "Emma Rodriguez",
      role: "Head of Compliance",
      bio: "Former SEC regulator ensuring user protection",
      avatar: "ER"
    }
  ];

  const achievements = [
    { icon: Users, metric: "5M+", label: "Active Users" },
    { icon: Globe, metric: "150+", label: "Countries" },
    { icon: Award, metric: "50+", label: "Industry Awards" },
    { icon: TrendingUp, metric: "$50B+", label: "Assets Under Management" }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl text-gray-900">
            {translations.aboutTitle || "About Invest-Free.com"}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {translations.aboutSubtitle || "Democratizing investment access for everyone"}
          </p>
        </div>

        {/* Hero Story */}
        <div className="grid gap-12 lg:grid-cols-2 items-center mb-20">
          <div className="space-y-6">
            <div>
              <Badge className="bg-amber-100 text-amber-800 mb-4">Our Story</Badge>
              <p className="text-lg text-gray-700 leading-relaxed">
                {translations.aboutDescription || "Founded in 2020, Invest-Free.com has revolutionized online investing by making it accessible, affordable, and simple for everyone. Our mission is to empower individuals to build wealth through smart investing."}
              </p>
            </div>
            <div className="space-y-4">
              <p className="text-gray-600">
                We believe that everyone deserves access to the same investment opportunities as Wall Street professionals. That's why we've built a platform that combines institutional-grade tools with user-friendly design.
              </p>
              <p className="text-gray-600">
                Today, millions of investors trust us with their financial future, and we're just getting started.
              </p>
            </div>
            <Button size="lg" className="bg-amber-500 hover:bg-amber-600">
              Join Our Mission
            </Button>
          </div>
          
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-amber-400 to-orange-500 rounded-3xl transform rotate-3"></div>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=800"
              alt="Team collaboration"
              className="relative rounded-3xl shadow-2xl w-full h-96 object-cover"
            />
          </div>
        </div>

        {/* Achievements */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
          {achievements.map((achievement, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <achievement.icon className="w-8 h-8 text-amber-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{achievement.metric}</div>
              <div className="text-sm text-gray-600">{achievement.label}</div>
            </div>
          ))}
        </div>

        {/* Values */}
        <div className="mb-20">
          <h3 className="text-2xl text-center mb-12 text-gray-900">Our Values</h3>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {values.map((value, index) => (
              <Card key={index} className="text-center border-0 bg-gray-50">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-6 h-6 text-amber-600" />
                  </div>
                  <h4 className="text-lg mb-2 text-gray-900">{value.title}</h4>
                  <p className="text-sm text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Timeline */}
        <div className="mb-20">
          <h3 className="text-2xl text-center mb-12 text-gray-900">Our Journey</h3>
          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-0.5 h-full w-0.5 bg-amber-200"></div>
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className={`flex items-center ${index % 2 === 0 ? 'justify-start' : 'justify-end'}`}>
                  <div className={`w-5/12 ${index % 2 === 0 ? 'text-right pr-8' : 'text-left pl-8'}`}>
                    <Card className="border-0 bg-amber-50">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <Clock className="w-4 h-4 text-amber-600" />
                          <Badge variant="outline" className="text-amber-600 border-amber-200">
                            {milestone.year}
                          </Badge>
                        </div>
                        <h4 className="font-medium text-gray-900 mb-1">{milestone.event}</h4>
                        <p className="text-sm text-gray-600">{milestone.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-amber-500 rounded-full border-4 border-white"></div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Leadership Team */}
        <div>
          <h3 className="text-2xl text-center mb-12 text-gray-900">Leadership Team</h3>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {team.map((member, index) => (
              <Card key={index} className="text-center border-0 bg-gray-50 hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-amber-600">{member.avatar}</span>
                  </div>
                  <h4 className="text-lg mb-1 text-gray-900">{member.name}</h4>
                  <p className="text-sm font-medium text-amber-600 mb-2">{member.role}</p>
                  <p className="text-xs text-gray-600">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}