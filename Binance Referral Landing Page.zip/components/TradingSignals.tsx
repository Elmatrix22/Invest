import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { Input } from './ui/input';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from './ui/tooltip';
import { 
  Signal, 
  TrendingUp, 
  TrendingDown, 
  Target, 
  Clock, 
  ExternalLink,
  Brain,
  Activity,
  Shield,
  Lightbulb,
  Calculator,
  Flame,
  Search,
  Heart,
  RefreshCw,
  Timer,
  Award,
  Loader2,
  Plus,
  Wand2,
  Database,
  Cpu,
  Lock,
  Sparkles,
  Crown
} from 'lucide-react';
import { toast } from "sonner@2.0.3";

interface TradingSignal {
  id: string;
  asset: string;
  symbol: string;
  category: 'crypto' | 'forex' | 'stocks' | 'commodities' | 'indices';
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  currentPrice: number;
  entryPrice: number;
  targetPrice: number;
  stopLoss: number;
  timeframe: 'scalp' | 'swing' | 'position';
  timestamp: string;
  change24h: number;
  volume: number;
  aiAnalysis: {
    reason: string;
    technicals: string;
    fundamentals: string;
    riskFactors: string[];
    probability: number;
    tutorial?: string;
    stepByStep?: string[];
  };
  riskLevel: 'Low' | 'Medium' | 'High';
  difficulty: 'beginner' | 'intermediate' | 'professional';
  expectedDuration: string;
  accuracy?: number;
  platform: string;
  positionSize: string;
  riskReward: number;
  tags: string[];
  isHot?: boolean;
  isFavorite?: boolean;
  isNew?: boolean;
  aiGenerated?: boolean;
}

interface TradingSignalsProps {
  translations: any;
  binanceReferralUrl: string;
  user?: any;
  onShowAuthModal?: () => void;
  marketData: any;
  isMarketDataReady?: boolean;
}

// Generate comprehensive signals with LIVE MARKET DATA
const generateComprehensiveSignals = (marketData: any, signalCount: number = 12): TradingSignal[] => {
  const currentTime = Date.now();
  const signals: TradingSignal[] = [];
  
  // Ensure we have live market data before generating signals
  if (!marketData || !marketData.prices || Object.keys(marketData.prices).length === 0) {
    console.warn('⚠️ Cannot generate signals: Live market data not available');
    return [];
  }

  console.log(`📊 Generating ${signalCount} signals using live market data from ${Object.keys(marketData.prices).length} assets`);
  
  // High-Quality Signal Pool with LIVE PRICES - PROPERLY CATEGORIZED
  const signalTemplates = [
    // CRYPTO SIGNALS
    {
      asset: 'Bitcoin',
      symbol: 'BTC/USDT',
      category: 'crypto' as const,
      signal: 'BUY' as const,
      basePrice: marketData.prices['BTC/USDT']?.price || 98750,
      confidence: 94,
      riskLevel: 'Medium' as const,
      difficulty: 'beginner' as const,
      timeframe: 'swing' as const,
      analysis: {
        reason: '🚀 Bitcoin showing massive institutional accumulation! Breaking above $98K resistance with record volume.',
        technicals: 'Golden cross on 4H + daily, RSI bullish divergence, ascending triangle completion with 340% volume surge.',
        fundamentals: 'BlackRock adds $2.1B, MicroStrategy $4.2B purchase, Japan pension fund approved. Fed dovish pivot confirmed.',
        riskFactors: ['Profit-taking at $100K', 'Macro headwinds', 'Overextended RSI'],
        tutorial: '🎯 PERFECT ENTRY: Bitcoin is breaking out of a major consolidation. This is a high-probability swing trade.',
        stepByStep: [
          '🔥 IMMEDIATE: Set buy orders at $98,200-$98,500',
          '💰 Position: 8-12% of trading capital',
          '⛔ STOP: $94,500 (non-negotiable)',
          '🎯 Target 1: $105,000 (40% profit)',
          '🎯 Target 2: $108,500 (60% profit)'
        ]
      },
      tags: ['Institutional', 'Breakout', 'High Volume']
    },
    {
      asset: 'Ethereum',
      symbol: 'ETH/USDT',
      category: 'crypto' as const,
      signal: 'BUY' as const,
      basePrice: marketData.prices['ETH/USDT']?.price || 3420,
      confidence: 88,
      riskLevel: 'Medium' as const,
      difficulty: 'intermediate' as const,
      timeframe: 'swing' as const,
      analysis: {
        reason: '⚡ Ethereum leading altcoin recovery! DeFi TVL surge + Layer 2 adoption accelerating rapidly.',
        technicals: 'Bullish flag completion, breaking $3,400 resistance, increasing on-chain activity, whale accumulation detected.',
        fundamentals: '94% ETH staked, DeFi TVL at $78B (+15% weekly), Layer 2 transactions +890% YoY, ETH 3.0 roadmap accelerating.',
        riskFactors: ['Bitcoin correlation', 'L2 competition', 'Regulatory concerns'],
        tutorial: '🔥 ETH MOMENTUM: Leading the altcoin charge. Perfect setup for DeFi narrative acceleration.',
        stepByStep: [
          '🎯 ENTRY: Scale in $3,350-$3,450',
          '💎 Size: 6-10% crypto allocation',
          '⛔ Stop: $3,150 (major support)',
          '🚀 Target 1: $3,950 (recent highs)',
          '🚀 Target 2: $4,200 (extended)'
        ]
      },
      tags: ['DeFi Leader', 'L2 Growth', 'Supply Shock']
    },
    {
      asset: 'Solana',
      symbol: 'SOL/USDT',
      category: 'crypto' as const,
      signal: 'BUY' as const,
      basePrice: marketData.prices['SOL/USDT']?.price || 238.50,
      confidence: 85,
      riskLevel: 'Medium' as const,
      difficulty: 'intermediate' as const,
      timeframe: 'swing' as const,
      analysis: {
        reason: '🔥 Solana ecosystem explosion! NFT + DeFi + meme coin volume surging. Network upgrades boosting performance.',
        technicals: 'Breaking key resistance at $235, volume surge 450%, whale accumulation pattern confirmed on-chain.',
        fundamentals: 'Daily active users +280% YoY, DeFi TVL growing rapidly, major integrations with traditional finance.',
        riskFactors: ['Network congestion', 'Ethereum competition', 'Regulatory uncertainty'],
        tutorial: '⚡ SOL MOMENTUM: Perfect breakout setup with massive ecosystem growth driving adoption.',
        stepByStep: [
          '🎯 ENTRY: Buy on any dip to $230-$235',
          '💎 Size: 4-8% crypto allocation',
          '⛔ Stop: $205 (key support)',
          '🚀 Target 1: $285 (next resistance)',
          '🚀 Target 2: $320 (cycle high)'
        ]
      },
      tags: ['Ecosystem Growth', 'DeFi', 'High Performance']
    },
    // FOREX SIGNALS
    {
      asset: 'EUR/USD',
      symbol: 'EURUSD',
      category: 'forex' as const,
      signal: 'SELL' as const,
      basePrice: marketData.prices['EURUSD']?.price || 1.0547,
      confidence: 87,
      riskLevel: 'Low' as const,
      difficulty: 'beginner' as const,
      timeframe: 'swing' as const,
      analysis: {
        reason: '💶 ECB dovish stance vs Fed hawkish hold! Economic divergence creating strong USD momentum.',
        technicals: 'Breaking below 1.0550 support, RSI oversold bounce failed, bearish flag completion with high volume.',
        fundamentals: 'US GDP outperforming EU by 1.2%, US yields rising, EU inflation falling faster than expected.',
        riskFactors: ['ECB surprise', 'Risk-off sentiment', 'Technical oversold'],
        tutorial: '📉 FOREX CLASSIC: Perfect USD strength setup. EU economic weakness vs US resilience.',
        stepByStep: [
          '💰 ENTRY: Sell on bounce to 1.0560-1.0580',
          '📊 Size: 2-4% forex allocation',
          '🛑 STOP: 1.0620 (recent high)',
          '🎯 Target 1: 1.0480 (next support)',
          '🎯 Target 2: 1.0420 (major level)'
        ]
      },
      tags: ['Central Bank', 'Economic Divergence', 'USD Strength']
    },
    {
      asset: 'GBP/USD',
      symbol: 'GBPUSD',
      category: 'forex' as const,
      signal: 'BUY' as const,
      basePrice: marketData.prices['GBPUSD']?.price || 1.2634,
      confidence: 82,
      riskLevel: 'Medium' as const,
      difficulty: 'intermediate' as const,
      timeframe: 'swing' as const,
      analysis: {
        reason: '🇬🇧 Sterling strengthening on BoE hawkish signals! UK inflation persistence forcing continued rate support.',
        technicals: 'Double bottom at 1.2520, breaking ascending triangle, GBP crosses showing strength across the board.',
        fundamentals: 'BoE maintaining restrictive stance, UK services inflation sticky, wage growth supporting consumption.',
        riskFactors: ['UK political uncertainty', 'Global risk-off', 'US economic data'],
        tutorial: '💂 GBP REVIVAL: Central bank divergence play. BoE staying hawkish while others pivot dovish.',
        stepByStep: [
          '🎯 ENTRY: Buy dips to 1.2580-1.2610',
          '💷 Size: 3-5% forex allocation',
          '⛔ STOP: 1.2520 (recent low)',
          '🚀 Target 1: 1.2750 (resistance)',
          '🚀 Target 2: 1.2850 (extended)'
        ]
      },
      tags: ['BoE Hawkish', 'Inflation Trade', 'GBP Strength']
    },
    {
      asset: 'USD/JPY',
      symbol: 'USDJPY',
      category: 'forex' as const,
      signal: 'SELL' as const,
      basePrice: marketData.prices['USDJPY']?.price || 149.85,
      confidence: 90,
      riskLevel: 'Medium' as const,
      difficulty: 'professional' as const,
      timeframe: 'position' as const,
      analysis: {
        reason: '🇯🇵 BoJ intervention risk CRITICAL! USD/JPY at dangerous levels triggering Japanese authority concern.',
        technicals: 'Testing intervention zone near 150, massive bearish divergence on momentum, volatility spike expected.',
        fundamentals: 'Japanese officials verbal intervention increasing, potential coordinated G7 action, yen severely undervalued.',
        riskFactors: ['Fed pivot delay', 'Risk-on sentiment', 'China economic weakness'],
        tutorial: '⚠️ INTERVENTION PLAY: High-risk/high-reward trade betting on Japanese currency intervention.',
        stepByStep: [
          '🚨 ENTRY: Sell 149.80-150.20 (intervention zone)',
          '⚖️ Size: 1-3% (HIGH RISK)',
          '🛑 STOP: 151.50 (risk management)',
          '🎯 Target 1: 147.50 (initial retracement)',
          '🎯 Target 2: 145.00 (major correction)'
        ]
      },
      tags: ['Intervention Risk', 'BoJ Watch', 'High Risk/Reward']
    },
    // STOCKS SIGNALS
    {
      asset: 'NVIDIA Corp',
      symbol: 'NVDA',
      category: 'stocks' as const,
      signal: 'BUY' as const,
      basePrice: marketData.prices['NVDA']?.price || 141.50,
      confidence: 91,
      riskLevel: 'Medium' as const,
      difficulty: 'professional' as const,
      timeframe: 'position' as const,
      analysis: {
        reason: '🤖 NVIDIA announcing revolutionary B200 chips. Q4 earnings preview shows 40% revenue jump from AI demand.',
        technicals: 'Cup & handle completion, institutional accumulation via dark pools, volume profile extremely bullish.',
        fundamentals: 'Data center revenue projected $35B vs $28B estimate. Microsoft, Google, Amazon increasing AI capex 60%+.',
        riskFactors: ['Semiconductor cycle', 'China restrictions', 'Valuation stretched'],
        tutorial: '💡 AI INFRASTRUCTURE: Next major AI chip breakthrough. Perfect earnings timing.',
        stepByStep: [
          '⚡ URGENT: Buy before earnings (3 days)',
          '💎 Allocation: 6-10% stock portfolio',
          '🛡️ Protection: Stop at $131',
          '🚀 Targets: $167 (primary), $175 (extended)',
          '📈 Hold through Q1 2025 earnings'
        ]
      },
      tags: ['AI Revolution', 'Earnings Play', 'Tech Leader']
    },
    {
      asset: 'Tesla Inc',
      symbol: 'TSLA',
      category: 'stocks' as const,
      signal: 'BUY' as const,
      basePrice: marketData.prices['TSLA']?.price || 352.60,
      confidence: 84,
      riskLevel: 'High' as const,
      difficulty: 'intermediate' as const,
      timeframe: 'swing' as const,
      analysis: {
        reason: '🚗 Tesla FSD breakthrough + Robotaxi updates driving massive sentiment shift. Model Y refresh incoming.',
        technicals: 'Breaking above 350 resistance, strong momentum, institutional buying detected, RSI healthy.',
        fundamentals: 'Q4 deliveries beating estimates, FSD adoption accelerating, energy business growing 40% YoY.',
        riskFactors: ['EV competition', 'Macro sensitivity', 'Elon Twitter factor'],
        tutorial: '⚡ TESLA MOMENTUM: FSD breakthrough creating new valuation paradigm for autonomous driving.',
        stepByStep: [
          '🎯 ENTRY: Buy breakout above $350',
          '🔋 Size: 3-6% stock allocation',
          '⚔️ STOP: $320 (support zone)',
          '🚀 Target 1: $395 (next resistance)',
          '🚀 Target 2: $420 (psychological)'
        ]
      },
      tags: ['FSD Breakthrough', 'EV Leader', 'Momentum']
    }
  ];

  // Generate signals based on templates WITH LIVE MARKET DATA
  for (let i = 0; i < signalCount; i++) {
    const template = signalTemplates[i % signalTemplates.length];
    
    // Use LIVE market price if available, with small variation for entry timing
    const livePrice = marketData.prices[template.symbol];
    const currentPrice = livePrice ? 
      livePrice.price * (1 + (Math.random() - 0.5) * 0.005) : // ±0.5% variation on live price
      template.basePrice * (1 + (Math.random() - 0.5) * 0.03);  // ±1.5% if no live data
    
    // Log when using live vs fallback data
    if (livePrice) {
      console.log(`✅ Using live price for ${template.symbol}: ${livePrice.price.toFixed(4)} (source: ${livePrice.source})`);
    } else {
      console.warn(`⚠️ Using fallback price for ${template.symbol}: ${template.basePrice}`);
    }
    const isPositive = template.signal === 'BUY';
    
    const signal: TradingSignal = {
      id: `SIG_${currentTime}_${String(i + 1).padStart(3, '0')}`,
      asset: template.asset,
      symbol: template.symbol,
      category: template.category,
      signal: template.signal,
      confidence: template.confidence + Math.floor((Math.random() - 0.5) * 6), // ±3 confidence variation
      currentPrice,
      entryPrice: currentPrice * (isPositive ? 0.997 : 1.003),
      targetPrice: currentPrice * (isPositive ? 1.085 : 0.915),
      stopLoss: currentPrice * (isPositive ? 0.955 : 1.045),
      timeframe: template.timeframe,
      timestamp: new Date(currentTime - Math.random() * 3600000).toISOString(),
      change24h: livePrice ? livePrice.change24h : (Math.random() - 0.3) * 8, // Use live 24h change
      volume: livePrice ? livePrice.volume : Math.floor(Math.random() * 2000000000) + 100000000,
      aiAnalysis: {
        reason: template.analysis.reason,
        technicals: template.analysis.technicals,
        fundamentals: template.analysis.fundamentals,
        riskFactors: template.analysis.riskFactors,
        probability: template.confidence,
        tutorial: template.analysis.tutorial,
        stepByStep: template.analysis.stepByStep
      },
      riskLevel: template.riskLevel,
      difficulty: template.difficulty,
      expectedDuration: template.timeframe === 'scalp' ? '1-4 hours' : 
                       template.timeframe === 'swing' ? '3-14 days' : 
                       '2-12 weeks',
      accuracy: 85 + Math.floor(Math.random() * 12), // 85-97% accuracy
      platform: template.category === 'crypto' ? 'Binance' : 
               template.category === 'forex' ? 'Forex Brokers' :
               template.category === 'commodities' ? 'Commodity Brokers' : 'All Major Brokers',
      positionSize: template.difficulty === 'beginner' ? '3-8% portfolio' :
                   template.difficulty === 'intermediate' ? '2-6% portfolio' :
                   '1-4% portfolio',
      riskReward: 1.2 + Math.random() * 2.8, // 1.2-4.0 risk/reward
      tags: template.tags,
      isHot: Math.random() > 0.6,
      isNew: Math.random() > 0.7,
      aiGenerated: Math.random() > 0.4
    };

    signals.push(signal);
  }

  return signals;
};

// Helper function to format time ago
const getTimeAgo = (date: Date): string => {
  const now = new Date();
  const diffInMs = now.getTime() - date.getTime();
  const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
  const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
  const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

  if (diffInMinutes < 1) return 'Just now';
  if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
  if (diffInHours < 24) return `${diffInHours}h ago`;
  if (diffInDays < 7) return `${diffInDays}d ago`;
  return date.toLocaleDateString();
};

export default function TradingSignals({ translations, binanceReferralUrl, user, onShowAuthModal, marketData, isMarketDataReady = false }: TradingSignalsProps) {
  // STATE MANAGEMENT
  const [signals, setSignals] = useState<TradingSignal[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState('all');
  const [selectedTimeframe, setSelectedTimeframe] = useState('all');
  const [filteredSignals, setFilteredSignals] = useState<TradingSignal[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [favoriteSignals, setFavoriteSignals] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState('all-signals');
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationCount, setGenerationCount] = useState(0);
  const [displayLimit, setDisplayLimit] = useState(6);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  // INITIALIZE SIGNALS ONLY WHEN LIVE MARKET DATA IS READY
  useEffect(() => {
    if (isMarketDataReady && marketData.prices && Object.keys(marketData.prices).length > 0) {
      console.log('🚀 Initializing signals with live market data...');
      const initialSignals = generateComprehensiveSignals(marketData, 15); // Generate 15 initial signals
      setSignals(initialSignals);
      setLastUpdate(new Date());
      console.log(`✅ Generated ${initialSignals.length} signals using live prices from ${Object.keys(marketData.prices).length} assets`);
    }
  }, [isMarketDataReady, marketData]);

  // FILTER SIGNALS LOGIC
  useEffect(() => {
    let filtered = signals;

    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(signal => signal.category === selectedCategory);
    }

    // Difficulty filter
    if (selectedDifficulty !== 'all') {
      filtered = filtered.filter(signal => signal.difficulty === selectedDifficulty);
    }

    // Timeframe filter
    if (selectedTimeframe !== 'all') {
      filtered = filtered.filter(signal => signal.timeframe === selectedTimeframe);
    }

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(signal => 
        signal.asset.toLowerCase().includes(searchTerm.toLowerCase()) ||
        signal.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
        signal.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Tab filters
    if (activeTab === 'beginner') {
      filtered = filtered.filter(signal => signal.difficulty === 'beginner');
    } else if (activeTab === 'professional') {
      filtered = filtered.filter(signal => signal.difficulty === 'professional');
    } else if (activeTab === 'favorites') {
      filtered = filtered.filter(signal => favoriteSignals.includes(signal.id));
    } else if (activeTab === 'hot') {
      filtered = filtered.filter(signal => signal.isHot);
    } else if (activeTab === 'ai-generated') {
      filtered = filtered.filter(signal => signal.aiGenerated);
    }

    setFilteredSignals(filtered);
  }, [selectedCategory, selectedDifficulty, selectedTimeframe, signals, searchTerm, activeTab, favoriteSignals]);

  // GENERATE NEW SIGNALS FUNCTION - REQUIRES LIVE DATA
  const handleGenerateSignals = async () => {
    if (!user) {
      onShowAuthModal?.();
      return;
    }

    if (!isMarketDataReady || !marketData.prices || Object.keys(marketData.prices).length === 0) {
      toast.error('Cannot generate signals: Live market data not available. Please wait for data to load.', {
        duration: 4000,
      });
      return;
    }

    setIsGenerating(true);
    
    try {
      console.log('🤖 AI Signal Generation: Analyzing live market data...');
      
      // Show progress of AI analysis
      const analysisSteps = [
        'Fetching live prices from exchanges...',
        'Analyzing technical indicators...',
        'Processing fundamental data...',
        'Calculating risk-reward ratios...',
        'Generating trading signals...'
      ];
      
      for (let i = 0; i < analysisSteps.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        console.log(`🔄 ${analysisSteps[i]}`);
      }
      
      // Generate new signals using LIVE market data
      const newSignals = generateComprehensiveSignals(marketData, 12);
      
      if (newSignals.length === 0) {
        throw new Error('No signals could be generated with current market data');
      }
      
      setSignals(newSignals);
      setGenerationCount(prev => prev + 1);
      setLastUpdate(new Date());
      setDisplayLimit(6); // Reset display limit
      
      const liveCount = newSignals.filter(signal => {
        const marketPrice = marketData.prices[signal.symbol];
        return marketPrice && marketPrice.source !== 'Fallback';
      }).length;
      
      console.log(`✅ Generated ${newSignals.length} new signals (${liveCount} using live prices)`);
      
      toast.success(`🎯 Generated ${newSignals.length} new AI signals using live market data!`, {
        duration: 4000,
      });
    } catch (error) {
      console.error('❌ Failed to generate signals:', error);
      toast.error('Failed to generate signals. Please try again.', {
        duration: 3000,
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // REFRESH SIGNALS FUNCTION - REQUIRES LIVE DATA
  const handleRefreshSignals = async () => {
    if (!isMarketDataReady || !marketData.prices || Object.keys(marketData.prices).length === 0) {
      toast.error('Cannot refresh signals: Live market data not available.', {
        duration: 3000,
      });
      return;
    }

    setIsRefreshing(true);
    
    try {
      console.log('🔄 Refreshing signals with latest market data...');
      
      // Simulate market data refresh
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Update existing signals with new live data
      const refreshedSignals = generateComprehensiveSignals(marketData, signals.length);
      
      if (refreshedSignals.length === 0) {
        throw new Error('No signals could be refreshed with current market data');
      }
      
      setSignals(refreshedSignals);
      setLastUpdate(new Date());
      
      const liveCount = refreshedSignals.filter(signal => {
        const marketPrice = marketData.prices[signal.symbol];
        return marketPrice && marketPrice.source !== 'Fallback';
      }).length;
      
      console.log(`🔄 Refreshed ${refreshedSignals.length} signals (${liveCount} using live prices)`);
      
      toast.success(`📊 Refreshed signals with latest market data!`, {
        duration: 3000,
      });
    } catch (error) {
      console.error('❌ Failed to refresh signals:', error);
      toast.error('Failed to refresh signals. Please try again.', {
        duration: 3000,
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  // LOAD MORE SIGNALS
  const handleLoadMore = () => {
    setIsLoadingMore(true);
    setTimeout(() => {
      setDisplayLimit(prev => prev + 6);
      setIsLoadingMore(false);
    }, 1000);
  };

  // TOGGLE FAVORITE
  const toggleFavorite = (signalId: string) => {
    setFavoriteSignals(prev => 
      prev.includes(signalId) 
        ? prev.filter(id => id !== signalId)
        : [...prev, signalId]
    );
  };

  // SIGNAL DISPLAY HELPERS
  const getSignalIcon = (signal: TradingSignal) => {
    if (signal.aiGenerated) return <Brain className="w-4 h-4" />;
    if (signal.signal === 'BUY') return <TrendingUp className="w-4 h-4" />;
    if (signal.signal === 'SELL') return <TrendingDown className="w-4 h-4" />;
    return <Target className="w-4 h-4" />;
  };

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case 'BUY': return 'text-soft-mint bg-soft-mint/10';
      case 'SELL': return 'text-danger-coral bg-danger-coral/10';
      case 'HOLD': return 'text-warm-slate bg-warm-slate/10';
      default: return 'text-deep-ocean bg-deep-ocean/10';
    }
  };

  // STATS CALCULATION
  const signalStats = {
    total: signals.length,
    beginner: signals.filter(s => s.difficulty === 'beginner').length,
    professional: signals.filter(s => s.difficulty === 'professional').length,
    hot: signals.filter(s => s.isHot).length,
    aiGenerated: signals.filter(s => s.aiGenerated).length,
    winRate: 87,
    avgReturn: 14.2
  };

  return (
    <>
      {/* Page Header */}
      <div className="page-header">
        <div className="page-badge">
          🚀 Live AI Trading Signals
        </div>
        <h1 className="page-title">
          Free AI Trading Signals
        </h1>
        <p className="page-subtitle">
          Get professional-grade trading signals powered by AI analysis and live market data. 
          All signals are 100% free with detailed tutorials for every skill level.
        </p>
      </div>

      {/* ENHANCED STATS DASHBOARD */}
      <div className="page-section">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <Card className="bg-gradient-to-br from-deep-ocean to-deep-ocean-light text-pearl-white">
            <CardContent className="p-4 text-center">
              <div className="flex items-center justify-center mb-2">
                <Activity className="w-5 h-5 mr-2" />
                <span className="font-bold">{signalStats.total}</span>
              </div>
              <p className="text-xs opacity-90">Total Signals</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-soft-teal to-soft-teal-light text-pearl-white">
            <CardContent className="p-4 text-center">
              <div className="flex items-center justify-center mb-2">
                <Brain className="w-5 h-5 mr-2" />
                <span className="font-bold">{signalStats.aiGenerated}</span>
              </div>
              <p className="text-xs opacity-90">AI Generated</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-warning-amber to-warning-amber text-deep-navy">
            <CardContent className="p-4 text-center">
              <div className="flex items-center justify-center mb-2">
                <Target className="w-5 h-5 mr-2" />
                <span className="font-bold">{signalStats.winRate}%</span>
              </div>
              <p className="text-xs opacity-80">Win Rate</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-soft-mint to-soft-mint-light text-pearl-white">
            <CardContent className="p-4 text-center">
              <div className="flex items-center justify-center mb-2">
                <TrendingUp className="w-5 h-5 mr-2" />
                <span className="font-bold">{signalStats.avgReturn}%</span>
              </div>
              <p className="text-xs opacity-90">Avg Return</p>
            </CardContent>
          </Card>

          <Card className="bg-pearl-white border-soft-teal/20">
            <CardContent className="p-4 text-center">
              <div className="flex items-center justify-center mb-2">
                <Flame className="w-5 h-5 mr-2 text-danger-coral" />
                <span className="font-bold text-deep-navy">{signalStats.hot}</span>
              </div>
              <p className="text-xs text-warm-slate">Hot Signals</p>
            </CardContent>
          </Card>

          <Card className="bg-pearl-white border-soft-teal/20">
            <CardContent className="p-4 text-center">
              <div className="flex items-center justify-center mb-2">
                <Clock className="w-5 h-5 mr-2 text-soft-teal" />
                <span className="font-bold text-deep-navy">{getTimeAgo(lastUpdate)}</span>
              </div>
              <p className="text-xs text-warm-slate">Last Update</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* AI SIGNAL GENERATION CONTROLS */}
      <div className="ai-signal-section">
        <div className="ai-signal-content">
          <div className="ai-signal-header">
            <div className="ai-signal-icon">
              <Brain className="w-6 h-6 text-pearl-white" />
            </div>
            <div>
              <h3 className="ai-signal-title">
                Mars X63 Signal Core
              </h3>
              <p className="ai-signal-subtitle">
                Real-time market analysis • Institutional-grade signals • {signalStats.total} active signals
              </p>
            </div>
          </div>
          
          <div className="ai-signal-controls">
            <div className="ai-signal-status">
              <div className="ai-status-indicator"></div>
              <span>
                AI Status: {isMarketDataReady ? 'Ready (Live Data)' : 'Waiting for Data...'}
              </span>
              {isMarketDataReady && (
                <>
                  <span className="mx-2">•</span>
                  <span>{generationCount} generations today</span>
                </>
              )}
            </div>
            
            <button
              onClick={handleGenerateSignals}
              disabled={isGenerating || !user || !isMarketDataReady}
              className="ai-button-primary disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Wand2 className="w-5 h-5 mr-2" />
                  Generate New Signals
                </>
              )}
            </button>
            
            <button
              onClick={handleRefreshSignals}
              disabled={isRefreshing || !isMarketDataReady}
              className="ai-button-secondary disabled:opacity-50"
            >
              {isRefreshing ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <RefreshCw className="w-5 h-5" />
              )}
            </button>
          </div>

          {!user && (
            <div className="ai-alert">
              <div className="ai-alert-content">
                <Lock className="w-5 h-5 ai-alert-icon" />
                <div className="ai-alert-text">
                  <strong>Premium AI Signals:</strong> Register for FREE access to unlimited signal generation with 90%+ accuracy rates.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* SIGNAL TABS AND CONTENT */}
      <div className="page-section">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-6 bg-warm-slate/10">
            <TabsTrigger value="all-signals" className="text-sm">
              All Signals
            </TabsTrigger>
            <TabsTrigger value="ai-generated" className="text-sm">
              <Brain className="w-4 h-4 mr-1" />
              AI Generated
            </TabsTrigger>
            <TabsTrigger value="beginner" className="text-sm">
              <Shield className="w-4 h-4 mr-1" />
              Beginner
            </TabsTrigger>
            <TabsTrigger value="professional" className="text-sm">
              <Crown className="w-4 h-4 mr-1" />
              Professional
            </TabsTrigger>
            <TabsTrigger value="hot" className="text-sm">
              <Flame className="w-4 h-4 mr-1" />
              Hot
            </TabsTrigger>
            <TabsTrigger value="favorites" className="text-sm">
              <Heart className="w-4 h-4 mr-1" />
              Favorites
            </TabsTrigger>
          </TabsList>

          {/* FILTERS SECTION */}
          <Card className="mt-4">
            <CardContent className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-warm-slate" />
                  <Input
                    placeholder="Search signals..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="crypto">🪙 Cryptocurrency</SelectItem>
                    <SelectItem value="stocks">📈 Stocks</SelectItem>
                    <SelectItem value="forex">💱 Forex</SelectItem>
                    <SelectItem value="commodities">🥇 Commodities</SelectItem>
                    <SelectItem value="indices">📊 Indices</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="beginner">🟢 Beginner</SelectItem>
                    <SelectItem value="intermediate">🟡 Intermediate</SelectItem>
                    <SelectItem value="professional">🔴 Professional</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Timeframes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Timeframes</SelectItem>
                    <SelectItem value="scalp">⚡ Scalping (1-4h)</SelectItem>
                    <SelectItem value="swing">🎯 Swing (1-14 days)</SelectItem>
                    <SelectItem value="position">🏛️ Position (weeks-months)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* TAB CONTENT */}
          <TabsContent value={activeTab} className="mt-6">
            <div className="grid gap-4">
              {filteredSignals.slice(0, displayLimit).map((signal) => (
                <Card key={signal.id} className={`hover:shadow-lg transition-all duration-300 ${signal.aiGenerated ? 'ring-2 ring-soft-teal/30 bg-gradient-to-r from-pearl-white to-pearl-gray/50' : ''}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className={`flex items-center justify-center w-10 h-10 rounded-full ${getSignalColor(signal.signal)}`}>
                          {getSignalIcon(signal)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-lg text-deep-ocean">{signal.asset}</h3>
                            {signal.aiGenerated && (
                              <Badge className="bg-gradient-to-r from-soft-teal to-soft-teal-light text-pearl-white text-xs font-bold">
                                <Brain className="w-3 h-3 mr-1" />
                                AI
                              </Badge>
                            )}
                            {signal.isNew && (
                              <Badge className="bg-soft-mint text-pearl-white text-xs">
                                NEW
                              </Badge>
                            )}
                            {signal.isHot && (
                              <Badge className="bg-danger-coral text-pearl-white text-xs">
                                <Flame className="w-3 h-3 mr-1" />
                                HOT
                              </Badge>
                            )}
                          </div>
                          <p className="text-warm-slate">{signal.symbol}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleFavorite(signal.id)}
                          className="p-2"
                        >
                          <Heart className={`w-4 h-4 ${favoriteSignals.includes(signal.id) ? 'fill-danger-coral text-danger-coral' : 'text-warm-slate'}`} />
                        </Button>
                        
                        <div className="text-right">
                          <div className="text-2xl font-bold text-deep-ocean">
                            ${signal.currentPrice.toLocaleString(undefined, { 
                              minimumFractionDigits: signal.currentPrice < 1 ? 4 : 2,
                              maximumFractionDigits: signal.currentPrice < 1 ? 6 : 2 
                            })}
                          </div>
                          <div className={`text-sm font-semibold ${signal.change24h >= 0 ? 'text-soft-mint' : 'text-danger-coral'}`}>
                            {signal.change24h >= 0 ? '+' : ''}{signal.change24h.toFixed(2)}%
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* SIGNAL DETAILS */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-warm-slate mb-1">Signal</p>
                        <Badge className={getSignalColor(signal.signal)}>
                          {signal.signal}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-xs text-warm-slate mb-1">Confidence</p>
                        <div className="flex items-center gap-2">
                          <Progress value={signal.confidence} className="flex-1 h-2" />
                          <span className="text-sm font-semibold text-deep-ocean">{signal.confidence}%</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-warm-slate mb-1">Target</p>
                        <p className="font-semibold text-deep-ocean">
                          ${signal.targetPrice.toLocaleString(undefined, { 
                            minimumFractionDigits: signal.targetPrice < 1 ? 4 : 2,
                            maximumFractionDigits: signal.targetPrice < 1 ? 6 : 2 
                          })}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-warm-slate mb-1">Risk/Reward</p>
                        <p className="font-semibold text-soft-mint">{signal.riskReward.toFixed(1)}:1</p>
                      </div>
                    </div>

                    {/* AI ANALYSIS */}
                    <div className="bg-pearl-gray rounded-lg p-4 mb-4">
                      <h4 className="font-semibold text-deep-ocean mb-2 flex items-center gap-2">
                        <Lightbulb className="w-4 h-4" />
                        AI Analysis
                      </h4>
                      <p className="text-sm text-charcoal mb-3">{signal.aiAnalysis.reason}</p>
                      
                      <div className="grid md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="font-semibold text-deep-ocean mb-1">Technical Analysis:</p>
                          <p className="text-warm-slate">{signal.aiAnalysis.technicals}</p>
                        </div>
                        <div>
                          <p className="font-semibold text-deep-ocean mb-1">Fundamentals:</p>
                          <p className="text-warm-slate">{signal.aiAnalysis.fundamentals}</p>
                        </div>
                      </div>

                      {signal.aiAnalysis.tutorial && (
                        <div className="mt-3 p-3 bg-soft-teal/10 rounded border-l-4 border-soft-teal">
                          <p className="text-sm text-charcoal">{signal.aiAnalysis.tutorial}</p>
                        </div>
                      )}
                    </div>

                    {/* STEP BY STEP GUIDE */}
                    {signal.aiAnalysis.stepByStep && (
                      <div className="bg-pearl-gray/50 rounded-lg p-4 mb-4">
                        <h4 className="font-semibold text-deep-ocean mb-2 flex items-center gap-2">
                          <Calculator className="w-4 h-4" />
                          Step-by-Step Trading Guide
                        </h4>
                        <ol className="space-y-1">
                          {signal.aiAnalysis.stepByStep.map((step, index) => (
                            <li key={index} className="text-sm text-charcoal flex items-start gap-2">
                              <span className="font-semibold text-deep-ocean min-w-[20px]">{index + 1}.</span>
                              <span>{step}</span>
                            </li>
                          ))}
                        </ol>
                      </div>
                    )}

                    {/* SIGNAL META INFORMATION */}
                    <div className="flex items-center justify-between text-xs text-warm-slate">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {getTimeAgo(new Date(signal.timestamp))}
                        </span>
                        <span className="flex items-center gap-1">
                          <Timer className="w-3 h-3" />
                          {signal.expectedDuration}
                        </span>
                        <span className="flex items-center gap-1">
                          <Shield className="w-3 h-3" />
                          {signal.riskLevel} Risk
                        </span>
                        {signal.accuracy && (
                          <span className="flex items-center gap-1">
                            <Target className="w-3 h-3" />
                            {signal.accuracy}% Accuracy
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {signal.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* TRADING PLATFORM LINK */}
                    <div className="mt-4 pt-4 border-t border-pearl-gray">
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-warm-slate">
                          Platform: <span className="font-semibold text-deep-ocean">{signal.platform}</span> • 
                          Position: <span className="font-semibold text-deep-ocean">{signal.positionSize}</span>
                        </div>
                        
                        <Button
                          onClick={() => window.open(binanceReferralUrl, '_blank')}
                          className="bg-warning-amber hover:bg-warning-amber/90 text-deep-navy font-semibold"
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Trade Now
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {/* LOAD MORE BUTTON */}
              {displayLimit < filteredSignals.length && (
                <div className="text-center mt-6">
                  <Button
                    onClick={handleLoadMore}
                    disabled={isLoadingMore}
                    variant="outline"
                    className="bg-pearl-white hover:bg-pearl-gray text-deep-navy border-soft-teal/20"
                  >
                    {isLoadingMore ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Loading More Signals...
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4 mr-2" />
                        Load More Signals ({filteredSignals.length - displayLimit} remaining)
                      </>
                    )}
                  </Button>
                </div>
              )}

              {/* EMPTY STATE */}
              {filteredSignals.length === 0 && (
                <Card className="text-center py-12">
                  <CardContent>
                    <Signal className="w-12 h-12 mx-auto mb-4 text-warm-slate" />
                    <h3 className="text-lg font-semibold text-deep-ocean mb-2">No Signals Found</h3>
                    <p className="text-warm-slate mb-4">
                      Try adjusting your filters or generate new signals.
                    </p>
                    {user && (
                      <Button
                        onClick={handleGenerateSignals}
                        className="bg-soft-teal hover:bg-soft-teal-light text-deep-navy"
                      >
                        <Brain className="w-4 h-4 mr-2" />
                        Generate New Signals
                      </Button>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>


    </>
  );
}