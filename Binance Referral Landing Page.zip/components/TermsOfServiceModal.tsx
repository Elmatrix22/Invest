import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { 
  FileText, 
  AlertTriangle, 
  Shield, 
  DollarSign, 
  Users, 
  Gavel,
  Clock,
  ExternalLink,
  Ban,
  CheckCircle2
} from 'lucide-react';

interface TermsOfServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  translations: any;
}

function TermsOfServiceModal({ isOpen, onClose, translations }: TermsOfServiceModalProps) {
  const lastUpdated = "January 15, 2025";

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl h-[80vh] border-old-money-beige">
        <DialogHeader className="pb-4">
          <DialogTitle className="flex items-center gap-2 text-old-money-navy">
            <FileText className="w-6 h-6" />
            {translations.termsOfServiceTitle || "Terms of Service"}
          </DialogTitle>
          <div className="flex items-center gap-2 text-sm text-old-money-warm-gray">
            <Clock className="w-4 h-4" />
            {translations.lastUpdated || "Last updated:"} {lastUpdated}
          </div>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-8">
            {/* Introduction */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Gavel className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">1. Agreement to Terms</h3>
              </div>
              <p className="text-old-money-charcoal mb-4">
                {translations.termsIntro || "By accessing and using Invest-Free.com, you agree to be bound by these Terms of Service and all applicable laws and regulations."}
              </p>
              
              <div className="bg-old-money-burgundy/10 p-4 rounded-lg border border-old-money-burgundy/30">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-old-money-burgundy" />
                  <span className="font-medium text-old-money-burgundy">Important Disclaimer</span>
                </div>
                <p className="text-sm text-old-money-charcoal">
                  This is a free educational platform. All trading signals and investment ideas are for informational purposes only and do not constitute financial advice. Trading involves substantial risk of loss.
                </p>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Platform Description */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Shield className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">2. Platform Description</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">2.1 Free Community Platform</h4>
                  <p className="text-old-money-charcoal text-sm mb-3">
                    Invest-Free.com provides a free community platform where users can:
                  </p>
                  <div className="grid md:grid-cols-2 gap-3">
                    <div className="bg-old-money-cream-dark p-3 rounded-lg">
                      <ul className="text-sm text-old-money-charcoal space-y-1">
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-old-money-sage" />
                          Share cryptocurrency investment ideas
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-old-money-sage" />
                          Access free trading signals
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-old-money-sage" />
                          Participate in live chat discussions
                        </li>
                      </ul>
                    </div>
                    <div className="bg-old-money-cream-dark p-3 rounded-lg">
                      <ul className="text-sm text-old-money-charcoal space-y-1">
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-old-money-sage" />
                          View community leaderboards
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-old-money-sage" />
                          Access Binance trading integration
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-old-money-sage" />
                          Participate in referral program
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">2.2 No Paid Services</h4>
                  <p className="text-old-money-charcoal text-sm">
                    Our platform is 100% free. We do not charge any fees for access to signals, community features, or any other platform functionality.
                  </p>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* User Responsibilities */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">3. User Responsibilities</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">3.1 Account Requirements</h4>
                  <ul className="list-disc list-inside space-y-1 text-old-money-charcoal ml-4 text-sm">
                    <li>You must be at least 18 years old to use this platform</li>
                    <li>Provide accurate and complete information when creating your account</li>
                    <li>Maintain the security of your account credentials</li>
                    <li>You are responsible for all activity under your account</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">3.2 Acceptable Use</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Badge className="bg-old-money-sage/10 text-old-money-sage mb-2">Allowed</Badge>
                      <ul className="text-sm text-old-money-charcoal space-y-1">
                        <li>• Share legitimate investment insights</li>
                        <li>• Engage in respectful discussions</li>
                        <li>• Help other community members</li>
                        <li>• Use referral links appropriately</li>
                      </ul>
                    </div>
                    
                    <div>
                      <Badge className="bg-old-money-burgundy/10 text-old-money-burgundy mb-2">Prohibited</Badge>
                      <ul className="text-sm text-old-money-charcoal space-y-1">
                        <li>• Post false or misleading information</li>
                        <li>• Engage in harassment or abuse</li>
                        <li>• Spam or excessive self-promotion</li>
                        <li>• Share illegal or harmful content</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Trading Disclaimers */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <DollarSign className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">4. Trading & Financial Disclaimers</h3>
              </div>
              
              <div className="space-y-4">
                <div className="bg-old-money-burgundy/10 p-4 rounded-lg border-2 border-old-money-burgundy/30">
                  <div className="flex items-center gap-2 mb-3">
                    <AlertTriangle className="w-5 h-5 text-old-money-burgundy" />
                    <span className="font-medium text-old-money-burgundy text-lg">RISK WARNING</span>
                  </div>
                  <ul className="space-y-2 text-sm text-old-money-charcoal">
                    <li><strong>• High Risk:</strong> Trading cryptocurrencies, forex, and binary options involves substantial risk of loss</li>
                    <li><strong>• Not Financial Advice:</strong> All content is for educational purposes only and not financial advice</li>
                    <li><strong>• Past Performance:</strong> Historical results do not guarantee future performance</li>
                    <li><strong>• Professional Advice:</strong> Always consult qualified financial advisors before investing</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">4.1 Signal Accuracy</h4>
                  <p className="text-old-money-charcoal text-sm mb-3">
                    While we strive to provide accurate signals using AI analysis, we make no guarantees about:
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-old-money-charcoal ml-4 text-sm">
                    <li>Signal accuracy or profitability</li>
                    <li>Timing of market movements</li>
                    <li>Specific trading outcomes</li>
                    <li>Platform availability or uptime</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">4.2 Third-Party Services</h4>
                  <p className="text-old-money-charcoal text-sm">
                    Our platform integrates with Binance through referral links. When you use these links, you are subject to Binance's terms of service and privacy policy. We are not responsible for Binance's services or policies.
                  </p>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Intellectual Property */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Shield className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">5. Intellectual Property</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">5.1 Platform Content</h4>
                  <p className="text-old-money-charcoal text-sm">
                    The Invest-Free.com platform, including its design, code, and original content, is protected by copyright and other intellectual property laws.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">5.2 User Content</h4>
                  <p className="text-old-money-charcoal text-sm mb-2">
                    When you post content on our platform, you:
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-old-money-charcoal ml-4 text-sm">
                    <li>Retain ownership of your original content</li>
                    <li>Grant us a license to display and distribute your content on the platform</li>
                    <li>Represent that you have the right to share the content</li>
                    <li>Agree that your content may be viewed by other users</li>
                  </ul>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Limitation of Liability */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Ban className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">6. Limitation of Liability</h3>
              </div>
              
              <div className="bg-old-money-warm-gray/10 p-4 rounded-lg border border-old-money-warm-gray/30 mb-4">
                <p className="text-sm text-old-money-charcoal">
                  <strong>To the fullest extent permitted by law:</strong> Invest-Free.com and its operators shall not be liable for any direct, indirect, incidental, special, or consequential damages resulting from your use of the platform or reliance on any information provided.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">6.1 Trading Losses</h4>
                  <p className="text-old-money-charcoal text-sm">
                    We are not liable for any trading losses, missed opportunities, or financial damages resulting from using our signals or community advice.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">6.2 Platform Availability</h4>
                  <p className="text-old-money-charcoal text-sm">
                    We strive for high uptime but are not liable for platform downtime, technical issues, or inability to access services.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">6.3 User Content</h4>
                  <p className="text-old-money-charcoal text-sm">
                    We are not responsible for user-generated content, including investment advice, predictions, or chat messages posted by community members.
                  </p>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Termination */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Ban className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">7. Account Termination</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">7.1 Voluntary Termination</h4>
                  <p className="text-old-money-charcoal text-sm">
                    You may terminate your account at any time by contacting us or using account deletion features in your profile settings.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">7.2 Platform Termination</h4>
                  <p className="text-old-money-charcoal text-sm">
                    We reserve the right to suspend or terminate accounts that violate these terms, engage in harmful behavior, or compromise platform security.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">7.3 Effect of Termination</h4>
                  <p className="text-old-money-charcoal text-sm">
                    Upon termination, your access will be revoked, but publicly posted content may remain visible to preserve community discussions and context.
                  </p>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Governing Law */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Gavel className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">8. Governing Law & Disputes</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">8.1 Applicable Law</h4>
                  <p className="text-old-money-charcoal text-sm">
                    These terms are governed by applicable international laws and regulations regarding online platforms and financial services.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">8.2 Dispute Resolution</h4>
                  <p className="text-old-money-charcoal text-sm">
                    We encourage resolving disputes through direct communication. For formal disputes, users agree to attempt mediation before pursuing legal action.
                  </p>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">8.3 Severability</h4>
                  <p className="text-old-money-charcoal text-sm">
                    If any provision of these terms is found unenforceable, the remaining provisions remain in full effect.
                  </p>
                </div>
              </div>
            </section>

            <Separator className="bg-old-money-beige" />

            {/* Contact Information */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <ExternalLink className="w-5 h-5 text-old-money-navy" />
                <h3 className="text-lg font-medium text-old-money-navy">9. Contact & Updates</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">Contact Information</h4>
                  <div className="bg-old-money-cream-dark p-3 rounded-lg text-sm">
                    <p>Email: support@invest-free.com</p>
                    <p>Legal: legal@invest-free.com</p>
                    <p>Address: Legal Team, Invest-Free.com</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-old-money-navy mb-2">Terms Updates</h4>
                  <p className="text-old-money-charcoal text-sm">
                    We may update these terms periodically. Significant changes will be communicated through the platform and the updated date will be modified accordingly.
                  </p>
                </div>
              </div>
            </section>
          </div>
        </ScrollArea>

        <div className="pt-4 border-t border-old-money-beige">
          <Button 
            onClick={onClose}
            className="w-full bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
          >
            <CheckCircle2 className="w-4 h-4 mr-2" />
            I Agree to These Terms
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default TermsOfServiceModal;