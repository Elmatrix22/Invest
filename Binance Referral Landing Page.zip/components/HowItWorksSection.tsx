import { MousePointer, UserPlus, CreditCard, Gift } from 'lucide-react';

interface HowItWorksSectionProps {
  translations: any;
}

export function HowItWorksSection({ translations }: HowItWorksSectionProps) {
  const steps = [
    {
      icon: MousePointer,
      title: translations.step1Title,
      description: translations.step1Description,
      color: "bg-blue-100 text-blue-600"
    },
    {
      icon: UserPlus,
      title: translations.step2Title,
      description: translations.step2Description,
      color: "bg-green-100 text-green-600"
    },
    {
      icon: CreditCard,
      title: translations.step3Title,
      description: translations.step3Description,
      color: "bg-purple-100 text-purple-600"
    },
    {
      icon: Gift,
      title: translations.step4Title,
      description: translations.step4Description,
      color: "bg-amber-100 text-amber-600"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl text-gray-900">
            {translations.howItWorksTitle}
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Get your $100 bonus in just 4 simple steps
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-[calc(100%-2rem)] w-16 h-0.5 bg-gray-200 z-0">
                  <div className="absolute inset-0 bg-gradient-to-r from-gray-300 to-transparent"></div>
                </div>
              )}
              
              <div className="relative bg-gray-50 rounded-2xl p-6 text-center hover:shadow-lg transition-shadow duration-300">
                <div className="relative mb-6">
                  <div className={`w-16 h-16 rounded-full ${step.color} flex items-center justify-center mx-auto`}>
                    <step.icon className="w-8 h-8" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-gray-900 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </div>
                </div>
                
                <h3 className="text-xl mb-3 text-gray-900">
                  {step.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-2 bg-green-50 border border-green-200 rounded-full px-6 py-3">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-green-800 font-medium">Average completion time: 5 minutes</span>
          </div>
        </div>
      </div>
    </section>
  );
}