import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Globe } from 'lucide-react';

interface LanguageSelectorProps {
  currentLanguage: string;
  onLanguageChange: (language: string) => void;
  variant?: 'default' | 'compact' | 'mobile';
  className?: string;
}

// Language options with proper names, flags, and native names
const languageOptions = [
  { code: 'en', name: 'English', flag: '🇺🇸', nativeName: 'English' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸', nativeName: 'Español' },
  { code: 'fr', name: 'French', flag: '🇫🇷', nativeName: 'Français' },
  { code: 'de', name: 'German', flag: '🇩🇪', nativeName: 'Deutsch' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳', nativeName: '中文' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵', nativeName: '日本語' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷', nativeName: '한국어' },
  { code: 'it', name: 'Italian', flag: '🇮🇹', nativeName: 'Italiano' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹', nativeName: 'Português' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺', nativeName: 'Русский' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦', nativeName: 'العربية' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳', nativeName: 'हिन्दी' }
];

export function LanguageSelector({ 
  currentLanguage, 
  onLanguageChange, 
  variant = 'default',
  className = ''
}: LanguageSelectorProps) {
  const currentLanguageData = languageOptions.find(lang => lang.code === currentLanguage) || languageOptions[0];

  const getSelectTriggerClass = () => {
    const baseClass = "bg-white/90 backdrop-blur-sm border-2 border-soft-teal/20 hover:border-soft-teal/40 transition-all duration-200 focus:border-soft-teal shadow-soft hover:shadow-medium";
    
    switch (variant) {
      case 'compact':
        return `w-[120px] ${baseClass}`;
      case 'mobile':
        return `w-full ${baseClass}`;
      default:
        return `w-[140px] ${baseClass}`;
    }
  };

  const renderTriggerContent = () => {
    switch (variant) {
      case 'compact':
        return (
          <div className="flex items-center gap-2">
            <span className="text-base">{currentLanguageData.flag}</span>
            <span className="text-sm font-medium text-deep-ocean">
              {currentLanguageData.code.toUpperCase()}
            </span>
          </div>
        );
      case 'mobile':
        return (
          <div className="flex items-center gap-3">
            <span className="text-lg">{currentLanguageData.flag}</span>
            <div className="flex flex-col items-start">
              <span className="font-medium text-deep-ocean">{currentLanguageData.name}</span>
              <span className="text-xs text-warm-slate">{currentLanguageData.nativeName}</span>
            </div>
          </div>
        );
      default:
        return (
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-soft-teal" />
            <span className="text-base font-medium">{currentLanguageData.flag}</span>
            <span className="text-sm font-medium text-deep-ocean hidden md:block">
              {currentLanguageData.code.toUpperCase()}
            </span>
          </div>
        );
    }
  };

  return (
    <div className={className}>
      {variant === 'mobile' && (
        <label className="block text-sm font-medium text-deep-ocean mb-2">
          🌐 Language / Idioma
        </label>
      )}
      
      <Select value={currentLanguage} onValueChange={onLanguageChange}>
        <SelectTrigger className={getSelectTriggerClass()}>
          {renderTriggerContent()}
        </SelectTrigger>
        <SelectContent className="bg-white/95 backdrop-blur-md border-2 border-soft-teal/20 shadow-deep max-h-[300px] overflow-y-auto">
          {languageOptions.map((language) => (
            <SelectItem 
              key={language.code} 
              value={language.code}
              className="cursor-pointer hover:bg-soft-teal/10 focus:bg-soft-teal/10 transition-all duration-200"
            >
              <div className="flex items-center gap-3 py-1">
                <span className="text-lg">{language.flag}</span>
                <div className="flex flex-col">
                  <span className="font-medium text-deep-ocean">{language.name}</span>
                  <span className="text-xs text-warm-slate">{language.nativeName}</span>
                </div>
                {language.code === currentLanguage && (
                  <div className="ml-auto w-2 h-2 bg-soft-teal rounded-full"></div>
                )}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

// Usage examples:
// <LanguageSelector currentLanguage="en" onLanguageChange={setLanguage} />
// <LanguageSelector currentLanguage="en" onLanguageChange={setLanguage} variant="compact" />
// <LanguageSelector currentLanguage="en" onLanguageChange={setLanguage} variant="mobile" />