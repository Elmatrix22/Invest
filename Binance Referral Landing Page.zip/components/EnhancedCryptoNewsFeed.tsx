import React, { useState, useEffect } from 'react';
import { Zap, TrendingUp, Clock, Eye, ExternalLink, Filter, Search, Bell, Star, Globe, AlertTriangle, CheckCircle, Flame, Award, BarChart3 } from 'lucide-react';

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  content: string;
  source: string;
  publishTime: string;
  category: 'breaking' | 'market' | 'regulation' | 'technology' | 'defi' | 'nft' | 'institutional' | 'analysis';
  impact: 'high' | 'medium' | 'low';
  sentiment: 'bullish' | 'bearish' | 'neutral';
  tags: string[];
  views: number;
  trending: boolean;
  verified: boolean;
  imageUrl: string;
  sourceUrl: string;
  priceImpact?: string;
  affectedCoins?: string[];
}

interface EnhancedCryptoNewsFeedProps {
  translations: any;
  binanceReferralUrl: string;
  user: any;
  onShowAuthModal: () => void;
  onRouteChange: (route: string) => void;
  marketData: any;
  isMarketDataReady: boolean;
}

export default function EnhancedCryptoNewsFeed({
  translations,
  binanceReferralUrl,
  user,
  onShowAuthModal,
  onRouteChange,
  marketData,
  isMarketDataReady
}: EnhancedCryptoNewsFeedProps) {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedImpact, setSelectedImpact] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  useEffect(() => {
    loadNews();
  }, []);

  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(loadNews, 60000); // Refresh every minute
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const loadNews = async () => {
    setIsLoading(true);
    // Simulate API call with latest news
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const latestNews = generateLatestNews();
    setNews(latestNews);
    setLastUpdate(new Date());
    setIsLoading(false);
  };

  const generateLatestNews = (): NewsItem[] => {
    const now = new Date();
    
    return [
      {
        id: 'btc-etf-inflow-record',
        title: '🚨 BREAKING: Bitcoin ETFs See Record $2.1B Single-Day Inflow',
        summary: 'BlackRock IBIT leads unprecedented institutional demand as Bitcoin surges past $48,000',
        content: `BlackRock's Bitcoin ETF (IBIT) recorded the largest single-day inflow in crypto ETF history with $1.2 billion, followed by Fidelity's FBTC at $600 million. This massive institutional influx has driven Bitcoin to break through key resistance levels, signaling potential continuation toward $50,000. Market analysts attribute the surge to renewed institutional confidence following regulatory clarity and increasing corporate treasury allocation to Bitcoin.`,
        source: 'CryptoPulse',
        publishTime: new Date(now.getTime() - 15 * 60 * 1000).toISOString(),
        category: 'breaking',
        impact: 'high',
        sentiment: 'bullish',
        tags: ['Bitcoin ETF', 'Institutional', 'BlackRock', 'Bull Market'],
        views: 45230,
        trending: true,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1518544866330-4e99499bb2b5?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '+8.5%',
        affectedCoins: ['BTC', 'ETH', 'SOL']
      },
      {
        id: 'solana-ecosystem-surge',
        title: 'Solana Ecosystem Explodes: SOL Hits $120 as DeFi TVL Crosses $5B',
        summary: 'Jupiter, Raydium, and Orca lead massive growth as Solana reclaims #4 crypto position',
        content: `Solana's price surge to $120 (+15% in 24h) coincides with Total Value Locked (TVL) reaching $5.1 billion across its DeFi ecosystem. Jupiter's JUP token launch and Raydium's concentrated liquidity upgrade have attracted significant capital. The network is processing over 2,000 TPS consistently with 99.98% uptime, demonstrating robust infrastructure improvements since the previous year's outages.`,
        source: 'DeFi Analytics',
        publishTime: new Date(now.getTime() - 45 * 60 * 1000).toISOString(),
        category: 'market',
        impact: 'high',
        sentiment: 'bullish',
        tags: ['Solana', 'DeFi', 'TVL', 'Jupiter', 'Performance'],
        views: 32150,
        trending: true,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '+15.2%',
        affectedCoins: ['SOL', 'JUP', 'RAY']
      },
      {
        id: 'ai-tokens-rally',
        title: 'AI Tokens Rally 300%+ as ChatGPT-5 Launch Approaches',
        summary: 'Render, Fetch.ai, and SingularityNET surge amid AI infrastructure demand',
        content: `Artificial Intelligence tokens are experiencing unprecedented gains with Render (RNDR) +340%, Fetch.ai (FET) +280%, and SingularityNET (AGIX) +250% in the past week. The rally is driven by OpenAI's upcoming ChatGPT-5 release and increasing demand for decentralized AI computation. Render Network is processing 50M+ GPU hours monthly, while Fetch.ai's autonomous agents ecosystem grows to 10,000+ active deployments.`,
        source: 'AI Crypto Report',
        publishTime: new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString(),
        category: 'technology',
        impact: 'high',
        sentiment: 'bullish',
        tags: ['AI Tokens', 'ChatGPT-5', 'Render', 'Machine Learning'],
        views: 28900,
        trending: true,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '+320%',
        affectedCoins: ['RNDR', 'FET', 'AGIX', 'TAO']
      },
      {
        id: 'sec-ethereum-staking',
        title: 'SEC Provides Clarity: Ethereum Staking Not Securities, ETF Path Opens',
        summary: 'Historic regulatory win removes major hurdle for Ethereum ETF approval',
        content: `The Securities and Exchange Commission issued formal guidance stating that Ethereum staking rewards do not constitute securities offerings, removing a significant regulatory barrier. This clarification paves the way for spot Ethereum ETF approvals, with applications from BlackRock, Fidelity, and Grayscale expected to advance rapidly. Legal experts consider this the most significant crypto regulatory development since Bitcoin ETF approval.`,
        source: 'Regulatory Watch',
        publishTime: new Date(now.getTime() - 4 * 60 * 60 * 1000).toISOString(),
        category: 'regulation',
        impact: 'high',
        sentiment: 'bullish',
        tags: ['SEC', 'Ethereum ETF', 'Staking', 'Regulation'],
        views: 41200,
        trending: true,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '+12.8%',
        affectedCoins: ['ETH', 'LDO', 'RPL']
      },
      {
        id: 'memecoins-marketcap',
        title: 'Memecoin Market Cap Hits $100B: DOGE, SHIB, PEPE Lead Charge',
        summary: 'Retail FOMO and social media hype drive unprecedented memecoin valuations',
        content: `The collective market capitalization of memecoins has reached $100 billion for the first time, led by Dogecoin ($18B), Shiba Inu ($15B), and Pepe ($8B). This milestone reflects massive retail participation and social media-driven speculation. New memecoins are launching daily with some achieving $1B+ valuations within hours, though analysts warn of extreme volatility and potential market corrections.`,
        source: 'Memecoin Tracker',
        publishTime: new Date(now.getTime() - 6 * 60 * 60 * 1000).toISOString(),
        category: 'market',
        impact: 'medium',
        sentiment: 'bullish',
        tags: ['Memecoins', 'DOGE', 'SHIB', 'PEPE', 'Retail'],
        views: 35800,
        trending: true,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '+150%',
        affectedCoins: ['DOGE', 'SHIB', 'PEPE', 'FLOKI']
      },
      {
        id: 'institutional-defi-adoption',
        title: 'JPMorgan Launches $2B DeFi Fund, Deutsche Bank Follows',
        summary: 'Traditional finance giants embrace decentralized protocols for yield generation',
        content: `JPMorgan announced a $2 billion institutional DeFi fund focusing on blue-chip protocols like Aave, Compound, and Uniswap. Deutsche Bank is launching a similar $1.5B initiative, marking mainstream adoption of decentralized finance by traditional banking. The funds will focus on stablecoin yield farming, DEX liquidity provision, and governance token investments with institutional-grade risk management.`,
        source: 'TradFi Crypto',
        publishTime: new Date(now.getTime() - 8 * 60 * 60 * 1000).toISOString(),
        category: 'institutional',
        impact: 'high',
        sentiment: 'bullish',
        tags: ['JPMorgan', 'Deutsche Bank', 'DeFi', 'Institutional'],
        views: 22400,
        trending: false,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '+8.2%',
        affectedCoins: ['AAVE', 'COMP', 'UNI', 'MKR']
      },
      {
        id: 'quantum-computing-threat',
        title: 'Google Quantum Breakthrough Sparks Crypto Security Concerns',
        summary: 'Willow chip advances raise questions about blockchain encryption vulnerabilities',
        content: `Google's new Willow quantum processor achieved significant breakthroughs in error correction, reigniting discussions about quantum computing threats to current cryptographic standards. While experts emphasize that practical quantum attacks on Bitcoin and Ethereum remain years away, the crypto community is accelerating research into quantum-resistant algorithms. Several blockchain projects are already implementing post-quantum cryptography solutions.`,
        source: 'Quantum Security News',
        publishTime: new Date(now.getTime() - 12 * 60 * 60 * 1000).toISOString(),
        category: 'technology',
        impact: 'medium',
        sentiment: 'neutral',
        tags: ['Quantum Computing', 'Security', 'Encryption', 'Google'],
        views: 18600,
        trending: false,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '-2.1%',
        affectedCoins: ['QRL', 'IOTA', 'ADA']
      },
      {
        id: 'layer2-scaling-race',
        title: 'Layer-2 Scaling Wars: Arbitrum vs Optimism vs Polygon Battle for Dominance',
        summary: 'Transaction volumes and TVL surge as Ethereum scaling solutions compete',
        content: `The Layer-2 scaling race intensifies with Arbitrum leading TVL at $3.2B, Optimism at $2.8B, and Polygon at $2.1B. Daily transaction volumes have increased 400% year-over-year as applications migrate from Ethereum mainnet. New features like Arbitrum Stylus (WASM support) and Optimism's Superchain architecture are differentiating platforms, while Polygon's zkEVM gains developer adoption.`,
        source: 'L2 Analytics',
        publishTime: new Date(now.getTime() - 18 * 60 * 60 * 1000).toISOString(),
        category: 'technology',
        impact: 'medium',
        sentiment: 'bullish',
        tags: ['Layer-2', 'Arbitrum', 'Optimism', 'Polygon', 'Scaling'],
        views: 16200,
        trending: false,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '+5.7%',
        affectedCoins: ['ARB', 'OP', 'MATIC']
      },
      {
        id: 'cbdc-global-rollout',
        title: 'Central Bank Digital Currencies: 15 Countries Launch CBDCs in December',
        summary: 'Global CBDC adoption accelerates with major economies going live',
        content: `Fifteen countries launched Central Bank Digital Currencies (CBDCs) in December 2024, including Brazil's Digital Real, Nigeria's eNaira expansion, and the EU's Digital Euro pilot. Over 130 countries are now exploring or implementing CBDCs, representing 98% of global GDP. While improving financial inclusion, CBDCs raise privacy concerns and competition questions for traditional cryptocurrencies.`,
        source: 'CBDC Watch',
        publishTime: new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString(),
        category: 'regulation',
        impact: 'medium',
        sentiment: 'neutral',
        tags: ['CBDC', 'Central Banks', 'Digital Currency', 'Regulation'],
        views: 14800,
        trending: false,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '-1.5%',
        affectedCoins: ['BTC', 'XMR', 'USDT']
      },
      {
        id: 'gaming-nft-recovery',
        title: 'Gaming NFTs Stage Comeback: Axie Infinity, The Sandbox Rally 200%+',
        summary: 'Play-to-earn tokens surge as gaming studios integrate blockchain technology',
        content: `Gaming NFTs are experiencing a remarkable recovery with Axie Infinity (AXS) +245%, The Sandbox (SAND) +198%, and Decentraland (MANA) +156% in December. The resurgence is driven by improved gameplay, sustainable tokenomics, and major gaming studios like Ubisoft and Square Enix launching blockchain games. Monthly active users across gaming NFT platforms have increased 300% year-over-year.`,
        source: 'GameFi News',
        publishTime: new Date(now.getTime() - 36 * 60 * 60 * 1000).toISOString(),
        category: 'nft',
        impact: 'medium',
        sentiment: 'bullish',
        tags: ['Gaming NFTs', 'Play-to-Earn', 'Axie Infinity', 'Metaverse'],
        views: 19300,
        trending: false,
        verified: true,
        imageUrl: 'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=800&h=600&fit=crop',
        sourceUrl: '#',
        priceImpact: '+220%',
        affectedCoins: ['AXS', 'SAND', 'MANA', 'ENJ']
      }
    ];
  };

  const filteredNews = news.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesImpact = selectedImpact === 'all' || item.impact === selectedImpact;
    const matchesSearch = searchQuery === '' || 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    return matchesCategory && matchesImpact && matchesSearch;
  });

  const categories = [
    { id: 'all', name: 'All News', icon: Globe },
    { id: 'breaking', name: 'Breaking', icon: Zap },
    { id: 'market', name: 'Market', icon: TrendingUp },
    { id: 'regulation', name: 'Regulation', icon: AlertTriangle },
    { id: 'technology', name: 'Technology', icon: CheckCircle },
    { id: 'defi', name: 'DeFi', icon: BarChart3 },
    { id: 'institutional', name: 'Institutional', icon: Award },
    { id: 'nft', name: 'NFT', icon: Star }
  ];

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-danger-coral bg-danger-coral/10 border-danger-coral/20';
      case 'medium': return 'text-warning-amber bg-warning-amber/10 border-warning-amber/20';
      case 'low': return 'text-success-green bg-success-green/10 border-success-green/20';
      default: return 'text-warm-slate bg-warm-slate/10 border-warm-slate/20';
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'bullish': return 'text-success-green';
      case 'bearish': return 'text-danger-coral';
      case 'neutral': return 'text-warm-slate';
      default: return 'text-warm-slate';
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      breaking: 'text-danger-coral bg-danger-coral/10',
      market: 'text-soft-teal bg-soft-teal/10',
      regulation: 'text-warning-amber bg-warning-amber/10',
      technology: 'text-subtle-lavender bg-subtle-lavender/10',
      defi: 'text-success-green bg-success-green/10',
      institutional: 'text-deep-ocean bg-deep-ocean/10',
      nft: 'text-soft-mint bg-soft-mint/10',
      analysis: 'text-charcoal bg-charcoal/10'
    };
    return colors[category] || 'text-warm-slate bg-warm-slate/10';
  };

  return (
    <div className="space-y-6">
      {/* Enhanced Header */}
      <div className="page-header">
        <div className="page-badge">
          🔥 Live Crypto News December 2024
        </div>
        <h1 className="page-title">
          Breaking Crypto News & Market Updates
        </h1>
        <p className="page-subtitle">
          Real-time cryptocurrency news, market analysis, and breaking developments. Stay informed with verified sources and instant updates.
        </p>
      </div>

      {/* Live Update Banner */}
      <div className="ai-signal-section">
        <div className="ai-signal-content">
          <div className="ai-signal-header">
            <div className="ai-signal-icon">
              <Bell className="w-6 h-6 text-pearl-white" />
            </div>
            <div>
              <h2 className="ai-signal-title">
                🚨 Live Market Feed
              </h2>
              <p className="ai-signal-subtitle">
                Last updated: {lastUpdate.toLocaleTimeString()} • Auto-refresh {autoRefresh ? 'ON' : 'OFF'}
              </p>
            </div>
          </div>
          
          <div className="ai-signal-controls">
            <div className="ai-signal-status">
              <div className="ai-status-indicator"></div>
              <span>Live News Feed Active</span>
            </div>
            
            <button
              onClick={loadNews}
              disabled={isLoading}
              className="ai-button-primary"
            >
              {isLoading ? 'Updating...' : 'Refresh News'}
            </button>
            
            <button
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`ai-button-secondary ${autoRefresh ? 'bg-success-green text-pearl-white' : ''}`}
            >
              Auto-Refresh {autoRefresh ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="page-section">
        <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between mb-6">
          <div className="flex flex-wrap gap-2">
            {categories.map(category => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg font-medium transition-all text-sm ${
                    selectedCategory === category.id
                      ? 'bg-soft-teal text-pearl-white'
                      : 'bg-pearl-gray text-charcoal hover:bg-soft-teal/10'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {category.name}
                </button>
              );
            })}
          </div>
          
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-warm-slate" />
              <input
                type="text"
                placeholder="Search news..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 border border-warm-slate/20 rounded-lg bg-pearl-white text-charcoal placeholder-warm-slate focus:outline-none focus:border-soft-teal"
              />
            </div>
            
            <select
              value={selectedImpact}
              onChange={(e) => setSelectedImpact(e.target.value)}
              className="form-input text-deep-navy"
            >
              <option value="all">All Impact</option>
              <option value="high">High Impact</option>
              <option value="medium">Medium Impact</option>
              <option value="low">Low Impact</option>
            </select>
          </div>
        </div>

        {/* News Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-soft-teal">{filteredNews.length}</div>
            <div className="text-sm text-warm-slate">Total News</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-danger-coral">{filteredNews.filter(n => n.category === 'breaking').length}</div>
            <div className="text-sm text-warm-slate">Breaking</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-warning-amber">{filteredNews.filter(n => n.trending).length}</div>
            <div className="text-sm text-warm-slate">Trending</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-success-green">{filteredNews.filter(n => n.verified).length}</div>
            <div className="text-sm text-warm-slate">Verified</div>
          </div>
        </div>
      </div>

      {/* News Feed */}
      {isLoading ? (
        <div className="page-section text-center py-12">
          <div className="w-8 h-8 border-2 border-soft-teal border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-warm-slate">Loading latest crypto news...</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredNews.map((item, index) => (
            <div key={item.id} className={`card-modern p-6 ${item.trending ? 'border-l-4 border-l-warning-amber' : ''}`}>
              <div className="flex flex-col lg:flex-row gap-4">
                {/* Image */}
                <div className="lg:w-48 flex-shrink-0">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-32 lg:h-24 object-cover rounded-lg"
                  />
                </div>
                
                {/* Content */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`px-2 py-1 rounded text-xs font-bold ${getCategoryColor(item.category)}`}>
                        {item.category.toUpperCase()}
                      </span>
                      
                      <span className={`px-2 py-1 rounded border text-xs font-medium ${getImpactColor(item.impact)}`}>
                        {item.impact.toUpperCase()} IMPACT
                      </span>
                      
                      {item.trending && (
                        <span className="flex items-center gap-1 px-2 py-1 rounded bg-warning-amber text-pearl-white text-xs font-bold">
                          <Flame className="w-3 h-3" />
                          TRENDING
                        </span>
                      )}
                      
                      {item.verified && (
                        <span className="flex items-center gap-1 px-2 py-1 rounded bg-success-green text-pearl-white text-xs font-bold">
                          <CheckCircle className="w-3 h-3" />
                          VERIFIED
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2 text-xs text-warm-slate">
                      <Clock className="w-3 h-3" />
                      {new Date(item.publishTime).toLocaleTimeString()}
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-bold text-deep-ocean mb-2 hover:text-soft-teal transition-colors cursor-pointer">
                    {item.title}
                  </h3>
                  
                  <p className="text-warm-slate mb-3 line-clamp-2">
                    {item.summary}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <span className="font-medium">{item.source}</span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {(item.views / 1000).toFixed(1)}K views
                      </div>
                      
                      {item.priceImpact && (
                        <div className={`flex items-center gap-1 font-bold ${getSentimentColor(item.sentiment)}`}>
                          {item.sentiment === 'bullish' ? '📈' : item.sentiment === 'bearish' ? '📉' : '📊'}
                          {item.priceImpact}
                        </div>
                      )}
                    </div>
                    
                    <button
                      onClick={() => window.open(item.sourceUrl, '_blank')}
                      className="flex items-center gap-1 text-soft-teal hover:text-soft-teal-dark transition-colors text-sm font-medium"
                    >
                      Read More
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                  
                  {/* Affected Coins */}
                  {item.affectedCoins && item.affectedCoins.length > 0 && (
                    <div className="flex items-center gap-2 mt-3 pt-3 border-t border-warm-slate/10">
                      <span className="text-xs font-medium text-warm-slate">Affected:</span>
                      <div className="flex flex-wrap gap-1">
                        {item.affectedCoins.map((coin, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-soft-teal/10 text-soft-teal text-xs font-bold rounded"
                          >
                            {coin}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Tags */}
                  {item.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-3">
                      {item.tags.slice(0, 4).map((tag, idx) => (
                        <span
                          key={idx}
                          className="text-xs bg-pearl-gray text-charcoal px-2 py-1 rounded hover:bg-warm-slate/10 transition-colors"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Premium News CTA */}
      {!user && (
        <div className="page-section text-center">
          <h3 className="text-2xl font-bold text-deep-ocean mb-4">
            Get Premium News Alerts
          </h3>
          <p className="text-warm-slate mb-6 max-w-2xl mx-auto">
            Receive instant notifications for market-moving news, exclusive analysis, and early access to breaking developments.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={onShowAuthModal}
              className="btn-teal text-lg px-8 py-4 shadow-glow hover:shadow-deep transition-all duration-300 transform hover:scale-105"
            >
              <Bell className="w-5 h-5" />
              Enable News Alerts
            </button>
            <button
              onClick={() => window.open(binanceReferralUrl, '_blank')}
              className="btn-primary text-lg px-8 py-4"
            >
              <TrendingUp className="w-5 h-5" />
              Trade the News
            </button>
          </div>
        </div>
      )}
    </div>
  );
}