import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { 
  Mail, 
  MessageCircle, 
  Clock, 
  MapPin, 
  Phone, 
  Send,
  CheckCircle,
  ExternalLink,
  Brain,
  Users,
  Shield,
  Headphones,
  Globe,
  Zap
} from 'lucide-react';

interface ContactPageProps {
  translations: any;
  binanceReferralUrl: string;
}

export function ContactPage({ translations, binanceReferralUrl }: ContactPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    category: 'general'
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const contactMethods = [
    {
      icon: MessageCircle,
      title: 'Live Chat Support',
      description: 'Get instant help from our AI chat assistant',
      action: 'Available 24/7',
      color: 'bg-old-money-sage'
    },
    {
      icon: Mail,
      title: 'Email Support',
      description: 'Send us detailed questions or feedback',
      action: 'support@invest-free.com',
      color: 'bg-old-money-navy'
    },
    {
      icon: Users,
      title: 'Community Forum',
      description: 'Connect with 125,000+ fellow traders',
      action: 'Join Discussion',
      color: 'bg-old-money-burgundy'
    },
    {
      icon: Brain,
      title: 'AI Assistant',
      description: 'Get instant answers about trading signals',
      action: 'Ask AI Now',
      color: 'bg-old-money-gold'
    }
  ];

  const faqItems = [
    {
      question: 'How do I get the $100 Binance bonus?',
      answer: 'Register for free on our platform, then click any "Trade on Binance" button to claim your exclusive $100 bonus. The bonus is automatically credited to your Binance account.'
    },
    {
      question: 'Are the trading signals really free?',
      answer: 'Yes! All our AI trading signals are 100% free forever. No hidden fees, no subscription costs. We make money through our Binance partnership when you trade.'
    },
    {
      question: 'How accurate are your AI signals?',
      answer: 'Our current success rate is 84% across all asset classes. We track all signal performance transparently and continuously improve our AI algorithms.'
    },
    {
      question: 'Can I use the signals with other brokers?',
      answer: 'Absolutely! While we recommend Binance for the best experience and bonus, you can use our signals with any broker or exchange you prefer.'
    },
    {
      question: 'How do I submit a business investment idea?',
      answer: 'Visit the Business Ideas section and click "Share Your Project." Fill out the form with your project details, upload media, and submit for review.'
    }
  ];

  const supportHours = [
    { day: 'Monday - Friday', hours: '24/7 AI Support + Live Chat' },
    { day: 'Weekend', hours: '24/7 AI Support' },
    { day: 'Holidays', hours: '24/7 AI Support' }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-old-money-navy">Contact Us</h1>
        <p className="text-xl text-old-money-warm-gray max-w-2xl mx-auto">
          Need help with trading signals, business ideas, or your $100 bonus? 
          We're here to help 24/7 with multiple support channels.
        </p>
        <Badge className="bg-old-money-sage text-old-money-cream">
          <Headphones className="w-4 h-4 mr-2" />
          24/7 AI Support Available
        </Badge>
      </div>

      {/* Contact Methods */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {contactMethods.map((method, index) => (
          <Card key={index} className="border-old-money-beige hover:shadow-lg transition-all cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className={`w-16 h-16 ${method.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <method.icon className="w-8 h-8 text-old-money-cream" />
              </div>
              <h3 className="font-bold text-old-money-navy mb-2">{method.title}</h3>
              <p className="text-old-money-warm-gray text-sm mb-3">{method.description}</p>
              <Badge variant="outline" className="text-xs border-old-money-warm-gray">
                {method.action}
              </Badge>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Contact Form */}
        <Card className="border-old-money-beige">
          <CardHeader>
            <CardTitle className="text-old-money-navy flex items-center gap-2">
              <Send className="w-5 h-5" />
              Send Us a Message
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isSubmitted ? (
              <div className="text-center py-8">
                <CheckCircle className="w-16 h-16 text-old-money-sage mx-auto mb-4" />
                <h3 className="text-xl font-bold text-old-money-sage mb-2">Message Sent!</h3>
                <p className="text-old-money-warm-gray">
                  Thanks for contacting us. We'll get back to you within 24 hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-old-money-navy mb-2">Name</label>
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      placeholder="Your full name"
                      required
                      className="border-old-money-warm-gray"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-old-money-navy mb-2">Email</label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      placeholder="your@email.com"
                      required
                      className="border-old-money-warm-gray"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-old-money-navy mb-2">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({...formData, category: e.target.value})}
                    className="w-full p-3 border border-old-money-warm-gray rounded-md bg-white"
                  >
                    <option value="general">General Inquiry</option>
                    <option value="signals">Trading Signals</option>
                    <option value="bonus">$100 Binance Bonus</option>
                    <option value="business">Business Ideas</option>
                    <option value="technical">Technical Support</option>
                    <option value="partnership">Partnership</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-old-money-navy mb-2">Subject</label>
                  <Input
                    value={formData.subject}
                    onChange={(e) => setFormData({...formData, subject: e.target.value})}
                    placeholder="Brief description of your inquiry"
                    required
                    className="border-old-money-warm-gray"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-old-money-navy mb-2">Message</label>
                  <Textarea
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    placeholder="Please provide details about your question or issue..."
                    required
                    className="border-old-money-warm-gray min-h-[120px]"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-old-money-burgundy hover:bg-old-money-burgundy-light text-old-money-cream"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Send Message
                </Button>
              </form>
            )}
          </CardContent>
        </Card>

        {/* Support Info & FAQ */}
        <div className="space-y-6">
          {/* Support Hours */}
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="text-old-money-navy flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Support Hours
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {supportHours.map((item, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-old-money-navy font-medium">{item.day}</span>
                    <span className="text-old-money-sage text-sm">{item.hours}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 bg-old-money-sage/10 rounded-lg">
                <p className="text-sm text-old-money-navy">
                  <Shield className="w-4 h-4 inline mr-1" />
                  Our AI assistant is available 24/7 for instant help with common questions.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Quick FAQ */}
          <Card className="border-old-money-beige">
            <CardHeader>
              <CardTitle className="text-old-money-navy">Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {faqItems.slice(0, 3).map((item, index) => (
                  <div key={index} className="border-b border-old-money-beige pb-3 last:border-b-0">
                    <h4 className="font-medium text-old-money-navy mb-2">{item.question}</h4>
                    <p className="text-old-money-warm-gray text-sm">{item.answer}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Office Info */}
      <Card className="bg-old-money-navy text-old-money-cream">
        <CardContent className="p-8">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <MapPin className="w-8 h-8 text-old-money-gold mx-auto mb-4" />
              <h3 className="font-bold mb-2">Global Headquarters</h3>
              <p className="text-old-money-cream/80">
                Singapore Financial District<br />
                Serving 150+ Countries Worldwide
              </p>
            </div>
            <div>
              <Globe className="w-8 h-8 text-old-money-sage mx-auto mb-4" />
              <h3 className="font-bold mb-2">24/7 Operations</h3>
              <p className="text-old-money-cream/80">
                Our AI systems monitor markets<br />
                around the clock for opportunities
              </p>
            </div>
            <div>
              <Zap className="w-8 h-8 text-old-money-gold mx-auto mb-4" />
              <h3 className="font-bold mb-2">Instant Response</h3>
              <p className="text-old-money-cream/80">
                Average response time: 2 hours<br />
                AI assistance: Immediate
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* CTA Section */}
      <Card className="bg-gradient-to-r from-old-money-gold/10 to-old-money-sage/10 border-old-money-gold">
        <CardContent className="p-8 text-center">
          <h2 className="text-2xl font-bold text-old-money-navy mb-4">
            Need Immediate Help?
          </h2>
          <p className="text-old-money-warm-gray mb-6">
            Don't wait! Our AI chat assistant can help you right now with trading questions, 
            signal explanations, and bonus claims.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Chat with AI Assistant
            </Button>
            <Button
              size="lg"
              onClick={handleBinanceClick}
              className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy"
            >
              <ExternalLink className="w-5 h-5 mr-2" />
              Claim $100 Bonus
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}