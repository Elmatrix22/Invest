import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { User, Clock, Calendar, Eye, Share2, ArrowRight } from 'lucide-react';
import { BlogArticle } from '../utils/blogData';

interface BlogArticleCardProps {
  article: BlogArticle;
  onReadMore: (article: BlogArticle) => void;
  onShare: (article: BlogArticle) => void;
  featured?: boolean;
}

export function BlogArticleCard({ article, onReadMore, onShare, featured = false }: BlogArticleCardProps) {
  return (
    <Card className="border-old-money-beige hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between mb-2">
          <Badge 
            className={featured 
              ? "bg-old-money-navy text-old-money-cream text-xs" 
              : "bg-old-money-cream-dark text-old-money-warm-gray border border-old-money-warm-gray text-xs"
            }
            variant={featured ? "default" : "outline"}
          >
            {article.category}
          </Badge>
          <div className="flex items-center gap-1 text-xs text-old-money-warm-gray">
            <Eye className="w-3 h-3" />
            {article.views.toLocaleString()}
          </div>
        </div>
        <CardTitle 
          className={`${featured ? 'text-lg' : 'text-base'} leading-tight hover:text-old-money-sage transition-colors cursor-pointer`}
          onClick={() => onReadMore(article)}
        >
          {article.title}
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <p className="text-old-money-warm-gray text-sm mb-4 line-clamp-3">
          {article.excerpt}
        </p>
        
        <div className="flex items-center justify-between text-xs text-old-money-warm-gray mb-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <User className="w-3 h-3" />
              {article.author}
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {article.readTime}
            </div>
          </div>
          {featured && (
            <div className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {new Date(article.publishDate).toLocaleDateString()}
            </div>
          )}
        </div>
        
        {!featured && (
          <div className="flex flex-wrap gap-1 mb-4">
            {article.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} className="bg-old-money-cream-dark text-old-money-warm-gray text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        )}
        
        <div className="flex items-center justify-between">
          <Button
            size="sm"
            onClick={() => onReadMore(article)}
            className={`bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream ${featured ? 'flex-1 mr-2' : 'flex-1 mr-2'}`}
          >
            {featured ? (
              <>
                <ArrowRight className="w-4 h-4 mr-1" />
                Read More
              </>
            ) : (
              'Read Article'
            )}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onShare(article)}
            className="border-old-money-warm-gray text-old-money-warm-gray hover:bg-old-money-cream-dark"
          >
            <Share2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}