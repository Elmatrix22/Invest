import { Card, CardContent } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Star, Quote } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface TestimonialsSectionProps {
  translations: any;
}

export function TestimonialsSection({ translations }: TestimonialsSectionProps) {
  const testimonials = [
    {
      name: "Sarah Chen",
      location: "San Francisco, USA",
      role: "Software Engineer",
      content: "Invest-Free.com changed my financial future. The platform is incredibly user-friendly and the educational resources helped me make smart investment decisions.",
      rating: 5,
      avatar: "SC",
      verified: true
    },
    {
      name: "Muhammad Al-Rashid",
      location: "Dubai, UAE", 
      role: "Business Owner",
      content: "As a busy entrepreneur, I needed a platform that was simple yet powerful. The mobile app allows me to manage my investments anywhere.",
      rating: 5,
      avatar: "MR",
      verified: true
    },
    {
      name: "Maria Rodriguez",
      location: "Madrid, Spain",
      role: "Teacher",
      content: "I started with just $100 and the free education helped me grow my portfolio significantly. The zero commission fees make a real difference.",
      rating: 5,
      avatar: "MR",
      verified: true
    },
    {
      name: "David Thompson",
      location: "London, UK",
      role: "Financial Analyst",
      content: "The advanced analytics tools are outstanding. Even as a professional, I find the platform's features comprehensive and well-designed.",
      rating: 5,
      avatar: "DT",
      verified: true
    },
    {
      name: "Yuki Tanaka",
      location: "Tokyo, Japan",
      role: "Student",
      content: "Perfect for beginners! The step-by-step guidance and $100 bonus helped me start investing while still in university.",
      rating: 5,
      avatar: "YT",
      verified: true
    },
    {
      name: "Roberto Silva",
      location: "São Paulo, Brazil",
      role: "Marketing Manager",
      content: "The multi-language support and 24/7 customer service impressed me. They truly care about their international users.",
      rating: 5,
      avatar: "RS",
      verified: true
    }
  ];

  const achievements = [
    { metric: "4.9/5", label: "App Store Rating" },
    { metric: "50,000+", label: "5-Star Reviews" },
    { metric: "99.1%", label: "Customer Satisfaction" },
    { metric: "2M+", label: "Success Stories" }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl text-gray-900">
            {translations.testimonialsTitle || "What Our Users Say"}
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {translations.testimonialsSubtitle || "Join thousands of satisfied investors"}
          </p>
        </div>

        {/* Achievement Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {achievements.map((achievement, index) => (
            <div key={index} className="text-center">
              <div className="text-2xl font-bold text-amber-600 mb-1">{achievement.metric}</div>
              <div className="text-sm text-gray-600">{achievement.label}</div>
            </div>
          ))}
        </div>

        {/* Testimonials Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300 border-0 bg-gray-50">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Quote className="w-5 h-5 text-amber-500" />
                    <div className="flex items-center gap-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                  </div>
                  
                  <p className="text-gray-700 leading-relaxed">
                    "{testimonial.content}"
                  </p>
                  
                  <div className="flex items-center gap-3 pt-4 border-t border-gray-200">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src="" alt={testimonial.name} />
                      <AvatarFallback className="bg-amber-100 text-amber-700">
                        {testimonial.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <div className="font-medium text-gray-900">{testimonial.name}</div>
                        {testimonial.verified && (
                          <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                            Verified
                          </Badge>
                        )}
                      </div>
                      <div className="text-sm text-gray-600">{testimonial.role}</div>
                      <div className="text-xs text-gray-500">{testimonial.location}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl p-8">
            <h3 className="text-xl mb-4 text-gray-900">Trusted by Financial Experts</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center opacity-60">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?q=80&w=200"
                alt="TechCrunch"
                className="h-8 object-contain mx-auto filter grayscale"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?q=80&w=200"
                alt="Forbes"
                className="h-8 object-contain mx-auto filter grayscale"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?q=80&w=200"
                alt="Wall Street Journal"
                className="h-8 object-contain mx-auto filter grayscale"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?q=80&w=200"
                alt="Reuters"
                className="h-8 object-contain mx-auto filter grayscale"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}