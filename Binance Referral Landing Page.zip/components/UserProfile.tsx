import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Progress } from './ui/progress';
import { Switch } from './ui/switch';
import { Textarea } from './ui/textarea';
import { 
  User, 
  Settings, 
  TrendingUp, 
  Gift, 
  Share2, 
  Crown, 
  Star,
  Copy,
  Check,
  Bell,
  Eye,
  Shield,
  Wallet,
  Award,
  Target,
  Users,
  MessageCircle,
  Heart,
  Edit,
  ExternalLink
} from 'lucide-react';

interface UserProfileProps {
  user: any;
  onUpdateUser: (user: any) => void;
  onClose: () => void;
  translations: any;
  binanceReferralUrl: string;
}

function UserProfile({ user, onUpdateUser, onClose, translations, binanceReferralUrl }: UserProfileProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isEditing, setIsEditing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [profileForm, setProfileForm] = useState({
    username: user.username,
    bio: user.bio || '',
    favoriteCoins: user.favoriteCoins || ['BTC', 'ETH'],
    tradingExperience: user.tradingExperience || 'intermediate',
    notifications: {
      email: true,
      push: true,
      marketing: false,
      priceAlerts: true
    },
    privacy: {
      showStats: true,
      showPosts: true,
      allowMessages: true
    }
  });

  const handleCopyReferral = () => {
    navigator.clipboard.writeText(`https://invest-free.com/ref/${user.referralCode}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const handleSaveProfile = () => {
    const updatedUser = {
      ...user,
      ...profileForm,
      lastUpdated: new Date().toISOString()
    };
    onUpdateUser(updatedUser);
    setIsEditing(false);
  };

  const achievementProgress = Math.min((user.totalPosts || 0) / 10 * 100, 100);
  const nextRankProgress = Math.min((user.successfulPredictions || 0) / 50 * 100, 100);

  const recentActivity = [
    { type: 'post', content: 'Shared BTC prediction', timestamp: '2 hours ago', likes: 15 },
    { type: 'like', content: 'Liked ETH analysis by CryptoExpert', timestamp: '4 hours ago' },
    { type: 'comment', content: 'Commented on SOL discussion', timestamp: '6 hours ago', replies: 3 },
    { type: 'achievement', content: 'Earned "Active Trader" badge', timestamp: '1 day ago' }
  ];

  const myPosts = [
    {
      id: 1,
      coin: 'Bitcoin',
      symbol: 'BTC',
      prediction: 'Bullish',
      target: '$120,000',
      accuracy: 85,
      likes: 47,
      comments: 12,
      timestamp: '2 days ago'
    },
    {
      id: 2,
      coin: 'Ethereum',
      symbol: 'ETH', 
      prediction: 'Bullish',
      target: '$6,500',
      accuracy: 72,
      likes: 34,
      comments: 8,
      timestamp: '5 days ago'
    }
  ];

  const referralStats = {
    totalReferrals: 23,
    activeReferrals: 18,
    totalEarned: 2300,
    thisMonth: 450
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden border-old-money-beige">
        <div className="flex items-center justify-between p-6 border-b border-old-money-beige">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16">
              <AvatarFallback className="bg-old-money-sage-light text-old-money-navy text-xl">
                {user.avatar}
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2 text-old-money-navy">
                {user.username}
                {user.isVip && <Crown className="w-5 h-5 text-old-money-gold" />}
                {user.isExpert && <Star className="w-5 h-5 text-old-money-burgundy" />}
              </h2>
              <p className="text-old-money-warm-gray">{user.rank}</p>
              <Badge className="bg-old-money-sage text-old-money-cream mt-1">
                <Gift className="w-3 h-3 mr-1" />
                ${user.bonusAmount} Available
              </Badge>
            </div>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={handleBinanceClick}
              className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Trade on Binance
            </Button>
            <Button variant="outline" onClick={onClose} className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark">
              Close
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5 mx-6 mt-4 bg-old-money-cream-dark border border-old-money-beige">
              <TabsTrigger value="dashboard" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">Dashboard</TabsTrigger>
              <TabsTrigger value="posts" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">My Posts</TabsTrigger>
              <TabsTrigger value="referrals" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">Referrals</TabsTrigger>
              <TabsTrigger value="achievements" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">Achievements</TabsTrigger>
              <TabsTrigger value="settings" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">Settings</TabsTrigger>
            </TabsList>

            <div className="p-6">
              <TabsContent value="dashboard" className="space-y-6">
                {/* Stats Overview */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card className="border-old-money-beige">
                    <CardContent className="p-4 text-center">
                      <MessageCircle className="w-8 h-8 text-old-money-navy mx-auto mb-2" />
                      <div className="text-2xl font-bold text-old-money-navy">{user.totalPosts || 0}</div>
                      <div className="text-sm text-old-money-warm-gray">Posts Shared</div>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-old-money-beige">
                    <CardContent className="p-4 text-center">
                      <Heart className="w-8 h-8 text-old-money-burgundy mx-auto mb-2" />
                      <div className="text-2xl font-bold text-old-money-navy">{user.totalLikes || 0}</div>
                      <div className="text-sm text-old-money-warm-gray">Likes Received</div>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-old-money-beige">
                    <CardContent className="p-4 text-center">
                      <Target className="w-8 h-8 text-old-money-sage mx-auto mb-2" />
                      <div className="text-2xl font-bold text-old-money-navy">{user.successfulPredictions || 0}</div>
                      <div className="text-sm text-old-money-warm-gray">Successful Calls</div>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-old-money-beige">
                    <CardContent className="p-4 text-center">
                      <Users className="w-8 h-8 text-old-money-charcoal mx-auto mb-2" />
                      <div className="text-2xl font-bold text-old-money-navy">{referralStats.totalReferrals}</div>
                      <div className="text-sm text-old-money-warm-gray">Referrals</div>
                    </CardContent>
                  </Card>
                </div>

                {/* Binance Trading Card */}
                <Card className="bg-gradient-to-r from-old-money-gold/10 to-old-money-gold-light/10 border-old-money-gold/30">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-old-money-gold rounded-full flex items-center justify-center">
                          <span className="text-old-money-navy font-bold text-lg">B</span>
                        </div>
                        <div>
                          <h3 className="font-bold text-old-money-navy">Ready to Execute Your Ideas?</h3>
                          <p className="text-old-money-warm-gray text-sm">
                            Start trading on Binance with your investment strategies
                          </p>
                        </div>
                      </div>
                      <Button 
                        onClick={handleBinanceClick}
                        className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy font-medium"
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Open Binance
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Progress Cards */}
                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="border-old-money-beige">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-old-money-navy">
                        <Award className="w-5 h-5 text-old-money-gold" />
                        Next Achievement
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-old-money-navy">Active Contributor</span>
                          <span className="text-old-money-warm-gray">{user.totalPosts || 0}/10 posts</span>
                        </div>
                        <Progress value={achievementProgress} className="h-2" />
                        <p className="text-xs text-old-money-warm-gray">
                          Share {10 - (user.totalPosts || 0)} more posts to unlock this achievement
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-old-money-beige">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-old-money-navy">
                        <Crown className="w-5 h-5 text-old-money-burgundy" />
                        Rank Progress
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-old-money-navy">Pro Trader</span>
                          <span className="text-old-money-warm-gray">{user.successfulPredictions || 0}/50 accurate calls</span>
                        </div>
                        <Progress value={nextRankProgress} className="h-2" />
                        <p className="text-xs text-old-money-warm-gray">
                          {50 - (user.successfulPredictions || 0)} more accurate predictions to rank up
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Recent Activity */}
                <Card className="border-old-money-beige">
                  <CardHeader>
                    <CardTitle className="text-old-money-navy">Recent Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentActivity.map((activity, index) => (
                        <div key={index} className="flex items-center gap-3 p-3 bg-old-money-cream-dark rounded-lg">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            activity.type === 'post' ? 'bg-old-money-navy/10 text-old-money-navy' :
                            activity.type === 'like' ? 'bg-old-money-burgundy/10 text-old-money-burgundy' :
                            activity.type === 'comment' ? 'bg-old-money-sage/10 text-old-money-sage' :
                            'bg-old-money-gold/10 text-old-money-gold'
                          }`}>
                            {activity.type === 'post' && <MessageCircle className="w-4 h-4" />}
                            {activity.type === 'like' && <Heart className="w-4 h-4" />}
                            {activity.type === 'comment' && <MessageCircle className="w-4 h-4" />}
                            {activity.type === 'achievement' && <Award className="w-4 h-4" />}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-old-money-navy">{activity.content}</p>
                            <p className="text-xs text-old-money-warm-gray">{activity.timestamp}</p>
                          </div>
                          {activity.likes && (
                            <Badge variant="outline" className="border-old-money-warm-gray text-old-money-warm-gray">{activity.likes} likes</Badge>
                          )}
                          {activity.replies && (
                            <Badge variant="outline" className="border-old-money-warm-gray text-old-money-warm-gray">{activity.replies} replies</Badge>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="posts" className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-old-money-navy">My Investment Ideas</h3>
                  <Button className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Share New Idea
                  </Button>
                </div>

                <div className="space-y-4">
                  {myPosts.map((post) => (
                    <Card key={post.id} className="border-old-money-beige">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-old-money-gold rounded-full flex items-center justify-center">
                              <span className="text-old-money-navy text-sm font-bold">{post.symbol}</span>
                            </div>
                            <div>
                              <h4 className="font-medium text-old-money-navy">{post.coin}</h4>
                              <p className="text-sm text-old-money-warm-gray">{post.timestamp}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={`${
                              post.prediction === 'Bullish' ? 'bg-old-money-sage text-old-money-cream' : 'bg-old-money-burgundy text-old-money-cream'
                            }`}>
                              {post.prediction}
                            </Badge>
                            <Button variant="ghost" size="sm" className="text-old-money-warm-gray hover:text-old-money-navy">
                              <Edit className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                          <div>
                            <p className="text-sm text-old-money-warm-gray">Target</p>
                            <p className="font-medium text-old-money-navy">{post.target}</p>
                          </div>
                          <div>
                            <p className="text-sm text-old-money-warm-gray">Accuracy</p>
                            <p className="font-medium text-old-money-sage">{post.accuracy}%</p>
                          </div>
                          <div>
                            <p className="text-sm text-old-money-warm-gray">Likes</p>
                            <p className="font-medium text-old-money-navy">{post.likes}</p>
                          </div>
                          <div>
                            <p className="text-sm text-old-money-warm-gray">Comments</p>
                            <p className="font-medium text-old-money-navy">{post.comments}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="referrals" className="space-y-6">
                <Card className="border-old-money-beige">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-old-money-navy">
                      <Share2 className="w-5 h-5 text-old-money-sage" />
                      Referral Program
                    </CardTitle>
                    <CardDescription className="text-old-money-warm-gray">
                      Earn $50 for each friend who joins and gets their $100 bonus
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="bg-old-money-sage/10 border border-old-money-sage/30 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-old-money-navy">Your Referral Link</p>
                          <p className="text-sm text-old-money-warm-gray font-mono break-all">
                            https://invest-free.com/ref/{user.referralCode}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          onClick={handleCopyReferral}
                          className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
                        >
                          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-old-money-cream-dark rounded-lg">
                        <div className="text-2xl font-bold text-old-money-sage">{referralStats.totalReferrals}</div>
                        <div className="text-sm text-old-money-warm-gray">Total Referrals</div>
                      </div>
                      <div className="text-center p-4 bg-old-money-cream-dark rounded-lg">
                        <div className="text-2xl font-bold text-old-money-navy">{referralStats.activeReferrals}</div>
                        <div className="text-sm text-old-money-warm-gray">Active Members</div>
                      </div>
                      <div className="text-center p-4 bg-old-money-cream-dark rounded-lg">
                        <div className="text-2xl font-bold text-old-money-burgundy">${referralStats.totalEarned}</div>
                        <div className="text-sm text-old-money-warm-gray">Total Earned</div>
                      </div>
                      <div className="text-center p-4 bg-old-money-cream-dark rounded-lg">
                        <div className="text-2xl font-bold text-old-money-gold">${referralStats.thisMonth}</div>
                        <div className="text-sm text-old-money-warm-gray">This Month</div>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <Button className="flex-1 bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream">
                        <Share2 className="w-4 h-4 mr-2" />
                        Share on Social
                      </Button>
                      <Button variant="outline" className="flex-1 border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark">
                        <Wallet className="w-4 h-4 mr-2" />
                        Withdraw Earnings
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="achievements" className="space-y-6">
                <div className="grid gap-4">
                  <Card className="bg-gradient-to-r from-old-money-sage/10 to-old-money-sage-light/10 border-old-money-sage/30">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-old-money-sage rounded-full flex items-center justify-center">
                          <Gift className="w-6 h-6 text-old-money-cream" />
                        </div>
                        <div>
                          <h4 className="font-medium text-old-money-navy">Welcome Bonus Claimed</h4>
                          <p className="text-sm text-old-money-warm-gray">Successfully claimed your $100 welcome bonus</p>
                          <Badge className="mt-1 bg-old-money-sage text-old-money-cream">Completed</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-old-money-beige">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-old-money-warm-gray/20 rounded-full flex items-center justify-center">
                          <MessageCircle className="w-6 h-6 text-old-money-warm-gray" />
                        </div>
                        <div>
                          <h4 className="font-medium text-old-money-navy">First Post</h4>
                          <p className="text-sm text-old-money-warm-gray">Share your first investment idea</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Progress value={user.totalPosts > 0 ? 100 : 0} className="h-2 flex-1" />
                            <span className="text-sm text-old-money-warm-gray">{user.totalPosts > 0 ? '1/1' : '0/1'}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-old-money-beige">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-old-money-warm-gray/20 rounded-full flex items-center justify-center">
                          <Award className="w-6 h-6 text-old-money-warm-gray" />
                        </div>
                        <div>
                          <h4 className="font-medium text-old-money-navy">Active Contributor</h4>
                          <p className="text-sm text-old-money-warm-gray">Share 10 investment ideas</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Progress value={achievementProgress} className="h-2 flex-1" />
                            <span className="text-sm text-old-money-warm-gray">{user.totalPosts || 0}/10</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="settings" className="space-y-6">
                <Card className="border-old-money-beige">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-old-money-navy">
                      <User className="w-5 h-5" />
                      Profile Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="username" className="text-old-money-navy">Username</Label>
                      <Input
                        id="username"
                        value={profileForm.username}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, username: e.target.value }))}
                        disabled={!isEditing}
                        className="border-old-money-warm-gray focus:border-old-money-navy"
                      />
                    </div>

                    <div>
                      <Label htmlFor="bio" className="text-old-money-navy">Bio</Label>
                      <Textarea
                        id="bio"
                        placeholder="Tell the community about your trading experience..."
                        value={profileForm.bio}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, bio: e.target.value }))}
                        disabled={!isEditing}
                        rows={3}
                        className="border-old-money-warm-gray focus:border-old-money-navy"
                      />
                    </div>

                    <div className="flex gap-3">
                      {isEditing ? (
                        <>
                          <Button onClick={handleSaveProfile} className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream">
                            Save Changes
                          </Button>
                          <Button variant="outline" onClick={() => setIsEditing(false)} className="border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark">
                            Cancel
                          </Button>
                        </>
                      ) : (
                        <Button onClick={() => setIsEditing(true)} className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream">
                          <Edit className="w-4 h-4 mr-2" />
                          Edit Profile
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-old-money-beige">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-old-money-navy">
                      <Bell className="w-5 h-5" />
                      Notification Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="emailNotif" className="text-old-money-navy">Email Notifications</Label>
                      <Switch 
                        id="emailNotif"
                        checked={profileForm.notifications.email}
                        onCheckedChange={(checked) => 
                          setProfileForm(prev => ({ 
                            ...prev, 
                            notifications: { ...prev.notifications, email: checked }
                          }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="pushNotif" className="text-old-money-navy">Push Notifications</Label>
                      <Switch 
                        id="pushNotif"
                        checked={profileForm.notifications.push}
                        onCheckedChange={(checked) => 
                          setProfileForm(prev => ({ 
                            ...prev, 
                            notifications: { ...prev.notifications, push: checked }
                          }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="priceAlerts" className="text-old-money-navy">Price Alerts</Label>
                      <Switch 
                        id="priceAlerts"
                        checked={profileForm.notifications.priceAlerts}
                        onCheckedChange={(checked) => 
                          setProfileForm(prev => ({ 
                            ...prev, 
                            notifications: { ...prev.notifications, priceAlerts: checked }
                          }))
                        }
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-old-money-beige">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-old-money-navy">
                      <Shield className="w-5 h-5" />
                      Privacy Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="showStats" className="text-old-money-navy">Show My Statistics</Label>
                      <Switch 
                        id="showStats"
                        checked={profileForm.privacy.showStats}
                        onCheckedChange={(checked) => 
                          setProfileForm(prev => ({ 
                            ...prev, 
                            privacy: { ...prev.privacy, showStats: checked }
                          }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="showPosts" className="text-old-money-navy">Show My Posts Publicly</Label>
                      <Switch 
                        id="showPosts"
                        checked={profileForm.privacy.showPosts}
                        onCheckedChange={(checked) => 
                          setProfileForm(prev => ({ 
                            ...prev, 
                            privacy: { ...prev.privacy, showPosts: checked }
                          }))
                        }
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

export default UserProfile;