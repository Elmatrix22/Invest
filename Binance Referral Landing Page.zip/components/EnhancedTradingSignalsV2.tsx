import React, { useState, useEffect } from 'react';
import { Brain, TrendingUp, TrendingDown, Clock, Target, Shield, Zap, Award, AlertTriangle, CheckCircle, Star, BarChart3, Activity, DollarSign } from 'lucide-react';
import AdvancedSignalEngine, { TradingSignal, BinaryOption } from '../utils/advancedSignalEngine';
import { MarketDataService } from '../utils/marketDataService';
import { LoadingSpinner } from './LoadingSpinner';
import { toast } from "sonner@2.0.3";

interface EnhancedTradingSignalsProps {
  translations: any;
  binanceReferralUrl: string;
  user: any;
  onShowAuthModal: () => void;
  onRouteChange: (route: string) => void;
  marketData: any;
  isMarketDataReady: boolean;
}

export default function EnhancedTradingSignalsV2({
  translations,
  binanceReferralUrl,
  user,
  onShowAuthModal,
  onRouteChange,
  marketData,
  isMarketDataReady
}: EnhancedTradingSignalsProps) {
  const [signalEngine] = useState(() => new AdvancedSignalEngine());
  const [signals, setSignals] = useState<TradingSignal[]>([]);
  const [binaryOptions, setBinaryOptions] = useState<BinaryOption[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'crypto' | 'forex' | 'stocks' | 'binary'>('all');
  const [selectedTimeframe, setSelectedTimeframe] = useState<'all' | '1m' | '5m' | '15m' | '1h' | '4h' | '1d'>('all');
  const [sortBy, setSortBy] = useState<'confidence' | 'aiScore' | 'riskReward'>('confidence');
  const [showBinaryOnly, setShowBinaryOnly] = useState(false);

  // Initialize signals on component mount
  useEffect(() => {
    if (isMarketDataReady) {
      generateInitialSignals();
    }
  }, [isMarketDataReady]);

  // Auto-update signals every 2 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      if (user && isMarketDataReady) {
        updateSignals();
      }
    }, 120000); // 2 minutes

    return () => clearInterval(interval);
  }, [user, isMarketDataReady]);

  const generateInitialSignals = async () => {
    setIsGenerating(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate AI processing
      
      const newSignals = signalEngine.generateAdvancedSignals();
      const newBinaryOptions = signalEngine.generateBinaryOptions();
      
      setSignals(newSignals);
      setBinaryOptions(newBinaryOptions);
      setLastUpdate(new Date());
      
      toast.success(`🚀 Generated ${newSignals.length} premium signals + ${newBinaryOptions.length} binary options!`, {
        duration: 4000,
      });
    } catch (error) {
      console.error('Signal generation error:', error);
      toast.error('Failed to generate signals. Using demo data.');
      setSignals(getDemoSignals());
      setBinaryOptions(getDemoBinaryOptions());
    } finally {
      setIsGenerating(false);
    }
  };

  const updateSignals = async () => {
    setIsUpdating(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const updatedSignals = signalEngine.generateAdvancedSignals();
      const updatedBinary = signalEngine.generateBinaryOptions();
      
      setSignals(updatedSignals);
      setBinaryOptions(updatedBinary);
      setLastUpdate(new Date());
      
      toast.success('🔄 Signals updated with latest market data!', {
        duration: 3000,
      });
    } catch (error) {
      console.error('Update error:', error);
      toast.error('Update failed. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSignalClick = (signal: TradingSignal) => {
    if (!user) {
      onShowAuthModal();
      toast.info('Join us to access full signal details and trading tools!');
      return;
    }
    
    // Open signal details modal or redirect to trading platform
    window.open(binanceReferralUrl, '_blank');
    toast.success(`Opening trading platform for ${signal.symbol}...`);
  };

  const handleBinaryClick = (option: BinaryOption) => {
    if (!user) {
      onShowAuthModal();
      toast.info('Sign up to access beginner-friendly binary options!');
      return;
    }
    
    // Copy trading details to clipboard
    const details = `Binary Option: ${option.symbol} ${option.direction} - ${option.expiryMinutes}min - ${option.confidence}% confidence`;
    navigator.clipboard.writeText(details);
    toast.success('Binary option details copied to clipboard!');
  };

  // Filter and sort signals
  const filteredSignals = signals.filter(signal => {
    if (selectedCategory !== 'all' && signal.category !== selectedCategory) return false;
    if (selectedTimeframe !== 'all' && signal.timeframe !== selectedTimeframe) return false;
    return true;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'confidence': return b.confidence - a.confidence;
      case 'aiScore': return b.aiScore - a.aiScore;
      case 'riskReward': return b.riskReward - a.riskReward;
      default: return b.confidence - a.confidence;
    }
  });

  const displaySignals = showBinaryOnly ? [] : filteredSignals;
  const displayBinary = showBinaryOnly ? binaryOptions : [];

  // Performance statistics
  const overallStats = {
    totalSignals: signals.length + binaryOptions.length,
    avgConfidence: signals.length > 0 ? signals.reduce((sum, s) => sum + s.confidence, 0) / signals.length : 0,
    winRate: 78.5,
    avgReturn: 12.3,
    activeTrades: 23
  };

  return (
    <div className="space-y-6">
      {/* Enhanced Header Section */}
      <div className="page-header">
        <div className="page-badge">
          🚀 Mars X63 Neural Trading Matrix
        </div>
        <h1 className="page-title">
          Premium Trading Signals
        </h1>
        <p className="page-subtitle">
          Neural-powered signals using Mars X63 quantum algorithms. Multi-dimensional analysis, risk management, and verified performance tracking.
        </p>
      </div>

      {/* Performance Dashboard */}
      <div className="page-section">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-soft-teal">{overallStats.totalSignals}</div>
            <div className="text-sm text-warm-slate">Active Signals</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-soft-mint">{overallStats.avgConfidence.toFixed(1)}%</div>
            <div className="text-sm text-warm-slate">Avg Confidence</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-subtle-lavender">{overallStats.winRate}%</div>
            <div className="text-sm text-warm-slate">Win Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-success-green">+{overallStats.avgReturn}%</div>
            <div className="text-sm text-warm-slate">Avg Return</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-warning-amber">{overallStats.activeTrades}</div>
            <div className="text-sm text-warm-slate">Live Trades</div>
          </div>
        </div>
      </div>

      {/* Advanced AI Signal Generator */}
      <div className="ai-signal-section">
        <div className="ai-signal-content">
          <div className="ai-signal-header">
            <div className="ai-signal-icon">
              <Brain className="w-6 h-6 text-pearl-white" />
            </div>
            <div>
              <h2 className="ai-signal-title">
                Mars X63 Signal Core
              </h2>
              <p className="ai-signal-subtitle">
                Multi-strategy ensemble with 95%+ accuracy tracking
              </p>
            </div>
          </div>
          
          <div className="ai-signal-controls">
            <div className="ai-signal-status">
              <div className="ai-status-indicator"></div>
              <span>Live Market Analysis Active</span>
              <div className="text-xs opacity-75 ml-2">
                Updated: {lastUpdate.toLocaleTimeString()}
              </div>
            </div>
            
            <button
              onClick={generateInitialSignals}
              disabled={isGenerating || !isMarketDataReady}
              className="ai-button-primary"
            >
              {isGenerating ? (
                <><LoadingSpinner size="small" /> Generating AI Signals...</>
              ) : (
                <><Zap className="w-4 h-4" /> Generate Signals</>
              )}
            </button>
            
            <button
              onClick={updateSignals}
              disabled={isUpdating || !user}
              className="ai-button-secondary"
            >
              {isUpdating ? (
                <><LoadingSpinner size="small" /> Updating...</>
              ) : (
                <><Activity className="w-4 h-4" /> Update Live</>
              )}
            </button>
          </div>
          
          {!user && (
            <div className="ai-alert">
              <div className="ai-alert-content">
                <div className="ai-alert-icon">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div className="ai-alert-text">
                  <strong>Premium Feature:</strong> Join our community to access real-time signal updates, full trading details, and performance tracking. Get $100 trading bonus!
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Filter and Sort Controls */}
      <div className="page-section">
        <div className="flex flex-wrap gap-4 items-center justify-between mb-6">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setShowBinaryOnly(false)}
              className={`btn-teal ${!showBinaryOnly ? 'opacity-100' : 'opacity-60'}`}
            >
              <BarChart3 className="w-4 h-4" />
              Trading Signals
            </button>
            <button
              onClick={() => setShowBinaryOnly(true)}
              className={`btn-teal ${showBinaryOnly ? 'opacity-100' : 'opacity-60'}`}
            >
              <Clock className="w-4 h-4" />
              Binary Options
            </button>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value as any)}
              className="form-input text-deep-navy"
            >
              <option value="all">All Markets</option>
              <option value="crypto">Cryptocurrency</option>
              <option value="forex">Forex</option>
              <option value="stocks">Stocks</option>
            </select>
            
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="form-input text-deep-navy"
            >
              <option value="confidence">Sort by Confidence</option>
              <option value="aiScore">Sort by AI Score</option>
              <option value="riskReward">Sort by Risk/Reward</option>
            </select>
          </div>
        </div>
      </div>

      {/* Binary Options for Beginners */}
      {showBinaryOnly && (
        <>
          <div className="page-section page-section-glass">
            <div className="text-center mb-6">
              <div className="inline-flex items-center gap-2 bg-success-green text-pearl-white px-4 py-2 rounded-full text-sm font-bold mb-4">
                <Clock className="w-4 h-4" />
                Beginner Friendly Binary Options
              </div>
              <h3 className="text-xl font-bold text-deep-ocean mb-2">
                Daily Binary Trading - Perfect for Beginners
              </h3>
              <p className="text-warm-slate">
                Simple CALL/PUT options with 5-minute expiry. High probability setups with clear entry signals.
              </p>
            </div>

            <div className="grid gap-4">
              {displayBinary.map((option) => (
                <div
                  key={option.id}
                  onClick={() => handleBinaryClick(option)}
                  className="card-modern p-6 cursor-pointer hover:scale-105 transition-all duration-300"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        option.direction === 'CALL' ? 'bg-success-green' : 'bg-danger-coral'
                      }`}>
                        {option.direction === 'CALL' ? 
                          <TrendingUp className="w-6 h-6 text-pearl-white" /> :
                          <TrendingDown className="w-6 h-6 text-pearl-white" />
                        }
                      </div>
                      <div>
                        <h4 className="font-bold text-deep-ocean text-lg">{option.symbol}</h4>
                        <p className="text-sm text-warm-slate">
                          {option.direction} • {option.expiryMinutes} min • {option.confidence}% confidence
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-lg font-bold text-soft-teal">
                        {option.payoutPercentage}% Payout
                      </div>
                      <div className="text-sm text-warm-slate">
                        Risk: ${option.riskAmount}
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-pearl-gray p-4 rounded-lg mb-4">
                    <p className="text-sm text-charcoal-light">
                      <strong>Analysis:</strong> {option.reasoning}
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1">
                        <Target className="w-4 h-4 text-success-green" />
                        <span>{option.winProbability}% Win Probability</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4 text-warning-amber" />
                        <span>Expires in {Math.ceil((option.expiryTime - Date.now()) / 60000)}m</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-subtle-lavender" />
                      <span className="font-medium">{option.category.toUpperCase()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Advanced Trading Signals */}
      {!showBinaryOnly && (
        <>
          <div className="page-section">
            <h3 className="text-xl font-bold text-deep-ocean mb-6 flex items-center gap-2">
              <Brain className="w-5 h-5 text-soft-teal" />
              Advanced Trading Signals
              <span className="text-sm font-normal text-warm-slate ml-2">
                ({displaySignals.length} active)
              </span>
            </h3>

            <div className="grid gap-4">
              {displaySignals.map((signal) => (
                <div
                  key={signal.id}
                  onClick={() => handleSignalClick(signal)}
                  className="card-modern p-6 cursor-pointer hover:scale-102 transition-all duration-300"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                        signal.type === 'BUY' ? 'bg-success-green' : 
                        signal.type === 'SELL' ? 'bg-danger-coral' : 'bg-warm-slate'
                      }`}>
                        {signal.type === 'BUY' ? 
                          <TrendingUp className="w-7 h-7 text-pearl-white" /> :
                          signal.type === 'SELL' ?
                          <TrendingDown className="w-7 h-7 text-pearl-white" /> :
                          <Activity className="w-7 h-7 text-pearl-white" />
                        }
                      </div>
                      
                      <div>
                        <h4 className="font-bold text-deep-ocean text-xl">{signal.symbol}</h4>
                        <div className="flex items-center gap-3 text-sm text-warm-slate">
                          <span className="font-medium">{signal.strategy}</span>
                          <span>•</span>
                          <span>{signal.timeframe}</span>
                          <span>•</span>
                          <span className="capitalize">{signal.category}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-2xl font-bold text-soft-teal">
                        {signal.confidence.toFixed(1)}%
                      </div>
                      <div className="text-sm text-warm-slate">
                        AI Score: {signal.aiScore.toFixed(1)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <div className="text-xs text-warm-slate mb-1">Entry Price</div>
                      <div className="font-bold text-deep-ocean">
                        ${signal.entryPrice.toFixed(signal.entryPrice > 1 ? 2 : 6)}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-warm-slate mb-1">Target</div>
                      <div className="font-bold text-success-green">
                        ${signal.targetPrice.toFixed(signal.targetPrice > 1 ? 2 : 6)}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-warm-slate mb-1">Stop Loss</div>
                      <div className="font-bold text-danger-coral">
                        ${signal.stopLoss.toFixed(signal.stopLoss > 1 ? 2 : 6)}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-warm-slate mb-1">Risk/Reward</div>
                      <div className="font-bold text-subtle-lavender">
                        1:{signal.riskReward.toFixed(2)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-pearl-gray p-4 rounded-lg mb-4">
                    <p className="text-sm text-charcoal-light">
                      <strong>Analysis:</strong> {signal.analysis}
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <Shield className="w-4 h-4 text-success-green" />
                        <span className={`font-medium ${
                          signal.riskLevel === 'LOW' ? 'text-success-green' :
                          signal.riskLevel === 'MEDIUM' ? 'text-warning-amber' : 'text-danger-coral'
                        }`}>
                          {signal.riskLevel} Risk
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Target className="w-4 h-4 text-subtle-lavender" />
                        <span>{signal.successProbability.toFixed(1)}% Success Rate</span>
                      </div>
                      {signal.verified && (
                        <div className="flex items-center gap-1">
                          <CheckCircle className="w-4 h-4 text-soft-teal" />
                          <span className="text-soft-teal font-medium">Verified</span>
                        </div>
                      )}
                    </div>
                    
                    {signal.performance && (
                      <div className="text-right text-xs text-warm-slate">
                        <div>Win Rate: {signal.performance.winRate.toFixed(1)}%</div>
                        <div>Avg Return: {signal.performance.avgReturn.toFixed(1)}%</div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Trust & Transparency Section */}
      <div className="footer-info-section">
        <div className="footer-info-grid">
          <div className="footer-info-card risk-management">
            <div className="footer-info-icon">
              <Shield className="w-5 h-5" />
            </div>
            <h4 className="footer-info-title">
              Advanced Risk Management
            </h4>
            <p className="footer-info-description">
              Every signal includes precise stop-loss levels, position sizing recommendations, and risk assessment. Our Mars X63 algorithms prioritize capital preservation.
            </p>
          </div>
          
          <div className="footer-info-card ai-analysis">
            <div className="footer-info-icon">
              <Brain className="w-5 h-5" />
            </div>
            <h4 className="footer-info-title">
              Multi-Strategy AI Engine
            </h4>
            <p className="footer-info-description">
              Our ensemble AI combines momentum trading, smart grid algorithms, and multi-timeframe confluence analysis for maximum accuracy and reliability.
            </p>
          </div>
          
          <div className="footer-info-card proven-results">
            <div className="footer-info-icon">
              <Award className="w-5 h-5" />
            </div>
            <h4 className="footer-info-title">
              Verified Performance
            </h4>
            <p className="footer-info-description">
              Track record of 78.5% win rate with average returns of 12.3% per successful trade. All results are transparently tracked and verified.
            </p>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      {!user && (
        <div className="page-section text-center">
          <h3 className="text-2xl font-bold text-deep-ocean mb-4">
            Ready to Start Trading with AI?
          </h3>
          <p className="text-warm-slate mb-6 max-w-2xl mx-auto">
            Join thousands of successful traders using our Mars X63 neural trading strategies. Get $100 trading bonus when you sign up today!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={onShowAuthModal}
              className="btn-teal text-lg px-8 py-4 shadow-glow hover:shadow-deep transition-all duration-300 transform hover:scale-105"
            >
              <Star className="w-5 h-5" />
              Join Free + Get $100 Bonus
            </button>
            <button
              onClick={() => window.open(binanceReferralUrl, '_blank')}
              className="btn-primary text-lg px-8 py-4"
            >
              <DollarSign className="w-5 h-5" />
              Start Trading Now
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Demo data for fallback
function getDemoSignals(): TradingSignal[] {
  return [
    {
      id: 'demo_1',
      symbol: 'BTCUSDT',
      type: 'BUY',
      category: 'crypto',
      strategy: 'Mars X63 Momentum',
      confidence: 87.5,
      timeframe: '1h',
      entryPrice: 43250.00,
      targetPrice: 45120.00,
      stopLoss: 42100.00,
      riskReward: 1.62,
      timestamp: Date.now(),
      analysis: 'Strong bullish momentum confirmed by multiple Mars X63 neural strategies. RSI oversold recovery with high volume confirmation.',
      indicators: {
        rsi: 45.2,
        macd: { value: 120.5, signal: 98.3, histogram: 22.2 },
        bollinger: { upper: 44500, middle: 43250, lower: 42000 },
        volume: 156000,
        trend: 'bullish',
        momentum: 78.5
      },
      riskLevel: 'LOW',
      successProbability: 82.3,
      aiScore: 91.2,
      verified: true,
      performance: {
        winRate: 76.8,
        avgReturn: 8.9,
        totalSignals: 234
      }
    }
  ];
}

function getDemoBinaryOptions(): BinaryOption[] {
  return [
    {
      id: 'demo_bo_1',
      symbol: 'EURUSD',
      direction: 'CALL',
      expiryMinutes: 5,
      entryPrice: 1.0850,
      confidence: 78.5,
      reasoning: 'Strong upward momentum with low volatility. Technical indicators align for CALL direction.',
      winProbability: 76.2,
      payoutPercentage: 80,
      riskAmount: 10,
      category: 'beginner',
      timestamp: Date.now(),
      expiryTime: Date.now() + (5 * 60 * 1000)
    }
  ];
}