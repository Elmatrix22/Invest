import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { User, Clock, Calendar } from 'lucide-react';
import { BlogArticle } from '../utils/blogData';

interface BlogArticleModalProps {
  article: BlogArticle | null;
  isOpen: boolean;
  onClose: () => void;
}

export function BlogArticleModal({ article, isOpen, onClose }: BlogArticleModalProps) {
  if (!article) return null;

  const processedContent = article.content
    .replace(/class="cta-box"/g, 'class="bg-old-money-cream-dark border border-old-money-beige rounded-lg p-6 my-6"')
    .replace(/class="calculation-box"/g, 'class="bg-old-money-sage/10 border border-old-money-sage/30 rounded-lg p-4 my-4"')
    .replace(/class="signal-example"/g, 'class="bg-old-money-navy text-old-money-cream rounded-lg p-4 my-4 font-mono text-sm"')
    .replace(/class="stats-grid"/g, 'class="grid md:grid-cols-3 gap-4 my-6"')
    .replace(/class="stat"/g, 'class="bg-old-money-cream-dark border border-old-money-beige rounded-lg p-4 text-center"')
    .replace(/<table>/g, '<table class="w-full border-collapse border border-old-money-beige my-4">')
    .replace(/<th>/g, '<th class="border border-old-money-beige bg-old-money-cream-dark p-2 text-left font-medium">')
    .replace(/<td>/g, '<td class="border border-old-money-beige p-2">');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[90vh] border-old-money-beige">
        <DialogHeader className="pb-4 border-b border-old-money-beige">
          <div className="flex items-center gap-2 mb-2">
            <Badge className="bg-old-money-navy text-old-money-cream">
              {article.category}
            </Badge>
            <div className="flex items-center gap-4 text-sm text-old-money-warm-gray">
              <div className="flex items-center gap-1">
                <User className="w-3 h-3" />
                {article.author}
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {article.readTime}
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {new Date(article.publishDate).toLocaleDateString()}
              </div>
            </div>
          </div>
          <DialogTitle className="text-xl text-old-money-navy leading-tight">
            {article.title}
          </DialogTitle>
          <DialogDescription className="text-old-money-warm-gray">
            {article.excerpt}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4">
          <div 
            className="prose prose-old-money max-w-none text-old-money-charcoal"
            dangerouslySetInnerHTML={{ __html: processedContent }}
            style={{
              lineHeight: '1.6',
              fontSize: '16px'
            }}
          />
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}