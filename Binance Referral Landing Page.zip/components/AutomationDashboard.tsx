import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Bot, 
  TrendingUp, 
  Link, 
  Share2, 
  FileText, 
  Users, 
  Activity,
  Clock,
  CheckCircle,
  AlertCircle,
  BarChart3,
  Calendar,
  Target,
  Zap
} from 'lucide-react';

// Initialize Supabase client
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

interface AutomationMetrics {
  contentGenerated: number;
  keywordsTracked: number;
  backlinksAcquired: number;
  socialPosts: number;
  organicTraffic: number;
  rankingImprovements: number;
}

interface AutomationJob {
  id: string;
  jobName: string;
  status: 'active' | 'paused' | 'failed';
  lastRun: string;
  nextRun: string;
  successRate: number;
}

export function AutomationDashboard() {
  const [metrics, setMetrics] = useState<AutomationMetrics>({
    contentGenerated: 0,
    keywordsTracked: 0,
    backlinksAcquired: 0,
    socialPosts: 0,
    organicTraffic: 0,
    rankingImprovements: 0
  });

  const [jobs, setJobs] = useState<AutomationJob[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // Load automation metrics
      const { data: performanceData } = await supabase
        .from('seo_performance_metrics')
        .select('*')
        .order('metric_date', { ascending: false })
        .limit(30);

      if (performanceData && performanceData.length > 0) {
        const latest = performanceData[0];
        const previous = performanceData[1] || latest;
        
        setMetrics({
          contentGenerated: performanceData.reduce((sum, day) => sum + day.content_pieces_published, 0),
          keywordsTracked: 150, // From seo_keywords table
          backlinksAcquired: performanceData.reduce((sum, day) => sum + day.backlinks_acquired, 0),
          socialPosts: performanceData.reduce((sum, day) => sum + day.social_media_engagement, 0),
          organicTraffic: latest.organic_traffic,
          rankingImprovements: latest.keyword_rankings_improved
        });
      }

      // Load automation jobs
      const { data: jobsData } = await supabase
        .from('automation_jobs')
        .select('*')
        .order('priority', { ascending: false });

      if (jobsData) {
        setJobs(jobsData.map(job => ({
          id: job.id,
          jobName: job.job_name,
          status: job.status,
          lastRun: job.last_run_at || 'Never',
          nextRun: job.next_run_at || 'Not scheduled',
          successRate: job.success_count / Math.max(job.success_count + job.failure_count, 1) * 100
        })));
      }

      setIsLoading(false);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setIsLoading(false);
    }
  };

  const triggerManualJob = async (jobType: string) => {
    try {
      // This would call your backend automation function
      const response = await fetch('/api/automation/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobType })
      });

      if (response.ok) {
        // Refresh dashboard data
        loadDashboardData();
      }
    } catch (error) {
      console.error('Error triggering job:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-old-money-navy"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-old-money-navy">SEO Automation Dashboard</h1>
          <p className="text-old-money-warm-gray mt-2">
            Automated content generation, link building, and SEO optimization for #1 Google ranking
          </p>
        </div>
        <Button 
          onClick={() => triggerManualJob('full_automation')}
          className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream"
        >
          <Zap className="w-4 h-4 mr-2" />
          Run Full Automation
        </Button>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Content Generated</CardTitle>
            <FileText className="h-4 w-4 text-old-money-burgundy" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-old-money-navy">{metrics.contentGenerated}</div>
            <p className="text-xs text-old-money-warm-gray">
              Blog posts, social content, guest posts
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Keywords Tracked</CardTitle>
            <Target className="h-4 w-4 text-old-money-sage" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-old-money-navy">{metrics.keywordsTracked}</div>
            <p className="text-xs text-old-money-warm-gray">
              High-value trading & investment keywords
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Backlinks Acquired</CardTitle>
            <Link className="h-4 w-4 text-old-money-gold" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-old-money-navy">{metrics.backlinksAcquired}</div>
            <p className="text-xs text-old-money-warm-gray">
              High-authority finance & crypto sites
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Social Media Posts</CardTitle>
            <Share2 className="h-4 w-4 text-old-money-navy" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-old-money-navy">{metrics.socialPosts}</div>
            <p className="text-xs text-old-money-warm-gray">
              Automated across all platforms
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Organic Traffic</CardTitle>
            <TrendingUp className="h-4 w-4 text-old-money-burgundy" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-old-money-navy">
              {metrics.organicTraffic.toLocaleString()}
            </div>
            <p className="text-xs text-old-money-warm-gray">
              Monthly visitors from search
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ranking Improvements</CardTitle>
            <BarChart3 className="h-4 w-4 text-old-money-sage" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-old-money-navy">{metrics.rankingImprovements}</div>
            <p className="text-xs text-old-money-warm-gray">
              Keywords moved up this month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tabs */}
      <Tabs defaultValue="automation-jobs" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="automation-jobs">Automation Jobs</TabsTrigger>
          <TabsTrigger value="content-pipeline">Content Pipeline</TabsTrigger>
          <TabsTrigger value="link-building">Link Building</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="automation-jobs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Active Automation Jobs</CardTitle>
              <CardDescription>
                Scheduled tasks running automatically to boost SEO performance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {jobs.map((job) => (
                  <div key={job.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        {job.status === 'active' && <CheckCircle className="w-5 h-5 text-green-600" />}
                        {job.status === 'paused' && <Clock className="w-5 h-5 text-yellow-600" />}
                        {job.status === 'failed' && <AlertCircle className="w-5 h-5 text-red-600" />}
                        <Badge variant={job.status === 'active' ? 'default' : 'secondary'}>
                          {job.status}
                        </Badge>
                      </div>
                      <div>
                        <h4 className="font-medium">{job.jobName}</h4>
                        <p className="text-sm text-old-money-warm-gray">
                          Last run: {new Date(job.lastRun).toLocaleDateString()} • 
                          Next: {new Date(job.nextRun).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="text-sm font-medium">{job.successRate.toFixed(1)}%</div>
                        <div className="text-xs text-old-money-warm-gray">Success Rate</div>
                      </div>
                      <Progress value={job.successRate} className="w-20" />
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => triggerManualJob(job.jobName.toLowerCase().replace(/\s+/g, '_'))}
                      >
                        Run Now
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="content-pipeline" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Content Generation Pipeline</CardTitle>
              <CardDescription>
                AI-powered content creation targeting high-value keywords
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">This Week</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-old-money-navy">7</div>
                      <p className="text-sm text-old-money-warm-gray">Blog posts scheduled</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">In Review</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-old-money-burgundy">3</div>
                      <p className="text-sm text-old-money-warm-gray">Posts awaiting approval</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Published</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-old-money-sage">42</div>
                      <p className="text-sm text-old-money-warm-gray">This month</p>
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Top Target Keywords</h4>
                  <div className="space-y-2">
                    {[
                      { keyword: 'free crypto signals', volume: '27,100', difficulty: 'Medium', status: 'Content Scheduled' },
                      { keyword: 'AI trading bot', volume: '18,500', difficulty: 'High', status: 'In Progress' },
                      { keyword: 'forex signals free', volume: '15,200', difficulty: 'Low', status: 'Published' },
                      { keyword: 'investment opportunities 2024', volume: '12,800', difficulty: 'Medium', status: 'Content Scheduled' }
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded">
                        <div>
                          <span className="font-medium">{item.keyword}</span>
                          <span className="text-sm text-old-money-warm-gray ml-2">
                            {item.volume} searches/month
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{item.difficulty}</Badge>
                          <Badge variant="secondary">{item.status}</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="link-building" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Link Building Campaign</CardTitle>
              <CardDescription>
                Automated outreach to high-authority finance and crypto websites
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Targets Found</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-old-money-navy">247</div>
                      <p className="text-sm text-old-money-warm-gray">Quality websites</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Outreach Sent</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-old-money-burgundy">89</div>
                      <p className="text-sm text-old-money-warm-gray">This month</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Response Rate</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-old-money-sage">23%</div>
                      <p className="text-sm text-old-money-warm-gray">Above industry avg</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Links Acquired</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-old-money-gold">12</div>
                      <p className="text-sm text-old-money-warm-gray">High-quality backlinks</p>
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Recent Link Acquisitions</h4>
                  <div className="space-y-2">
                    {[
                      { domain: 'coindesk.com', da: 89, type: 'Guest Post', status: 'Live' },
                      { domain: 'investing.com', da: 85, type: 'Resource Mention', status: 'Live' },
                      { domain: 'cryptonews.com', da: 72, type: 'Guest Post', status: 'Pending' },
                      { domain: 'forexfactory.com', da: 78, type: 'Directory', status: 'Live' }
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded">
                        <div>
                          <span className="font-medium">{item.domain}</span>
                          <span className="text-sm text-old-money-warm-gray ml-2">
                            DA: {item.da}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{item.type}</Badge>
                          <Badge variant={item.status === 'Live' ? 'default' : 'secondary'}>
                            {item.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>SEO Performance Trends</CardTitle>
                <CardDescription>30-day performance overview</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Organic Traffic Growth</span>
                    <span className="text-green-600 font-medium">+127%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Keyword Rankings Improved</span>
                    <span className="text-green-600 font-medium">+89 positions</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Domain Authority</span>
                    <span className="text-old-money-navy font-medium">42 → 58</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Conversion Rate</span>
                    <span className="text-green-600 font-medium">+34%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Automation ROI</CardTitle>
                <CardDescription>Return on automation investment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">847%</div>
                    <p className="text-sm text-old-money-warm-gray">ROI from automation</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Time Saved</span>
                      <span className="font-medium">156 hours/month</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Cost Reduction</span>
                      <span className="font-medium">-73%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Quality Improvement</span>
                      <span className="font-medium">+91%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}