import { Button } from './ui/button';
import { Bell, ExternalLink, Target } from 'lucide-react';

interface FloatingActionButtonsProps {
  user: any;
  onSetActiveTab: (tab: string) => void;
  onBinanceReferral: () => void;
  onShowAuthModal: () => void;
}

export function FloatingActionButtons({ 
  user, 
  onSetActiveTab, 
  onBinanceReferral, 
  onShowAuthModal 
}: FloatingActionButtonsProps) {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3">
      <Button 
        onClick={() => onSetActiveTab('alerts')}
        className="bg-old-money-burgundy hover:bg-old-money-burgundy-light text-old-money-cream shadow-lg rounded-full w-14 h-14"
        title="Price Alerts"
      >
        <Bell className="w-6 h-6 animate-pulse" />
      </Button>
      
      <Button 
        onClick={onBinanceReferral}
        className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy shadow-lg rounded-full w-14 h-14"
        title="Trade on Binance"
      >
        <ExternalLink className="w-6 h-6" />
      </Button>
      
      <Button 
        onClick={() => {
          if (user) {
            onSetActiveTab('community');
          } else {
            onShowAuthModal();
          }
        }}
        className="bg-gradient-to-r from-old-money-navy to-old-money-charcoal hover:from-old-money-navy-light hover:to-old-money-charcoal-light text-old-money-cream shadow-lg rounded-full w-14 h-14"
        title="Community"
      >
        <Target className="w-6 h-6" />
      </Button>
    </div>
  );
}