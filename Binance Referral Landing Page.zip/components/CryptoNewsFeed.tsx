import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Progress } from './ui/progress';
import { 
  Newspaper, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  ExternalLink, 
  Search,
  Bookmark,
  Share2,
  Eye,
  MessageCircle,
  Filter,
  Zap,
  AlertTriangle,
  Star,
  Target,
  ArrowRight,
  Globe,
  Calendar,
  ChevronRight,
  Flame,
  Award,
  BarChart3,
  DollarSign,
  Shield,
  Users,
  Brain,
  Gift,
  RefreshCw,
  Bell
} from 'lucide-react';

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  content: string;
  source: string;
  category: 'breaking' | 'market' | 'technology' | 'regulation' | 'analysis' | 'defi' | 'nft' | 'institutional';
  sentiment: 'bullish' | 'bearish' | 'neutral';
  publishedAt: string;
  imageUrl?: string;
  tags: string[];
  views: number;
  comments: number;
  isBookmarked: boolean;
  isHot: boolean;
  importance: 'high' | 'medium' | 'low';
  readTime: number;
  tradingSignal?: {
    type: 'buy' | 'sell' | 'hold';
    coin: string;
    confidence: number;
    target?: number;
    stopLoss?: number;
  };
  priceImpact?: {
    coins: string[];
    expectedMove: number;
    timeframe: string;
  };
}

interface CryptoNewsFeedProps {
  translations: any;
  binanceReferralUrl: string;
}

// Generate comprehensive news data
const generateNewsData = (): NewsItem[] => [
  {
    id: '1',
    title: 'Bitcoin Breaks $100K Resistance - Analysts Predict $120K by March 2025',
    summary: 'Bitcoin has finally broken through the psychological $100,000 barrier with unprecedented institutional support. Technical analysis suggests the next target could be $120K within the next quarter.',
    content: 'Breaking news content...',
    source: 'CryptoDaily Pro',
    category: 'breaking',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
    tags: ['BTC', 'Bullish', 'Technical Analysis', 'Institutional'],
    views: 25420,
    comments: 342,
    isBookmarked: false,
    isHot: true,
    importance: 'high',
    readTime: 4,
    tradingSignal: {
      type: 'buy',
      coin: 'BTC',
      confidence: 85,
      target: 120000,
      stopLoss: 95000
    },
    priceImpact: {
      coins: ['BTC', 'ETH', 'MSTR'],
      expectedMove: 15,
      timeframe: '1-3 months'
    }
  },
  {
    id: '2',
    title: 'Ethereum 2.0 Staking Yields Hit Record 6.8% APY Following Shanghai Upgrade',
    summary: 'ETH staking rewards reach all-time highs as network improvements drive institutional validator adoption. New staking protocols launching this week.',
    content: 'Ethereum staking content...',
    source: 'DeFi Pulse',
    category: 'technology',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 90 * 60 * 1000).toISOString(), // 1.5 hours ago
    tags: ['ETH', 'Staking', 'DeFi', 'Yield'],
    views: 18970,
    comments: 256,
    isBookmarked: true,
    isHot: true,
    importance: 'high',
    readTime: 5,
    tradingSignal: {
      type: 'buy',
      coin: 'ETH',
      confidence: 78,
      target: 4200,
      stopLoss: 3200
    },
    priceImpact: {
      coins: ['ETH', 'LDO', 'RPL'],
      expectedMove: 12,
      timeframe: '2-4 weeks'
    }
  },
  {
    id: '3',
    title: 'SEC Approves Spot Solana ETF - Markets React Positively',
    summary: 'The Securities and Exchange Commission has approved the first Solana spot ETF, following Bitcoin and Ethereum ETF successes. Trading begins Monday.',
    content: 'Solana ETF content...',
    source: 'Regulatory Watch',
    category: 'regulation',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
    tags: ['SOL', 'ETF', 'SEC', 'Institutional'],
    views: 32140,
    comments: 587,
    isBookmarked: false,
    isHot: true,
    importance: 'high',
    readTime: 6,
    tradingSignal: {
      type: 'buy',
      coin: 'SOL',
      confidence: 89,
      target: 350,
      stopLoss: 220
    },
    priceImpact: {
      coins: ['SOL', 'RAY', 'SRM'],
      expectedMove: 25,
      timeframe: '1-2 weeks'
    }
  },
  {
    id: '4',
    title: 'Major DeFi Protocol Launches $2B Liquidity Mining Program',
    summary: 'Uniswap V4 announces massive liquidity incentives across 50+ trading pairs. Early participants can earn up to 45% APY in governance tokens.',
    content: 'DeFi protocol content...',
    source: 'DeFi Monitor',
    category: 'defi',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    tags: ['DeFi', 'Uniswap', 'Liquidity Mining', 'UNI'],
    views: 14780,
    comments: 198,
    isBookmarked: false,
    isHot: false,
    importance: 'medium',
    readTime: 4,
    tradingSignal: {
      type: 'buy',
      coin: 'UNI',
      confidence: 72,
      target: 18,
      stopLoss: 8
    }
  },
  {
    id: '5',
    title: 'BlackRock Increases Bitcoin Holdings by $500M - Institution Adoption Surges',
    summary: 'World\'s largest asset manager adds another 5,000 BTC to portfolio. Other institutions following suit as Bitcoin becomes treasury asset.',
    content: 'BlackRock content...',
    source: 'Institutional Crypto',
    category: 'institutional',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    tags: ['BlackRock', 'Institutional', 'BTC', 'Treasury'],
    views: 21340,
    comments: 423,
    isBookmarked: true,
    isHot: false,
    importance: 'high',
    readTime: 3,
    priceImpact: {
      coins: ['BTC', 'COIN', 'MSTR'],
      expectedMove: 8,
      timeframe: '1-2 weeks'
    }
  },
  {
    id: '6',
    title: 'NFT Market Recovers: Blue-Chip Collections Surge 150% This Month',
    summary: 'Bored Apes, CryptoPunks, and Azuki see massive volume increases as institutional buyers return to digital art and collectibles market.',
    content: 'NFT market content...',
    source: 'NFT Insider',
    category: 'nft',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    tags: ['NFT', 'BAYC', 'CryptoPunks', 'Digital Art'],
    views: 9650,
    comments: 134,
    isBookmarked: false,
    isHot: false,
    importance: 'medium',
    readTime: 4
  },
  {
    id: '7',
    title: 'Fed Chairman Hints at Crypto-Friendly Regulatory Framework',
    summary: 'Jerome Powell suggests new regulations could provide clarity for digital assets while maintaining financial stability. Market responds positively.',
    content: 'Federal Reserve content...',
    source: 'Central Bank News',
    category: 'regulation',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    tags: ['Fed', 'Regulation', 'Powell', 'Framework'],
    views: 18920,
    comments: 298,
    isBookmarked: false,
    isHot: false,
    importance: 'high',
    readTime: 5,
    priceImpact: {
      coins: ['BTC', 'ETH', 'XRP'],
      expectedMove: 10,
      timeframe: '2-4 weeks'
    }
  },
  {
    id: '8',
    title: 'Crypto Exchange Reports $100M Security Breach - Funds Recovered',
    summary: 'Major exchange quickly identifies and patches vulnerability after white hat hackers discover potential exploit. All user funds secure.',
    content: 'Security breach content...',
    source: 'Security Alert Network',
    category: 'breaking',
    sentiment: 'neutral',
    publishedAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    tags: ['Security', 'Exchange', 'White Hat', 'Recovery'],
    views: 15420,
    comments: 287,
    isBookmarked: true,
    isHot: false,
    importance: 'medium',
    readTime: 3
  },
  {
    id: '9',
    title: 'AI Trading Bots Drive 60% of Crypto Volume - Retail Adapts',
    summary: 'Artificial intelligence and algorithmic trading now dominate cryptocurrency markets. Retail investors increasingly using AI tools for better returns.',
    content: 'AI trading content...',
    source: 'AI Finance Today',
    category: 'technology',
    sentiment: 'neutral',
    publishedAt: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString(),
    tags: ['AI', 'Trading Bots', 'Volume', 'Algorithms'],
    views: 12780,
    comments: 176,
    isBookmarked: false,
    isHot: false,
    importance: 'medium',
    readTime: 4
  },
  {
    id: '10',
    title: 'Layer 2 Networks See Record Transaction Growth - Ethereum Scaling',
    summary: 'Polygon, Arbitrum, and Optimism process over 10M daily transactions as Ethereum scaling solutions gain massive adoption.',
    content: 'Layer 2 content...',
    source: 'Layer2 Analytics',
    category: 'technology',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    tags: ['Layer2', 'Polygon', 'Arbitrum', 'Scaling'],
    views: 8940,
    comments: 123,
    isBookmarked: false,
    isHot: false,
    importance: 'medium',
    readTime: 4,
    tradingSignal: {
      type: 'buy',
      coin: 'MATIC',
      confidence: 74,
      target: 2.5,
      stopLoss: 0.8
    }
  },
  {
    id: '11',
    title: 'Central Bank Digital Currencies (CBDCs) Gain Momentum Globally',
    summary: 'Over 50 countries now actively developing or piloting CBDCs. China leads with digital yuan adoption, EU announces digital euro timeline.',
    content: 'CBDC content...',
    source: 'Global Finance Report',
    category: 'regulation',
    sentiment: 'neutral',
    publishedAt: new Date(Date.now() - 16 * 60 * 60 * 1000).toISOString(),
    tags: ['CBDC', 'Digital Yuan', 'Digital Euro', 'Central Banks'],
    views: 7420,
    comments: 89,
    isBookmarked: false,
    isHot: false,
    importance: 'medium',
    readTime: 5
  },
  {
    id: '12',
    title: 'GameFi Tokens Rally 200% as New Play-to-Earn Launches',
    summary: 'Gaming tokens see massive gains as innovative blockchain games attract millions of players. Next-generation P2E mechanics drive adoption.',
    content: 'GameFi content...',
    source: 'Gaming Crypto Weekly',
    category: 'technology',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 18 * 60 * 60 * 1000).toISOString(),
    tags: ['GameFi', 'P2E', 'Gaming', 'Metaverse'],
    views: 11230,
    comments: 167,
    isBookmarked: false,
    isHot: false,
    importance: 'medium',
    readTime: 4
  },
  {
    id: '13',
    title: 'Whale Alert: $2.3B Bitcoin Moved from Cold Storage',
    summary: 'Large Bitcoin holder transfers massive amount to exchanges, sparking speculation about potential market impact and selling pressure.',
    content: 'Whale movement content...',
    source: 'On-Chain Analytics',
    category: 'market',
    sentiment: 'bearish',
    publishedAt: new Date(Date.now() - 20 * 60 * 60 * 1000).toISOString(),
    tags: ['Whale Alert', 'BTC', 'Cold Storage', 'Market Impact'],
    views: 19650,
    comments: 456,
    isBookmarked: true,
    isHot: false,
    importance: 'high',
    readTime: 3,
    priceImpact: {
      coins: ['BTC'],
      expectedMove: -5,
      timeframe: '24-48 hours'
    }
  },
  {
    id: '14',
    title: 'Metaverse Real Estate Sales Jump 400% in Virtual Worlds',
    summary: 'Decentraland, Sandbox, and other virtual worlds see explosive growth in land sales. Major brands establishing virtual headquarters.',
    content: 'Metaverse content...',
    source: 'Virtual Reality Report',
    category: 'nft',
    sentiment: 'bullish',
    publishedAt: new Date(Date.now() - 22 * 60 * 60 * 1000).toISOString(),
    tags: ['Metaverse', 'Real Estate', 'MANA', 'SAND'],
    views: 6780,
    comments: 92,
    isBookmarked: false,
    isHot: false,
    importance: 'low',
    readTime: 3
  },
  {
    id: '15',
    title: 'Crypto Tax Guidelines Updated for 2025 - What Traders Need to Know',
    summary: 'IRS releases comprehensive cryptocurrency tax guidance for 2025. New rules for DeFi, staking rewards, and NFT transactions explained.',
    content: 'Tax guidelines content...',
    source: 'Tax Crypto Legal',
    category: 'regulation',
    sentiment: 'neutral',
    publishedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    tags: ['Tax', 'IRS', 'Guidelines', 'Compliance'],
    views: 13450,
    comments: 234,
    isBookmarked: false,
    isHot: false,
    importance: 'medium',
    readTime: 6
  }
];

function CryptoNewsFeed({ translations, binanceReferralUrl }: CryptoNewsFeedProps) {
  const [newsItems, setNewsItems] = useState<NewsItem[]>(generateNewsData());
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredNews, setFilteredNews] = useState(newsItems);
  const [sortBy, setSortBy] = useState<'latest' | 'trending' | 'popular'>('latest');
  const [showOnlyHot, setShowOnlyHot] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());

  useEffect(() => {
    let filtered = newsItems;

    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(item => item.category === selectedCategory);
    }

    // Hot filter
    if (showOnlyHot) {
      filtered = filtered.filter(item => item.isHot);
    }

    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(item => 
        item.title.toLowerCase().includes(query) ||
        item.summary.toLowerCase().includes(query) ||
        item.tags.some(tag => tag.toLowerCase().includes(query)) ||
        item.source.toLowerCase().includes(query)
      );
    }

    // Sort
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'trending':
          return (b.views + b.comments * 10) - (a.views + a.comments * 10);
        case 'popular':
          return b.views - a.views;
        default:
          return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
      }
    });

    setFilteredNews(filtered);
  }, [selectedCategory, searchQuery, newsItems, sortBy, showOnlyHot]);

  // Auto-refresh news every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(new Date());
      // In real app, this would fetch new news
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, []);

  const handleBookmark = (id: string) => {
    setNewsItems(prev => prev.map(item => 
      item.id === id ? { ...item, isBookmarked: !item.isBookmarked } : item
    ));
  };

  const handleShare = (item: NewsItem) => {
    if (navigator.share) {
      navigator.share({
        title: item.title,
        text: item.summary,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(`${item.title}\n\n${item.summary}\n\nRead more at: ${window.location.href}`);
    }
  };

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'bullish': return 'text-old-money-sage';
      case 'bearish': return 'text-old-money-burgundy';
      default: return 'text-old-money-warm-gray';
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'bullish': return <TrendingUp className="w-4 h-4" />;
      case 'bearish': return <TrendingDown className="w-4 h-4" />;
      default: return <Target className="w-4 h-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      breaking: 'bg-old-money-burgundy text-old-money-cream',
      market: 'bg-old-money-sage text-old-money-cream',
      technology: 'bg-old-money-navy text-old-money-cream',
      regulation: 'bg-old-money-gold text-old-money-navy',
      analysis: 'bg-old-money-charcoal text-old-money-cream',
      defi: 'bg-purple-600 text-white',
      nft: 'bg-pink-600 text-white',
      institutional: 'bg-blue-600 text-white'
    };
    return colors[category as keyof typeof colors] || 'bg-old-money-warm-gray text-old-money-cream';
  };

  const getImportanceIcon = (importance: string) => {
    switch (importance) {
      case 'high': return <AlertTriangle className="w-4 h-4 text-old-money-burgundy" />;
      case 'medium': return <Star className="w-4 h-4 text-old-money-gold" />;
      default: return null;
    }
  };

  const categories = [
    { id: 'all', name: 'All News', icon: Newspaper },
    { id: 'breaking', name: 'Breaking', icon: Zap },
    { id: 'market', name: 'Markets', icon: TrendingUp },
    { id: 'technology', name: 'Technology', icon: Star },
    { id: 'regulation', name: 'Regulation', icon: Shield },
    { id: 'defi', name: 'DeFi', icon: Target },
    { id: 'nft', name: 'NFT', icon: Award },
    { id: 'institutional', name: 'Institutional', icon: Users }
  ];

  const hotNews = filteredNews.filter(item => item.isHot);
  const breakingNews = filteredNews.filter(item => item.category === 'breaking');
  const featuredNews = filteredNews.slice(0, 3);
  const regularNews = filteredNews.slice(3);

  const stats = {
    total: filteredNews.length,
    bullish: filteredNews.filter(item => item.sentiment === 'bullish').length,
    withSignals: filteredNews.filter(item => item.tradingSignal).length,
    hot: hotNews.length,
    totalViews: filteredNews.reduce((sum, item) => sum + item.views, 0)
  };

  return (
    <div className="space-y-6">
      {/* Enhanced Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-old-money-navy flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-old-money-burgundy to-old-money-sage rounded-full flex items-center justify-center">
              <Newspaper className="w-6 h-6 text-old-money-cream" />
            </div>
            Live Crypto News & Analysis
            <Badge className="bg-old-money-sage text-old-money-cream">
              Live Updates
            </Badge>
          </h2>
          <p className="text-old-money-warm-gray flex items-center gap-2 mt-2">
            📰 Real-time news • 🔍 Market analysis • 📊 Trading signals • 💡 AI insights
            <span className="ml-4 text-sm">
              Last update: {lastUpdate.toLocaleTimeString()}
            </span>
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setLastUpdate(new Date())}
            className="border-old-money-navy text-old-money-navy"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button
            onClick={handleBinanceClick}
            className="bg-old-money-gold hover:bg-old-money-gold-light text-old-money-navy font-bold"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Trade on Binance + $100 Bonus
          </Button>
        </div>
      </div>

      {/* Breaking News Ticker */}
      {breakingNews.length > 0 && (
        <Card className="border-old-money-burgundy border-2 bg-gradient-to-r from-old-money-burgundy/10 to-old-money-burgundy/5">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Badge className="bg-old-money-burgundy text-old-money-cream animate-pulse">
                <Zap className="w-3 h-3 mr-1" />
                BREAKING
              </Badge>
              <ScrollArea className="flex-1 h-8">
                <div className="flex items-center gap-8 animate-scroll">
                  {breakingNews.map((item, index) => (
                    <div key={item.id} className="flex items-center gap-2 whitespace-nowrap">
                      <span className="font-medium text-old-money-navy">{item.title}</span>
                      {index < breakingNews.length - 1 && (
                        <span className="text-old-money-warm-gray">•</span>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Enhanced Stats Dashboard */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="border-old-money-beige bg-old-money-navy/5">
          <CardContent className="p-4 text-center">
            <Newspaper className="w-6 h-6 mx-auto mb-2 text-old-money-navy" />
            <div className="text-2xl font-bold text-old-money-navy">{stats.total}</div>
            <div className="text-sm text-old-money-warm-gray">Articles Today</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige bg-old-money-sage/10">
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-6 h-6 mx-auto mb-2 text-old-money-sage" />
            <div className="text-2xl font-bold text-old-money-sage">{stats.bullish}</div>
            <div className="text-sm text-old-money-warm-gray">Bullish News</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige bg-old-money-gold/10">
          <CardContent className="p-4 text-center">
            <Target className="w-6 h-6 mx-auto mb-2 text-old-money-gold" />
            <div className="text-2xl font-bold text-old-money-gold">{stats.withSignals}</div>
            <div className="text-sm text-old-money-warm-gray">With Signals</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige bg-old-money-burgundy/10">
          <CardContent className="p-4 text-center">
            <Flame className="w-6 h-6 mx-auto mb-2 text-old-money-burgundy" />
            <div className="text-2xl font-bold text-old-money-burgundy">{stats.hot}</div>
            <div className="text-sm text-old-money-warm-gray">Hot Stories</div>
          </CardContent>
        </Card>
        
        <Card className="border-old-money-beige bg-old-money-charcoal/10">
          <CardContent className="p-4 text-center">
            <Eye className="w-6 h-6 mx-auto mb-2 text-old-money-charcoal" />
            <div className="text-2xl font-bold text-old-money-charcoal">{stats.totalViews.toLocaleString()}</div>
            <div className="text-sm text-old-money-warm-gray">Total Views</div>
          </CardContent>
        </Card>
      </div>

      {/* Enhanced Search and Filters */}
      <div className="space-y-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-old-money-warm-gray" />
              <Input
                placeholder="Search news, coins, topics, or sources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-2 border-old-money-warm-gray focus:border-old-money-gold text-lg py-3"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant={showOnlyHot ? 'default' : 'outline'}
              onClick={() => setShowOnlyHot(!showOnlyHot)}
              className={showOnlyHot ? 'bg-old-money-burgundy text-old-money-cream' : 'border-old-money-warm-gray'}
            >
              <Flame className="w-4 h-4 mr-1" />
              Hot Only
            </Button>
            
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-2 border border-old-money-warm-gray rounded-md bg-white text-old-money-navy"
            >
              <option value="latest">Latest</option>
              <option value="trending">Trending</option>
              <option value="popular">Most Popular</option>
            </select>
          </div>
        </div>
        
        {/* Category Filters */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className={`whitespace-nowrap flex items-center gap-2 ${
                selectedCategory === category.id 
                  ? 'bg-old-money-navy text-old-money-cream' 
                  : 'border-old-money-warm-gray text-old-money-navy hover:bg-old-money-cream-dark'
              }`}
            >
              <category.icon className="w-4 h-4" />
              {category.name}
              {category.id !== 'all' && (
                <Badge variant="secondary" className="text-xs ml-1">
                  {newsItems.filter(item => item.category === category.id).length}
                </Badge>
              )}
            </Button>
          ))}
        </div>
      </div>

      <Tabs defaultValue="latest" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-md bg-old-money-cream-dark border border-old-money-beige">
          <TabsTrigger value="latest" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Latest News
          </TabsTrigger>
          <TabsTrigger value="trending" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Trending
          </TabsTrigger>
          <TabsTrigger value="bookmarks" className="data-[state=active]:bg-old-money-navy data-[state=active]:text-old-money-cream">
            Bookmarks ({newsItems.filter(item => item.isBookmarked).length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="latest" className="space-y-6">
          {/* Featured News */}
          {featuredNews.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-old-money-navy flex items-center gap-2">
                  <Star className="w-5 h-5 text-old-money-gold" />
                  Featured Stories
                </h3>
                <Badge className="bg-old-money-sage text-old-money-cream">
                  Top {featuredNews.length}
                </Badge>
              </div>
              
              <div className="grid lg:grid-cols-3 gap-6">
                {featuredNews.map((item) => (
                  <Card key={item.id} className={`border-old-money-beige hover:shadow-xl transition-all duration-300 ${item.isHot ? 'border-old-money-gold border-2' : ''}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <Badge className={getCategoryColor(item.category)}>
                            {item.category.toUpperCase()}
                          </Badge>
                          {item.isHot && (
                            <Badge className="bg-old-money-burgundy text-old-money-cream">
                              <Flame className="w-3 h-3 mr-1" />
                              HOT
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          {getImportanceIcon(item.importance)}
                          <div className={`flex items-center gap-1 ${getSentimentColor(item.sentiment)}`}>
                            {getSentimentIcon(item.sentiment)}
                            <span className="text-xs capitalize">{item.sentiment}</span>
                          </div>
                        </div>
                      </div>
                      <CardTitle className="text-lg leading-tight hover:text-old-money-sage cursor-pointer transition-colors">
                        {item.title}
                      </CardTitle>
                    </CardHeader>
                    
                    <CardContent>
                      <p className="text-old-money-warm-gray text-sm mb-4 line-clamp-3">
                        {item.summary}
                      </p>
                      
                      {/* Trading Signal */}
                      {item.tradingSignal && (
                        <div className="bg-old-money-sage/10 border border-old-money-sage/30 rounded-lg p-3 mb-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Brain className="w-4 h-4 text-old-money-sage" />
                              <span className="text-sm font-bold text-old-money-navy">
                                AI SIGNAL: {item.tradingSignal.type.toUpperCase()} {item.tradingSignal.coin}
                              </span>
                            </div>
                            <Badge className="bg-old-money-sage text-old-money-cream text-xs">
                              {item.tradingSignal.confidence}%
                            </Badge>
                          </div>
                          {item.tradingSignal.target && (
                            <div className="text-xs text-old-money-navy">
                              Target: ${item.tradingSignal.target.toLocaleString()} • 
                              Stop: ${item.tradingSignal.stopLoss?.toLocaleString()}
                            </div>
                          )}
                        </div>
                      )}
                      
                      {/* Price Impact */}
                      {item.priceImpact && (
                        <div className="bg-old-money-gold/10 border border-old-money-gold/30 rounded-lg p-3 mb-4">
                          <div className="flex items-center gap-2 mb-1">
                            <BarChart3 className="w-4 h-4 text-old-money-gold" />
                            <span className="text-sm font-medium text-old-money-navy">Price Impact</span>
                          </div>
                          <div className="text-xs text-old-money-navy">
                            Expected {item.priceImpact.expectedMove > 0 ? '+' : ''}{item.priceImpact.expectedMove}% 
                            for {item.priceImpact.coins.join(', ')} • {item.priceImpact.timeframe}
                          </div>
                        </div>
                      )}
                      
                      {/* Tags */}
                      <div className="flex flex-wrap gap-1 mb-4">
                        {item.tags.slice(0, 4).map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs border-old-money-warm-gray text-old-money-warm-gray">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      {/* Meta Info */}
                      <div className="flex items-center justify-between text-xs text-old-money-warm-gray mb-4">
                        <div className="flex items-center gap-3">
                          <span className="font-medium">{item.source}</span>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(item.publishedAt).toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {item.readTime} min read
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between text-xs text-old-money-warm-gray mb-4">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            {item.views.toLocaleString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageCircle className="w-3 h-3" />
                            {item.comments}
                          </div>
                        </div>
                      </div>
                      
                      {/* Actions */}
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          className="bg-old-money-navy hover:bg-old-money-navy-light text-old-money-cream flex-1"
                        >
                          Read Full Article
                          <ArrowRight className="w-3 h-3 ml-1" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleBookmark(item.id)}
                          className={`border-old-money-warm-gray ${
                            item.isBookmarked ? 'bg-old-money-sage text-old-money-cream' : 'text-old-money-warm-gray hover:bg-old-money-cream-dark'
                          }`}
                        >
                          <Bookmark className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleShare(item)}
                          className="border-old-money-warm-gray text-old-money-warm-gray hover:bg-old-money-cream-dark"
                        >
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Regular News List */}
          {regularNews.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-old-money-navy flex items-center gap-2">
                  <Newspaper className="w-5 h-5 text-old-money-burgundy" />
                  Latest Updates
                </h3>
                <span className="text-sm text-old-money-warm-gray">
                  {regularNews.length} more articles
                </span>
              </div>
              
              <div className="space-y-4">
                {regularNews.map((item) => (
                  <Card key={item.id} className={`border-old-money-beige hover:shadow-lg transition-all ${item.isHot ? 'border-l-4 border-l-old-money-gold' : ''}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={getCategoryColor(item.category)} variant="outline">
                              {item.category}
                            </Badge>
                            <div className={`flex items-center gap-1 ${getSentimentColor(item.sentiment)}`}>
                              {getSentimentIcon(item.sentiment)}
                              <span className="text-xs">{item.sentiment}</span>
                            </div>
                            {item.isHot && (
                              <Badge className="bg-old-money-burgundy text-old-money-cream">
                                <Flame className="w-3 h-3 mr-1" />
                                HOT
                              </Badge>
                            )}
                            {item.tradingSignal && (
                              <Badge className="bg-old-money-sage text-old-money-cream text-xs">
                                Signal: {item.tradingSignal.type.toUpperCase()}
                              </Badge>
                            )}
                            {getImportanceIcon(item.importance)}
                          </div>
                          
                          <h4 className="font-bold text-old-money-navy mb-2 hover:text-old-money-sage cursor-pointer transition-colors text-lg">
                            {item.title}
                          </h4>
                          
                          <p className="text-old-money-warm-gray text-sm mb-3 leading-relaxed">
                            {item.summary}
                          </p>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-xs text-old-money-warm-gray">
                              <span className="font-medium">{item.source}</span>
                              <div className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(item.publishedAt).toLocaleDateString()} • {item.readTime} min
                              </div>
                              <div className="flex items-center gap-1">
                                <Eye className="w-3 h-3" />
                                {item.views.toLocaleString()}
                              </div>
                              <div className="flex items-center gap-1">
                                <MessageCircle className="w-3 h-3" />
                                {item.comments}
                              </div>
                            </div>
                            
                            <div className="flex gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleBookmark(item.id)}
                                className={item.isBookmarked ? 'text-old-money-sage' : 'text-old-money-warm-gray'}
                              >
                                <Bookmark className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleShare(item)}
                                className="text-old-money-warm-gray"
                              >
                                <Share2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* No Results */}
          {filteredNews.length === 0 && (
            <div className="text-center py-12">
              <Newspaper className="w-16 h-16 text-old-money-warm-gray mx-auto mb-4" />
              <h3 className="text-xl font-medium text-old-money-navy mb-2">No news found</h3>
              <p className="text-old-money-warm-gray mb-4">No articles match your current filters</p>
              <Button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                  setShowOnlyHot(false);
                }}
                className="bg-old-money-sage hover:bg-old-money-sage-light text-old-money-cream"
              >
                Reset All Filters
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="trending">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-old-money-navy flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-old-money-sage" />
              Trending Stories
            </h3>
            
            {filteredNews
              .sort((a, b) => (b.views + b.comments * 10) - (a.views + a.comments * 10))
              .slice(0, 10)
              .map((item, index) => (
                <Card key={item.id} className="border-old-money-beige">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-8 h-8 bg-old-money-sage rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-old-money-cream font-bold text-sm">#{index + 1}</span>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-old-money-navy mb-2">{item.title}</h4>
                        <div className="flex items-center gap-4 text-xs text-old-money-warm-gray">
                          <span>{item.source}</span>
                          <div className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            {item.views.toLocaleString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageCircle className="w-3 h-3" />
                            {item.comments}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="bookmarks">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-old-money-navy flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-old-money-gold" />
              Your Bookmarks
            </h3>
            
            {newsItems.filter(item => item.isBookmarked).length === 0 ? (
              <div className="text-center py-12">
                <Bookmark className="w-16 h-16 text-old-money-warm-gray mx-auto mb-4" />
                <h3 className="text-xl font-medium text-old-money-navy mb-2">No bookmarks yet</h3>
                <p className="text-old-money-warm-gray">Bookmark articles to read them later</p>
              </div>
            ) : (
              newsItems.filter(item => item.isBookmarked).map((item) => (
                <Card key={item.id} className="border-old-money-beige">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className={getCategoryColor(item.category)} variant="outline">
                            {item.category}
                          </Badge>
                          <span className="text-xs text-old-money-warm-gray">
                            {new Date(item.publishedAt).toLocaleDateString()}
                          </span>
                        </div>
                        <h4 className="font-medium text-old-money-navy mb-1">{item.title}</h4>
                        <p className="text-old-money-warm-gray text-sm">{item.summary}</p>
                      </div>
                      <Button
                        variant="ghost"
                        onClick={() => handleBookmark(item.id)}
                        className="text-old-money-sage"
                      >
                        <Bookmark className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Enhanced Binance CTA */}
      <Card className="bg-gradient-to-r from-old-money-gold/10 via-old-money-sage/10 to-old-money-burgundy/10 border-2 border-old-money-gold">
        <CardContent className="p-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-old-money-gold to-old-money-gold-light rounded-full flex items-center justify-center">
                <DollarSign className="w-8 h-8 text-old-money-navy" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-old-money-navy mb-2">
                  📰 News → 💰 Profits
                </h3>
                <p className="text-old-money-warm-gray text-lg">
                  Turn breaking news into trading opportunities. Start with $100 FREE bonus on Binance!
                </p>
                <div className="flex items-center gap-4 mt-2 text-sm text-old-money-navy">
                  <span>✅ Real-time market reaction</span>
                  <span>✅ AI trading signals</span>
                  <span>✅ $100 instant bonus</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-3">
              <Button
                size="lg"
                onClick={handleBinanceClick}
                className="bg-gradient-to-r from-old-money-gold to-old-money-gold-light hover:from-old-money-gold-light hover:to-old-money-gold text-old-money-navy font-bold px-8 py-4"
              >
                <Gift className="w-6 h-6 mr-3" />
                Claim $100 + Start Trading
                <ExternalLink className="w-5 h-5 ml-2" />
              </Button>
              <div className="text-center text-xs text-old-money-warm-gray">
                Join 125M+ traders worldwide
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default CryptoNewsFeed;