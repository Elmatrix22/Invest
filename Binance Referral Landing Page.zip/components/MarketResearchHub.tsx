import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Globe, Target, Brain, Zap, Award, Rocket, Shield, DollarSign, ChevronRight, Calendar, User, Eye, Download, Star, Filter } from 'lucide-react';

interface ResearchReport {
  id: string;
  title: string;
  summary: string;
  category: 'market-analysis' | 'business-plan' | 'investment-guide' | 'trend-report' | 'regulatory-update' | 'technology-deep-dive';
  publishDate: string;
  author: string;
  readTime: number;
  downloads: number;
  rating: number;
  premium: boolean;
  tags: string[];
  marketCap?: string;
  roi?: string;
  riskLevel: 'low' | 'medium' | 'high';
  imageUrl: string;
  pdfUrl?: string;
}

interface MarketResearchHubProps {
  translations: any;
  binanceReferralUrl: string;
  user: any;
  onShowAuthModal: () => void;
}

export default function MarketResearchHub({
  translations,
  binanceReferralUrl,
  user,
  onShowAuthModal
}: MarketResearchHubProps) {
  const [reports, setReports] = useState<ResearchReport[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'popular' | 'rating'>('latest');
  const [showPremiumOnly, setShowPremiumOnly] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadResearchReports();
  }, []);

  const loadResearchReports = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const currentReports = generateCurrentResearchReports();
    setReports(currentReports);
    setIsLoading(false);
  };

  const generateCurrentResearchReports = (): ResearchReport[] => {
    return [
      {
        id: 'crypto-market-outlook-2025',
        title: 'Cryptocurrency Market Outlook 2025: $10 Trillion Market Cap Prediction',
        summary: 'Comprehensive analysis of crypto market trajectories, institutional adoption patterns, and regulatory developments shaping the $10T market by 2025.',
        category: 'market-analysis',
        publishDate: '2024-12-19',
        author: 'Dr. Michael Zhang, CFA',
        readTime: 45,
        downloads: 15420,
        rating: 4.9,
        premium: true,
        tags: ['Market Outlook', 'Institutional Adoption', '2025 Predictions', 'Bitcoin ETF'],
        marketCap: '$10.2T',
        roi: '340%',
        riskLevel: 'medium',
        imageUrl: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&h=600&fit=crop',
        pdfUrl: '#'
      },
      {
        id: 'ai-trading-business-plan',
        title: 'AI Trading Platform Business Plan: $50M Revenue Blueprint',
        summary: 'Complete business plan for launching an AI-powered trading platform, including market analysis, technical architecture, and revenue projections.',
        category: 'business-plan',
        publishDate: '2024-12-18',
        author: 'Sarah Kim, MBA',
        readTime: 60,
        downloads: 8950,
        rating: 4.8,
        premium: true,
        tags: ['AI Trading', 'Business Plan', 'FinTech', 'Revenue Model'],
        marketCap: '$50M',
        roi: '450%',
        riskLevel: 'high',
        imageUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=600&fit=crop',
        pdfUrl: '#'
      },
      {
        id: 'defi-investment-guide-2025',
        title: 'DeFi Investment Guide 2025: Navigate $500B Ecosystem Safely',
        summary: 'Strategic guide to DeFi investing covering yield farming, liquidity mining, governance tokens, and risk management in the expanding DeFi landscape.',
        category: 'investment-guide',
        publishDate: '2024-12-17',
        author: 'Alex Rodriguez, CFA',
        readTime: 35,
        downloads: 12300,
        rating: 4.7,
        premium: false,
        tags: ['DeFi', 'Yield Farming', 'Investment Strategy', 'Risk Management'],
        marketCap: '$500B',
        roi: '180%',
        riskLevel: 'high',
        imageUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&h=600&fit=crop',
        pdfUrl: '#'
      },
      {
        id: 'memecoin-trend-analysis',
        title: 'Memecoin Phenomenon: $100B Market Psychology & Investment Thesis',
        summary: 'Deep dive into memecoin market dynamics, social sentiment analysis, and strategic approaches to the $100B memecoin ecosystem.',
        category: 'trend-report',
        publishDate: '2024-12-16',
        author: 'Dr. Lisa Chang, PhD',
        readTime: 25,
        downloads: 18750,
        rating: 4.6,
        premium: false,
        tags: ['Memecoins', 'Market Psychology', 'Social Trading', 'Viral Marketing'],
        marketCap: '$100B',
        roi: '250%',
        riskLevel: 'high',
        imageUrl: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?w=800&h=600&fit=crop',
        pdfUrl: '#'
      },
      {
        id: 'sec-crypto-regulation-2024',
        title: 'SEC Crypto Regulation Framework 2024: Complete Compliance Guide',
        summary: 'Comprehensive analysis of new SEC regulations, compliance requirements, and strategic implications for crypto businesses and investors.',
        category: 'regulatory-update',
        publishDate: '2024-12-15',
        author: 'Jennifer Walsh, JD',
        readTime: 40,
        downloads: 9420,
        rating: 4.8,
        premium: true,
        tags: ['SEC Regulation', 'Compliance', 'Legal Framework', 'Policy Analysis'],
        riskLevel: 'low',
        imageUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&h=600&fit=crop',
        pdfUrl: '#'
      },
      {
        id: 'quantum-computing-blockchain',
        title: 'Quantum Computing Impact on Blockchain: Technical Deep Dive',
        summary: 'Technical analysis of quantum computing threats to current blockchain infrastructure and emerging quantum-resistant solutions.',
        category: 'technology-deep-dive',
        publishDate: '2024-12-14',
        author: 'Prof. Robert Chen, PhD',
        readTime: 55,
        downloads: 6850,
        rating: 4.9,
        premium: true,
        tags: ['Quantum Computing', 'Blockchain Security', 'Cryptography', 'Future Tech'],
        riskLevel: 'medium',
        imageUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&h=600&fit=crop',
        pdfUrl: '#'
      },
      {
        id: 'layer2-scaling-investment',
        title: 'Layer-2 Scaling Solutions: $20B Investment Opportunity Analysis',
        summary: 'Investment analysis of Layer-2 scaling solutions including Arbitrum, Optimism, Polygon, and emerging technologies.',
        category: 'investment-guide',
        publishDate: '2024-12-13',
        author: 'David Park, CFA',
        readTime: 30,
        downloads: 11200,
        rating: 4.7,
        premium: false,
        tags: ['Layer-2', 'Scaling Solutions', 'Investment Analysis', 'Arbitrum'],
        marketCap: '$20B',
        roi: '320%',
        riskLevel: 'medium',
        imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=600&fit=crop',
        pdfUrl: '#'
      },
      {
        id: 'institutional-crypto-adoption',
        title: 'Institutional Crypto Adoption 2025: $5T Asset Allocation Shift',
        summary: 'Analysis of institutional crypto adoption trends, regulatory catalysts, and the projected $5 trillion asset allocation shift.',
        category: 'market-analysis',
        publishDate: '2024-12-12',
        author: 'Marcus Thompson, CFA',
        readTime: 50,
        downloads: 13680,
        rating: 4.8,
        premium: true,
        tags: ['Institutional Adoption', 'Asset Allocation', 'Bitcoin ETF', 'Wall Street'],
        marketCap: '$5T',
        roi: '280%',
        riskLevel: 'low',
        imageUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=800&h=600&fit=crop',
        pdfUrl: '#'
      },
      {
        id: 'cbdc-business-impact',
        title: 'Central Bank Digital Currencies: Business Impact & Strategy Guide',
        summary: 'Strategic analysis of CBDC rollouts worldwide and their impact on traditional finance, crypto markets, and business operations.',
        category: 'business-plan',
        publishDate: '2024-12-11',
        author: 'Emma Rodriguez, MBA',
        readTime: 38,
        downloads: 7560,
        rating: 4.6,
        premium: false,
        tags: ['CBDC', 'Central Banks', 'Business Strategy', 'Digital Currency'],
        riskLevel: 'medium',
        imageUrl: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=800&h=600&fit=crop',
        pdfUrl: '#'
      },
      {
        id: 'green-crypto-mining-plan',
        title: 'Sustainable Crypto Mining: $100M Green Energy Business Plan',
        summary: 'Complete business plan for sustainable cryptocurrency mining operations using renewable energy and carbon-negative technologies.',
        category: 'business-plan',
        publishDate: '2024-12-10',
        author: 'Dr. Green Miller, PhD',
        readTime: 65,
        downloads: 5420,
        rating: 4.7,
        premium: true,
        tags: ['Green Mining', 'Sustainability', 'Business Plan', 'Renewable Energy'],
        marketCap: '$100M',
        roi: '190%',
        riskLevel: 'medium',
        imageUrl: 'https://images.unsplash.com/photo-1466611653911-95081537e5b7?w=800&h=600&fit=crop',
        pdfUrl: '#'
      }
    ];
  };

  const filteredReports = reports.filter(report => {
    const matchesCategory = selectedCategory === 'all' || report.category === selectedCategory;
    const matchesPremium = !showPremiumOnly || report.premium;
    return matchesCategory && matchesPremium;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'popular':
        return b.downloads - a.downloads;
      case 'rating':
        return b.rating - a.rating;
      case 'latest':
      default:
        return new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime();
    }
  });

  const categories = [
    { id: 'all', name: 'All Reports', icon: Globe },
    { id: 'market-analysis', name: 'Market Analysis', icon: BarChart3 },
    { id: 'business-plan', name: 'Business Plans', icon: Target },
    { id: 'investment-guide', name: 'Investment Guides', icon: DollarSign },
    { id: 'trend-report', name: 'Trend Reports', icon: TrendingUp },
    { id: 'regulatory-update', name: 'Regulatory', icon: Shield },
    { id: 'technology-deep-dive', name: 'Technology', icon: Brain }
  ];

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-success-green bg-success-green/10';
      case 'medium': return 'text-warning-amber bg-warning-amber/10';
      case 'high': return 'text-danger-coral bg-danger-coral/10';
      default: return 'text-warm-slate bg-warm-slate/10';
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'market-analysis': 'text-soft-teal bg-soft-teal/10',
      'business-plan': 'text-success-green bg-success-green/10',
      'investment-guide': 'text-warning-amber bg-warning-amber/10',
      'trend-report': 'text-danger-coral bg-danger-coral/10',
      'regulatory-update': 'text-subtle-lavender bg-subtle-lavender/10',
      'technology-deep-dive': 'text-deep-ocean bg-deep-ocean/10'
    };
    return colors[category] || 'text-warm-slate bg-warm-slate/10';
  };

  const handleDownload = (report: ResearchReport) => {
    if (report.premium && !user) {
      onShowAuthModal();
      return;
    }
    
    // Simulate download
    console.log(`Downloading ${report.title}`);
    // In real implementation, this would trigger actual download
  };

  return (
    <div className="space-y-6">
      {/* Enhanced Header */}
      <div className="page-header">
        <div className="page-badge">
          📊 Professional Market Research 2025
        </div>
        <h1 className="page-title">
          Market Research & Business Intelligence
        </h1>
        <p className="page-subtitle">
          Comprehensive market analysis, business plans, and investment guides from leading industry experts. Data-driven insights for strategic decision making.
        </p>
      </div>

      {/* Featured Research Banner */}
      <div className="ai-signal-section">
        <div className="ai-signal-content">
          <div className="ai-signal-header">
            <div className="ai-signal-icon">
              <Award className="w-6 h-6 text-pearl-white" />
            </div>
            <div>
              <h2 className="ai-signal-title">
                🏆 Featured Research: Crypto Market $10T Outlook
              </h2>
              <p className="ai-signal-subtitle">
                Professional-grade market analysis • 45-page detailed report • 15K+ downloads
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Controls */}
      <div className="page-section">
        <div className="flex flex-wrap gap-4 items-center justify-between mb-6">
          <div className="flex flex-wrap gap-2">
            {categories.map(category => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                    selectedCategory === category.id
                      ? 'bg-soft-teal text-pearl-white'
                      : 'bg-pearl-gray text-charcoal hover:bg-soft-teal/10'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {category.name}
                </button>
              );
            })}
          </div>
          
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={showPremiumOnly}
                onChange={(e) => setShowPremiumOnly(e.target.checked)}
                className="rounded border-warm-slate/30 text-soft-teal focus:ring-soft-teal"
              />
              Premium Only
            </label>
            
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="form-input text-deep-navy"
            >
              <option value="latest">Latest Reports</option>
              <option value="popular">Most Downloaded</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>
        </div>

        {/* Research Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-soft-teal">{filteredReports.length}</div>
            <div className="text-sm text-warm-slate">Reports</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-success-green">{filteredReports.filter(r => r.premium).length}</div>
            <div className="text-sm text-warm-slate">Premium</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-warning-amber">
              {Math.round(filteredReports.reduce((sum, r) => sum + r.downloads, 0) / 1000)}K
            </div>
            <div className="text-sm text-warm-slate">Downloads</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-subtle-lavender">
              {(filteredReports.reduce((sum, r) => sum + r.rating, 0) / filteredReports.length).toFixed(1)}
            </div>
            <div className="text-sm text-warm-slate">Avg Rating</div>
          </div>
        </div>
      </div>

      {/* Research Reports Grid */}
      {isLoading ? (
        <div className="page-section text-center py-12">
          <div className="w-8 h-8 border-2 border-soft-teal border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-warm-slate">Loading market research reports...</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          {filteredReports.map((report) => (
            <div key={report.id} className="card-modern overflow-hidden group">
              <div className="relative">
                <img
                  src={report.imageUrl}
                  alt={report.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${getCategoryColor(report.category)}`}>
                    {report.category.replace('-', ' ').toUpperCase()}
                  </span>
                </div>
                {report.premium && (
                  <div className="absolute top-4 right-4">
                    <span className="bg-warning-amber text-pearl-white px-3 py-1 rounded-full text-xs font-bold">
                      <Star className="w-3 h-3 inline mr-1" />
                      PREMIUM
                    </span>
                  </div>
                )}
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getRiskColor(report.riskLevel)}`}>
                      {report.riskLevel.toUpperCase()} RISK
                    </span>
                    <div className="flex items-center gap-1 text-xs text-warning-amber">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-3 h-3 ${i < Math.floor(report.rating) ? 'fill-current' : ''}`} />
                      ))}
                      <span className="ml-1 font-medium">{report.rating}</span>
                    </div>
                  </div>
                  <div className="text-xs text-warm-slate">
                    {report.readTime} min read
                  </div>
                </div>
                
                <h3 className="text-lg font-bold text-deep-ocean mb-3 group-hover:text-soft-teal transition-colors line-clamp-2">
                  {report.title}
                </h3>
                
                <p className="text-sm text-warm-slate mb-4 line-clamp-3">
                  {report.summary}
                </p>
                
                {/* Key Metrics */}
                {(report.marketCap || report.roi) && (
                  <div className="grid grid-cols-2 gap-3 mb-4 p-3 bg-pearl-gray rounded-lg">
                    {report.marketCap && (
                      <div className="text-center">
                        <div className="text-sm font-bold text-soft-teal">{report.marketCap}</div>
                        <div className="text-xs text-warm-slate">Market Cap</div>
                      </div>
                    )}
                    {report.roi && (
                      <div className="text-center">
                        <div className="text-sm font-bold text-success-green">{report.roi}</div>
                        <div className="text-xs text-warm-slate">Projected ROI</div>
                      </div>
                    )}
                  </div>
                )}
                
                <div className="flex items-center justify-between text-xs text-warm-slate mb-4">
                  <div className="flex items-center gap-1">
                    <User className="w-3 h-3" />
                    {report.author}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <Download className="w-3 h-3" />
                      {(report.downloads / 1000).toFixed(1)}K
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(report.publishDate).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex flex-wrap gap-1">
                    {report.tags.slice(0, 2).map((tag, index) => (
                      <span key={index} className="text-xs bg-pearl-gray text-charcoal px-2 py-1 rounded">
                        #{tag}
                      </span>
                    ))}
                  </div>
                  
                  <button
                    onClick={() => handleDownload(report)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                      report.premium && !user
                        ? 'bg-warning-amber text-pearl-white hover:bg-warning-amber/90'
                        : 'bg-soft-teal text-pearl-white hover:bg-soft-teal-dark'
                    }`}
                  >
                    <Download className="w-4 h-4" />
                    {report.premium && !user ? 'Get Access' : 'Download'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Premium Research CTA */}
      {!user && (
        <div className="page-section text-center">
          <h3 className="text-2xl font-bold text-deep-ocean mb-4">
            Access Premium Research & Business Plans
          </h3>
          <p className="text-warm-slate mb-6 max-w-2xl mx-auto">
            Join our professional community for unlimited access to premium market research, detailed business plans, and exclusive investment guides from industry experts.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={onShowAuthModal}
              className="btn-teal text-lg px-8 py-4 shadow-glow hover:shadow-deep transition-all duration-300 transform hover:scale-105"
            >
              <Award className="w-5 h-5" />
              Get Premium Access
            </button>
            <button
              onClick={() => window.open(binanceReferralUrl, '_blank')}
              className="btn-primary text-lg px-8 py-4"
            >
              <Rocket className="w-5 h-5" />
              Start Trading
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-soft-teal/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                <BarChart3 className="w-8 h-8 text-soft-teal" />
              </div>
              <h4 className="font-bold text-deep-ocean mb-2">Professional Analysis</h4>
              <p className="text-sm text-warm-slate">40+ page detailed reports from certified analysts</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-success-green/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Target className="w-8 h-8 text-success-green" />
              </div>
              <h4 className="font-bold text-deep-ocean mb-2">Business Templates</h4>
              <p className="text-sm text-warm-slate">Ready-to-use business plans and financial models</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-warning-amber/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Brain className="w-8 h-8 text-warning-amber" />
              </div>
              <h4 className="font-bold text-deep-ocean mb-2">Expert Insights</h4>
              <p className="text-sm text-warm-slate">Exclusive research from leading industry experts</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}