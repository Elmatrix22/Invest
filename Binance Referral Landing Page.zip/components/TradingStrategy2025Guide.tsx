import React, { useState } from 'react';
import { Brain, TrendingUp, Target, Shield, Zap, BarChart3, Activity, Clock, Award, CheckCircle, AlertTriangle, Star } from 'lucide-react';

interface Strategy2025GuideProps {
  isOpen: boolean;
  onClose: () => void;
  translations: any;
}

export default function TradingStrategy2025Guide({ isOpen, onClose, translations }: Strategy2025GuideProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'strategies' | 'binary' | 'risk'>('overview');

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content max-w-4xl" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 bg-deep-navy p-6 border-b border-soft-teal/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-r from-soft-teal to-soft-teal-light rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-pearl-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-pearl-white">
                  Trading Strategies 2025 Guide
                </h2>
                <p className="text-pearl-white/80">
                  Master our advanced AI trading methodologies
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-soft-teal/20 text-pearl-white hover:bg-soft-teal/30 transition-colors"
            >
              ×
            </button>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex gap-2 mt-6">
            {[
              { id: 'overview', label: 'Overview', icon: Brain },
              { id: 'strategies', label: 'AI Strategies', icon: TrendingUp },
              { id: 'binary', label: 'Binary Options', icon: Clock },
              { id: 'risk', label: 'Risk Management', icon: Shield }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                    activeTab === tab.id
                      ? 'bg-soft-teal text-deep-navy'
                      : 'text-pearl-white/80 hover:bg-soft-teal/20'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-6 text-pearl-white max-h-96 overflow-y-auto">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Star className="w-5 h-5 text-soft-teal" />
                  2025 Trading Revolution
                </h3>
                <p className="text-pearl-white/90 mb-4">
                  Our platform uses cutting-edge AI algorithms that combine multiple proven trading strategies to deliver accurate, profitable signals. Here's what makes our 2025 approach unique:
                </p>
                
                <div className="grid gap-4">
                  <div className="bg-deep-ocean/50 p-4 rounded-lg">
                    <h4 className="font-bold text-soft-teal mb-2">🧠 Multi-Strategy AI Ensemble</h4>
                    <p className="text-sm text-pearl-white/80">
                      Our AI combines momentum trading, smart grid algorithms, and multi-timeframe confluence analysis for maximum accuracy.
                    </p>
                  </div>
                  
                  <div className="bg-deep-ocean/50 p-4 rounded-lg">
                    <h4 className="font-bold text-soft-teal mb-2">📊 Real-Time Market Analysis</h4>
                    <p className="text-sm text-pearl-white/80">
                      Live data feeds from multiple exchanges ensure our signals are based on the most current market conditions.
                    </p>
                  </div>
                  
                  <div className="bg-deep-ocean/50 p-4 rounded-lg">
                    <h4 className="font-bold text-soft-teal mb-2">🎯 Verified Performance</h4>
                    <p className="text-sm text-pearl-white/80">
                      78.5% win rate with transparent tracking. Every signal is monitored and results are publicly verified.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-bold mb-3">Key Benefits for 2025:</h4>
                <ul className="space-y-2 text-sm text-pearl-white/90">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-success-green" />
                    Advanced risk management with precise stop-losses
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-success-green" />
                    Beginner-friendly binary options for daily trading
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-success-green" />
                    Multi-asset coverage: Crypto, Forex, Stocks, Commodities
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-success-green" />
                    Real-time signal updates every 2 minutes
                  </li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'strategies' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-soft-teal" />
                Advanced AI Trading Strategies
              </h3>
              
              <div className="space-y-4">
                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3 flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    1. AI-Enhanced Momentum Trading
                  </h4>
                  <p className="text-sm text-pearl-white/90 mb-3">
                    Our flagship strategy combines RSI, MACD, and volume analysis with machine learning to identify high-probability momentum shifts.
                  </p>
                  <div className="text-xs text-pearl-white/70">
                    <strong>Best for:</strong> Crypto and volatile forex pairs<br/>
                    <strong>Timeframes:</strong> 15m, 1h, 4h<br/>
                    <strong>Win Rate:</strong> 82% (verified)<br/>
                    <strong>Risk Level:</strong> Low to Medium
                  </div>
                </div>

                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    2. Smart Grid Trading with AI
                  </h4>
                  <p className="text-sm text-pearl-white/90 mb-3">
                    Advanced grid algorithm that identifies support/resistance levels and places strategic trades at optimal price zones.
                  </p>
                  <div className="text-xs text-pearl-white/70">
                    <strong>Best for:</strong> Range-bound markets, Forex majors<br/>
                    <strong>Timeframes:</strong> 1h, 4h, 1d<br/>
                    <strong>Win Rate:</strong> 76% (verified)<br/>
                    <strong>Risk Level:</strong> Low
                  </div>
                </div>

                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3 flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    3. Multi-Timeframe Confluence
                  </h4>
                  <p className="text-sm text-pearl-white/90 mb-3">
                    Analyzes trends across multiple timeframes (5m to 1d) to find high-confluence entry points with maximum probability.
                  </p>
                  <div className="text-xs text-pearl-white/70">
                    <strong>Best for:</strong> All markets, swing trading<br/>
                    <strong>Timeframes:</strong> Multiple (5m-1d analysis)<br/>
                    <strong>Win Rate:</strong> 79% (verified)<br/>
                    <strong>Risk Level:</strong> Low to Medium
                  </div>
                </div>
              </div>

              <div className="bg-warning-amber/20 p-4 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-warning-amber flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <strong className="text-warning-amber">Pro Tip:</strong> Our AI automatically selects the best strategy for current market conditions. The ensemble method combines all three for maximum accuracy.
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'binary' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5 text-soft-teal" />
                Binary Options for Beginners
              </h3>
              
              <div className="bg-success-green/20 p-4 rounded-lg">
                <h4 className="font-bold text-success-green mb-2">🎯 Perfect for Daily Trading</h4>
                <p className="text-sm text-pearl-white/90">
                  Binary options offer a simple way to profit from short-term price movements. Our AI identifies high-probability setups with clear CALL/PUT signals.
                </p>
              </div>

              <div className="space-y-4">
                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3">How It Works</h4>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-pearl-white/90">
                    <li>AI analyzes short-term market trends (1-5 minutes)</li>
                    <li>Identifies clear directional momentum</li>
                    <li>Provides CALL (up) or PUT (down) recommendation</li>
                    <li>Shows exact entry price and 5-minute expiry</li>
                    <li>Displays confidence level and payout percentage</li>
                  </ol>
                </div>

                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3">Key Features</h4>
                  <ul className="space-y-2 text-sm text-pearl-white/90">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success-green" />
                      <strong>5-minute expiry:</strong> Quick results, perfect for beginners
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success-green" />
                      <strong>75-90% payout:</strong> High returns on successful trades
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success-green" />
                      <strong>$10 minimum:</strong> Low risk for learning
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success-green" />
                      <strong>70%+ accuracy:</strong> AI-verified performance
                    </li>
                  </ul>
                </div>

                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3">Best Practices</h4>
                  <ul className="space-y-2 text-sm text-pearl-white/90">
                    <li>• Start with $10 trades to learn the system</li>
                    <li>• Only trade signals with 70%+ confidence</li>
                    <li>• Focus on major currency pairs (EUR/USD, GBP/USD)</li>
                    <li>• Avoid trading during major news events</li>
                    <li>• Set daily loss limits and stick to them</li>
                  </ul>
                </div>
              </div>

              <div className="bg-soft-teal/20 p-4 rounded-lg">
                <div className="flex items-start gap-2">
                  <Star className="w-5 h-5 text-soft-teal flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <strong className="text-soft-teal">Success Tip:</strong> Our binary options are designed for beginners. Follow the signals exactly as provided and gradually increase position sizes as you gain confidence.
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'risk' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5 text-soft-teal" />
                Advanced Risk Management
              </h3>
              
              <div className="bg-danger-coral/20 p-4 rounded-lg">
                <h4 className="font-bold text-danger-coral mb-2">⚠️ Risk Warning</h4>
                <p className="text-sm text-pearl-white/90">
                  Trading involves significant risk. Never risk more than you can afford to lose. Our risk management tools help protect your capital.
                </p>
              </div>

              <div className="space-y-4">
                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3">Position Sizing Rules</h4>
                  <ul className="space-y-2 text-sm text-pearl-white/90">
                    <li className="flex items-center gap-2">
                      <Target className="w-4 h-4 text-success-green" />
                      <strong>Conservative:</strong> Risk 1-2% of account per trade
                    </li>
                    <li className="flex items-center gap-2">
                      <Target className="w-4 h-4 text-warning-amber" />
                      <strong>Moderate:</strong> Risk 2-3% of account per trade
                    </li>
                    <li className="flex items-center gap-2">
                      <Target className="w-4 h-4 text-danger-coral" />
                      <strong>Aggressive:</strong> Risk 3-5% of account per trade
                    </li>
                  </ul>
                </div>

                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3">Stop-Loss Strategy</h4>
                  <p className="text-sm text-pearl-white/90 mb-3">
                    Every signal includes precise stop-loss levels calculated by our AI to minimize risk while maximizing profit potential.
                  </p>
                  <ul className="space-y-1 text-xs text-pearl-white/70">
                    <li>• Momentum signals: 1-2% below/above entry</li>
                    <li>• Grid signals: At nearest support/resistance</li>
                    <li>• Confluence signals: Multi-timeframe confirmation</li>
                  </ul>
                </div>

                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3">Portfolio Diversification</h4>
                  <ul className="space-y-2 text-sm text-pearl-white/90">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success-green" />
                      Trade multiple asset classes (crypto, forex, stocks)
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success-green" />
                      Use different timeframes to spread risk
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success-green" />
                      Never put all capital in a single trade
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-success-green" />
                      Maintain 50%+ cash reserves for opportunities
                    </li>
                  </ul>
                </div>

                <div className="bg-deep-ocean/50 p-5 rounded-lg">
                  <h4 className="font-bold text-soft-teal mb-3">Daily Limits</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <strong className="text-pearl-white">Beginner:</strong>
                      <ul className="text-pearl-white/70 text-xs mt-1">
                        <li>• Max 3 trades per day</li>
                        <li>• Max 5% daily risk</li>
                        <li>• Stop at 2 losses</li>
                      </ul>
                    </div>
                    <div>
                      <strong className="text-pearl-white">Experienced:</strong>
                      <ul className="text-pearl-white/70 text-xs mt-1">
                        <li>• Max 5 trades per day</li>
                        <li>• Max 10% daily risk</li>
                        <li>• Stop at 3 losses</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-success-green/20 p-4 rounded-lg">
                <div className="flex items-start gap-2">
                  <Award className="w-5 h-5 text-success-green flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <strong className="text-success-green">Remember:</strong> Successful trading is about consistency, not big wins. Our risk management ensures you can trade profitably for years, not just days.
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="sticky bottom-0 bg-deep-navy p-6 border-t border-soft-teal/20">
          <div className="flex justify-between items-center">
            <div className="text-sm text-pearl-white/70">
              Always trade responsibly and within your means
            </div>
            <button
              onClick={onClose}
              className="btn-teal px-6 py-2"
            >
              Start Trading
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}