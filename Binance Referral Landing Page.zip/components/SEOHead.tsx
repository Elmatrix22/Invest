import React from 'react';

export interface SEOHeadProps {
  title: string;
  description: string;
  keywords?: string;
  canonicalUrl?: string;
  ogImage?: string;
  ogType?: 'website' | 'article' | 'profile';
  articlePublishedTime?: string;
  articleModifiedTime?: string;
  articleAuthor?: string;
  articleSection?: string;
  articleTags?: string[];
  twitterCard?: 'summary' | 'summary_large_image' | 'app' | 'player';
  twitterSite?: string;
  twitterCreator?: string;
  noIndex?: boolean;
  noFollow?: boolean;
  schemaData?: object[];
  alternateLanguages?: { lang: string; url: string }[];
  robots?: string;
  viewport?: string;
  lang?: string;
}

export function SEOHead({
  title,
  description,
  keywords = 'free trading signals, crypto signals, forex signals, AI trading, investment community, crypto trading, financial markets, technical analysis',
  canonicalUrl = 'https://invest-free.com/',
  ogImage = 'https://invest-free.com/images/og-image-main.jpg',
  ogType = 'website',
  articlePublishedTime,
  articleModifiedTime,
  articleAuthor,
  articleSection,
  articleTags = [],
  twitterCard = 'summary_large_image',
  twitterSite = '@InvestFreecom',
  twitterCreator = '@InvestFreecom',
  noIndex = false,
  noFollow = false,
  schemaData = [],
  alternateLanguages = [],
  robots,
  viewport = 'width=device-width, initial-scale=1.0, maximum-scale=5.0',
  lang = 'en'
}: SEOHeadProps) {
  
  // Clean and optimize title
  const cleanTitle = title.length > 60 ? title.substring(0, 57) + '...' : title;
  const fullTitle = title.includes('Invest-Free.com') ? title : `${title} | Invest-Free.com`;
  
  // Clean and optimize description
  const cleanDescription = description.length > 160 ? description.substring(0, 157) + '...' : description;
  
  // Generate robots directive
  const robotsDirective = robots || `${noIndex ? 'noindex' : 'index'}, ${noFollow ? 'nofollow' : 'follow'}, max-snippet:-1, max-image-preview:large, max-video-preview:-1`;
  
  // Default structured data for the organization
  const defaultSchemaData = [
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Invest-Free.com",
      "description": "Free cryptocurrency trading signals, AI-powered market analysis, and investment community platform",
      "url": "https://invest-free.com",
      "logo": {
        "@type": "ImageObject",
        "url": "https://invest-free.com/images/logo-512.png",
        "width": 512,
        "height": 512
      },
      "foundingDate": "2024",
      "founder": {
        "@type": "Organization",
        "name": "Invest-Free Team"
      },
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+1-555-INVEST",
        "contactType": "customer service",
        "email": "support@invest-free.com",
        "availableLanguage": ["English", "Spanish", "French", "German", "Italian", "Portuguese", "Russian", "Chinese", "Japanese", "Korean"]
      },
      "sameAs": [
        "https://twitter.com/InvestFreecom",
        "https://t.me/investfreecom",
        "https://discord.gg/investfree",
        "https://youtube.com/@investfreecom"
      ],
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Trading Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Free Crypto Trading Signals",
              "description": "AI-powered cryptocurrency trading signals with 90%+ accuracy"
            },
            "price": "0",
            "priceCurrency": "USD"
          },
          {
            "@type": "Offer", 
            "itemOffered": {
              "@type": "Service",
              "name": "Forex Trading Signals",
              "description": "Professional forex market analysis and trading recommendations"
            },
            "price": "0",
            "priceCurrency": "USD"
          }
        ]
      }
    },
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "Invest-Free.com",
      "description": "Free trading signals and investment community platform",
      "url": "https://invest-free.com",
      "potentialAction": {
        "@type": "SearchAction",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://invest-free.com/search?q={search_term_string}"
        },
        "query-input": "required name=search_term_string"
      },
      "publisher": {
        "@type": "Organization",
        "name": "Invest-Free.com",
        "logo": {
          "@type": "ImageObject",
          "url": "https://invest-free.com/images/logo-512.png"
        }
      }
    }
  ];

  // Financial service schema
  const financialServiceSchema = {
    "@context": "https://schema.org",
    "@type": "FinancialService",
    "name": "Invest-Free Trading Platform",
    "description": "Free cryptocurrency and forex trading signals with AI-powered market analysis",
    "url": "https://invest-free.com",
    "serviceType": "Investment Advisory",
    "areaServed": "Worldwide",
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "Trading Signals",
      "itemListElement": [
        {
          "@type": "Service",
          "name": "Cryptocurrency Signals",
          "description": "Real-time crypto trading signals with technical analysis"
        },
        {
          "@type": "Service", 
          "name": "Forex Signals",
          "description": "Foreign exchange trading recommendations"
        },
        {
          "@type": "Service",
          "name": "AI Market Analysis",
          "description": "Artificial intelligence powered market predictions"
        }
      ]
    }
  };

  // Combine all schema data
  const allSchemaData = [...defaultSchemaData, financialServiceSchema, ...schemaData];

  return (
    <>
      {/* Basic Meta Tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={cleanDescription} />
      <meta name="keywords" content={keywords} />
      <meta name="robots" content={robotsDirective} />
      <meta name="viewport" content={viewport} />
      <meta httpEquiv="Content-Language" content={lang} />
      <meta name="language" content={lang} />
      
      {/* Canonical URL */}
      <link rel="canonical" href={canonicalUrl} />
      
      {/* Alternate Language Links */}
      {alternateLanguages.map(({ lang: altLang, url }) => (
        <link key={altLang} rel="alternate" hrefLang={altLang} href={url} />
      ))}
      
      {/* Open Graph Meta Tags */}
      <meta property="og:type" content={ogType} />
      <meta property="og:title" content={cleanTitle} />
      <meta property="og:description" content={cleanDescription} />
      <meta property="og:url" content={canonicalUrl} />
      <meta property="og:image" content={ogImage} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:image:alt" content={`${title} - Invest-Free.com Trading Platform`} />
      <meta property="og:site_name" content="Invest-Free.com" />
      <meta property="og:locale" content={lang === 'en' ? 'en_US' : `${lang}_${lang.toUpperCase()}`} />
      
      {/* Article specific Open Graph tags */}
      {ogType === 'article' && (
        <>
          {articlePublishedTime && (
            <meta property="article:published_time" content={articlePublishedTime} />
          )}
          {articleModifiedTime && (
            <meta property="article:modified_time" content={articleModifiedTime} />
          )}
          {articleAuthor && (
            <meta property="article:author" content={articleAuthor} />
          )}
          {articleSection && (
            <meta property="article:section" content={articleSection} />
          )}
          {articleTags.map((tag, index) => (
            <meta key={index} property="article:tag" content={tag} />
          ))}
        </>
      )}
      
      {/* Twitter Card Meta Tags */}
      <meta name="twitter:card" content={twitterCard} />
      <meta name="twitter:site" content={twitterSite} />
      <meta name="twitter:creator" content={twitterCreator} />
      <meta name="twitter:title" content={cleanTitle} />
      <meta name="twitter:description" content={cleanDescription} />
      <meta name="twitter:image" content={ogImage} />
      <meta name="twitter:image:alt" content={`${title} - Free Trading Signals`} />
      
      {/* Additional SEO Meta Tags */}
      <meta name="author" content="Invest-Free.com Team" />
      <meta name="copyright" content="© 2024 Invest-Free.com" />
      <meta name="application-name" content="Invest-Free" />
      <meta name="apple-mobile-web-app-title" content="Invest-Free" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      <meta name="mobile-web-app-capable" content="yes" />
      <meta name="theme-color" content="#4ecdc4" />
      <meta name="msapplication-TileColor" content="#4ecdc4" />
      <meta name="msapplication-config" content="/browserconfig.xml" />
      
      {/* Favicon and Icons */}
      <link rel="icon" type="image/x-icon" href="/favicon.ico" />
      <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
      <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
      <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
      <link rel="manifest" href="/site.webmanifest" />
      
      {/* DNS Prefetch and Preconnect for Performance */}
      <link rel="dns-prefetch" href="//fonts.googleapis.com" />
      <link rel="dns-prefetch" href="//api.binance.com" />
      <link rel="dns-prefetch" href="//cdn.jsdelivr.net" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      
      {/* Google Search Console Verification */}
      <meta name="google-site-verification" content="your-google-verification-code" />
      
      {/* Bing Webmaster Tools Verification */}
      <meta name="msvalidate.01" content="your-bing-verification-code" />
      
      {/* Yandex Verification */}
      <meta name="yandex-verification" content="your-yandex-verification-code" />
      
      {/* Structured Data (JSON-LD) */}
      {allSchemaData.map((schema, index) => (
        <script
          key={index}
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(schema, null, 0)
          }}
        />
      ))}
      
      {/* Additional Performance Hints */}
      <link rel="prefetch" href="/signals" />
      <link rel="prefetch" href="/community" />
      <link rel="prefetch" href="/education" />
      
      {/* Security Headers */}
      <meta httpEquiv="X-Content-Type-Options" content="nosniff" />
      <meta httpEquiv="X-Frame-Options" content="DENY" />
      <meta httpEquiv="X-XSS-Protection" content="1; mode=block" />
      <meta httpEquiv="Referrer-Policy" content="strict-origin-when-cross-origin" />
      
      {/* Cache Control */}
      <meta httpEquiv="Cache-Control" content="public, max-age=3600" />
      
      {/* Geographic Targeting */}
      <meta name="geo.region" content="US" />
      <meta name="geo.placename" content="Global" />
      <meta name="ICBM" content="40.7128, -74.0060" />
      
      {/* Business Information */}
      <meta name="contact" content="support@invest-free.com" />
      <meta name="category" content="Finance, Trading, Cryptocurrency, Investment" />
      <meta name="coverage" content="Worldwide" />
      <meta name="distribution" content="Global" />
      <meta name="rating" content="General" />
    </>
  );
}

// Helper function to generate page-specific SEO data
export function generatePageSEO(pageType: string, customData?: Partial<SEOHeadProps>): SEOHeadProps {
  const baseUrl = 'https://invest-free.com';
  
  const seoData: Record<string, SEOHeadProps> = {
    home: {
      title: 'Free Crypto Trading Signals & AI Investment Community 2025',
      description: 'Get live crypto, forex & stock trading signals powered by AI analysis. Join thousands of investors sharing profitable ideas. 100% free platform with $100 signup bonus.',
      keywords: 'free trading signals, crypto signals, forex signals, AI trading, investment community, trading platform, cryptocurrency trading, technical analysis, market predictions',
      canonicalUrl: `${baseUrl}/`,
      ogImage: `${baseUrl}/images/og-home.jpg`,
      schemaData: [
        {
          "@context": "https://schema.org",
          "@type": "WebApplication",
          "name": "Invest-Free Trading Platform",
          "description": "Free trading signals and investment community",
          "applicationCategory": "FinanceApplication",
          "operatingSystem": "Web Browser",
          "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
          }
        }
      ]
    },
    
    signals: {
      title: 'Free AI Trading Signals - Crypto, Forex & Stock Signals 2025',
      description: 'Access live trading signals with 90%+ accuracy. AI-powered analysis for crypto, forex, stocks & commodities. Real-time alerts with stop-loss and take-profit levels.',
      keywords: 'trading signals, crypto signals, forex signals, AI signals, live signals, technical analysis, market signals, trading alerts, stop loss, take profit',
      canonicalUrl: `${baseUrl}/signals`,
      ogImage: `${baseUrl}/images/og-signals.jpg`,
      schemaData: [
        {
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "AI Trading Signals",
          "description": "Free trading signals with artificial intelligence analysis",
          "provider": {
            "@type": "Organization",
            "name": "Invest-Free.com"
          },
          "hasOfferCatalog": {
            "@type": "OfferCatalog",
            "name": "Signal Types",
            "itemListElement": [
              {
                "@type": "Offer",
                "itemOffered": {
                  "@type": "Service",
                  "name": "Cryptocurrency Signals"
                }
              },
              {
                "@type": "Offer",
                "itemOffered": {
                  "@type": "Service", 
                  "name": "Forex Signals"
                }
              }
            ]
          }
        }
      ]
    },
    
    community: {
      title: 'Investment Community & Trading Ideas - Share & Discover 2025',
      description: 'Join thousands of traders sharing investment ideas, market insights, and trading strategies. Connect with experienced investors and discover profitable opportunities.',
      keywords: 'investment community, trading ideas, investor network, market insights, trading strategies, social trading, investment forum, trader community',
      canonicalUrl: `${baseUrl}/community`,
      ogImage: `${baseUrl}/images/og-community.jpg`
    },
    
    education: {
      title: 'Free Trading Education & Learning Resources 2025',
      description: 'Learn crypto trading, forex basics, technical analysis, and risk management. Comprehensive guides, tutorials, and educational content for all skill levels.',
      keywords: 'trading education, crypto trading guide, forex basics, technical analysis, trading tutorial, investment learning, trading strategies, market education',
      canonicalUrl: `${baseUrl}/education`,
      ogImage: `${baseUrl}/images/og-education.jpg`
    },
    
    news: {
      title: 'Latest Crypto & Financial Market News 2025',
      description: 'Stay updated with breaking cryptocurrency news, market analysis, regulatory updates, and financial insights. Real-time news affecting trading decisions.',
      keywords: 'crypto news, financial news, market analysis, cryptocurrency updates, blockchain news, trading news, market insights, financial markets',
      canonicalUrl: `${baseUrl}/news`,
      ogImage: `${baseUrl}/images/og-news.jpg`
    }
  };
  
  const baseSEO = seoData[pageType] || seoData.home;
  
  return {
    ...baseSEO,
    ...customData
  };
}

export default SEOHead;