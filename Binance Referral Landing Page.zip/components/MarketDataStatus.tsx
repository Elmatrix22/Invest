import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { AlertTriangle, RefreshCw, CheckCircle, Clock, Database } from 'lucide-react';
import { MarketDataState, marketDataService } from '../utils/marketDataService';

interface MarketDataStatusProps {
  marketData: MarketDataState;
  onRefresh: () => void;
}

export function MarketDataStatus({ marketData, onRefresh }: MarketDataStatusProps) {
  const validation = marketDataService.validatePriceData();
  const priceCount = Object.keys(marketData.prices).length;
  const lastUpdateTime = new Date(marketData.lastUpdate).toLocaleTimeString();
  
  if (marketData.errors.length > 0 || !validation.isValid) {
    return (
      <Alert className="border-old-money-burgundy bg-old-money-burgundy/10 mb-4">
        <AlertTriangle className="w-4 h-4" />
        <AlertDescription className="text-old-money-navy flex items-center justify-between">
          <div>
            <div className="font-medium">Market Data Issues Detected</div>
            <div className="text-sm text-old-money-warm-gray mt-1">
              {marketData.errors.length > 0 && `API Errors: ${marketData.errors.join(', ')}`}
              {validation.issues.length > 0 && `Validation: ${validation.issues.join(', ')}`}
            </div>
          </div>
          <Button 
            onClick={onRefresh}
            size="sm"
            variant="outline"
            className="border-old-money-burgundy text-old-money-burgundy hover:bg-old-money-burgundy hover:text-old-money-cream"
          >
            <RefreshCw className="w-3 h-3 mr-1" />
            Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Alert className="border-old-money-sage bg-old-money-sage/10 mb-4">
      <CheckCircle className="w-4 h-4" />
      <AlertDescription className="text-old-money-navy flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Database className="w-3 h-3" />
            <span className="font-medium">{priceCount} Live Prices</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span className="text-sm">Updated: {lastUpdateTime}</span>
          </div>
        </div>
        <div className="text-xs text-old-money-sage">
          ✅ All systems operational
        </div>
      </AlertDescription>
    </Alert>
  );
}