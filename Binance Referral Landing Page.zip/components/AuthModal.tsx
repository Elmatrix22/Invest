import { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  X, 
  Mail, 
  Lock, 
  User, 
  Eye, 
  EyeOff,
  Sparkles,
  ExternalLink,
  Zap,
  TrendingUp
} from 'lucide-react';
import { toast } from "sonner@2.0.3";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: any) => void;
  translations: any;
  binanceReferralUrl: string;
}

export default function AuthModal({
  isOpen,
  onClose,
  onAuthSuccess,
  translations: t,
  binanceReferralUrl
}: AuthModalProps) {
  const [activeTab, setActiveTab] = useState('register');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Basic validation
      if (activeTab === 'register') {
        if (!formData.name || !formData.email || !formData.password) {
          toast.error('Please fill in all required fields');
          return;
        }
        if (formData.password !== formData.confirmPassword) {
          toast.error('Passwords do not match');
          return;
        }
        if (formData.password.length < 6) {
          toast.error('Password must be at least 6 characters');
          return;
        }
      } else {
        if (!formData.email || !formData.password) {
          toast.error('Please enter your email and password');
          return;
        }
      }

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Mock successful auth
      const mockUser = {
        id: Date.now(),
        name: formData.name || 'Premium Member',
        email: formData.email,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${formData.email}`,
        isPremium: true,
        joinedDate: new Date().toISOString(),
        tradingLevel: 'Advanced',
        totalSignals: 247,
        successRate: 84
      };

      onAuthSuccess(mockUser);
      toast.success(`🎉 Welcome ${activeTab === 'register' ? 'to the community' : 'back'}!`);
    } catch (error) {
      toast.error('Authentication failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialLogin = (provider: string) => {
    setIsLoading(true);
    toast.info(`${provider} login coming soon!`);
    
    // Mock social login success after delay
    setTimeout(() => {
      const mockUser = {
        id: Date.now(),
        name: `${provider} User`,
        email: `user@${provider.toLowerCase()}.com`,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${provider}`,
        isPremium: true,
        joinedDate: new Date().toISOString(),
        tradingLevel: 'Advanced',
        totalSignals: 247,
        successRate: 84
      };
      
      onAuthSuccess(mockUser);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-deep-navy rounded-3xl shadow-deep max-w-md w-full max-h-[90vh] overflow-y-auto border border-soft-teal/20">
        
        {/* Header */}
        <div className="relative p-8 pb-6">
          <button
            onClick={onClose}
            className="absolute top-6 right-6 p-2 text-pearl-white/70 hover:text-pearl-white hover:bg-pearl-white/10 rounded-xl transition-all duration-200"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-soft-teal to-soft-teal-light rounded-2xl flex items-center justify-center mx-auto mb-4 animate-float shadow-glow-dark">
              <TrendingUp className="w-8 h-8 text-pearl-white" />
            </div>
            
            <h2 className="text-2xl font-bold text-pearl-white mb-2">
              Join Invest-Free<span className="text-soft-teal">.com</span>
            </h2>
            
            <div className="flex items-center justify-center gap-3 mb-2">
              <div className="inline-flex items-center gap-2 bg-soft-teal/20 border border-soft-teal/30 rounded-full px-4 py-2">
                <Sparkles className="w-4 h-4 text-soft-teal animate-pulse" />
                <span className="text-pearl-white text-sm font-semibold">Free AI Trading Platform</span>
                <Badge className="bg-soft-teal text-deep-navy text-xs font-bold animate-bounce">
                  LIVE NOW
                </Badge>
              </div>
            </div>
            
            <p className="text-pearl-white/80 text-sm">
              Get access to FREE AI trading signals and join our community
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-8">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-deep-ocean/50 border border-soft-teal/20 rounded-2xl p-1">
              <TabsTrigger 
                value="register"
                className="data-[state=active]:bg-soft-teal data-[state=active]:text-deep-navy text-pearl-white/80 font-semibold rounded-xl transition-all duration-200"
              >
                Register
              </TabsTrigger>
              <TabsTrigger 
                value="login"
                className="data-[state=active]:bg-soft-teal data-[state=active]:text-deep-navy text-pearl-white/80 font-semibold rounded-xl transition-all duration-200"
              >
                Login
              </TabsTrigger>
            </TabsList>

            {/* Social Login Buttons */}
            <div className="mt-6 space-y-3">
              <Button
                onClick={() => handleSocialLogin('Google')}
                disabled={isLoading}
                className="w-full bg-pearl-white hover:bg-pearl-white/90 text-deep-navy font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-3 transition-all duration-200 hover:shadow-medium"
              >
                <div className="w-5 h-5 bg-gradient-to-r from-blue-500 to-red-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs font-bold">G</span>
                </div>
                Continue with Google
                <Badge className="bg-soft-teal/20 text-soft-teal text-xs font-bold border-0">
                  Instant
                </Badge>
              </Button>

              <div className="grid grid-cols-2 gap-3">
                <Button
                  onClick={() => handleSocialLogin('Apple')}
                  disabled={isLoading}
                  className="bg-charcoal hover:bg-charcoal-light text-pearl-white font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all duration-200"
                >
                  <div className="w-5 h-5 bg-pearl-white rounded-sm flex items-center justify-center">
                    <span className="text-black text-xs font-bold">🍎</span>
                  </div>
                  Apple
                </Button>
                
                <Button
                  onClick={() => handleSocialLogin('Twitter')}
                  disabled={isLoading}
                  className="bg-blue-500 hover:bg-blue-600 text-pearl-white font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all duration-200"
                >
                  <div className="w-5 h-5 bg-pearl-white rounded-sm flex items-center justify-center">
                    <span className="text-blue-500 text-xs font-bold">𝕏</span>
                  </div>
                  Twitter
                </Button>
              </div>
            </div>

            {/* Divider */}
            <div className="flex items-center my-6">
              <div className="flex-1 border-t border-pearl-white/20"></div>
              <span className="px-4 text-pearl-white/60 text-sm">or continue with email</span>
              <div className="flex-1 border-t border-pearl-white/20"></div>
            </div>

            {/* Form Content */}
            <TabsContent value="register" className="mt-0">
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Name Field */}
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-pearl-white/90 font-medium">
                    Full Name
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-pearl-white/50 w-5 h-5" />
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="pl-11 bg-deep-ocean/50 border-2 border-pearl-white/20 text-pearl-white placeholder:text-pearl-white/50 rounded-xl h-12 focus:border-soft-teal focus:ring-2 focus:ring-soft-teal/20"
                      required
                    />
                  </div>
                </div>

                {/* Email Field */}
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-pearl-white/90 font-medium">
                    Email Address
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-pearl-white/50 w-5 h-5" />
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="Enter your email address"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="pl-11 bg-deep-ocean/50 border-2 border-pearl-white/20 text-pearl-white placeholder:text-pearl-white/50 rounded-xl h-12 focus:border-soft-teal focus:ring-2 focus:ring-soft-teal/20"
                      required
                    />
                  </div>
                </div>

                {/* Password Field */}
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-pearl-white/90 font-medium">
                    Create a password (min 6 characters)
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-pearl-white/50 w-5 h-5" />
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Create a strong password"
                      value={formData.password}
                      onChange={handleInputChange}
                      className="pl-11 pr-11 bg-deep-ocean/50 border-2 border-pearl-white/20 text-pearl-white placeholder:text-pearl-white/50 rounded-xl h-12 focus:border-soft-teal focus:ring-2 focus:ring-soft-teal/20"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-pearl-white/50 hover:text-pearl-white"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Confirm Password Field */}
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-pearl-white/90 font-medium">
                    Confirm Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-pearl-white/50 w-5 h-5" />
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="Confirm your password"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      className="pl-11 pr-11 bg-deep-ocean/50 border-2 border-pearl-white/20 text-pearl-white placeholder:text-pearl-white/50 rounded-xl h-12 focus:border-soft-teal focus:ring-2 focus:ring-soft-teal/20"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-pearl-white/50 hover:text-pearl-white"
                    >
                      {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-soft-teal to-soft-teal-light hover:from-soft-teal-light hover:to-soft-teal text-deep-navy font-bold py-3 px-4 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-glow-dark disabled:opacity-50 disabled:transform-none"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-deep-navy/30 border-t-deep-navy rounded-full animate-spin"></div>
                      Creating Account...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Zap className="w-5 h-5" />
                      Join Invest-Free Community
                    </div>
                  )}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="login" className="mt-0">
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Email Field */}
                <div className="space-y-2">
                  <Label htmlFor="loginEmail" className="text-pearl-white/90 font-medium">
                    Email Address
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-pearl-white/50 w-5 h-5" />
                    <Input
                      id="loginEmail"
                      name="email"
                      type="email"
                      placeholder="Enter your email address"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="pl-11 bg-deep-ocean/50 border-2 border-pearl-white/20 text-pearl-white placeholder:text-pearl-white/50 rounded-xl h-12 focus:border-soft-teal focus:ring-2 focus:ring-soft-teal/20"
                      required
                    />
                  </div>
                </div>

                {/* Password Field */}
                <div className="space-y-2">
                  <Label htmlFor="loginPassword" className="text-pearl-white/90 font-medium">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-pearl-white/50 w-5 h-5" />
                    <Input
                      id="loginPassword"
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Enter your password"
                      value={formData.password}
                      onChange={handleInputChange}
                      className="pl-11 pr-11 bg-deep-ocean/50 border-2 border-pearl-white/20 text-pearl-white placeholder:text-pearl-white/50 rounded-xl h-12 focus:border-soft-teal focus:ring-2 focus:ring-soft-teal/20"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-pearl-white/50 hover:text-pearl-white"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <input
                      id="remember"
                      type="checkbox"
                      className="h-4 w-4 text-soft-teal focus:ring-soft-teal border-pearl-white/30 rounded bg-deep-ocean/50"
                    />
                    <label htmlFor="remember" className="ml-2 block text-sm text-pearl-white/80">
                      Remember me
                    </label>
                  </div>
                  <button
                    type="button"
                    className="text-sm text-soft-teal hover:text-soft-teal-light transition-colors duration-200"
                  >
                    Forgot password?
                  </button>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-soft-teal to-soft-teal-light hover:from-soft-teal-light hover:to-soft-teal text-deep-navy font-bold py-3 px-4 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-glow-dark disabled:opacity-50 disabled:transform-none"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-deep-navy/30 border-t-deep-navy rounded-full animate-spin"></div>
                      Signing In...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5" />
                      Access Your AI Signals
                    </div>
                  )}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>

        {/* Footer */}
        <div className="p-8 pt-6 border-t border-pearl-white/10 mt-6">
          {/* Binance CTA */}
          <div className="bg-gradient-to-r from-warning-amber/20 to-warning-amber/10 rounded-2xl p-4 mb-6 border border-warning-amber/20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-warning-amber/20 rounded-xl flex items-center justify-center">
                <ExternalLink className="w-6 h-6 text-warning-amber" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-pearl-white text-sm">🎁 $100 Trading Bonus</h4>
                <p className="text-pearl-white/70 text-xs">Get started with our Binance referral bonus</p>
              </div>
              <Button
                onClick={() => window.open(binanceReferralUrl, '_blank')}
                size="sm"
                className="bg-warning-amber hover:bg-warning-amber/90 text-deep-navy font-bold text-xs px-3 py-2 rounded-lg"
              >
                Claim Now
              </Button>
            </div>
          </div>

          {/* Community Stats */}
          <div className="text-center space-y-3">
            <div className="flex items-center justify-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-soft-mint rounded-full animate-pulse"></div>
                <span className="text-pearl-white/80">125k+ Members</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-soft-teal rounded-full animate-pulse"></div>
                <span className="text-pearl-white/80">84% Success Rate</span>
              </div>
            </div>
            
            <p className="text-xs text-pearl-white/60 leading-relaxed">
              By joining, you agree to our Terms of Service and Privacy Policy. 
              <br />
              Start trading with confidence using our AI-powered signals.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}