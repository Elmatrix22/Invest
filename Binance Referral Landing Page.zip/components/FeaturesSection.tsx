import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  Shield, 
  Smartphone, 
  TrendingUp, 
  CreditCard, 
  HeadphonesIcon, 
  GraduationCap,
  Zap,
  Globe,
  Award,
  Lock,
  BarChart3,
  Users
} from 'lucide-react';

interface FeaturesSectionProps {
  translations: any;
}

export function FeaturesSection({ translations }: FeaturesSectionProps) {
  const features = [
    {
      icon: CreditCard,
      title: translations.feature1Title || "Zero Commission Trading",
      description: translations.feature1Description || "Trade stocks, crypto, and ETFs without paying commission fees",
      badge: "Most Popular",
      color: "bg-green-500"
    },
    {
      icon: BarChart3,
      title: translations.feature2Title || "Advanced Analytics",
      description: translations.feature2Description || "Professional-grade charts and market analysis tools",
      badge: "Pro Tools",
      color: "bg-blue-500"
    },
    {
      icon: HeadphonesIcon,
      title: translations.feature3Title || "24/7 Support",
      description: translations.feature3Description || "Round-the-clock customer support in multiple languages",
      badge: "Always Available",
      color: "bg-purple-500"
    },
    {
      icon: Shield,
      title: translations.feature4Title || "Secure Platform",
      description: translations.feature4Description || "Bank-level security with insurance protection",
      badge: "Bank-Level",
      color: "bg-red-500"
    },
    {
      icon: Smartphone,
      title: translations.feature5Title || "Mobile Trading",
      description: translations.feature5Description || "Trade anywhere with our award-winning mobile app",
      badge: "Award-Winning",
      color: "bg-orange-500"
    },
    {
      icon: GraduationCap,
      title: translations.feature6Title || "Educational Resources",
      description: translations.feature6Description || "Free courses, webinars, and market insights",
      badge: "Free Learning",
      color: "bg-indigo-500"
    }
  ];

  const stats = [
    { icon: Users, value: "5M+", label: "Active Users" },
    { icon: Globe, value: "150+", label: "Countries" },
    { icon: Award, value: "50+", label: "Awards Won" },
    { icon: Lock, value: "99.9%", label: "Uptime" }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl text-gray-900">
            {translations.featuresTitle || "Why Choose Invest-Free.com?"}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {translations.featuresSubtitle || "Everything you need to succeed in your investment journey"}
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <stat.icon className="w-6 h-6 text-amber-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Features Grid */}
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 bg-white">
              <CardHeader className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center`}>
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {feature.badge}
                  </Badge>
                </div>
                <div>
                  <CardTitle className="text-lg group-hover:text-amber-600 transition-colors">
                    {feature.title}
                  </CardTitle>
                  <CardDescription className="mt-2">
                    {feature.description}
                  </CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                <Button variant="ghost" className="w-full justify-start group-hover:bg-amber-50 transition-colors">
                  <Zap className="w-4 h-4 mr-2" />
                  {translations.learnMoreBtn || "Learn More"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-amber-500 to-orange-500 rounded-2xl p-8 text-white">
            <h3 className="text-2xl mb-4">Ready to Start Your Investment Journey?</h3>
            <p className="text-amber-100 mb-6 max-w-2xl mx-auto">
              Join millions of investors who trust Invest-Free.com for their financial future
            </p>
            <Button size="lg" className="bg-white text-amber-600 hover:bg-gray-100">
              {translations.getStarted || "Get Started Now"}
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}