import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Gift, 
  ExternalLink, 
  CheckCircle, 
  Clock, 
  Star,
  Shield,
  DollarSign,
  Zap,
  Crown,
  Users,
  TrendingUp,
  Award
} from 'lucide-react';

interface BonusModalProps {
  isOpen: boolean;
  onClose: () => void;
  binanceReferralUrl: string;
}

function BonusModal({ isOpen, onClose, binanceReferralUrl }: BonusModalProps) {
  const [timeLeft, setTimeLeft] = useState({ hours: 23, minutes: 47, seconds: 32 });

  // Simulate countdown timer
  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { hours: prev.hours, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleBinanceClick = () => {
    window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
    onClose();
  };

  const bonusFeatures = [
    {
      icon: DollarSign,
      title: '$100 Instant Bonus',
      description: 'Credited immediately to your account upon successful registration',
      highlight: true
    },
    {
      icon: Zap,
      title: 'Zero Trading Fees',
      description: 'Enjoy the lowest trading fees in the industry (0.1%)',
      highlight: false
    },
    {
      icon: Shield,
      title: 'Secure Platform',
      description: 'Bank-level security with SAFU insurance protection',
      highlight: false
    },
    {
      icon: Crown,
      title: 'VIP Treatment',
      description: 'Access to premium features and priority customer support',
      highlight: false
    },
    {
      icon: Users,
      title: 'Community Access',
      description: 'Join our exclusive trading community with 125k+ members',
      highlight: false
    },
    {
      icon: TrendingUp,
      title: 'AI Trading Signals',
      description: 'Get free access to our 84% accurate trading signals',
      highlight: false
    }
  ];

  const steps = [
    {
      number: 1,
      title: 'Click "Claim Bonus"',
      description: 'Use our exclusive referral link',
      icon: ExternalLink
    },
    {
      number: 2,
      title: 'Sign Up on Binance',
      description: 'Create your free account',
      icon: Users
    },
    {
      number: 3,
      title: 'Get $100 Instantly',
      description: 'Bonus credited automatically',
      icon: Gift
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto border-old-money-gold bg-gradient-to-br from-old-money-cream to-old-money-cream-dark">
        <DialogHeader className="text-center pb-0">
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 bg-gradient-to-br from-old-money-gold to-old-money-gold-light rounded-full flex items-center justify-center shadow-lg">
              <Gift className="w-12 h-12 text-old-money-navy animate-bounce" />
            </div>
          </div>
          
          <Badge className="bg-old-money-burgundy text-old-money-cream text-lg px-4 py-2 mx-auto mb-4">
            🎉 EXCLUSIVE LIMITED OFFER
          </Badge>
          
          <DialogTitle className="text-4xl font-bold text-old-money-navy mb-2">
            Get $100 FREE Bonus!
          </DialogTitle>
          
          <DialogDescription className="text-lg text-old-money-warm-gray">
            Join Binance through our exclusive partnership and receive an instant $100 bonus - no deposit required!
          </DialogDescription>
        </DialogHeader>

        {/* Countdown Timer */}
        <div className="bg-gradient-to-r from-old-money-burgundy to-old-money-sage text-old-money-cream rounded-xl p-6 my-6">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Clock className="w-6 h-6" />
            <span className="text-xl font-bold">Offer Expires In:</span>
          </div>
          <div className="flex justify-center gap-4 text-center">
            <div className="bg-old-money-cream/20 rounded-lg p-3">
              <div className="text-3xl font-bold">{timeLeft.hours.toString().padStart(2, '0')}</div>
              <div className="text-sm">Hours</div>
            </div>
            <div className="bg-old-money-cream/20 rounded-lg p-3">
              <div className="text-3xl font-bold">{timeLeft.minutes.toString().padStart(2, '0')}</div>
              <div className="text-sm">Minutes</div>
            </div>
            <div className="bg-old-money-cream/20 rounded-lg p-3">
              <div className="text-3xl font-bold">{timeLeft.seconds.toString().padStart(2, '0')}</div>
              <div className="text-sm">Seconds</div>
            </div>
          </div>
          <Progress value={Math.random() * 100} className="mt-4 h-2" />
          <div className="text-center text-sm mt-2 opacity-80">
            🔥 Only 247 bonuses remaining!
          </div>
        </div>

        {/* Bonus Features Grid */}
        <div className="grid md:grid-cols-2 gap-4 mb-6">
          {bonusFeatures.map((feature, index) => (
            <div 
              key={index} 
              className={`p-4 rounded-lg border-2 transition-all ${
                feature.highlight 
                  ? 'border-old-money-gold bg-old-money-gold/10 shadow-lg' 
                  : 'border-old-money-beige bg-white'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  feature.highlight 
                    ? 'bg-old-money-gold text-old-money-navy' 
                    : 'bg-old-money-sage text-old-money-cream'
                }`}>
                  <feature.icon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-old-money-navy mb-1">{feature.title}</h4>
                  <p className="text-sm text-old-money-warm-gray">{feature.description}</p>
                  {feature.highlight && (
                    <Badge className="bg-old-money-burgundy text-old-money-cream text-xs mt-2">
                      ⭐ Most Popular
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* How It Works */}
        <div className="bg-old-money-cream-dark rounded-xl p-6 mb-6">
          <h3 className="text-xl font-bold text-old-money-navy mb-4 text-center">
            How to Claim Your $100 Bonus
          </h3>
          <div className="grid md:grid-cols-3 gap-4">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-old-money-navy rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-old-money-gold font-bold text-xl">{step.number}</span>
                </div>
                <step.icon className="w-8 h-8 text-old-money-sage mx-auto mb-2" />
                <h4 className="font-bold text-old-money-navy mb-1">{step.title}</h4>
                <p className="text-sm text-old-money-warm-gray">{step.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Social Proof */}
        <div className="bg-old-money-sage/10 rounded-xl p-6 mb-6">
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div>
              <Award className="w-12 h-12 text-old-money-gold mx-auto mb-2" />
              <div className="text-2xl font-bold text-old-money-navy">125,847</div>
              <div className="text-sm text-old-money-warm-gray">Members Joined</div>
            </div>
            <div>
              <Star className="w-12 h-12 text-old-money-gold mx-auto mb-2" />
              <div className="text-2xl font-bold text-old-money-navy">$2.8M+</div>
              <div className="text-sm text-old-money-warm-gray">Bonuses Claimed</div>
            </div>
            <div>
              <TrendingUp className="w-12 h-12 text-old-money-gold mx-auto mb-2" />
              <div className="text-2xl font-bold text-old-money-navy">84%</div>
              <div className="text-sm text-old-money-warm-gray">Success Rate</div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <Button
            onClick={handleBinanceClick}
            className="bg-gradient-to-r from-old-money-gold to-old-money-gold-light hover:from-old-money-gold-light hover:to-old-money-gold text-old-money-navy font-bold text-xl px-12 py-6 rounded-xl shadow-lg transform hover:scale-105 transition-all mb-4"
          >
            <Gift className="w-8 h-8 mr-4" />
            Claim Your $100 Bonus Now
            <ExternalLink className="w-6 h-6 ml-4" />
          </Button>
          
          <div className="flex items-center justify-center gap-4 text-sm text-old-money-warm-gray">
            <div className="flex items-center gap-1">
              <CheckCircle className="w-4 h-4 text-old-money-sage" />
              <span>No deposit required</span>
            </div>
            <div className="flex items-center gap-1">
              <CheckCircle className="w-4 h-4 text-old-money-sage" />
              <span>Instant bonus</span>
            </div>
            <div className="flex items-center gap-1">
              <CheckCircle className="w-4 h-4 text-old-money-sage" />
              <span>New users only</span>
            </div>
          </div>
          
          <p className="text-xs text-old-money-warm-gray mt-4 opacity-70">
            * Terms and conditions apply. Bonus subject to Binance's promotional terms. 
            This offer is exclusively available through our referral partnership.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default BonusModal;