// Enhanced SEO utilities for comprehensive optimization

export interface BreadcrumbItem {
  name: string;
  url: string;
  position: number;
}

export interface FAQItem {
  question: string;
  answer: string;
}

// Generate breadcrumb structured data
export function generateBreadcrumbSchema(items: BreadcrumbItem[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": items.map(item => ({
      "@type": "ListItem",
      "position": item.position,
      "name": item.name,
      "item": item.url
    }))
  };
}

// Generate FAQ structured data
export function generateFAQSchema(faqs: FAQItem[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqs.map(faq => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  };
}

// Generate article structured data
export function generateArticleSchema({
  headline,
  description,
  image,
  datePublished,
  dateModified,
  author,
  publisher = "Invest-Free.com",
  url
}: {
  headline: string;
  description: string;
  image: string;
  datePublished: string;
  dateModified?: string;
  author: string;
  publisher?: string;
  url: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": headline,
    "description": description,
    "image": [image],
    "datePublished": datePublished,
    "dateModified": dateModified || datePublished,
    "author": {
      "@type": "Person",
      "name": author
    },
    "publisher": {
      "@type": "Organization",
      "name": publisher,
      "logo": {
        "@type": "ImageObject",
        "url": "https://invest-free.com/images/logo-512.png"
      }
    },
    "url": url,
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": url
    }
  };
}

// Generate product/service schema for trading signals
export function generateTradingSignalSchema({
  name,
  description,
  accuracy,
  price = "0",
  category,
  features
}: {
  name: string;
  description: string;
  accuracy: string;
  price?: string;
  category: string;
  features: string[];
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": name,
    "description": description,
    "category": category,
    "provider": {
      "@type": "Organization",
      "name": "Invest-Free.com"
    },
    "offers": {
      "@type": "Offer",
      "price": price,
      "priceCurrency": "USD",
      "availability": "https://schema.org/InStock",
      "validFrom": new Date().toISOString()
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "bestRating": "5",
      "worstRating": "1",
      "ratingCount": "1247"
    },
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "Features",
      "itemListElement": features.map(feature => ({
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": feature
        }
      }))
    },
    "additionalProperty": [
      {
        "@type": "PropertyValue",
        "name": "Accuracy Rate",
        "value": accuracy
      },
      {
        "@type": "PropertyValue",
        "name": "Update Frequency",
        "value": "Real-time"
      }
    ]
  };
}

// Generate review schema
export function generateReviewSchema({
  itemName,
  reviewBody,
  rating,
  author,
  datePublished
}: {
  itemName: string;
  reviewBody: string;
  rating: number;
  author: string;
  datePublished: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Review",
    "itemReviewed": {
      "@type": "Service",
      "name": itemName
    },
    "reviewBody": reviewBody,
    "reviewRating": {
      "@type": "Rating",
      "ratingValue": rating,
      "bestRating": 5,
      "worstRating": 1
    },
    "author": {
      "@type": "Person",
      "name": author
    },
    "datePublished": datePublished
  };
}

// Generate local business schema (if applicable)
export function generateLocalBusinessSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    "name": "Invest-Free.com",
    "description": "Free cryptocurrency and forex trading signals platform",
    "url": "https://invest-free.com",
    "telephone": "+1-555-INVEST",
    "email": "support@invest-free.com",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Global",
      "addressCountry": "Worldwide"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": 40.7128,
      "longitude": -74.0060
    },
    "openingHours": "Mo-Su 00:00-23:59",
    "sameAs": [
      "https://twitter.com/InvestFreecom",
      "https://t.me/investfreecom",
      "https://discord.gg/investfree"
    ],
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "reviewCount": "1247"
    }
  };
}

// Generate course schema for educational content
export function generateCourseSchema({
  name,
  description,
  provider = "Invest-Free.com",
  courseCode,
  hasCourseInstance
}: {
  name: string;
  description: string;
  provider?: string;
  courseCode: string;
  hasCourseInstance: any[];
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Course",
    "name": name,
    "description": description,
    "provider": {
      "@type": "Organization",
      "name": provider
    },
    "courseCode": courseCode,
    "hasCourseInstance": hasCourseInstance
  };
}

// SEO keywords for different sections
export const seoKeywords = {
  crypto: [
    'cryptocurrency trading',
    'bitcoin signals',
    'ethereum trading',
    'altcoin signals',
    'crypto market analysis',
    'blockchain trading',
    'digital currency signals',
    'crypto technical analysis'
  ],
  
  forex: [
    'forex signals',
    'currency trading',
    'foreign exchange',
    'EUR/USD signals',
    'GBP/USD trading',
    'forex market analysis',
    'currency pairs',
    'forex technical analysis'
  ],
  
  stocks: [
    'stock market signals',
    'equity trading',
    'stock analysis',
    'market predictions',
    'trading recommendations',
    'stock picks',
    'market trends',
    'investment signals'
  ],
  
  ai: [
    'AI trading signals',
    'artificial intelligence trading',
    'machine learning analysis',
    'algorithmic trading',
    'automated signals',
    'AI market predictions',
    'smart trading',
    'predictive analytics'
  ],
  
  education: [
    'trading education',
    'investment learning',
    'trading tutorial',
    'market education',
    'trading strategies',
    'technical analysis course',
    'trading basics',
    'investment guide'
  ],
  
  community: [
    'trading community',
    'investment forum',
    'trader network',
    'social trading',
    'investment ideas',
    'trading discussion',
    'market insights',
    'investor community'
  ]
};

// Generate meta keywords for a page
export function generateMetaKeywords(categories: (keyof typeof seoKeywords)[], additionalKeywords: string[] = []) {
  const keywords = categories.flatMap(category => seoKeywords[category] || []);
  return [...keywords, ...additionalKeywords, 'free trading signals', 'invest-free.com'].join(', ');
}

// Optimize text content for SEO
export function optimizeTextForSEO(text: string, targetKeywords: string[]): string {
  let optimizedText = text;
  
  // Ensure target keywords appear naturally
  targetKeywords.forEach(keyword => {
    if (!optimizedText.toLowerCase().includes(keyword.toLowerCase())) {
      // Add keyword naturally to the text
      optimizedText = `${optimizedText} Our platform specializes in ${keyword}.`;
    }
  });
  
  return optimizedText;
}

// Generate canonical URL variations
export function generateCanonicalUrls(basePath: string, languages: string[] = ['en']) {
  const baseUrl = 'https://invest-free.com';
  
  return languages.map(lang => ({
    lang: lang === 'en' ? 'x-default' : lang,
    url: `${baseUrl}${lang === 'en' ? '' : `/${lang}`}${basePath}`
  }));
}

// SEO-friendly URL slug generator
export function generateSEOSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/--+/g, '-')
    .trim()
    .substring(0, 60);
}

// Generate social media sharing URLs
export function generateSocialUrls(url: string, title: string, description: string) {
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);
  const encodedDescription = encodeURIComponent(description);
  
  return {
    twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}&via=InvestFreecom`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
    telegram: `https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}`,
    whatsapp: `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`,
    reddit: `https://reddit.com/submit?url=${encodedUrl}&title=${encodedTitle}`,
    pinterest: `https://pinterest.com/pin/create/button/?url=${encodedUrl}&description=${encodedDescription}`
  };
}

// Performance optimization hints
export const performanceHints = {
  // Critical resources to preload
  criticalResources: [
    '/fonts/inter-var.woff2',
    '/images/hero-bg.webp',
    '/css/critical.css'
  ],
  
  // Resources to prefetch
  prefetchResources: [
    '/signals',
    '/community', 
    '/education',
    '/news'
  ],
  
  // DNS prefetch domains
  dnsPrefetch: [
    'fonts.googleapis.com',
    'fonts.gstatic.com',
    'api.binance.com',
    'cdn.jsdelivr.net'
  ]
};

// Core Web Vitals optimization
export const coreWebVitals = {
  // Largest Contentful Paint (LCP) - target: <2.5s
  lcpOptimization: {
    preloadHeroImage: true,
    optimizeServerResponse: true,
    useWebP: true,
    lazyLoadBelowFold: true
  },
  
  // First Input Delay (FID) - target: <100ms
  fidOptimization: {
    deferNonCriticalJS: true,
    splitLargeJSBundles: true,
    useWebWorkers: true
  },
  
  // Cumulative Layout Shift (CLS) - target: <0.1
  clsOptimization: {
    setImageDimensions: true,
    reserveSpaceForAds: false,
    avoidDynamicContent: true
  }
};

export default {
  generateBreadcrumbSchema,
  generateFAQSchema,
  generateArticleSchema,
  generateTradingSignalSchema,
  generateReviewSchema,
  generateLocalBusinessSchema,
  generateCourseSchema,
  generateMetaKeywords,
  optimizeTextForSEO,
  generateCanonicalUrls,
  generateSEOSlug,
  generateSocialUrls,
  seoKeywords,
  performanceHints,
  coreWebVitals
};