// Trading API utilities for live market data
export interface MarketData {
  symbol: string;
  price: number;
  change24h: number;
  volume: number;
  marketCap?: number;
}

export interface ForexData {
  pair: string;
  rate: number;
  change: number;
  timestamp: string;
}

// Mock CoinGecko API for crypto data
export async function getCryptoData(symbols: string[] = ['bitcoin', 'ethereum', 'solana']): Promise<MarketData[]> {
  // In a real app, you would call: 
  // const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd&include_24hr_change=true&include_market_cap=true');
  
  // Mock data for demo
  const mockData: MarketData[] = [
    {
      symbol: 'BTC',
      price: 99250 + (Math.random() - 0.5) * 2000,
      change24h: 2.5 + (Math.random() - 0.5) * 5,
      volume: 28500000000,
      marketCap: 1950000000000
    },
    {
      symbol: 'ETH',
      price: 3650 + (Math.random() - 0.5) * 200,
      change24h: 1.8 + (Math.random() - 0.5) * 4,
      volume: 15200000000,
      marketCap: 438000000000
    },
    {
      symbol: 'SOL',
      price: 235 + (Math.random() - 0.5) * 20,
      change24h: -0.8 + (Math.random() - 0.5) * 6,
      volume: 2800000000,
      marketCap: 112000000000
    }
  ];

  return new Promise(resolve => {
    setTimeout(() => resolve(mockData), 500);
  });
}

// Mock Alpha Vantage API for forex data
export async function getForexData(pairs: string[] = ['EURUSD', 'GBPUSD', 'USDJPY']): Promise<ForexData[]> {
  // In a real app, you would call Alpha Vantage API:
  // const response = await fetch(`https://www.alphavantage.co/query?function=FX_INTRADAY&from_symbol=EUR&to_symbol=USD&interval=1min&apikey=YOUR_API_KEY`);
  
  // Mock data for demo
  const mockData: ForexData[] = [
    {
      pair: 'EUR/USD',
      rate: 1.0534 + (Math.random() - 0.5) * 0.01,
      change: -0.12 + (Math.random() - 0.5) * 0.5,
      timestamp: new Date().toISOString()
    },
    {
      pair: 'GBP/USD',
      rate: 1.2845 + (Math.random() - 0.5) * 0.02,
      change: 0.08 + (Math.random() - 0.5) * 0.4,
      timestamp: new Date().toISOString()
    },
    {
      pair: 'USD/JPY',
      rate: 149.85 + (Math.random() - 0.5) * 1,
      change: 0.25 + (Math.random() - 0.5) * 0.8,
      timestamp: new Date().toISOString()
    }
  ];

  return new Promise(resolve => {
    setTimeout(() => resolve(mockData), 300);
  });
}

// Generate trading signals based on technical analysis
export function generateTradingSignal(marketData: MarketData | ForexData, type: 'crypto' | 'forex' | 'binary') {
  const isPositive = Math.random() > 0.4; // 60% chance for buy signals
  const confidence = Math.floor(Math.random() * 30) + 65; // 65-95% confidence
  
  const signal = {
    id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
    type,
    action: isPositive ? 'BUY' : 'SELL' as 'BUY' | 'SELL',
    confidence,
    timestamp: new Date().toISOString(),
    status: 'active' as 'active',
    timeframe: ['15M', '1H', '4H', '1D'][Math.floor(Math.random() * 4)]
  };

  if (type === 'crypto' && 'symbol' in marketData) {
    const price = marketData.price;
    return {
      ...signal,
      symbol: `${marketData.symbol}/USDT`,
      asset: getAssetName(marketData.symbol),
      currentPrice: price,
      entryPrice: price * (1 + (Math.random() - 0.5) * 0.005),
      targetPrice: price * (isPositive ? 1.05 : 0.95),
      stopLoss: price * (isPositive ? 0.97 : 1.03),
      reasoning: generateReasoning(marketData.symbol, isPositive, type)
    };
  } else if (type === 'forex' && 'pair' in marketData) {
    const rate = marketData.rate;
    return {
      ...signal,
      symbol: marketData.pair,
      asset: marketData.pair.replace('/', ' '),
      currentPrice: rate,
      entryPrice: rate * (1 + (Math.random() - 0.5) * 0.001),
      targetPrice: rate * (isPositive ? 1.008 : 0.992),
      stopLoss: rate * (isPositive ? 0.995 : 1.005),
      reasoning: generateReasoning(marketData.pair, isPositive, type)
    };
  }

  return null;
}

function getAssetName(symbol: string): string {
  const assetNames: {[key: string]: string} = {
    'BTC': 'Bitcoin',
    'ETH': 'Ethereum', 
    'SOL': 'Solana',
    'ADA': 'Cardano',
    'DOT': 'Polkadot',
    'LINK': 'Chainlink',
    'MATIC': 'Polygon',
    'AVAX': 'Avalanche'
  };
  return assetNames[symbol] || symbol;
}

function generateReasoning(symbol: string, isPositive: boolean, type: 'crypto' | 'forex' | 'binary'): string {
  const bullishReasons = [
    'Strong bullish momentum detected, RSI showing oversold bounce potential',
    'Institutional buying pressure increasing, technical breakout confirmed',
    'Volume surge with positive price action, uptrend continuation likely',
    'Support level holding strong, bullish divergence on indicators',
    'Market sentiment improving, fundamental catalysts supporting upside'
  ];

  const bearishReasons = [
    'Resistance level reached, overbought conditions suggest pullback',
    'Volume declining with price stagnation, bearish divergence forming',
    'Technical indicators showing sell signals, downtrend likely',
    'Market sentiment turning negative, profit-taking pressure building',
    'Key support broken, further downside expected'
  ];

  const reasons = isPositive ? bullishReasons : bearishReasons;
  return reasons[Math.floor(Math.random() * reasons.length)];
}

// Simulate real-time price updates
export function subscribeToPriceUpdates(callback: (data: any) => void) {
  const interval = setInterval(async () => {
    try {
      const cryptoData = await getCryptoData();
      const forexData = await getForexData();
      
      callback({
        crypto: cryptoData,
        forex: forexData,
        timestamp: new Date()
      });
    } catch (error) {
      console.error('Error fetching market data:', error);
    }
  }, 10000); // Update every 10 seconds

  return () => clearInterval(interval);
}

// Calculate signal performance
export function calculateSignalPerformance(signal: any): number {
  const entryPrice = signal.entryPrice;
  const currentPrice = signal.currentPrice;
  const isLong = signal.action === 'BUY';
  
  if (isLong) {
    return ((currentPrice - entryPrice) / entryPrice) * 100;
  } else {
    return ((entryPrice - currentPrice) / entryPrice) * 100;
  }
}

// Signal status updates
export function updateSignalStatus(signal: any): 'active' | 'hit_target' | 'hit_stop' | 'expired' {
  const performance = calculateSignalPerformance(signal);
  const targetPercentage = Math.abs(((signal.targetPrice - signal.entryPrice) / signal.entryPrice) * 100);
  const stopPercentage = Math.abs(((signal.stopLoss - signal.entryPrice) / signal.entryPrice) * 100);
  
  if (Math.abs(performance) >= targetPercentage && performance > 0) {
    return 'hit_target';
  } else if (Math.abs(performance) >= stopPercentage && performance < 0) {
    return 'hit_stop';
  } else if (Date.now() - new Date(signal.timestamp).getTime() > 24 * 60 * 60 * 1000) {
    return 'expired';
  }
  
  return 'active';
}