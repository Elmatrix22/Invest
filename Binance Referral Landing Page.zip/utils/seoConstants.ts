// SEO configuration constants
export const SEO_ALTERNATE_LANGUAGES = [
  { lang: 'x-default', url: 'https://invest-free.com/' },
  { lang: 'en', url: 'https://invest-free.com/' },
  { lang: 'es', url: 'https://invest-free.com/es/' },
  { lang: 'fr', url: 'https://invest-free.com/fr/' },
  { lang: 'de', url: 'https://invest-free.com/de/' },
  { lang: 'it', url: 'https://invest-free.com/it/' },
  { lang: 'pt', url: 'https://invest-free.com/pt/' },
  { lang: 'ru', url: 'https://invest-free.com/ru/' },
  { lang: 'zh', url: 'https://invest-free.com/zh/' },
  { lang: 'ja', url: 'https://invest-free.com/ja/' },
  { lang: 'ko', url: 'https://invest-free.com/ko/' }
];

export const generateAlternateLanguagesForRoute = (route: string) => {
  return SEO_ALTERNATE_LANGUAGES.map(({ lang, url }) => ({
    lang,
    url: route === 'home' ? url : `${url}${route}`
  }));
};