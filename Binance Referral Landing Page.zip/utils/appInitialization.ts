import { marketDataService, MarketDataState } from './marketDataService';
import { detectLanguage } from './languages';
import { setupNotificationInterval } from './appHelpers';
import { toast } from "sonner@2.0.3";

export interface InitializationState {
  marketDataInitialized: boolean;
  initializationError: string | null;
  isLoading: boolean;
}

export async function initializeMarketData(): Promise<MarketDataState> {
  try {
    console.log('🚀 Initializing Invest-Free.com with real-time market data...');
    
    // Show loading toast
    toast.loading('🔄 Fetching real-time market prices...', { 
      id: 'market-init',
      duration: 10000 
    });

    // Fetch market data with timeout
    const marketDataPromise = marketDataService.fetchAllMarketData();
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Market data fetch timeout')), 15000)
    );

    const marketDataResult = await Promise.race([marketDataPromise, timeoutPromise]) as MarketDataState;
    
    // Validate market data quality
    const validation = marketDataService.validatePriceData();
    if (!validation.isValid) {
      console.warn('⚠️ Market data validation issues:', validation.issues);
      toast.warning(`⚠️ Market data quality issues: ${validation.issues.join(', ')}`, {
        id: 'market-init',
        duration: 5000
      });
    } else {
      toast.success(`✅ Live market data loaded - ${Object.keys(marketDataResult.prices).length} prices`, {
        id: 'market-init',
        duration: 3000
      });
    }

    // Start real-time updates every 2 minutes
    marketDataService.startRealTimeUpdates(120000);
    
    console.log(`✅ Market data initialized successfully with ${Object.keys(marketDataResult.prices).length} prices`);
    
    return marketDataResult;
  } catch (error) {
    console.error('❌ Failed to initialize market data:', error);
    
    toast.error('❌ Failed to load real-time prices. Using fallback data.', {
      id: 'market-init',
      duration: 5000
    });
    
    // Return fallback data to prevent complete failure
    throw error;
  }
}

export async function initializeApp(
  user: any,
  setNotifications: React.Dispatch<React.SetStateAction<any[]>>,
  setShowBonusModal: React.Dispatch<React.SetStateAction<boolean>>
): Promise<{ language: string; cleanup: () => void }> {
  try {
    console.log('🎯 Initializing app components...');
    
    const detectedLang = detectLanguage();

    // Setup notification interval
    const notificationInterval = setupNotificationInterval(setNotifications);
    
    // Reduced bonus modal frequency - only show for first-time visitors after 10 seconds
    const hasSeenBonus = localStorage.getItem('hasSeenBonusModal');
    if (!hasSeenBonus && !user) {
      setTimeout(() => {
        setShowBonusModal(true);
        localStorage.setItem('hasSeenBonusModal', 'true');
      }, 10000);
    }

    console.log('✅ App initialization complete');

    // Return cleanup function
    const cleanup = () => clearInterval(notificationInterval);
    
    return { language: detectedLang, cleanup };
  } catch (error) {
    console.error('❌ App initialization error:', error);
    toast.error('App initialization error. Some features may not work correctly.');
    throw error;
  }
}

export function setupPerformanceMonitoring() {
  // Performance optimization: Report web vitals
  if (typeof window !== 'undefined' && 'requestIdleCallback' in window) {
    window.requestIdleCallback(() => {
      // This would integrate with your analytics service
      console.log('📊 App ready for Core Web Vitals measurement');
    });
  }
}

export function createFallbackMarketData(error: Error): MarketDataState {
  return {
    prices: {},
    isLoading: false,
    lastUpdate: Date.now(),
    errors: [error instanceof Error ? error.message : 'Initialization failed']
  };
}