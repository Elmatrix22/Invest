export interface Language {
  code: string;
  name: string;
  flag: string;
  rtl?: boolean;
}

export const languages: Language[] = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'zh', name: '中文', flag: '🇨🇳' },
  { code: 'ru', name: 'Русский', flag: '🇷🇺' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦', rtl: true },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'tr', name: 'Türkçe', flag: '🇹🇷' },
  { code: 'pt', name: 'Português', flag: '🇵🇹' },
  { code: 'hi', name: 'हिंदी', flag: '🇮🇳' },
  { code: 'id', name: 'Bahasa Indonesia', flag: '🇮🇩' },
  { code: 'ko', name: '한국어', flag: '🇰🇷' },
];

export const translations = {
  en: {
    // SEO Meta
    seoTitle: "Free Crypto, Forex & Binary Signals + Investment Community 2025 | Invest-Free.com",
    seoDescription: "Get live trading signals powered by AI analysis + join thousands of investors sharing profitable ideas. 100% free platform for crypto, forex & binary options.",
    seoKeywords: "free trading signals, crypto signals, forex signals, binary options signals, investment community, trading community",
    
    // Navigation
    navCommunity: "Community",
    navIdeas: "Investment Ideas",
    navChat: "Live Chat", 
    navProfile: "My Profile",
    navSignals: "Live Signals",
    navLeaderboard: "Leaderboard",
    navNews: "Market News",
    navBlog: "Business Learning",
    
    // Header
    login: "Login",
    joinNow: "Join Free",
    joinFree: "Join Free",
    claimBinanceBonus: "Claim $100 Bonus",
    verifiedMember: "Verified Member",
    viewProfile: "View Profile",
    accountSettings: "Account Settings",
    profile: "Profile",
    logout: "Sign Out",
    
    // Hero
    heroTitle: "Free Crypto, Forex & Binary Signals + Investment Community",
    heroSubtitle: "Get live trading signals powered by AI analysis + join thousands of investors sharing profitable ideas. 100% free platform.",
    joinCommunity: "Join Free Community",
    postIdea: "Share Your Idea",
    viewLiveSignals: "View Live Signals",
    startTradingBinance: "Start Trading on Binance",
    
    // AI Signals
    aiSignalsTitle: "🚀 Exclusive AI Signal Generator",
    aiSignalsSubtitle: "Real-time market analysis • Institutional-grade signals",
    generateAISignals: "Generate AI Signals",
    updateAISignals: "Update Signals",
    aiSignalsExclusive: "AI Exclusive",
    aiStatus: "AI Status",
    aiReady: "Ready",
    aiProcessing: "Processing...",
    analyzingMarkets: "Analyzing Markets...",
    generationsToday: "generations today",
    nextAutoUpdate: "Next auto-update:",
    lastGenerated: "Last generated:",
    premiumAISignals: "Premium AI Signals:",
    premiumAIDescription: "Register for FREE access to exclusive AI-generated trading signals with 90%+ accuracy rates.",
    loginRequired: "Login required for AI signals",
    generateExclusiveSignals: "Generate exclusive AI trading signals",
    updateLatestData: "Update AI signals with latest market data",
    
    // Signal Types & Categories
    allSignals: "All Signals",
    beginnerSignals: "Beginner",
    professionalSignals: "Professional", 
    hotSignals: "Hot",
    favoriteSignals: "Favorites",
    cryptocurrency: "🪙 Cryptocurrency",
    stocks: "📈 Stocks",
    forex: "💱 Forex",
    commodities: "🥇 Commodities",
    indices: "📊 Indices",
    
    // Signal Details
    signalConfidence: "Confidence",
    signalTarget: "Target",
    riskReward: "Risk/Reward",
    aiAnalysis: "AI Analysis",
    technicalAnalysis: "Technical Analysis:",
    fundamentals: "Fundamentals:",
    stepByStepGuide: "Step-by-Step Guide",
    riskManagement: "Risk Management",
    aiPoweredAnalysis: "AI-Powered Analysis",
    provenResults: "Proven Results",
    
    // Signal Levels
    beginnerLevel: "🟢 Beginner",
    intermediateLevel: "🟡 Intermediate",
    professionalLevel: "🔴 Professional",
    
    // Timeframes
    allTimeframes: "All Timeframes",
    scalpingTimeframe: "⚡ Scalping (1-4h)",
    swingTimeframe: "🎯 Swing (1-14 days)",
    positionTimeframe: "🏛️ Position (weeks-months)",
    
    // Risk Levels
    lowRisk: "Low Risk",
    mediumRisk: "Medium Risk",
    highRisk: "High Risk",
    
    // Trading Actions
    tradeNow: "Trade Now",
    addToFavorites: "Add to Favorites",
    removeFromFavorites: "Remove from Favorites",
    shareSignal: "Share Signal",
    loadMoreSignals: "Load More Signals",
    signalsRemaining: "remaining",
    noSignalsFound: "No Signals Found",
    adjustFilters: "Try adjusting your filters or generate new AI signals.",
    
    // Signal Stats
    totalSignals: "Total Signals",
    aiExclusive: "AI Exclusive",
    winRate: "Win Rate",
    avgReturn: "Avg Return",
    hotSignalsCount: "Hot Signals",
    beginnerSafe: "Beginner Safe",
    professionalTier: "Professional",
    profitToday: "Profit Today",
    
    // Live Signals Banner
    liveSignalsTitle: "Live Trading Signals",
    liveSignalsSubtitle: "Crypto • Forex • Stocks • Commodities",
    aiPowered: "AI Powered",
    realTime: "Real-time",
    freeForever: "Free Forever",
    viewSignals: "View Signals",
    
    // Community Feed
    communityTitle: "Latest Investment Ideas",
    shareIdea: "Share Investment Idea",
    selectCoin: "Select Asset",
    writeAdvice: "Write your investment advice and target...",
    postButton: "Post Idea",
    likes: "Likes",
    comments: "Comments",
    likePost: "Like",
    commentOn: "Comment",
    sharePost: "Share",
    
    // News & Blog
    newsTitle: "Latest Market News",
    blogTitle: "Business Learning Center",
    readMore: "Read More",
    marketAnalysis: "Market Analysis",
    tradingEducation: "Trading Education",
    investmentStrategy: "Investment Strategy",
    
    // Chat
    chatTitle: "Live Investor Chat",
    chatPlaceholder: "Type your message...",
    sendMessage: "Send",
    online: "online",
    live: "Live",
    shareCryptoInsights: "Share crypto insights & help the community!",
    
    // Auth Modal
    welcomeTitle: "Welcome to Invest-Free.com",
    welcomeSubtitle: "Join the world's largest free crypto investment community",
    registerFree: "Register Free",
    continueWithGoogle: "Continue with Google",
    connectingToGoogle: "Connecting to Google...",
    orRegisterWithEmail: "Or register with email",
    orLoginWithEmail: "Or login with email",
    binancePartnership: "Binance Partnership",
    binancePartnershipDesc: "Start trading with the world's #1 exchange",
    startTrading: "Start Trading",
    joinFreeGetAccess: "Join Free & Get Access To:",
    freeInvestmentCommunity: "Free crypto investment community",
    expertPredictions: "Expert predictions and analysis",
    directBinanceAccess: "Direct access to Binance trading",
    liveChatMembers: "Live chat with 125k+ members",
    username: "Username",
    chooseUsername: "Choose a username",
    emailAddress: "Email Address",
    enterEmail: "Enter your email",
    password: "Password",
    createPassword: "Create a strong password",
    confirmPassword: "Confirm Password",
    confirmPasswordPlaceholder: "Confirm your password",
    referralCode: "Referral Code (Optional)",
    referralCodePlaceholder: "Enter referral code for extra bonus",
    agreeTerms: "I agree to the",
    termsOfService: "Terms of Service",
    and: "and",
    privacyPolicy: "Privacy Policy",
    marketingEmails: "Send me crypto market updates and Binance trading tips",
    joinFreeCommunity: "Join Free Community",
    creatingAccount: "Creating Account...",
    rememberMe: "Remember me",
    forgotPassword: "Forgot password?",
    signInToCommunity: "Sign In to Community",
    signingIn: "Signing In...",
    secureEncrypted: "Your data is secure and encrypted",
    continueToBinance: "Continue to Binance Trading",
    
    // User Profile
    myProfile: "My Profile",
    editProfile: "Edit Profile",
    accountSettings: "Account Settings",
    tradingStats: "Trading Stats",
    communityStats: "Community Stats",
    totalPosts: "Total Posts",
    totalLikes: "Total Likes",
    successfulPredictions: "Successful Predictions",
    memberSince: "Member Since",
    referralCode2: "Referral Code",
    shareReferral: "Share Referral",
    binanceAccount: "Binance Account",
    linkBinance: "Link Binance",
    linked: "Linked",
    favoriteCoins: "Favorite Coins",
    bio: "Bio",
    updateProfile: "Update Profile",
    
    // Leaderboard
    leaderboardTitle: "Community Leaderboard",
    topInvestors: "Top Investors",
    rank: "Rank",
    user: "User",
    posts: "Posts",
    accuracy: "Accuracy",
    followers: "Followers",
    
    // Notifications
    notifications: "Notifications",
    markAllRead: "Mark all as read",
    noNotifications: "No notifications",
    
    // Footer
    freeSignals: "Free Signals",
    tradingBenefits: "Trading Benefits",
    communityStats2: "Community Stats",
    totalMembers: "Total Members:",
    liveSignals2: "Live Signals:",
    successRate: "Success Rate:",
    activeTraders: "Active Traders:",
    lowTradingFees: "Low Trading Fees",
    securePlatform: "Secure Platform",
    advancedTools: "Advanced Tools",
    mobileTrading: "Mobile Trading",
    footerCopyright: "© 2025 Invest-Free.com. Free signals + investment community. Not financial advice.",
    tradeOnBinance: "Trade on Binance",
    
    // Post Form
    coinLabel: "Asset",
    adviceLabel: "Investment Advice & Target",
    advicePlaceholder: "Example: BTC is looking bullish, expecting $120k by March. Strong support at $95k, good entry point now. Target: $120k (25% gain). Stop loss: $90k",
    selectAssetType: "Select Asset Type",
    uploadChart: "Upload Chart Analysis",
    dragDropImage: "Drag & drop image here, or click to browse",
    imageUploaded: "Image uploaded successfully",
    
    // Filters
    searchSignals: "Search signals...",
    allCategories: "All Categories",
    allLevels: "All Levels",
    
    // GDPR & Privacy
    gdprTitle: "We Value Your Privacy",
    gdprMessage: "We use cookies and similar technologies to improve your experience, analyze traffic, and personalize content. By clicking 'Accept All', you consent to our use of cookies.",
    gdprAcceptAll: "Accept All",
    gdprRejectAll: "Reject All",
    gdprManagePreferences: "Manage Preferences",
    gdprLearnMore: "Learn More",
    
    // Cookie Preferences
    cookiePreferences: "Cookie Preferences",
    cookiePreferencesDesc: "Manage your cookie preferences below. Some cookies are essential for the website to function properly.",
    essentialCookies: "Essential Cookies",
    essentialCookiesDesc: "These cookies are necessary for the website to function and cannot be switched off in our systems.",
    analyticsCookies: "Analytics Cookies",
    analyticsCookiesDesc: "These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site.",
    marketingCookies: "Marketing Cookies",
    marketingCookiesDesc: "These cookies may be set through our site by our advertising partners to build a profile of your interests.",
    savePreferences: "Save Preferences",
    
    // Privacy Policy
    privacyPolicyTitle: "Privacy Policy",
    lastUpdated: "Last updated:",
    privacyIntro: "Invest-Free.com is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your information when you use our free trading signals and investment community platform.",
    
    // Terms of Service
    termsOfServiceTitle: "Terms of Service",
    termsIntro: "By accessing and using Invest-Free.com, you agree to be bound by these Terms of Service and all applicable laws and regulations.",
    
    // Common
    learnMore: "Learn More",
    getStarted: "Get Started",
    signUp: "Join Free",
    noFees: "No Fees",
    close: "Close",
    save: "Save",
    cancel: "Cancel",
    loading: "Loading...",
    loadingMore: "Loading More Signals...",
    error: "Error",
    success: "Success",
    warning: "Warning",
    info: "Info",
    new: "NEW",
    hot: "HOT",
    just_now: "Just now",
    minutes_ago: "min ago",
    hours_ago: "hour ago",
    days_ago: "day ago",
    
    // Time Units
    minute: "minute",
    minutes: "minutes", 
    hour: "hour",
    hours: "hours",
    day: "day",
    days: "days",
    week: "week",
    weeks: "weeks",
    month: "month",
    months: "months",
    
    // Errors
    usernameRequired: "Username is required",
    usernameMinLength: "Username must be at least 3 characters",
    emailRequired: "Email is required",
    invalidEmail: "Please enter a valid email address",
    passwordRequired: "Password is required",
    passwordWeak: "Password must be 8+ characters with uppercase, lowercase & number",
    passwordsNoMatch: "Passwords do not match",
    agreeToTerms: "You must agree to the terms and conditions",
    registrationFailed: "Registration failed. Please try again.",
    loginFailed: "Invalid email or password.",
    googleSignInFailed: "Google sign-in failed. Please try again.",
    
    // Signal Descriptions
    signalDescriptionBuy: "Strong buy signal based on comprehensive technical and fundamental analysis",
    signalDescriptionSell: "Strong sell signal indicating potential downward movement",
    signalDescriptionHold: "Hold position - neutral market conditions detected",
    
    // Platform Information
    platformBinance: "Binance",
    platformMultipleBrokers: "Multiple Brokers",
    platformAllBrokers: "All Brokers",
    platformForexBrokers: "Forex Brokers",
    platformCommodityBrokers: "Commodity Brokers",
    
    // Footer Risk Warning
    riskWarningTitle: "Risk Warning",
    riskWarningText: "Trading involves substantial risk and may result in the loss of your invested capital. Past performance is not indicative of future results. Only invest what you can afford to lose.",
    
    // Market Data
    marketDataLoading: "Loading real-time market data...",
    marketDataError: "Market data temporarily unavailable",
    marketDataRefresh: "Refresh Data",
    marketDataLastUpdate: "Last updated:",
    
    // Professional Disclaimers
    notFinancialAdvice: "Not financial advice",
    dyor: "Do Your Own Research",
    riskManagementRequired: "Risk management required",
    professionalTradingOnly: "For experienced traders only",
  },
  
  zh: {
    seoTitle: "免费加密货币、外汇和二元期权信号+投资社区2025 | Invest-Free.com",
    seoDescription: "获取AI分析驱动的实时交易信号+加入数千投资者分享盈利想法。100%免费平台。",
    heroTitle: "免费加密货币、外汇和二元期权信号+投资社区",
    heroSubtitle: "获取AI分析驱动的实时交易信号+加入数千投资者分享盈利想法。100%免费平台。",
    joinCommunity: "加入免费社区",
    postIdea: "分享您的想法",
    viewLiveSignals: "查看实时信号",
    startTradingBinance: "在币安开始交易",
    
    // AI Signals
    aiSignalsTitle: "🚀 专属AI信号生成器",
    aiSignalsSubtitle: "实时市场分析 • 机构级信号",
    generateAISignals: "生成AI信号",
    updateAISignals: "更新信号",
    aiSignalsExclusive: "AI专属",
    aiStatus: "AI状态",
    aiReady: "就绪",
    aiProcessing: "处理中...",
    analyzingMarkets: "分析市场中...",
    generationsToday: "今日生成次数",
    nextAutoUpdate: "下次自动更新:",
    lastGenerated: "最后生成:",
    premiumAISignals: "高级AI信号:",
    premiumAIDescription: "免费注册以获得90%+准确率的专属AI生成交易信号。",
    
    liveSignalsTitle: "实时交易信号",
    liveSignalsSubtitle: "加密货币 • 外汇 • 股票 • 商品",
    aiPowered: "AI驱动",
    realTime: "实时",
    freeForever: "永远免费",
    viewSignals: "查看信号",
    
    communityTitle: "最新投资想法",
    shareIdea: "分享投资想法",
    selectCoin: "选择资产",
    writeAdvice: "写下您的投资建议和目标...",
    postButton: "发布想法",
    likes: "点赞",
    comments: "评论",
    
    signalsTitle: "实时交易信号",
    signalsSubtitle: "AI驱动的加密货币、外汇和股票信号",
    
    newsTitle: "最新市场新闻",
    blogTitle: "商业学习中心",
    
    chatTitle: "实时投资者聊天",
    chatPlaceholder: "输入您的消息...",
    online: "在线",
    live: "直播",
    
    login: "登录",
    joinNow: "免费加入",
    coinLabel: "资产",
    adviceLabel: "投资建议与目标",
    
    // Categories
    allSignals: "所有信号",
    beginnerSignals: "初学者",
    professionalSignals: "专业级",
    hotSignals: "热门",
    favoriteSignals: "收藏夹",
    cryptocurrency: "🪙 加密货币",
    stocks: "📈 股票",
    forex: "💱 外汇",
    commodities: "🥇 商品",
    indices: "📊 指数",
    
    // GDPR
    gdprTitle: "我们重视您的隐私",
    gdprMessage: "我们使用cookies和类似技术来改善您的体验、分析流量和个性化内容。点击'接受全部'，您同意我们使用cookies。",
    gdprAcceptAll: "接受全部",
    gdprRejectAll: "拒绝全部",
    gdprManagePreferences: "管理偏好",
    
    privacyPolicy: "隐私政策",
    termsOfService: "服务条款",
    
    // Common
    loading: "加载中...",
    loadingMore: "加载更多信号...",
    new: "新",
    hot: "热门",
    just_now: "刚刚",
    minutes_ago: "分钟前",
    hours_ago: "小时前",
    days_ago: "天前",
  },
  
  ru: {
    seoTitle: "Бесплатные сигналы крипто, форекс и бинарные опционы + инвестиционное сообщество 2025 | Invest-Free.com", 
    seoDescription: "Получайте торговые сигналы на основе ИИ анализа + присоединяйтесь к тысячам инвесторов, делящихся прибыльными идеями. 100% бесплатная платформа.",
    heroTitle: "Бесплатные сигналы крипто, форекс и бинарные опционы + инвестиционное сообщество",
    heroSubtitle: "Получайте торговые сигналы на основе ИИ анализа + присоединяйтесь к тысячам инвесторов, делящихся прибыльными идеями.",
    joinCommunity: "Присоединиться к бесплатному сообществу",
    postIdea: "Поделиться идеей",
    viewLiveSignals: "Просмотр живых сигналов",
    
    // AI Signals
    aiSignalsTitle: "🚀 Эксклюзивный ИИ генератор сигналов",
    aiSignalsSubtitle: "Анализ рынка в реальном времени • Институциональные сигналы",
    generateAISignals: "Генерировать ИИ сигналы",
    updateAISignals: "Обновить сигналы",
    aiSignalsExclusive: "ИИ Эксклюзив",
    aiStatus: "Статус ИИ",
    aiReady: "Готов",
    aiProcessing: "Обработка...",
    analyzingMarkets: "Анализ рынков...",
    
    liveSignalsTitle: "Живые торговые сигналы",
    liveSignalsSubtitle: "Криптовалюты • Форекс • Акции • Сырьё",
    aiPowered: "На основе ИИ",
    realTime: "В реальном времени",
    freeForever: "Бесплатно навсегда",
    
    communityTitle: "Последние инвестиционные идеи",
    shareIdea: "Поделиться инвестиционной идеей",
    newsTitle: "Последние новости рынка",
    blogTitle: "Центр бизнес-обучения",
    chatTitle: "Живой чат инвесторов",
    
    login: "Войти",
    joinNow: "Присоединиться бесплатно",
    
    // Categories
    allSignals: "Все сигналы",
    beginnerSignals: "Новичок",
    professionalSignals: "Профессионал",
    hotSignals: "Горячие",
    favoriteSignals: "Избранное",
    cryptocurrency: "🪙 Криптовалюта",
    stocks: "📈 Акции",
    forex: "💱 Форекс",
    commodities: "🥇 Сырьё",
    indices: "📊 Индексы",
    
    // GDPR
    gdprTitle: "Мы ценим вашу конфиденциальность",
    gdprMessage: "Мы используем файлы cookie и аналогичные технологии для улучшения вашего опыта. Нажав 'Принять все', вы соглашаетесь на использование файлов cookie.",
    gdprAcceptAll: "Принять все",
    gdprRejectAll: "Отклонить все",
    
    privacyPolicy: "Политика конфиденциальности",
    termsOfService: "Условия обслуживания",
    
    // Common
    loading: "Загрузка...",
    loadingMore: "Загрузка ещё сигналов...",
    new: "НОВЫЙ",
    hot: "ГОРЯЧИЙ",
    just_now: "Только что",
    minutes_ago: "мин назад",
    hours_ago: "ч назад",
    days_ago: "дн назад",
  },
  
  ar: {
    seoTitle: "إشارات مجانية للعملات المشفرة والفوركس والخيارات الثنائية + مجتمع الاستثمار 2025 | Invest-Free.com",
    seoDescription: "احصل على إشارات التداول المدعومة بتحليل الذكاء الاصطناعي + انضم إلى آلاف المستثمرين الذين يشاركون الأفكار المربحة. منصة مجانية 100%.",
    heroTitle: "إشارات مجانية للعملات المشفرة والفوركس والخيارات الثنائية + مجتمع الاستثمار",
    heroSubtitle: "احصل على إشارات التداول المدعومة بتحليل الذكاء الاصطناعي + انضم إلى آلاف المستثمرين الذين يشاركون الأفكار المربحة.",
    joinCommunity: "انضم للمجتمع المجاني",
    postIdea: "شارك فكرتك",
    
    // AI Signals
    aiSignalsTitle: "🚀 مولد الإشارات الحصري بالذكاء الاصطناعي",
    aiSignalsSubtitle: "تحليل السوق في الوقت الفعلي • إشارات مؤسسية",
    generateAISignals: "توليد إشارات الذكاء الاصطناعي",
    updateAISignals: "تحديث الإشارات",
    aiSignalsExclusive: "حصري بالذكاء الاصطناعي",
    
    liveSignalsTitle: "إشارات التداول المباشرة",
    liveSignalsSubtitle: "العملات المشفرة • الفوركس • الأسهم • السلع",
    aiPowered: "مدعوم بالذكاء الاصطناعي",
    realTime: "في الوقت الفعلي",
    freeForever: "مجاني للأبد",
    
    communityTitle: "أحدث الأفكار الاستثمارية",
    shareIdea: "شارك فكرة استثمارية",
    newsTitle: "آخر أخبار السوق",
    blogTitle: "مركز تعلم الأعمال",
    chatTitle: "محادثة المستثمرين المباشرة",
    
    login: "تسجيل الدخول",
    joinNow: "انضم مجاناً",
    
    // Categories
    allSignals: "جميع الإشارات",
    beginnerSignals: "مبتدئ",
    professionalSignals: "محترف",
    hotSignals: "ساخنة",
    favoriteSignals: "المفضلة",
    cryptocurrency: "🪙 العملات المشفرة",
    stocks: "📈 الأسهم",
    forex: "💱 الفوركس",
    commodities: "🥇 السلع",
    indices: "📊 المؤشرات",
    
    // GDPR
    gdprTitle: "نحن نقدر خصوصيتك",
    gdprMessage: "نستخدم ملفات تعريف الارتباط والتقنيات المماثلة لتحسين تجربتك. بالنقر على 'قبول الكل'، فإنك توافق على استخدامنا لملفات تعريف الارتباط.",
    gdprAcceptAll: "قبول الكل",
    gdprRejectAll: "رفض الكل",
    
    privacyPolicy: "سياسة الخصوصية",
    termsOfService: "شروط الخدمة",
    
    // Common
    loading: "جارٍ التحميل...",
    loadingMore: "تحميل المزيد من الإشارات...",
    new: "جديد",
    hot: "ساخن",
    just_now: "الآن",
    minutes_ago: "دقائق مضت",
    hours_ago: "ساعات مضت",
    days_ago: "أيام مضت",
  },
  
  fr: {
    heroTitle: "Signaux gratuits crypto, forex et options binaires + communauté d'investissement",
    heroSubtitle: "Obtenez des signaux de trading alimentés par l'analyse IA + rejoignez des milliers d'investisseurs partageant des idées rentables.",
    joinCommunity: "Rejoindre la communauté gratuite",
    postIdea: "Partager votre idée",
    
    // AI Signals
    aiSignalsTitle: "🚀 Générateur de signaux IA exclusif",
    aiSignalsSubtitle: "Analyse de marché en temps réel • Signaux institutionnels",
    generateAISignals: "Générer des signaux IA",
    updateAISignals: "Mettre à jour les signaux",
    aiSignalsExclusive: "IA Exclusif",
    
    liveSignalsTitle: "Signaux de trading en direct",
    liveSignalsSubtitle: "Crypto • Forex • Actions • Matières premières",
    communityTitle: "Dernières idées d'investissement",
    newsTitle: "Dernières nouvelles du marché",
    blogTitle: "Centre d'apprentissage business",
    chatTitle: "Chat en direct des investisseurs",
    
    login: "Se connecter",
    joinNow: "Rejoindre gratuitement",
    
    // Categories
    allSignals: "Tous les signaux",
    beginnerSignals: "Débutant",
    professionalSignals: "Professionnel",
    hotSignals: "Tendance",
    favoriteSignals: "Favoris",
    cryptocurrency: "🪙 Cryptomonnaie",
    stocks: "📈 Actions",
    forex: "💱 Forex",
    commodities: "🥇 Matières premières",
    indices: "📊 Indices",
    
    // GDPR
    gdprTitle: "Nous respectons votre vie privée",
    gdprAcceptAll: "Accepter tout",
    gdprRejectAll: "Tout refuser",
    privacyPolicy: "Politique de confidentialité",
    termsOfService: "Conditions d'utilisation",
    
    // Common
    loading: "Chargement...",
    loadingMore: "Chargement de plus de signaux...",
    new: "NOUVEAU",
    hot: "TENDANCE",
  },
  
  es: {
    heroTitle: "Señales gratuitas de crypto, forex y opciones binarias + comunidad de inversión",
    heroSubtitle: "Obtén señales de trading impulsadas por análisis de IA + únete a miles de inversores compartiendo ideas rentables.",
    joinCommunity: "Unirse a la comunidad gratis",
    postIdea: "Compartir tu idea",
    
    // AI Signals
    aiSignalsTitle: "🚀 Generador de señales IA exclusivo",
    aiSignalsSubtitle: "Análisis de mercado en tiempo real • Señales institucionales",
    generateAISignals: "Generar señales IA",
    updateAISignals: "Actualizar señales",
    aiSignalsExclusive: "IA Exclusivo",
    
    liveSignalsTitle: "Señales de trading en vivo",
    liveSignalsSubtitle: "Crypto • Forex • Acciones • Commodities",
    communityTitle: "Últimas ideas de inversión",
    newsTitle: "Últimas noticias del mercado",
    blogTitle: "Centro de aprendizaje empresarial",
    chatTitle: "Chat en vivo de inversores",
    
    login: "Iniciar sesión",
    joinNow: "Únete gratis",
    
    // Categories
    allSignals: "Todas las señales",
    beginnerSignals: "Principiante",
    professionalSignals: "Profesional",
    hotSignals: "Popular",
    favoriteSignals: "Favoritos",
    cryptocurrency: "🪙 Criptomoneda",
    stocks: "📈 Acciones",
    forex: "💱 Forex",
    commodities: "🥇 Commodities",
    indices: "📊 Índices",
    
    // GDPR
    gdprTitle: "Valoramos tu privacidad",
    gdprAcceptAll: "Aceptar todo",
    gdprRejectAll: "Rechazar todo",
    privacyPolicy: "Política de privacidad",
    termsOfService: "Términos de servicio",
    
    // Common
    loading: "Cargando...",
    loadingMore: "Cargando más señales...",
    new: "NUEVO",
    hot: "POPULAR",
  },
  
  de: {
    heroTitle: "Kostenlose Krypto-, Forex- und Binäre Optionen Signale + Investment Community",
    joinCommunity: "Kostenloser Community beitreten",
    
    // AI Signals
    aiSignalsTitle: "🚀 Exklusiver KI-Signal-Generator",
    aiSignalsSubtitle: "Echtzeit-Marktanalyse • Institutionelle Signale",
    generateAISignals: "KI-Signale generieren",
    updateAISignals: "Signale aktualisieren",
    aiSignalsExclusive: "KI Exklusiv",
    
    newsTitle: "Neueste Marktnachrichten",
    blogTitle: "Business-Lernzentrum",
    login: "Anmelden",
    joinNow: "Kostenlos beitreten",
    
    // Categories
    allSignals: "Alle Signale",
    beginnerSignals: "Anfänger",
    professionalSignals: "Profi",
    hotSignals: "Heiß",
    favoriteSignals: "Favoriten",
    cryptocurrency: "🪙 Kryptowährung",
    stocks: "📈 Aktien",
    forex: "💱 Forex",
    commodities: "🥇 Rohstoffe",
    indices: "📊 Indizes",
    
    // GDPR
    gdprTitle: "Wir schätzen Ihre Privatsphäre",
    gdprAcceptAll: "Alle akzeptieren",
    gdprRejectAll: "Alle ablehnen",
    privacyPolicy: "Datenschutzrichtlinie",
    termsOfService: "Nutzungsbedingungen",
    
    // Common
    loading: "Laden...",
    loadingMore: "Weitere Signale laden...",
    new: "NEU",
    hot: "HEIß",
  },
  
  tr: {
    heroTitle: "Ücretsiz kripto, forex ve ikili opsiyon sinyalleri + yatırım topluluğu",
    joinCommunity: "Ücretsiz topluluğa katıl",
    
    // AI Signals
    aiSignalsTitle: "🚀 Özel AI Sinyal Üreticisi",
    aiSignalsSubtitle: "Gerçek zamanlı pazar analizi • Kurumsal sinyaller",
    generateAISignals: "AI sinyalleri oluştur",
    updateAISignals: "Sinyalleri güncelle",
    aiSignalsExclusive: "AI Özel",
    
    newsTitle: "Son pazar haberleri",
    blogTitle: "İş öğrenim merkezi",
    login: "Giriş yap",
    joinNow: "Ücretsiz katıl",
    
    // Categories
    allSignals: "Tüm sinyaller",
    beginnerSignals: "Başlangıç",
    professionalSignals: "Profesyonel",
    hotSignals: "Popüler",
    favoriteSignals: "Favoriler",
    cryptocurrency: "🪙 Kripto para",
    stocks: "📈 Hisse senetleri",
    forex: "💱 Forex",
    commodities: "🥇 Emtialar",
    indices: "📊 Endeksler",
    
    // GDPR
    gdprTitle: "Gizliliğinize değer veriyoruz",
    gdprAcceptAll: "Tümünü kabul et",
    gdprRejectAll: "Tümünü reddet",
    privacyPolicy: "Gizlilik Politikası",
    termsOfService: "Hizmet Şartları",
    
    // Common
    loading: "Yükleniyor...",
    loadingMore: "Daha fazla sinyal yükleniyor...",
    new: "YENİ",
    hot: "POPÜLER",
  },
  
  pt: {
    heroTitle: "Sinais gratuitos de crypto, forex e opções binárias + comunidade de investimento",
    joinCommunity: "Juntar-se à comunidade gratuita",
    
    // AI Signals
    aiSignalsTitle: "🚀 Gerador de sinais IA exclusivo",
    aiSignalsSubtitle: "Análise de mercado em tempo real • Sinais institucionais",
    generateAISignals: "Gerar sinais IA",
    updateAISignals: "Atualizar sinais",
    aiSignalsExclusive: "IA Exclusivo",
    
    newsTitle: "Últimas notícias do mercado",
    blogTitle: "Centro de aprendizagem empresarial",
    login: "Entrar",
    joinNow: "Junte-se grátis",
    
    // Categories
    allSignals: "Todos os sinais",
    beginnerSignals: "Iniciante",
    professionalSignals: "Profissional",
    hotSignals: "Popular",
    favoriteSignals: "Favoritos",
    cryptocurrency: "🪙 Criptomoeda",
    stocks: "📈 Ações",
    forex: "💱 Forex",
    commodities: "🥇 Commodities",
    indices: "📊 Índices",
    
    // GDPR
    gdprTitle: "Valorizamos sua privacidade",
    gdprAcceptAll: "Aceitar tudo",
    gdprRejectAll: "Rejeitar tudo",
    privacyPolicy: "Política de Privacidade",
    termsOfService: "Termos de Serviço",
    
    // Common
    loading: "Carregando...",
    loadingMore: "Carregando mais sinais...",
    new: "NOVO",
    hot: "POPULAR",
  },
  
  hi: {
    heroTitle: "मुफ्त क्रिप्टो, फॉरेक्स और बाइनरी ऑप्शन सिग्नल + निवेश समुदाय",
    joinCommunity: "मुफ्त समुदाय में शामिल हों",
    
    // AI Signals
    aiSignalsTitle: "🚀 विशेष AI सिग्नल जेनेरेटर",
    aiSignalsSubtitle: "रियल-टाइम मार्केट एनालिसिस • संस्थागत सिग्नल",
    generateAISignals: "AI सिग्नल जेनेरेट करें",
    updateAISignals: "सिग्नल अपडेट करें",
    aiSignalsExclusive: "AI विशेष",
    
    newsTitle: "नवीनतम बाजार समाचार",
    blogTitle: "व्यापार सीखने का केंद्र",
    login: "लॉग इन",
    joinNow: "मुफ्त में जुड़ें",
    
    // Categories
    allSignals: "सभी सिग्नल",
    beginnerSignals: "शुरुआती",
    professionalSignals: "पेशेवर",
    hotSignals: "हॉट",
    favoriteSignals: "पसंदीदा",
    cryptocurrency: "🪙 क्रिप्टोकरेंसी",
    stocks: "📈 स्टॉक",
    forex: "💱 फॉरेक्स",
    commodities: "🥇 कमोडिटी",
    indices: "📊 इंडेक्स",
    
    // GDPR
    gdprTitle: "हम आपकी गोपनीयता को महत्व देते हैं",
    gdprAcceptAll: "सभी स्वीकार करें",
    gdprRejectAll: "सभी अस्वीकार करें",
    privacyPolicy: "गोपनीयता नीति",
    termsOfService: "सेवा की शर्तें",
    
    // Common
    loading: "लोड हो रहा है...",
    loadingMore: "अधिक सिग्नल लोड हो रहे हैं...",
    new: "नया",
    hot: "हॉट",
  },
  
  id: {
    heroTitle: "Sinyal gratis crypto, forex, dan opsi biner + komunitas investasi",
    joinCommunity: "Bergabung dengan komunitas gratis",
    
    // AI Signals
    aiSignalsTitle: "🚀 Generator sinyal AI eksklusif",
    aiSignalsSubtitle: "Analisis pasar real-time • Sinyal institusional",
    generateAISignals: "Buat sinyal AI",
    updateAISignals: "Perbarui sinyal",
    aiSignalsExclusive: "AI Eksklusif",
    
    newsTitle: "Berita pasar terbaru",
    blogTitle: "Pusat pembelajaran bisnis",
    login: "Masuk",
    joinNow: "Bergabung gratis",
    
    // Categories
    allSignals: "Semua sinyal",
    beginnerSignals: "Pemula",
    professionalSignals: "Profesional",
    hotSignals: "Populer",
    favoriteSignals: "Favorit",
    cryptocurrency: "🪙 Cryptocurrency",
    stocks: "📈 Saham",
    forex: "💱 Forex",
    commodities: "🥇 Komoditas",
    indices: "📊 Indeks",
    
    // GDPR
    gdprTitle: "Kami menghargai privasi Anda",
    gdprAcceptAll: "Terima semua",
    gdprRejectAll: "Tolak semua",
    privacyPolicy: "Kebijakan Privasi",
    termsOfService: "Syarat Layanan",
    
    // Common
    loading: "Memuat...",
    loadingMore: "Memuat lebih banyak sinyal...",
    new: "BARU",
    hot: "POPULER",
  },
  
  ko: {
    heroTitle: "무료 암호화폐, 외환 및 바이너리 옵션 신호 + 투자 커뮤니티",
    joinCommunity: "무료 커뮤니티 가입",
    
    // AI Signals
    aiSignalsTitle: "🚀 독점 AI 신호 생성기",
    aiSignalsSubtitle: "실시간 시장 분석 • 기관급 신호",
    generateAISignals: "AI 신호 생성",
    updateAISignals: "신호 업데이트",
    aiSignalsExclusive: "AI 독점",
    
    newsTitle: "최신 시장 뉴스",
    blogTitle: "비즈니스 학습 센터",
    login: "로그인",
    joinNow: "무료 가입",
    
    // Categories
    allSignals: "모든 신호",
    beginnerSignals: "초보자",
    professionalSignals: "전문가",
    hotSignals: "인기",
    favoriteSignals: "즐겨찾기",
    cryptocurrency: "🪙 암호화폐",
    stocks: "📈 주식",
    forex: "💱 외환",
    commodities: "🥇 원자재",
    indices: "📊 지수",
    
    // GDPR
    gdprTitle: "우리는 귀하의 개인정보를 소중히 여깁니다",
    gdprAcceptAll: "모두 수락",
    gdprRejectAll: "모두 거부",
    privacyPolicy: "개인정보 보호정책",
    termsOfService: "서비스 약관",
    
    // Common
    loading: "로딩 중...",
    loadingMore: "더 많은 신호 로딩 중...",
    new: "새로운",
    hot: "인기",
  }
};

export function detectLanguage(): string {
  if (typeof window === 'undefined') return 'en';
  
  const stored = localStorage.getItem('preferred-language');
  if (stored && languages.find(lang => lang.code === stored)) {
    return stored;
  }
  
  const browserLang = navigator.language.split('-')[0];
  const supportedLang = languages.find(lang => lang.code === browserLang);
  
  return supportedLang?.code || 'en';
}