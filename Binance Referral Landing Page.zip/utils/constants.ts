export const BINANCE_REFERRAL_URL =
  "https://www.binance.com/referral/earn-together/refer-in-hotsummer/claim?hl=en&ref=GRO_20338_NYNN1";

export const APP_CONFIG = {
  name: "Invest-Free.com",
  description:
    "Free Crypto, Forex & Binary Signals + Investment Community",
  url: "https://invest-free.com",
  ogImage: "https://invest-free.com/og-image.jpg",
};

export const MARKET_CATEGORIES = [
  { value: "crypto", label: "🪙 Cryptocurrency" },
  { value: "stocks", label: "📈 Stocks" },
  { value: "forex", label: "💱 Forex" },
  { value: "commodities", label: "🥇 Commodities" },
  { value: "indices", label: "📊 Indices" },
];

export const SIGNAL_TIMEFRAMES = [
  { value: "scalp", label: "⚡ Scalping (1-4h)" },
  { value: "swing", label: "🎯 Swing (1-14 days)" },
  { value: "position", label: "🏛️ Position (weeks-months)" },
];

export const RISK_LEVELS = [
  { value: "Low", color: "text-old-money-sage" },
  { value: "Medium", color: "text-old-money-gold" },
  { value: "High", color: "text-old-money-burgundy" },
];

export const DIFFICULTY_LEVELS = [
  {
    value: "beginner",
    label: "🟢 Beginner",
    color: "bg-old-money-sage",
  },
  {
    value: "intermediate",
    label: "🟡 Intermediate",
    color: "bg-old-money-gold",
  },
  {
    value: "professional",
    label: "🔴 Professional",
    color: "bg-old-money-burgundy",
  },
];