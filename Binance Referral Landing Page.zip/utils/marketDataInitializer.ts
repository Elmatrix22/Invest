import { MarketDataService } from './marketDataService';
import { createEmergencyFallbackData } from './emergencyFallbackData';
import { 
  ESSENTIAL_SYMBOLS, 
  MIN_REQUIRED_SYMBOLS, 
  MARKET_DATA_TIMEOUT,
  RETRY_DELAY,
  LIVE_DATA_SOURCES,
  HEALTH_CHECK_INTERVAL,
  DATA_STALE_THRESHOLD,
  REAL_TIME_UPDATE_INTERVAL
} from './appConstants';
import { toast } from "sonner@2.0.3";

interface MarketDataInitializerCallbacks {
  onUpdateMarketData: (data: any) => void;
  onSetIsMarketDataReady: (ready: boolean) => void;
  onSetInitializationAttempts: (attempts: number) => void;
}

export class MarketDataInitializer {
  private marketDataService: MarketDataService;
  private callbacks: MarketDataInitializerCallbacks;
  private mounted = true;
  private retryTimeout: NodeJS.Timeout | null = null;
  private healthCheckInterval: NodeJS.Timeout | null = null;

  constructor(marketDataService: MarketDataService, callbacks: MarketDataInitializerCallbacks) {
    this.marketDataService = marketDataService;
    this.callbacks = callbacks;
  }

  // Validation function for essential data
  private validateEssentialData = (data: any): boolean => {
    if (!data || !data.prices) return false;
    
    const hasEssentials = ESSENTIAL_SYMBOLS.every(symbol => 
      data.prices[symbol] && data.prices[symbol].price > 0
    );
    
    return hasEssentials && Object.keys(data.prices).length >= MIN_REQUIRED_SYMBOLS;
  };

  // Enhanced real-time updates with better error handling
  private startRealTimeUpdates = () => {
    this.marketDataService.startRealTimeUpdates(REAL_TIME_UPDATE_INTERVAL);
    
    // Set up periodic health checks
    this.healthCheckInterval = setInterval(() => {
      if (!this.mounted) {
        this.cleanup();
        return;
      }
      
      const currentData = this.marketDataService.getMarketData();
      const timeSinceUpdate = Date.now() - currentData.lastUpdate;
      
      // If data is too old, trigger refresh
      if (timeSinceUpdate > DATA_STALE_THRESHOLD) {
        console.log('🔄 Data is stale, triggering refresh...');
        this.marketDataService.fetchAllMarketData().catch(console.error);
      }
    }, HEALTH_CHECK_INTERVAL);
  };

  // Main initialization method
  public initializeMarketData = async (attempt: number = 1, maxAttempts: number = 3) => {
    if (!this.mounted) return;
    
    try {
      console.log(`🔄 Initializing market data service (attempt ${attempt}/${maxAttempts})...`);
      
      // Set loading state
      this.callbacks.onUpdateMarketData(prev => ({ ...prev, isLoading: true, errors: [] }));
      
      // Initialize with comprehensive error handling
      await Promise.race([
        this.marketDataService.fetchAllMarketData(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Initialization timeout')), MARKET_DATA_TIMEOUT)
        )
      ]);
      
      if (!this.mounted) return;
      
      // Ensure required symbols are available
      this.marketDataService.ensureRequiredSymbols();
      
      // Get updated data with validation
      const updatedData = this.marketDataService.getMarketData();
      
      // Validate that we have essential data
      const hasEssentialData = this.validateEssentialData(updatedData);
      
      if (!hasEssentialData && attempt < maxAttempts) {
        console.warn(`⚠️ Essential data missing on attempt ${attempt}, retrying...`);
        this.callbacks.onSetInitializationAttempts(attempt);
        this.retryTimeout = setTimeout(() => this.initializeMarketData(attempt + 1, maxAttempts), 2000);
        return;
      }
      
      // Force populate essential data if still missing
      if (!hasEssentialData) {
        console.log('🔧 Force populating essential data...');
        this.marketDataService.forcePopulateEssentialData();
        const finalData = this.marketDataService.getMarketData();
        this.callbacks.onUpdateMarketData(finalData);
      } else {
        this.callbacks.onUpdateMarketData(updatedData);
      }
      
      // Mark as ready
      this.callbacks.onSetIsMarketDataReady(true);
      this.callbacks.onSetInitializationAttempts(0);
      
      // Start real-time updates with error recovery
      this.startRealTimeUpdates();
      
      // Show success message
      const liveCount = Object.values(updatedData.prices).filter(p => 
        LIVE_DATA_SOURCES.includes(p.source)
      ).length;
      
      const totalCount = Object.keys(updatedData.prices).length;
      
      if (liveCount > totalCount * 0.5) {
        toast.success(`🚀 Market data connected - ${totalCount} feeds active (${liveCount} live)`, {
          duration: 3000,
        });
      } else if (totalCount > 0) {
        toast.info(`📊 Market simulation active - ${totalCount} price feeds available`, {
          duration: 3000,
        });
      }
      
    } catch (error) {
      console.error(`❌ Market data initialization failed (attempt ${attempt}):`, error);
      
      if (!this.mounted) return;
      
      if (attempt < maxAttempts) {
        console.log(`🔄 Retrying market data initialization in ${RETRY_DELAY/1000} seconds...`);
        this.callbacks.onSetInitializationAttempts(attempt);
        this.retryTimeout = setTimeout(() => this.initializeMarketData(attempt + 1, maxAttempts), RETRY_DELAY);
        return;
      }
      
      // Final fallback - create comprehensive emergency data
      console.log('🆘 Using emergency fallback data...');
      const emergencyData = createEmergencyFallbackData();
      this.callbacks.onUpdateMarketData(emergencyData);
      this.callbacks.onSetIsMarketDataReady(true);
      this.callbacks.onSetInitializationAttempts(0);
      
      toast.warning('Using backup market data - some features may be limited', { 
        duration: 4000 
      });
    }
  };

  // Monitor data updates
  public monitorDataUpdates = (currentMarketData: any) => {
    if (!this.mounted) return null;

    const updateInterval = setInterval(() => {
      try {
        const currentData = this.marketDataService.getMarketData();
        
        if (currentData.lastUpdate > currentMarketData.lastUpdate) {
          // Check if service has recovered from error state
          const wasInErrorState = currentMarketData.errors.length > 0;
          const isNowHealthy = currentData.errors.length === 0;
          
          if (wasInErrorState && isNowHealthy) {
            const liveCount = Object.values(currentData.prices).filter(p => 
              LIVE_DATA_SOURCES.includes(p.source)
            ).length;
            
            if (liveCount > 0) {
              toast.success(`✅ Market data service recovered - ${liveCount} live feeds restored`, {
                duration: 4000,
              });
            }
          }
          
          this.callbacks.onUpdateMarketData(currentData);
        }
      } catch (error) {
        console.error('❌ Error updating market data:', error);
      }
    }, 5000);
    
    return () => clearInterval(updateInterval);
  };

  // Cleanup method
  public cleanup = () => {
    this.mounted = false;
    if (this.retryTimeout) {
      clearTimeout(this.retryTimeout);
      this.retryTimeout = null;
    }
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
    this.marketDataService.stopRealTimeUpdates();
  };

  // Set mounted state
  public setMounted = (mounted: boolean) => {
    this.mounted = mounted;
  };
}