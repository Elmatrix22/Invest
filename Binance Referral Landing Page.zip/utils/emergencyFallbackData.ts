// Emergency fallback market data for when all APIs fail
export const createEmergencyFallbackData = () => {
  return {
    prices: {
      'BTC/USDT': {
        symbol: 'BTC/USDT',
        price: 97500 + (Math.random() - 0.5) * 1000,
        change24h: (Math.random() - 0.5) * 4,
        volume: 1000000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'BTCUSDT': {
        symbol: 'BTCUSDT',
        price: 97500 + (Math.random() - 0.5) * 1000,
        change24h: (Math.random() - 0.5) * 4,
        volume: 1000000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'ETH/USDT': {
        symbol: 'ETH/USDT', 
        price: 3420 + (Math.random() - 0.5) * 100,
        change24h: (Math.random() - 0.5) * 3,
        volume: 500000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'ETHUSDT': {
        symbol: 'ETHUSDT', 
        price: 3420 + (Math.random() - 0.5) * 100,
        change24h: (Math.random() - 0.5) * 3,
        volume: 500000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'SOL/USDT': {
        symbol: 'SOL/USDT',
        price: 238 + (Math.random() - 0.5) * 20,
        change24h: (Math.random() - 0.5) * 5,
        volume: 200000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'SOLUSDT': {
        symbol: 'SOLUSDT',
        price: 238 + (Math.random() - 0.5) * 20,
        change24h: (Math.random() - 0.5) * 5,
        volume: 200000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'ADA/USDT': {
        symbol: 'ADA/USDT',
        price: 1.05 + (Math.random() - 0.5) * 0.1,
        change24h: (Math.random() - 0.5) * 3,
        volume: 150000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'ADAUSDT': {
        symbol: 'ADAUSDT',
        price: 1.05 + (Math.random() - 0.5) * 0.1,
        change24h: (Math.random() - 0.5) * 3,
        volume: 150000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'DOT/USDT': {
        symbol: 'DOT/USDT',
        price: 7.84 + (Math.random() - 0.5) * 0.5,
        change24h: (Math.random() - 0.5) * 3,
        volume: 100000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'DOTUSDT': {
        symbol: 'DOTUSDT',
        price: 7.84 + (Math.random() - 0.5) * 0.5,
        change24h: (Math.random() - 0.5) * 3,
        volume: 100000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'LINK/USDT': {
        symbol: 'LINK/USDT',
        price: 22.65 + (Math.random() - 0.5) * 2,
        change24h: (Math.random() - 0.5) * 3,
        volume: 80000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'LINKUSDT': {
        symbol: 'LINKUSDT',
        price: 22.65 + (Math.random() - 0.5) * 2,
        change24h: (Math.random() - 0.5) * 3,
        volume: 80000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      // Essential forex pairs
      'EURUSD': {
        symbol: 'EURUSD',
        price: 1.0547 + (Math.random() - 0.5) * 0.01,
        change24h: (Math.random() - 0.5) * 0.5,
        volume: 1000000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'GBPUSD': {
        symbol: 'GBPUSD',
        price: 1.2634 + (Math.random() - 0.5) * 0.015,
        change24h: (Math.random() - 0.5) * 0.8,
        volume: 800000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      // Essential stocks
      'AAPL': {
        symbol: 'AAPL',
        price: 229.87 + (Math.random() - 0.5) * 10,
        change24h: (Math.random() - 0.5) * 2,
        volume: 50000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'MSFT': {
        symbol: 'MSFT',
        price: 415.26 + (Math.random() - 0.5) * 15,
        change24h: (Math.random() - 0.5) * 2,
        volume: 30000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      },
      'TSLA': {
        symbol: 'TSLA',
        price: 352.60 + (Math.random() - 0.5) * 20,
        change24h: (Math.random() - 0.5) * 4,
        volume: 80000000,
        lastUpdate: Date.now(),
        source: 'Emergency Fallback'
      }
    },
    isLoading: false,
    lastUpdate: Date.now(),
    errors: ['Using emergency backup data']
  };
};