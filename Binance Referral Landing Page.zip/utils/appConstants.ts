// Application constants and configurations
export const ROUTES = {
  HOME: 'home',
  SIGNALS: 'signals', 
  COMMUNITY: 'community',
  NEWS: 'news',
  EDUCATION: 'education',
  PROFILE: 'profile'
} as const;

export type RouteType = typeof ROUTES[keyof typeof ROUTES];

export const MAX_INIT_ATTEMPTS = 3;
export const MARKET_DATA_TIMEOUT = 15000;
export const RETRY_DELAY = 3000;
export const UPDATE_INTERVAL = 5000;
export const HEALTH_CHECK_INTERVAL = 60000;
export const DATA_STALE_THRESHOLD = 300000; // 5 minutes
export const REAL_TIME_UPDATE_INTERVAL = 120000; // 2 minutes

export const ESSENTIAL_SYMBOLS = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT'];
export const MIN_REQUIRED_SYMBOLS = 10;

export const LIVE_DATA_SOURCES = ['CoinGecko', 'CoinPaprika', 'ExchangeRate-API'];