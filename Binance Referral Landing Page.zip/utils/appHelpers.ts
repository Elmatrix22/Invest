import { languages } from './languages';
import { POSSIBLE_NOTIFICATIONS } from './constants';

export const handleLanguageChange = (
  languageCode: string,
  setCurrentLanguage: (lang: string) => void
) => {
  setCurrentLanguage(languageCode);
  localStorage.setItem('preferred-language', languageCode);
  
  // Apply RTL styling for Arabic
  const isRTL = languages.find(lang => lang.code === languageCode)?.rtl;
  document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
};

export const handleAuthSuccess = (
  userData: any,
  setUser: (user: any) => void,
  setShowAuthModal: (show: boolean) => void
) => {
  setUser(userData);
  setShowAuthModal(false);
};

export const handleLogout = (
  setUser: (user: any) => void
) => {
  setUser(null);
  localStorage.removeItem('user');
};

export const handleUpdateUser = (
  updatedUser: any,
  setUser: (user: any) => void
) => {
  setUser(updatedUser);
  localStorage.setItem('user', JSON.stringify(updatedUser));
};

export const handleBinanceReferral = (binanceReferralUrl: string) => {
  window.open(binanceReferralUrl, '_blank', 'noopener,noreferrer');
};

export const createNotificationHandlers = (
  setNotifications: React.Dispatch<React.SetStateAction<any[]>>
) => {
  const handleMarkAsRead = (id: number) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id 
          ? { ...notification, unread: !notification.unread }
          : notification
      )
    );
  };

  const handleMarkAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, unread: false }))
    );
  };

  const handleDeleteNotification = (id: number) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  };

  return { handleMarkAsRead, handleMarkAllAsRead, handleDeleteNotification };
};

export const setupNotificationInterval = (
  setNotifications: React.Dispatch<React.SetStateAction<any[]>>
) => {
  return setInterval(() => {
    const randomNotification = POSSIBLE_NOTIFICATIONS[Math.floor(Math.random() * POSSIBLE_NOTIFICATIONS.length)];
    
    // Add new notification occasionally (20% chance every 30 seconds)
    if (Math.random() > 0.8) {
      const newNotification = {
        id: Date.now(),
        message: randomNotification.message,
        unread: true,
        type: randomNotification.type,
        timestamp: 'Just now'
      };
      
      setNotifications(prev => [newNotification, ...prev.slice(0, 9)]); // Keep last 10 notifications
    }
  }, 30000); // Check every 30 seconds
};