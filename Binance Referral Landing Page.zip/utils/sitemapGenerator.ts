export interface SitemapPage {
  url: string;
  lastModified: string;
  changeFrequency: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
  priority: number;
  alternateLanguages?: { lang: string; url: string }[];
}

export class SitemapGenerator {
  private baseUrl: string;
  private supportedLanguages: string[];

  constructor(baseUrl: string = 'https://invest-free.com', languages: string[] = ['en', 'es', 'fr', 'de', 'it', 'pt', 'ru', 'zh', 'ja', 'ko']) {
    this.baseUrl = baseUrl.replace(/\/$/, ''); // Remove trailing slash
    this.supportedLanguages = languages;
  }

  private createAlternateLanguages(path: string): { lang: string; url: string }[] {
    return this.supportedLanguages.map(lang => ({
      lang: lang === 'en' ? 'x-default' : lang,
      url: `${this.baseUrl}${lang === 'en' ? '' : `/${lang}`}${path}`
    }));
  }

  private formatDate(date: Date): string {
    return date.toISOString().split('T')[0];
  }

  generateSitemapPages(): SitemapPage[] {
    const currentDate = this.formatDate(new Date());
    const pages: SitemapPage[] = [];

    // Main pages with high priority
    const mainPages = [
      {
        path: '',
        priority: 1.0,
        changeFreq: 'daily' as const,
        description: 'Homepage - Free Crypto Trading Signals & Investment Community'
      },
      {
        path: '/signals',
        priority: 0.9,
        changeFreq: 'hourly' as const,
        description: 'AI Trading Signals - Crypto, Forex, Stocks'
      },
      {
        path: '/community',
        priority: 0.8,
        changeFreq: 'hourly' as const,
        description: 'Investment Community & Ideas Sharing'
      },
      {
        path: '/news',
        priority: 0.8,
        changeFreq: 'hourly' as const,
        description: 'Latest Crypto & Financial News'
      },
      {
        path: '/education',
        priority: 0.7,
        changeFreq: 'weekly' as const,
        description: 'Trading Education & Learning Resources'
      }
    ];

    // Add main pages
    mainPages.forEach(page => {
      pages.push({
        url: `${this.baseUrl}${page.path}`,
        lastModified: currentDate,
        changeFrequency: page.changeFreq,
        priority: page.priority,
        alternateLanguages: this.createAlternateLanguages(page.path)
      });
    });

    // Trading signal categories with medium-high priority
    const signalCategories = [
      'crypto-signals',
      'forex-signals', 
      'stock-signals',
      'binary-options-signals',
      'commodities-signals',
      'ai-signals',
      'live-signals',
      'free-signals'
    ];

    signalCategories.forEach(category => {
      const path = `/signals/${category}`;
      pages.push({
        url: `${this.baseUrl}${path}`,
        lastModified: currentDate,
        changeFrequency: 'daily',
        priority: 0.8,
        alternateLanguages: this.createAlternateLanguages(path)
      });
    });

    // Educational content pages
    const educationTopics = [
      'crypto-trading-guide',
      'forex-basics',
      'technical-analysis',
      'risk-management',
      'portfolio-management',
      'ai-trading-strategies',
      'market-analysis',
      'trading-psychology'
    ];

    educationTopics.forEach(topic => {
      const path = `/education/${topic}`;
      pages.push({
        url: `${this.baseUrl}${path}`,
        lastModified: currentDate,
        changeFrequency: 'weekly',
        priority: 0.6,
        alternateLanguages: this.createAlternateLanguages(path)
      });
    });

    // Community sections
    const communityPages = [
      'investment-ideas',
      'trading-competitions',
      'leaderboard',
      'live-chat',
      'social-trading'
    ];

    communityPages.forEach(section => {
      const path = `/community/${section}`;
      pages.push({
        url: `${this.baseUrl}${path}`,
        lastModified: currentDate,
        changeFrequency: 'daily',
        priority: 0.7,
        alternateLanguages: this.createAlternateLanguages(path)
      });
    });

    // News categories
    const newsCategories = [
      'crypto-news',
      'market-analysis',
      'regulatory-updates',
      'blockchain-technology',
      'defi-news',
      'altcoin-news',
      'bitcoin-news',
      'ethereum-news'
    ];

    newsCategories.forEach(category => {
      const path = `/news/${category}`;
      pages.push({
        url: `${this.baseUrl}${path}`,
        lastModified: currentDate,
        changeFrequency: 'hourly',
        priority: 0.6,
        alternateLanguages: this.createAlternateLanguages(path)
      });
    });

    // Important static pages
    const staticPages = [
      { path: '/about', priority: 0.5, changeFreq: 'monthly' as const },
      { path: '/contact', priority: 0.5, changeFreq: 'monthly' as const },
      { path: '/faq', priority: 0.6, changeFreq: 'weekly' as const },
      { path: '/privacy-policy', priority: 0.3, changeFreq: 'yearly' as const },
      { path: '/terms-of-service', priority: 0.3, changeFreq: 'yearly' as const },
      { path: '/referral-program', priority: 0.7, changeFreq: 'weekly' as const },
      { path: '/api-documentation', priority: 0.4, changeFreq: 'monthly' as const }
    ];

    staticPages.forEach(page => {
      pages.push({
        url: `${this.baseUrl}${page.path}`,
        lastModified: currentDate,
        changeFrequency: page.changeFreq,
        priority: page.priority,
        alternateLanguages: this.createAlternateLanguages(page.path)
      });
    });

    return pages;
  }

  generateXMLSitemap(): string {
    const pages = this.generateSitemapPages();
    
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
    xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"\n';
    xml += '        xmlns:xhtml="http://www.w3.org/1999/xhtml">\n';

    pages.forEach(page => {
      xml += '  <url>\n';
      xml += `    <loc>${page.url}</loc>\n`;
      xml += `    <lastmod>${page.lastModified}</lastmod>\n`;
      xml += `    <changefreq>${page.changeFrequency}</changefreq>\n`;
      xml += `    <priority>${page.priority}</priority>\n`;
      
      // Add alternate language links
      if (page.alternateLanguages) {
        page.alternateLanguages.forEach(alt => {
          xml += `    <xhtml:link rel="alternate" hreflang="${alt.lang}" href="${alt.url}" />\n`;
        });
      }
      
      xml += '  </url>\n';
    });

    xml += '</urlset>';
    return xml;
  }

  generateRobotsTxt(): string {
    const robotsTxt = `# Robots.txt for Invest-Free.com - Free Crypto Trading Platform

User-agent: *
Allow: /

# High-priority pages for crawling
Allow: /signals
Allow: /community
Allow: /education
Allow: /news

# Specific crawl directives for trading signals
Allow: /signals/crypto-signals
Allow: /signals/forex-signals
Allow: /signals/ai-signals
Allow: /signals/live-signals

# Block admin and private areas
Disallow: /admin/
Disallow: /api/private/
Disallow: /user/private/
Disallow: /_next/
Disallow: /.well-known/

# Block search and filter URLs
Disallow: /*?search=
Disallow: /*?filter=
Disallow: /*?sort=
Disallow: /*?page=

# Allow essential crawl paths
Allow: /api/public/
Allow: /images/
Allow: /assets/

# Sitemap location
Sitemap: ${this.baseUrl}/sitemap.xml

# Crawl delay (be nice to servers)
Crawl-delay: 1

# Specific rules for major search engines
User-agent: Googlebot
Allow: /
Crawl-delay: 0

User-agent: Bingbot
Allow: /
Crawl-delay: 1

User-agent: Slurp
Allow: /
Crawl-delay: 2

# Block known bad bots
User-agent: AhrefsBot
Disallow: /

User-agent: MJ12bot
Disallow: /

User-agent: DotBot
Disallow: /

# Social media crawlers
User-agent: facebookexternalhit
Allow: /

User-agent: Twitterbot
Allow: /

User-agent: LinkedInBot
Allow: /

# Additional information
# Website: https://invest-free.com
# Contact: admin@invest-free.com
# Last updated: ${new Date().toISOString().split('T')[0]}
`;

    return robotsTxt;
  }

  generateSitemapIndex(): string {
    const currentDate = this.formatDate(new Date());
    
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
    xml += '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
    
    // Main sitemap
    xml += '  <sitemap>\n';
    xml += `    <loc>${this.baseUrl}/sitemap.xml</loc>\n`;
    xml += `    <lastmod>${currentDate}</lastmod>\n`;
    xml += '  </sitemap>\n';
    
    // News sitemap (for Google News)
    xml += '  <sitemap>\n';
    xml += `    <loc>${this.baseUrl}/sitemap-news.xml</loc>\n`;
    xml += `    <lastmod>${currentDate}</lastmod>\n`;
    xml += '  </sitemap>\n';
    
    // Images sitemap
    xml += '  <sitemap>\n';
    xml += `    <loc>${this.baseUrl}/sitemap-images.xml</loc>\n`;
    xml += `    <lastmod>${currentDate}</lastmod>\n`;
    xml += '  </sitemap>\n';
    
    xml += '</sitemapindex>';
    return xml;
  }

  generateNewsSitemap(): string {
    const currentDate = new Date();
    const yesterday = new Date(currentDate.getTime() - 24 * 60 * 60 * 1000);
    
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
    xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"\n';
    xml += '        xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">\n';

    // Sample news articles (would be dynamic in real implementation)
    const newsArticles = [
      {
        url: '/news/bitcoin-reaches-new-highs-analysis',
        title: 'Bitcoin Reaches New Highs: Market Analysis and Trading Signals',
        publicationDate: currentDate,
        keywords: 'bitcoin, crypto signals, market analysis, trading'
      },
      {
        url: '/news/ai-trading-signals-accuracy-report',
        title: 'AI Trading Signals Show 95% Accuracy in Latest Report',
        publicationDate: yesterday,
        keywords: 'AI trading, signals accuracy, automated trading'
      }
    ];

    newsArticles.forEach(article => {
      xml += '  <url>\n';
      xml += `    <loc>${this.baseUrl}${article.url}</loc>\n`;
      xml += '    <news:news>\n';
      xml += '      <news:publication>\n';
      xml += '        <news:name>Invest-Free.com</news:name>\n';
      xml += '        <news:language>en</news:language>\n';
      xml += '      </news:publication>\n';
      xml += '      <news:publication_date>' + article.publicationDate.toISOString() + '</news:publication_date>\n';
      xml += `      <news:title><![CDATA[${article.title}]]></news:title>\n`;
      xml += `      <news:keywords>${article.keywords}</news:keywords>\n`;
      xml += '    </news:news>\n';
      xml += '  </url>\n';
    });

    xml += '</urlset>';
    return xml;
  }
}

// Utility function to generate and download sitemaps
export function generateAllSitemaps(): {
  mainSitemap: string;
  robotsTxt: string;
  sitemapIndex: string;
  newsSitemap: string;
} {
  const generator = new SitemapGenerator();
  
  return {
    mainSitemap: generator.generateXMLSitemap(),
    robotsTxt: generator.generateRobotsTxt(),
    sitemapIndex: generator.generateSitemapIndex(),
    newsSitemap: generator.generateNewsSitemap()
  };
}

// SEO URL structure helpers
export const seoUrls = {
  // Main pages
  home: '/',
  signals: '/signals',
  community: '/community', 
  news: '/news',
  education: '/education',
  
  // Signal categories
  cryptoSignals: '/signals/crypto-signals',
  forexSignals: '/signals/forex-signals',
  stockSignals: '/signals/stock-signals',
  aiSignals: '/signals/ai-signals',
  liveSignals: '/signals/live-signals',
  freeSignals: '/signals/free-signals',
  
  // Community sections
  investmentIdeas: '/community/investment-ideas',
  tradingCompetitions: '/community/trading-competitions',
  leaderboard: '/community/leaderboard',
  liveChat: '/community/live-chat',
  
  // Educational content
  tradingGuide: '/education/crypto-trading-guide',
  forexBasics: '/education/forex-basics',
  technicalAnalysis: '/education/technical-analysis',
  riskManagement: '/education/risk-management',
  
  // News categories
  cryptoNews: '/news/crypto-news',
  marketAnalysis: '/news/market-analysis',
  bitcoinNews: '/news/bitcoin-news',
  altcoinNews: '/news/altcoin-news',
  
  // Static pages
  about: '/about',
  contact: '/contact',
  faq: '/faq',
  privacy: '/privacy-policy',
  terms: '/terms-of-service',
  referral: '/referral-program'
};

export default SitemapGenerator;