import { marketDataService } from './marketDataService';
import { defaultStructuredData } from '../components/SEOHead';

export interface SEOData {
  title: string;
  description: string;
  keywords: string;
}

export function getSEOData(activeTab: string, marketData: any, translations: any): SEOData {
  const priceCount = Object.keys(marketData.prices).length;
  const freshData = marketDataService.isDataFresh();
  
  switch (activeTab) {
    case 'signals':
      return {
        title: `FREE AI Trading Signals | Live ${priceCount}+ Prices | Real-time Market Data - Invest-Free.com`,
        description: `🎯 Get FREE AI trading signals with real-time pricing for crypto, forex, stocks & commodities. ${priceCount}+ live prices updated ${freshData ? 'now' : 'recently'}. Registration required for premium access.`,
        keywords: "free AI trading signals, real-time prices, live market data, crypto signals, forex signals, stock signals, AI trading, automated trading, trading bot, investment signals"
      };
    case 'community':
      return {
        title: "Business Learning Hub | Market Analysis & Case Studies - Invest-Free.com",
        description: "💡 Educational business analyses and market studies to help you understand investment opportunities and business models.",
        keywords: "business learning, market analysis, case studies, business education, investment education, business models, market research, industry analysis"
      };
    case 'news':
      return {
        title: "Live Crypto & Market News | Real-time Updates | Trading News - Invest-Free.com",
        description: "📈 Stay updated with live crypto and market news. Real-time updates on cryptocurrency, forex, stocks, and commodities. Breaking news affects your trading decisions.",
        keywords: "crypto news, market news, trading news, cryptocurrency news, forex news, stock market news, financial news, investment news, real-time market updates"
      };
    case 'blog':
      return {
        title: "Trading Blog | Investment Tips & Strategies | Expert Insights - Invest-Free.com",
        description: "📚 Read expert trading and investment insights. Learn trading strategies, market analysis, investment tips, and financial education from our expert contributors.",
        keywords: "trading blog, investment blog, trading strategies, investment tips, market analysis, financial education, trading education, investment strategies"
      };
    default:
      return {
        title: `FREE AI Trading Signals | Live Market Data | ${priceCount}+ Real-time Prices - Invest-Free.com`,
        description: `🎁 Get FREE AI trading signals with live market data for crypto, forex, stocks & commodities. ${priceCount}+ real-time prices. Learn about business models and market opportunities.`,
        keywords: "free AI trading signals, live market data, real-time prices, crypto signals, business learning, market analysis, investment education"
      };
  }
}

export function getStructuredData(activeTab: string, marketData: any) {
  const baseData = { ...defaultStructuredData };
  
  switch (activeTab) {
    case 'signals':
      baseData['@graph'].push({
        "@type": "Article",
        "headline": "FREE AI Trading Signals - Real-time Market Analysis",
        "description": "Access free AI-powered trading signals for crypto, forex, stocks, and commodities with real-time pricing data.",
        "author": {
          "@type": "Organization",
          "name": "Invest-Free.com"
        },
        "publisher": {
          "@id": "https://invest-free.com/#organization"
        },
        "datePublished": new Date().toISOString(),
        "dateModified": new Date(marketData.lastUpdate).toISOString(),
        "mainEntityOfPage": "https://invest-free.com/signals"
      });
      break;
    case 'community':
      baseData['@graph'].push({
        "@type": "Article",
        "headline": "Business Learning Hub - Market Analysis & Case Studies",
        "description": "Educational business analyses and market studies to help you learn about investment opportunities.",
        "author": {
          "@type": "Organization",
          "name": "Invest-Free.com"
        },
        "publisher": {
          "@id": "https://invest-free.com/#organization"
        },
        "datePublished": new Date().toISOString(),
        "dateModified": new Date().toISOString(),
        "mainEntityOfPage": "https://invest-free.com/business-learning"
      });
      break;
    case 'blog':
      baseData['@graph'].push({
        "@type": "Blog",
        "name": "Investment & Trading Blog",
        "description": "Expert insights on trading, investing, and business opportunities.",
        "publisher": {
          "@id": "https://invest-free.com/#organization"
        },
        "mainEntityOfPage": "https://invest-free.com/blog"
      });
      break;
  }
  
  return baseData;
}

export function getCurrentUrl(activeTab: string): string {
  return `https://invest-free.com${activeTab !== 'signals' ? `/${activeTab}` : ''}`;
}

export const ALTERNATE_URLS = {
  'en': 'https://invest-free.com',
  'es': 'https://invest-free.com/es',
  'fr': 'https://invest-free.com/fr',
  'de': 'https://invest-free.com/de',
  'it': 'https://invest-free.com/it',
  'pt': 'https://invest-free.com/pt',
  'ru': 'https://invest-free.com/ru',
  'zh': 'https://invest-free.com/zh',
  'ja': 'https://invest-free.com/ja',
  'ko': 'https://invest-free.com/ko',
  'ar': 'https://invest-free.com/ar',
  'hi': 'https://invest-free.com/hi'
};